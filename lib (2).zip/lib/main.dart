import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:google_maps_flutter_android/google_maps_flutter_android.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/bloc/analytics_bloc/analytics_bloc.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/bloc/notification_history/notification_history_bloc.dart';

import 'app/router/router.dart';
import 'config/theme/theme.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'core/di/injection.dart';
import 'core/services/notifications/notification_service.dart';
import 'core/theme/theme_cubit.dart';

// Import Blocs for global usage
import 'features/auth/presentation/bloc/auth_bloc.dart';
import 'features/contractor/presentation/bloc/sites_bloc.dart';
import 'features/contractor/presentation/bloc/sprinkler_bloc.dart';
import 'features/admin/presentation/bloc/admin_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // SystemChrome.setEnabledSystemUIMode(
  //   SystemUiMode.edgeToEdge,
  // );

  // SystemChrome.setSystemUIOverlayStyle(
  //   const SystemUiOverlayStyle(
  //     statusBarColor: Colors.transparent,
  //     statusBarIconBrightness: Brightness.dark,
  //     systemNavigationBarColor: Colors.white,
  //     systemNavigationBarIconBrightness: Brightness.dark,
  //   ),
  // );

  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Initialize Maps platform configuration for Android to prevent rendering/loading issues
  final GoogleMapsFlutterPlatform mapsImplementation =
      GoogleMapsFlutterPlatform.instance;
  if (mapsImplementation is GoogleMapsFlutterAndroid) {
    // Force Hybrid Composition to resolve rendering crashes and black views on older devices (e.g. Android < 33)
    mapsImplementation.useAndroidViewSurface = true;
    try {
      await mapsImplementation
          .initializeWithRenderer(AndroidMapRenderer.latest);
    } on PlatformException catch (e) {
      if (e.code != 'Renderer already initialized') {
        debugPrint(
            "Failed to initialize Google Maps latest renderer, falling back: $e");
      }
    } catch (e) {
      debugPrint(
          "Failed to initialize Google Maps latest renderer, falling back: $e");
    }
  }
//http://192.168.1.18:9090/aqi-consumer/api/v1/device/customer/allocated_devices/8eac80cf-5d9a-475a-9adf-bd7c643b101f?page=0&size=20&role=Sub_User
  // Initialize Hive for offline support
  await Hive.initFlutter();
  await Hive.openBox('settings');
  await Hive.openBox('sites_cache');

  // Initialize Service Locator (GetIt)
  await configureDependencies();
  // Initialize Push Notifications
  await getIt<NotificationService>().initialize();

  runApp(const MahaAQIApp());
}

/// Root Application Widget.
/// Configures routing and registers global state blocs.
class MahaAQIApp extends StatelessWidget {
  const MahaAQIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ThemeCubit>.value(
          value: getIt<ThemeCubit>(),
        ),
        BlocProvider<AuthBloc>(
          create: (_) => getIt<AuthBloc>()..add(AuthCheckRequested()),
        ),
        BlocProvider<SitesBloc>(
          create: (_) => getIt<SitesBloc>()..add(LoadSites()),
        ),
        BlocProvider<SprinklerBloc>(
          create: (_) => getIt<SprinklerBloc>(),
        ),
        BlocProvider<AdminBloc>(
          create: (_) => getIt<AdminBloc>()..add(LoadAdminDashboard()),
        ),
        BlocProvider<AnalyticsBloc>(create: (_) => getIt<AnalyticsBloc>()),
        BlocProvider<NotificationHistoryBloc>(
            create: (_) => getIt<NotificationHistoryBloc>()),
      ],
      child: ScreenUtilInit(
        designSize: const Size(360, 690),
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (context, child) {
          return BlocListener<AuthBloc, AuthState>(
            listener: (context, state) {
              if (state is AuthAuthenticated) {
                // When logging in, reload data for the new user's role
                context.read<SitesBloc>().add(LoadSites());
                if (state.user.role == UserRole.admin ||
                    state.user.role == UserRole.subAdmin) {
                  context.read<AdminBloc>().add(LoadAdminDashboard());
                }
              } else if (state is AuthUnauthenticated) {
                // When logging out, reset caches and state of both data blocs
                context.read<SitesBloc>().add(ClearSitesCache());
                context.read<AdminBloc>().add(ClearAdminCache());
              }
            },
            child: BlocBuilder<ThemeCubit, ThemeMode>(
              builder: (context, themeMode) {
                return MaterialApp.router(
                  title: 'Maha AQI Platform',
                  debugShowCheckedModeBanner: false,
                  theme: AppTheme.lightTheme,
                  darkTheme: AppTheme.darkTheme,
                  themeMode: themeMode,
                  routerConfig: appRouter,
                );
              },
            ),
          );
        },
      ),
    );
  }
}
