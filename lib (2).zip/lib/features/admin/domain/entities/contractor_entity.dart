import 'package:equatable/equatable.dart';

class ContractorEntity extends Equatable {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String companyName;
  final int sitesCount;
  final bool isSuspended;

  const ContractorEntity({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.companyName,
    required this.sitesCount,
    this.isSuspended = false,
  });

  @override
  List<Object?> get props =>
      [id, name, email, phone, companyName, sitesCount, isSuspended];

  ContractorEntity copyWith({
    String? name,
    String? email,
    String? phone,
    String? companyName,
    int? sitesCount,
    bool? isSuspended,
  }) {
    return ContractorEntity(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      companyName: companyName ?? this.companyName,
      sitesCount: sitesCount ?? this.sitesCount,
      isSuspended: isSuspended ?? this.isSuspended,
    );
  }
}
