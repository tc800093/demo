import 'package:equatable/equatable.dart';

class DeviceEntity extends Equatable {
  final int srNo;
  final String deviceId;
  final String deviceCode;
  final String deviceName;
  final String imeiNo;
  final String simNo;
  final String firmwareVersion;
  final DateTime? installationDate;
  final DateTime? expiryDate;
  final bool active;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  // New site & device unified fields
  final String? customerId;
  final String? siteName;
  final String? projectName;
  final double? latitude;
  final double? longitude;
  final int? geofenceRadius;
  final String? address;
  final String? city;
  final String? district;
  final String? state;
  final String? remarks;
  final String? userName;
  final String? firmName;
  final String? mobileNo;
  final String? email;

  const DeviceEntity({
    required this.srNo,
    required this.deviceId,
    required this.deviceCode,
    required this.deviceName,
    required this.imeiNo,
    required this.simNo,
    required this.firmwareVersion,
    this.installationDate,
    this.expiryDate,
    required this.active,
    this.createdAt,
    this.updatedAt,
    this.customerId,
    this.siteName,
    this.projectName,
    this.latitude,
    this.longitude,
    this.geofenceRadius,
    this.address,
    this.city,
    this.district,
    this.state,
    this.remarks,
    this.userName,
    this.firmName,
    this.mobileNo,
    this.email,
  });

  @override
  List<Object?> get props => [
        srNo,
        deviceId,
        deviceCode,
        deviceName,
        imeiNo,
        simNo,
        firmwareVersion,
        installationDate,
        expiryDate,
        active,
        createdAt,
        updatedAt,
        customerId,
        siteName,
        projectName,
        latitude,
        longitude,
        geofenceRadius,
        address,
        city,
        district,
        state,
        remarks,
        userName,
        firmName,
        mobileNo,
        email,
      ];

  DeviceEntity copyWith({
    int? srNo,
    String? deviceId,
    String? deviceCode,
    String? deviceName,
    String? imeiNo,
    String? simNo,
    String? firmwareVersion,
    DateTime? installationDate,
    DateTime? expiryDate,
    bool? active,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? customerId,
    String? siteName,
    String? projectName,
    double? latitude,
    double? longitude,
    int? geofenceRadius,
    String? address,
    String? city,
    String? district,
    String? state,
    String? remarks,
    String? userName,
    String? firmName,
    String? mobileNo,
    String? email,
  }) {
    return DeviceEntity(
      srNo: srNo ?? this.srNo,
      deviceId: deviceId ?? this.deviceId,
      deviceCode: deviceCode ?? this.deviceCode,
      deviceName: deviceName ?? this.deviceName,
      imeiNo: imeiNo ?? this.imeiNo,
      simNo: simNo ?? this.simNo,
      firmwareVersion: firmwareVersion ?? this.firmwareVersion,
      installationDate: installationDate ?? this.installationDate,
      expiryDate: expiryDate ?? this.expiryDate,
      active: active ?? this.active,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      customerId: customerId ?? this.customerId,
      siteName: siteName ?? this.siteName,
      projectName: projectName ?? this.projectName,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      geofenceRadius: geofenceRadius ?? this.geofenceRadius,
      address: address ?? this.address,
      city: city ?? this.city,
      district: district ?? this.district,
      state: state ?? this.state,
      remarks: remarks ?? this.remarks,
      userName: userName ?? this.userName,
      firmName: firmName ?? this.firmName,
      mobileNo: mobileNo ?? this.mobileNo,
      email: email ?? this.email,
    );
  }
}
