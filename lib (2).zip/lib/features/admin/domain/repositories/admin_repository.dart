import '../entities/contractor_entity.dart';
import '../entities/device_entity.dart';

class PaginatedDevicesResponse {
  final List<DeviceEntity> devices;
  final int currentPage;
  final int pageSize;
  final int totalItems;
  final int totalPages;

  const PaginatedDevicesResponse({
    required this.devices,
    required this.currentPage,
    required this.pageSize,
    required this.totalItems,
    required this.totalPages,
  });
}

abstract class AdminRepository {
  Future<List<ContractorEntity>> getContractors();
  Future<void> suspendContractor(String contractorId, bool suspend);
  Future<void> addContractor(ContractorEntity contractor);
  
  /// Fetch a paginated and searched list of devices.
  Future<PaginatedDevicesResponse> getDevices({
    required int page,
    required int size,
    String? search,
  });

  /// Fetch a single device detail by its ID.
  Future<DeviceEntity> getDeviceDetail(String deviceId);

  /// Create a new device registry record.
  Future<void> createDevice(DeviceEntity device, {bool isDeviceReactivate = false});

  /// Update an existing device registry record.
  Future<void> updateDevice(DeviceEntity device);
}
