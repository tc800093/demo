import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import 'package:vasundhara_maha_aqim/core/utils/validator.dart';
import 'dart:async';
import '../../../../core/services/geocoding_service.dart';
import '../../../../config/theme/colors.dart';
import '../../../../config/theme/map_styles.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../bloc/admin_bloc.dart';
import '../../../customer/domain/repositories/customer_repository.dart';
import '../../../customer/domain/entities/customer_entity.dart';
import '../../../auth/domain/repositories/auth_repository.dart';
import '../../../../core/di/injection.dart';

class AddSiteWizard extends StatefulWidget {
  const AddSiteWizard({super.key});

  @override
  State<AddSiteWizard> createState() => _AddSiteWizardState();
}

class _AddSiteWizardState extends State<AddSiteWizard> {
  int _currentStep = 0;
  final int _totalSteps = 4;

  // Form keys
  final _step1Key = GlobalKey<FormState>();
  final _step2Key = GlobalKey<FormState>();
  final _step3Key = GlobalKey<FormState>();

  // Step 1: Device Configuration Controllers
  final _deviceCodeController = TextEditingController();
  final _deviceNameController = TextEditingController();
  final _imeiController = TextEditingController();
  final _simController = TextEditingController();
  final _firmwareController = TextEditingController(text: 'v1.0.0');
  DateTime _installationDate = DateTime.now();
  DateTime _expiryDate =
      DateTime.now().add(const Duration(days: 730)); // 2 years default
  final _remarksController = TextEditingController();
  DeviceEntity? _pendingDevice;

  // Step 2: Project Metadata Controllers
  final _nameController = TextEditingController(); // Site Name
  final _projectNameController = TextEditingController();
  final _geofenceRadiusController = TextEditingController(text: '500');
  List<CustomerEntity> _customers = [];
  bool _isLoadingCustomers = false;
  String? _selectedCustomerId;
  String _selectedCustomerName = '';

  // Step 3: Location Controllers
  final _addressController = TextEditingController();
  final _latController = TextEditingController(text: '18.5204');
  final _lngController = TextEditingController(text: '73.8567');
  final _cityController = TextEditingController();
  final _districtController = TextEditingController();
  final _stateController = TextEditingController();

  GoogleMapController? _mapController;
  late LatLng _cameraPosition;
  bool _isGeocoding = false;

  List<AddressSuggestion> _addressSuggestions = [];
  bool _isSearchingAddress = false;
  Timer? _addressDebounce;

  Future<void> _fetchCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    try {
      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;

      permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return;
      }

      if (permission == LocationPermission.deniedForever) return;

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      setState(() {
        _latController.text = position.latitude.toStringAsFixed(6);
        _lngController.text = position.longitude.toStringAsFixed(6);
        _cameraPosition = LatLng(position.latitude, position.longitude);
      });

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(target: _cameraPosition, zoom: 16.0),
          ),
        );
      }

      await _fetchAddressFromCoordinates(position.latitude, position.longitude);
    } catch (e) {
      debugPrint('Error fetching current location: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _cameraPosition = LatLng(
      double.tryParse(_latController.text) ?? 18.5204,
      double.tryParse(_lngController.text) ?? 73.8567,
    );
    _fetchCurrentLocation();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    setState(() {
      _isLoadingCustomers = true;
    });
    try {
      final repository = getIt<CustomerRepository>();
      final result = await repository.getCustomers(page: 0, size: 500);
      setState(() {
        _customers =
            result.where((c) => c.active && c.role == UserRole.user).toList();
        _isLoadingCustomers = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingCustomers = false;
      });
      debugPrint('Error loading customers for wizard: $e');
    }
  }

  @override
  void dispose() {
    _addressDebounce?.cancel();
    _deviceCodeController.dispose();
    _deviceNameController.dispose();
    _imeiController.dispose();
    _simController.dispose();
    _firmwareController.dispose();
    _remarksController.dispose();
    _nameController.dispose();
    _projectNameController.dispose();
    _geofenceRadiusController.dispose();
    _addressController.dispose();
    _latController.dispose();
    _lngController.dispose();
    _cityController.dispose();
    _districtController.dispose();
    _stateController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> _fetchAddressFromCoordinates(double lat, double lng) async {
    if (_isGeocoding) return;
    setState(() {
      _isGeocoding = true;
    });

    try {
      final response = await Dio().get(
        'https://nominatim.openstreetmap.org/reverse',
        queryParameters: {
          'format': 'json',
          'lat': lat,
          'lon': lng,
          'zoom': 18,
          'addressdetails': 1,
        },
        options: Options(
          headers: {
            'User-Agent': 'vasundhara_aqim_admin_app',
          },
        ),
      );

      if (response.statusCode == 200 && response.data != null) {
        final displayName = response.data['display_name'] as String?;
        if (displayName != null) {
          setState(() {
            // _addressController.text = displayName;
          });
        }
        final addr = response.data['address'] as Map<String, dynamic>?;
        if (addr != null) {
          final city = addr['city'] ??
              addr['town'] ??
              addr['village'] ??
              addr['municipality'] ??
              addr['suburb'] ??
              '';
          final district = addr['district'] ?? addr['county'] ?? '';
          final state = addr['state'] ?? '';
          setState(() {
            // _cityController.text = city.toString();
            // _districtController.text = district.toString();
            // _stateController.text = state.toString();
          });
        }
      }
    } catch (e) {
      debugPrint('Geocoding error: $e');
    } finally {
      setState(() {
        _isGeocoding = false;
      });
    }
  }

  /// old function for address which shows suggestions
  // void _onAddressChanged(String query) {
  //   if (_addressDebounce?.isActive ?? false) _addressDebounce!.cancel();
  //   _addressDebounce = Timer(const Duration(milliseconds: 600), () async {
  //     if (query.trim().isEmpty) {
  //       setState(() {
  //         _addressSuggestions = [];
  //       });
  //       return;
  //     }
  //     setState(() {
  //       _isSearchingAddress = true;
  //     });
  //     final suggestions = await GeocodingService.searchAddress(query);
  //     if (mounted) {
  //       setState(() {
  //         _addressSuggestions = suggestions;
  //         _isSearchingAddress = false;
  //       });
  //     }
  //   });
  // }

  void _onAddressChanged(String query) {
    if (_addressDebounce?.isActive ?? false) {
      _addressDebounce!.cancel();
    }

    _addressDebounce = Timer(
      const Duration(milliseconds: 600),
      () async {
        if (query.trim().isEmpty) {
          setState(() {
            _addressSuggestions = [];
          });
          return;
        }

        setState(() {
          _isSearchingAddress = true;
        });

        try {
          final addressSuggestion =
              await GeocodingService.getCoordinatesFromAddress(query);

          // final suggestions = await GeocodingService.searchAddress(query);

          if (addressSuggestion != null) {
            setState(() {
              // _addressController.text = query;
              _latController.text =
                  addressSuggestion.latitude.toStringAsFixed(6);
              _lngController.text =
                  addressSuggestion.longitude.toStringAsFixed(6);
              _cityController.text = addressSuggestion.city;
              _districtController.text = addressSuggestion.district;
              _stateController.text = addressSuggestion.state;

              final newLatLng = LatLng(
                  addressSuggestion.latitude, addressSuggestion.longitude);
              _cameraPosition = newLatLng;
              _mapController?.animateCamera(
                CameraUpdate.newLatLng(newLatLng),
              );
              _isSearchingAddress = false;
            });
          }
        } catch (e) {
          if (mounted) {
            setState(() {
              _addressSuggestions = [];
              _isSearchingAddress = false;
            });
          }

          debugPrint("Address search error: $e");
        }
      },
    );
  }

  void _onNext() {
    if (_currentStep == 0) {
      if (_step1Key.currentState?.validate() ?? false) {
        setState(() => _currentStep++);
      }
    } else if (_currentStep == 1) {
      if (_step2Key.currentState?.validate() ?? false) {
        setState(() => _currentStep++);
      }
    } else if (_currentStep == 2) {
      if (_step3Key.currentState?.validate() ?? false) {
        setState(() => _currentStep++);
      }
    } else if (_currentStep == 3) {
      _submitWizard();
    }
  }

  void _onBack() {
    if (_currentStep > 0) {
      setState(() => _currentStep--);
    } else {
      context.pop();
    }
  }

  void _submitWizard() {
    final lat = double.tryParse(_latController.text) ?? 18.5204;
    final lng = double.tryParse(_lngController.text) ?? 73.8567;
    final radius = int.tryParse(_geofenceRadiusController.text) ?? 500;

    final device = DeviceEntity(
      srNo: 0,
      deviceId: '',
      deviceCode: _deviceCodeController.text.trim(),
      deviceName: _deviceNameController.text.trim(),
      imeiNo: _imeiController.text.trim(),
      simNo: _simController.text.trim(),
      firmwareVersion: _firmwareController.text.trim(),
      installationDate: _installationDate,
      expiryDate: _expiryDate,
      active: true,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      customerId: _selectedCustomerId,
      siteName: _nameController.text.trim(),
      projectName: _projectNameController.text.trim(),
      latitude: lat,
      longitude: lng,
      geofenceRadius: radius,
      address: _addressController.text.trim(),
      city: _cityController.text.trim(),
      district: _districtController.text.trim(),
      state: _stateController.text.trim(),
      remarks: _remarksController.text.trim(),
    );

    _pendingDevice = device;

    context.read<AdminBloc>().add(AddDevice(device));
  }

  Future<void> _selectDate(BuildContext context, DateTime initial,
      Function(DateTime) onPicked) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() {
        onPicked(picked);
      });
    }
  }

  void _showDuplicateDeviceDialog(
      BuildContext context, DeviceDuplicateState state) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        if (state.isCurrentlyActive) {
          return AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.warning_amber_rounded, color: AppColors.aqiOrange),
                SizedBox(width: 8),
                Text('Device Already Active'),
              ],
            ),
            content: Text(state.message),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('OK'),
              ),
            ],
          );
        } else {
          return AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.help_outline_rounded, color: AppColors.primary),
                SizedBox(width: 8),
                Text('Reactivate Device?'),
              ],
            ),
            content: Text(state.message),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('No'),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.of(dialogContext).pop();
                  final deviceToReactivate = state.existingDevice.copyWith(
                    customerId:
                        _pendingDevice?.customerId ?? _selectedCustomerId,
                    siteName: _pendingDevice?.siteName,
                    projectName: _pendingDevice?.projectName,
                    latitude: _pendingDevice?.latitude,
                    longitude: _pendingDevice?.longitude,
                    geofenceRadius: _pendingDevice?.geofenceRadius,
                    address: _pendingDevice?.address,
                    city: _pendingDevice?.city,
                    district: _pendingDevice?.district,
                    state: _pendingDevice?.state,
                    remarks: _pendingDevice?.remarks,
                  );
                  context.read<AdminBloc>().add(
                        AddDevice(
                          deviceToReactivate,
                          isDeviceReactivate: true,
                        ),
                      );
                },
                child: const Text('Yes, Reactivate'),
              ),
            ],
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _currentStep == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _onBack();
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text(_currentStep == 0
              ? 'Configure Device'
              : _currentStep == 1
                  ? 'Project Details'
                  : _currentStep == 2
                      ? 'Location Details'
                      : 'Confirmation'),
          backgroundColor: Colors.white,
          foregroundColor: AppColors.textPrimary,
          iconTheme: IconThemeData(color: AppColors.textPrimary),
          titleTextStyle: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: _onBack,
          ),
        ),
        body: SafeArea(
          child: BlocConsumer<AdminBloc, AdminState>(
            listener: (context, state) {
              if (state is AdminActionSuccess) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Device registered successfully!'),
                    backgroundColor: AppColors.online,
                  ),
                );
                context.go(AppRoutes.adminDevices);
              } else if (state is AdminError) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(state.message),
                    backgroundColor: AppColors.aqiRed,
                  ),
                );
              } else if (state is DeviceDuplicateState) {
                _showDuplicateDeviceDialog(context, state);
              }
            },
            builder: (context, state) {
              final bool isLoading = state is AdminLoading;
              return Stack(
                children: [
                  Column(
                    children: [
                      _buildProgressBar(),
                      Expanded(
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.all(24.0),
                          child: _buildStepContent(),
                        ),
                      ),
                      _buildBottomActionBar(isLoading),
                    ],
                  ),
                  if (isLoading)
                    Container(
                      color: Colors.black.withValues(alpha: 0.3),
                      child: const Center(
                        child: CircularProgressIndicator(
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildProgressBar() {
    final percent = (_currentStep + 1) / _totalSteps;
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Step ${_currentStep + 1} of $_totalSteps',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textSecondary),
              ),
              Text(
                '${(percent * 100).toInt()}% Complete',
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: percent,
              backgroundColor: AppColors.border,
              valueColor:
                  const AlwaysStoppedAnimation<Color>(AppColors.primary),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildStep1DeviceDetails();
      case 1:
        return _buildStep2ProjectDetails();
      case 2:
        return _buildStep3LocationSelection();
      case 3:
        return _buildStep4Confirmation();
      default:
        return Container();
    }
  }

  Widget _buildBottomActionBar(bool isLoading) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Row(
        children: [
          if (_currentStep > 0) ...[
            Expanded(
              child: SecondaryButton(
                text: 'Back',
                onPressed: isLoading ? null : _onBack,
              ),
            ),
            const SizedBox(width: 16),
          ],
          Expanded(
            child: PrimaryButton(
              text: _currentStep == _totalSteps - 1 ? 'Register' : 'Next',
              onPressed: isLoading ? null : _onNext,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep1DeviceDetails() {
    final colors = AppColors.of(context);
    return Form(
      key: _step1Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('IoT Device Information',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: colors.textPrimary)),
          const SizedBox(height: 16),

          // _buildFieldLabel('Device Code'),
          // TextFormField(
          //   controller: _deviceCodeController,
          //   validator: (value) => (value == null || value.trim().isEmpty)
          //       ? 'Enter device code'
          //       : null,
          //   decoration: InputDecoration(
          //       hintText: 'e.g. AQI_DEV_004', fillColor: colors.surface),
          // ),
          // const SizedBox(height: 16),

          _buildFieldLabel('Device Name'),
          TextFormField(
            controller: _deviceNameController,
            validator: (value) => (value == null || value.trim().isEmpty)
                ? 'Enter device name'
                : null,
            decoration: InputDecoration(
                hintText: 'e.g. AQI_DECCAN_CORNER', fillColor: colors.surface),
          ),
          const SizedBox(height: 16),

          _buildFieldLabel('IMEI Number'),
          TextFormField(
            controller: _imeiController,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(15),
            ],
            // validator: (value) {
            //   if (value == null || value.trim().isEmpty) {
            //     return 'Enter IMEI number';
            //   }
            //   if (value.trim().length < 15) {
            //     return 'IMEI must be at least 15 digits';
            //   }
            //   return null;
            // },
            validator: (value) => Validator.validateImei(value),
            decoration: InputDecoration(
                hintText: 'e.g. 356789012345683', fillColor: colors.surface),
          ),
          const SizedBox(height: 16),

          _buildFieldLabel('SIM Number'),
          TextFormField(
            controller: _simController,
            keyboardType: TextInputType.phone,
            validator: (value) =>
                Validator.simNumber(value, 'Enter SIM number'),
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              // LengthLimitingTextInputFormatter(16),
            ],
            decoration: InputDecoration(
                hintText: 'e.g. 9876543214', fillColor: colors.surface),
          ),
          const SizedBox(height: 16),
          _buildFieldLabel('Firmware Version'),
          TextFormField(
            controller: _firmwareController,
            validator: (value) => Validator.validateFirmwareVersion(value),
            // validator: (value) => (value == null || value.trim().isEmpty)
            //     ? 'Enter firmware version'
            //     : null,
            decoration: InputDecoration(
                hintText: 'e.g. v1.0.2', fillColor: colors.surface),
          ),
          const SizedBox(height: 16),

          // Date Selectors
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('Installation Date'),
                    InkWell(
                      onTap: () => _selectDate(context, _installationDate,
                          (date) => _installationDate = date),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: colors.surface,
                          border: Border.all(color: colors.border),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${_installationDate.day}/${_installationDate.month}/${_installationDate.year}',
                              style: const TextStyle(fontSize: 14),
                            ),
                            Icon(Icons.calendar_today_rounded,
                                size: 16, color: colors.textSecondary),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('Expiry Date'),
                    InkWell(
                      onTap: () => _selectDate(
                          context, _expiryDate, (date) => _expiryDate = date),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: colors.surface,
                          border: Border.all(color: colors.border),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${_expiryDate.day}/${_expiryDate.month}/${_expiryDate.year}',
                              style: const TextStyle(fontSize: 14),
                            ),
                            Icon(Icons.calendar_today_rounded,
                                size: 16, color: colors.textSecondary),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          _buildFieldLabel('Remarks'),
          TextFormField(
            controller: _remarksController,
            maxLines: 2,
            decoration: InputDecoration(
                hintText: 'e.g. Device allocated at Deccan Corner site',
                fillColor: colors.surface),
          ),
        ],
      ),
    );
  }

  Widget _buildStep2ProjectDetails() {
    final colors = AppColors.of(context);
    return Form(
      key: _step2Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Project & Site Details',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: colors.textPrimary)),
          const SizedBox(height: 16),
          _buildFieldLabel('Assign Customer / Contractor'),
          _isLoadingCustomers
              ? const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Center(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                )
              : DropdownButtonFormField<String>(
                  isExpanded: true,
                  initialValue: _selectedCustomerId,
                  validator: (value) => (value == null || value.isEmpty)
                      ? 'Select a customer'
                      : null,
                  onChanged: (val) {
                    final selected =
                        _customers.firstWhere((c) => c.customerId == val);
                    setState(() {
                      _selectedCustomerId = val;
                      _selectedCustomerName = selected.fullName;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Select Customer',
                    fillColor: colors.surface,
                    prefixIcon: Icon(Icons.person_outline_rounded,
                        color: colors.textSecondary),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none),
                  ),
                  items: _customers
                      .map((c) => DropdownMenuItem(
                            value: c.customerId,
                            child: Text(
                              c.firmName != null && c.firmName!.isNotEmpty
                                  ? "${c.firmName}"
                                  : "",
                              style: const TextStyle(fontSize: 14),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ))
                      .toList(),
                ),
          const SizedBox(height: 16),
          _buildFieldLabel('Site Name'),
          TextFormField(
            controller: _nameController,
            validator: (value) => (value == null || value.trim().isEmpty)
                ? 'Enter site name'
                : null,
            decoration: InputDecoration(
                hintText: 'e.g. Deccan Monitoring Station',
                fillColor: colors.surface),
          ),
          const SizedBox(height: 16),
          _buildFieldLabel('Project Name (Work)'),
          TextFormField(
            controller: _projectNameController,
            validator: (value) => (value == null || value.trim().isEmpty)
                ? 'Enter project name'
                : null,
            decoration: InputDecoration(
                hintText: 'e.g. Pune Smart City AQI Project',
                fillColor: colors.surface),
          ),
          const SizedBox(height: 16),
          _buildFieldLabel('Geofence Radius (meters)'),
          TextFormField(
            controller: _geofenceRadiusController,
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Enter geofence radius';
              }
              if (int.tryParse(value.trim()) == null) {
                return 'Enter a valid number';
              }
              return null;
            },
            decoration: InputDecoration(
                hintText: 'e.g. 500', fillColor: colors.surface),
          ),
        ],
      ),
    );
  }

  Widget _buildStep3LocationSelection() {
    final colors = AppColors.of(context);
    final initialLat = double.tryParse(_latController.text) ?? 18.5204;
    final initialLng = double.tryParse(_lngController.text) ?? 73.8567;

    return Form(
      key: _step3Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Location & Address',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: colors.textPrimary)),
          const SizedBox(height: 6),
          Text(
            'Tap on the map or drag to select a location. Coordinates and address fields will auto-fill automatically.',
            style: TextStyle(fontSize: 12, color: colors.textSecondary),
          ),
          const SizedBox(height: 16),

          // Map — wrapped in a GestureDetector with HitTestBehavior.opaque
          // so the parent SingleChildScrollView does not steal vertical
          // drag gestures from the Google Map widget.
          Container(
            height: 300,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: colors.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: GestureDetector(
              // Block scroll-view from intercepting map pans
              onVerticalDragStart: (_) {},
              onVerticalDragUpdate: (_) {},
              child: Stack(
                children: [
                  GoogleMap(
                    style: Theme.of(context).brightness == Brightness.dark
                        ? MapStyles.dark
                        : MapStyles.silver,
                    initialCameraPosition: CameraPosition(
                      target: LatLng(initialLat, initialLng),
                      zoom: 15.0,
                    ),
                    onMapCreated: (GoogleMapController controller) {
                      _mapController = controller;
                      if (_cameraPosition.latitude != 18.5204 ||
                          _cameraPosition.longitude != 73.8567) {
                        _mapController!.animateCamera(
                          CameraUpdate.newCameraPosition(
                            CameraPosition(target: _cameraPosition, zoom: 16.0),
                          ),
                        );
                      }
                    },
                    onCameraMove: (position) {
                      _cameraPosition = position.target;
                    },
                    onCameraIdle: () {
                      setState(() {
                        _latController.text =
                            _cameraPosition.latitude.toStringAsFixed(6);
                        _lngController.text =
                            _cameraPosition.longitude.toStringAsFixed(6);
                      });
                      _fetchAddressFromCoordinates(
                          _cameraPosition.latitude, _cameraPosition.longitude);
                    },
                    onTap: (LatLng tappedPoint) {
                      setState(() {
                        _cameraPosition = tappedPoint;
                        _latController.text =
                            tappedPoint.latitude.toStringAsFixed(6);
                        _lngController.text =
                            tappedPoint.longitude.toStringAsFixed(6);
                      });
                      _mapController?.animateCamera(
                        CameraUpdate.newLatLng(tappedPoint),
                      );
                      _fetchAddressFromCoordinates(
                          tappedPoint.latitude, tappedPoint.longitude);
                    },
                    zoomControlsEnabled: false,
                    scrollGesturesEnabled: true,
                    zoomGesturesEnabled: true,
                    rotateGesturesEnabled: false,
                    tiltGesturesEnabled: false,
                    mapToolbarEnabled: false,
                    myLocationEnabled: false,
                    myLocationButtonEnabled: false,
                  ),
                  // Center pin marker
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 40.0),
                      child: Icon(
                        Icons.location_on_rounded,
                        size: 44,
                        color: AppColors.aqiRed,
                        shadows: [
                          Shadow(
                            color: Colors.black.withValues(alpha: 0.25),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Zoom In / Zoom Out buttons
                  Positioned(
                    top: 12,
                    right: 12,
                    child: Column(
                      children: [
                        _buildMapZoomButton(Icons.add_rounded, () {
                          _mapController?.animateCamera(CameraUpdate.zoomIn());
                        }),
                        const SizedBox(height: 6),
                        _buildMapZoomButton(Icons.remove_rounded, () {
                          _mapController?.animateCamera(CameraUpdate.zoomOut());
                        }),
                      ],
                    ),
                  ),
                  // My location button
                  Positioned(
                    bottom: 12,
                    right: 12,
                    child: FloatingActionButton.small(
                      heroTag: 'detect_location_wizard_btn',
                      onPressed: _fetchCurrentLocation,
                      backgroundColor: colors.surface,
                      foregroundColor: AppColors.primary,
                      child: const Icon(Icons.my_location_rounded, size: 20),
                    ),
                  ),
                  if (_isGeocoding)
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: colors.surface,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.08),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(
                              width: 12,
                              height: 12,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: AppColors.primary,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Updating address...',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: colors.textSecondary,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          _buildFieldLabel('Site Address'),
          _buildAddressSearchField(),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('Latitude'),
                    TextFormField(
                      controller: _latController,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'Required'
                              : null,
                      decoration: InputDecoration(fillColor: colors.surface),
                      onChanged: (val) {
                        final lat = double.tryParse(val);
                        final lng = double.tryParse(_lngController.text);
                        if (lat != null &&
                            lng != null &&
                            _mapController != null) {
                          _mapController!.animateCamera(
                              CameraUpdate.newLatLng(LatLng(lat, lng)));
                        }
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('Longitude'),
                    TextFormField(
                      controller: _lngController,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'Required'
                              : null,
                      decoration: InputDecoration(fillColor: colors.surface),
                      onChanged: (val) {
                        final lat = double.tryParse(_latController.text);
                        final lng = double.tryParse(val);
                        if (lat != null &&
                            lng != null &&
                            _mapController != null) {
                          _mapController!.animateCamera(
                              CameraUpdate.newLatLng(LatLng(lat, lng)));
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // City, District, State Fields
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('City'),
                    TextFormField(
                      controller: _cityController,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'City required'
                              : null,
                      decoration: InputDecoration(
                          hintText: 'Pune', fillColor: colors.surface),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('District'),
                    TextFormField(
                      controller: _districtController,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'District required'
                              : null,
                      decoration: InputDecoration(
                          hintText: 'Pune', fillColor: colors.surface),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFieldLabel('State'),
                    TextFormField(
                      controller: _stateController,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'State required'
                              : null,
                      decoration: InputDecoration(
                          hintText: 'Maharashtra', fillColor: colors.surface),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStep4Confirmation() {
    final colors = AppColors.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Confirm Module Details',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: colors.textPrimary)),
        const SizedBox(height: 16),
        ScadaCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionHeader('Device Specifications'),
              // _buildConfirmRow('Device Code', _deviceCodeController.text),
              _buildConfirmRow('Device Name', _deviceNameController.text),
              _buildConfirmRow('IMEI Number', _imeiController.text),
              _buildConfirmRow('SIM Number', _simController.text),
              _buildConfirmRow('Firmware Version', _firmwareController.text),
              _buildConfirmRow(
                  'Remarks',
                  _remarksController.text.isEmpty
                      ? '-'
                      : _remarksController.text),
              Divider(height: 32, color: colors.border),
              _buildSectionHeader('Project & Site Details'),
              _buildConfirmRow('Contractor / Customer', _selectedCustomerName),
              _buildConfirmRow('Site Name', _nameController.text),
              _buildConfirmRow('Project Name', _projectNameController.text),
              _buildConfirmRow('Geofence Radius',
                  '${_geofenceRadiusController.text} meters'),
              Divider(height: 32, color: colors.border),
              _buildSectionHeader('Location Metadata'),
              _buildConfirmRow('Address', _addressController.text),
              _buildConfirmRow('Coordinates',
                  'Lat ${_latController.text}, Lng ${_lngController.text}'),
              _buildConfirmRow('City / District / State',
                  '${_cityController.text} / ${_districtController.text} / ${_stateController.text}'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: AppColors.primary,
        ),
      ),
    );
  }

  Widget _buildConfirmRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(label,
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.of(context).textSecondary,
                    fontWeight: FontWeight.w600)),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(
                    fontSize: 13,
                    color: AppColors.of(context).textPrimary,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildAddressSearchField() {
    final colors = AppColors.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: _addressController,
          maxLines: 2,
          onChanged: (val) {
            _onAddressChanged(val);
          },
          validator: (value) => (value == null || value.trim().isEmpty)
              ? 'Enter or select site address'
              : null,
          decoration: InputDecoration(
            hintText: 'e.g. Hinjawadi Phase 1, Pune, MH',
            fillColor: colors.surface,
            suffixIcon: _isSearchingAddress
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppColors.primary,
                      ),
                    ),
                  )
                : null,
          ),
        ),
        // if (_addressSuggestions.isNotEmpty) ...[
        //   const SizedBox(height: 6),
        //   Container(
        //     decoration: BoxDecoration(
        //       color: colors.surface,
        //       borderRadius: BorderRadius.circular(12),
        //       border: Border.all(color: colors.border),
        //       boxShadow: [
        //         BoxShadow(
        //           color: Colors.black.withValues(alpha: 0.05),
        //           blurRadius: 4,
        //           offset: const Offset(0, 2),
        //         ),
        //       ],
        //     ),
        //     constraints: const BoxConstraints(maxHeight: 180),
        //     child: ListView.separated(
        //       shrinkWrap: true,
        //       padding: EdgeInsets.zero,
        //       itemCount: _addressSuggestions.length,
        //       separatorBuilder: (context, index) =>
        //           Divider(height: 1, color: colors.border),
        //       itemBuilder: (context, index) {
        //         final suggestion = _addressSuggestions[index];
        //         return ListTile(
        //           dense: true,
        //           contentPadding:
        //               const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        //           title: Text(
        //             suggestion.displayName,
        //             style: TextStyle(fontSize: 13, color: colors.textPrimary),
        //           ),
        //           onTap: () {
        //             setState(() {
        //               // _addressController.text = suggestion.displayName;
        //               _latController.text =
        //                   suggestion.latitude.toStringAsFixed(6);
        //               _lngController.text =
        //                   suggestion.longitude.toStringAsFixed(6);
        //               _cityController.text = suggestion.city;
        //               _districtController.text = suggestion.district;
        //               _stateController.text = suggestion.state;

        //               final newLatLng =
        //                   LatLng(suggestion.latitude, suggestion.longitude);
        //               _cameraPosition = newLatLng;
        //               _mapController?.animateCamera(
        //                 CameraUpdate.newLatLng(newLatLng),
        //               );
        //               _addressSuggestions = [];
        //             });
        //           },
        //         );
        //       },
        //     ),
        //   ),
        // ],
      ],
    );
  }

  Widget _buildFieldLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(label,
          style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.of(context).textPrimary)),
    );
  }

  Widget _buildMapZoomButton(IconData icon, VoidCallback onPressed) {
    return Material(
      color: AppColors.of(context).surface,
      borderRadius: BorderRadius.circular(8),
      elevation: 2,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(
          width: 36,
          height: 36,
          child: Icon(icon, size: 20, color: AppColors.of(context).textPrimary),
        ),
      ),
    );
  }
}
