import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';

class CompliancePage extends StatelessWidget {
  const CompliancePage({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('Compliance & Violations'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Environmental Compliance Overview', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: colors.textPrimary)),
              SizedBox(height: 4.h),
              Text('Summary of threshold compliance violations across all active devices.', style: TextStyle(fontSize: 13.sp, color: colors.textSecondary)),
              
              SizedBox(height: 14.h),
              
              // Exceedance stats grid
              _buildStatsGrid(),
              
              SizedBox(height: 16.h),
              
              Text('Critical Devices (AQI > 200)', style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
              SizedBox(height: 8.h),
              _buildCriticalSitesList(context),
              
              SizedBox(height: 14.h),
              
              Text('Offline Hardware Nodes', style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
              SizedBox(height: 8.h),
              _buildOfflineDevicesList(),
              
              SizedBox(height: 20.h),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsGrid() {
    final list = [
      {'title': 'AQI Exceeded', 'count': '24 Devices', 'color': AppColors.aqiRed},
      {'title': 'PM2.5 Exceeded', 'count': '18 Devices', 'color': AppColors.aqiOrange},
      {'title': 'PM10 Exceeded', 'count': '22 Devices', 'color': AppColors.aqiYellow},
      {'title': 'Offline Devices', 'count': '26 Nodes', 'color': AppColors.offline},
      {'title': 'Sprinkler Runs', 'count': '18 Today', 'color': AppColors.online},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: list.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.6,
        crossAxisSpacing: 8.w,
        mainAxisSpacing: 8.h,
      ),
      itemBuilder: (context, index) {
        final item = list[index];
        return ScadaCard(
          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
          child: Row(
            children: [
              Container(
                width: 4.w,
                height: 28.h,
                decoration: BoxDecoration(color: item['color'] as Color, borderRadius: BorderRadius.circular(2.r)),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(item['title'] as String, style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                    ),
                    SizedBox(height: 2.h),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(item['count'] as String, style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCriticalSitesList(BuildContext context) {
    final list = [
      {'name': 'Device AQI_DEV_001', 'aqi': '319', 'status': 'VERY POOR', 'contractor': 'BuildWell Pvt. Ltd.'},
      {'name': 'Device AQI_DEV_005', 'aqi': '245', 'status': 'POOR (OFFLINE)', 'contractor': 'Urban Builders'},
    ];

    return Column(
      children: list.map((item) {
        final aqiVal = int.tryParse(item['aqi']!) ?? 0;
        final color = AppColors.getAqiColor(aqiVal);
        return Container(
          margin: EdgeInsets.only(bottom: 10.h),
          padding: EdgeInsets.all(14.r),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['name']!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.sp, color: AppColors.textPrimary)),
                    Text('Contractor: ${item['contractor']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6.r)),
                child: Text(
                  'AQI ${item['aqi']}',
                  style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold, color: color),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildOfflineDevicesList() {
    final list = [
      {'serial': 'AQI-HWY-0987654321', 'site': 'Site E - Project X', 'lastSeen': '24 hours ago'},
      {'serial': 'AQI-MIN-4827164920', 'site': 'Highway Mining Grid', 'lastSeen': '2 days ago'},
    ];

    return Column(
      children: list.map((item) {
        return Container(
          margin: EdgeInsets.only(bottom: 10.h),
          padding: EdgeInsets.all(14.r),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['serial']!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.sp, color: AppColors.textPrimary)),
                    Text('Site: ${item['site']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Text(
                'Last seen: ${item['lastSeen']}',
                style: TextStyle(fontSize: 11.sp, color: AppColors.textMuted),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
