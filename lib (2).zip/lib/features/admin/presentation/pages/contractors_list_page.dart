import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../bloc/admin_bloc.dart';

class ContractorsListPage extends StatefulWidget {
  const ContractorsListPage({super.key});

  @override
  State<ContractorsListPage> createState() => _ContractorsListPageState();
}

class _ContractorsListPageState extends State<ContractorsListPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _filter = 'All'; // 'All', 'Active', 'Suspended'

  @override
  void initState() {
    super.initState();
    context.read<AdminBloc>().add(LoadContractors());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('All Contractors'),
        actions: [
          BlocBuilder<AdminBloc, AdminState>(
            builder: (context, state) {
              if (state is ContractorsLoaded) {
                return Padding(
                  padding: EdgeInsets.only(right: 16.w),
                  child: Center(
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12.r),
                        border: Border.all(
                          color: AppColors.primary.withValues(alpha: 0.2),
                          width: 1.r,
                        ),
                      ),
                      child: Text(
                        'Total: ${state.contractors.length}',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search Input Row
            Container(
              color: colors.surface,
              padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 8.h),
              child: TextFormField(
                controller: _searchController,
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.toLowerCase();
                  });
                },
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textPrimary,
                ),
                decoration: InputDecoration(
                  hintText: 'Search contractors or companies...',
                  hintStyle: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 13.sp,
                  ),
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    color: AppColors.textSecondary,
                    size: 20.r,
                  ),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                          icon: Icon(
                            Icons.cancel_rounded,
                            color: AppColors.textMuted,
                            size: 18.r,
                          ),
                          onPressed: () {
                            _searchController.clear();
                            setState(() {
                              _searchQuery = '';
                            });
                          },
                        )
                      : null,
                  fillColor: colors.background,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r),
                    borderSide: BorderSide(color: colors.border, width: 1.r),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r),
                    borderSide: BorderSide(color: AppColors.border, width: 1.r),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r),
                    borderSide:
                        BorderSide(color: AppColors.primary, width: 1.5.r),
                  ),
                ),
              ),
            ),

            // Segmented Chips
            Container(
              height: 48.h,
              padding: EdgeInsets.only(bottom: 8.h),
              decoration: BoxDecoration(
                color: colors.surface,
                border: Border(
                  bottom: BorderSide(
                    color: colors.border.withValues(alpha: 0.5),
                    width: 1.h,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: ['All', 'Active', 'Suspended'].map((filterName) {
                  final isSelected = _filter == filterName;
                  Color chipBgColor = colors.background;
                  Color labelColor = colors.textSecondary;

                  if (isSelected) {
                    if (filterName == 'Active') {
                      chipBgColor = AppColors.online.withValues(alpha: 0.1);
                      labelColor = AppColors.online;
                    } else if (filterName == 'Suspended') {
                      chipBgColor = AppColors.aqiRed.withValues(alpha: 0.1);
                      labelColor = AppColors.aqiRed;
                    } else {
                      chipBgColor = AppColors.primaryLight;
                      labelColor = AppColors.primary;
                    }
                  }

                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: ChoiceChip(
                      label: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (filterName == 'Active') ...[
                            Container(
                              width: 6.r,
                              height: 6.r,
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppColors.online
                                    : colors.textMuted,
                                shape: BoxShape.circle,
                              ),
                            ),
                            SizedBox(width: 6.w),
                          ] else if (filterName == 'Suspended') ...[
                            Container(
                              width: 6.r,
                              height: 6.r,
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppColors.aqiRed
                                    : colors.textMuted,
                                shape: BoxShape.circle,
                              ),
                            ),
                            SizedBox(width: 6.w),
                          ],
                          Text(filterName),
                        ],
                      ),
                      selected: isSelected,
                      labelStyle: TextStyle(
                        fontSize: 12.sp,
                        color: labelColor,
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                      selectedColor: chipBgColor,
                      backgroundColor: colors.background,
                      side: BorderSide(
                        color: isSelected
                            ? labelColor.withValues(alpha: 0.3)
                            : Colors.transparent,
                        width: 1.r,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.r),
                      ),
                      onSelected: (val) {
                        if (val) setState(() => _filter = filterName);
                      },
                    ),
                  );
                }).toList(),
              ),
            ),

            // Contractors List
            Expanded(
              child: BlocBuilder<AdminBloc, AdminState>(
                builder: (context, state) {
                  if (state is AdminLoading) {
                    return const Center(
                        child: CircularProgressIndicator(
                            color: AppColors.primary));
                  }
                  if (state is ContractorsLoaded) {
                    final filteredList = state.contractors.where((c) {
                      final matchesSearch = c.name
                              .toLowerCase()
                              .contains(_searchQuery) ||
                          c.companyName.toLowerCase().contains(_searchQuery);

                      if (!matchesSearch) return false;

                      if (_filter == 'Active') return !c.isSuspended;
                      if (_filter == 'Suspended') return c.isSuspended;
                      return true;
                    }).toList();

                    if (filteredList.isEmpty) {
                      return Center(
                        child: Text('No contractors found.',
                            style: TextStyle(
                                color: AppColors.textSecondary,
                                fontSize: 14.sp)),
                      );
                    }

                    return ListView.builder(
                      padding: EdgeInsets.all(16.r),
                      itemCount: filteredList.length,
                      itemBuilder: (context, index) {
                        final contractor = filteredList[index];
                        return _buildContractorCard(context, contractor);
                      },
                    );
                  }
                  return const Center(
                      child: Text('Failed to load contractors'));
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddContractorBottomSheet(context),
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: const Text('Add Contractor',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  void _showAddContractorBottomSheet(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();
    final companyController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24.r),
                topRight: Radius.circular(24.r),
              ),
            ),
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40.w,
                        height: 4.h,
                        margin: EdgeInsets.only(bottom: 16.h),
                        decoration: BoxDecoration(
                          color: AppColors.border,
                          borderRadius: BorderRadius.circular(2.r),
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Add New Contractor',
                          style: TextStyle(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.close_rounded,
                              size: 22.r, color: AppColors.textSecondary),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    SizedBox(height: 16.h),
                    _buildFormField(
                      controller: companyController,
                      label: 'Company Name',
                      hint: 'e.g. Apex Infrastructures',
                      icon: Icons.business_rounded,
                      validator: (val) => val == null || val.trim().isEmpty
                          ? 'Company name is required'
                          : null,
                    ),
                    SizedBox(height: 12.h),
                    _buildFormField(
                      controller: nameController,
                      label: 'Contractor Contact Name',
                      hint: 'e.g. John Doe',
                      icon: Icons.person_rounded,
                      validator: (val) => val == null || val.trim().isEmpty
                          ? 'Contact name is required'
                          : null,
                    ),
                    SizedBox(height: 12.h),
                    _buildFormField(
                      controller: phoneController,
                      label: 'Phone Number',
                      hint: 'e.g. +91 98765 43210',
                      icon: Icons.phone_rounded,
                      keyboardType: TextInputType.phone,
                      validator: (val) {
                        if (val == null || val.trim().isEmpty) {
                          return 'Phone number is required';
                        }
                        if (val.trim().length < 10) {
                          return 'Enter a valid phone number';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 12.h),
                    _buildFormField(
                      controller: emailController,
                      label: 'Email Address',
                      hint: 'e.g. contact@company.com',
                      icon: Icons.email_rounded,
                      keyboardType: TextInputType.emailAddress,
                      validator: (val) {
                        if (val == null || val.trim().isEmpty) {
                          return 'Email is required';
                        }
                        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                            .hasMatch(val.trim())) {
                          return 'Enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 24.h),
                    PrimaryButton(
                      text: 'Register Contractor',
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          final contractor = ContractorEntity(
                            id: 'c_${DateTime.now().millisecondsSinceEpoch}',
                            name: nameController.text.trim(),
                            email: emailController.text.trim(),
                            phone: phoneController.text.trim(),
                            companyName: companyController.text.trim(),
                            sitesCount: 0,
                          );
                          context
                              .read<AdminBloc>()
                              .add(AddContractor(contractor));
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  '${contractor.companyName} Registered Successfully'),
                              backgroundColor: AppColors.online,
                            ),
                          );
                        }
                      },
                    ),
                    SizedBox(height: 12.h),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFormField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12.sp,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        SizedBox(height: 6.h),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          validator: validator,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: AppColors.textPrimary,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: AppColors.textMuted,
              fontSize: 13.sp,
            ),
            prefixIcon: Icon(icon, color: AppColors.textSecondary, size: 18.r),
            fillColor: AppColors.background,
            filled: true,
            contentPadding:
                EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.w),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.r),
              borderSide: BorderSide.none,
            ),
            errorStyle: TextStyle(
              fontSize: 11.sp,
              color: AppColors.aqiRed,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContractorCard(
      BuildContext context, ContractorEntity contractor) {
    final statusColor =
        contractor.isSuspended ? AppColors.aqiRed : AppColors.online;
    final initials = contractor.companyName.isNotEmpty
        ? contractor.companyName[0].toUpperCase()
        : 'C';

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      child: GestureDetector(
        onTap: () => context.push('/admin/contractors/${contractor.id}'),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16.r),
            border: Border.all(color: AppColors.border.withValues(alpha: 0.8)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 10,
                offset: const Offset(0, 4),
              )
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16.r),
            child: Row(
              children: [
                Container(
                  width: 4.w,
                  height: 90.h,
                  color: statusColor,
                ),
                SizedBox(width: 12.w),
                Container(
                  width: 40.r,
                  height: 40.r,
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.08),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      initials,
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: statusColor,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          contractor.companyName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15.sp,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'Contact: ${contractor.name}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12.sp,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        SizedBox(height: 6.h),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 6.w, vertical: 2.h),
                          decoration: BoxDecoration(
                            color:
                                AppColors.primaryLight.withValues(alpha: 0.5),
                            borderRadius: BorderRadius.circular(6.r),
                          ),
                          child: Text(
                            '${contractor.sitesCount} Associated Sites',
                            style: TextStyle(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 8.w),
                Padding(
                  padding: EdgeInsets.only(right: 12.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AqiStatusChip(
                        label: contractor.isSuspended ? 'Suspended' : 'Active',
                        color: statusColor,
                      ),
                      SizedBox(height: 12.h),
                      Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 14.r,
                        color: AppColors.textMuted,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
