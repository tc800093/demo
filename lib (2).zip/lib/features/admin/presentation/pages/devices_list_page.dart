// features/admin/presentation/pages/devices_list_page.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:vasundhara_maha_aqim/core/utils/validator.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../../app/router/router.dart';
import '../../../customer/domain/repositories/customer_repository.dart';
import '../../../customer/domain/entities/customer_entity.dart';
import '../../../../core/di/injection.dart';
import '../bloc/admin_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:dio/dio.dart';
import '../../../../config/theme/map_styles.dart';
import '../../../auth/domain/repositories/auth_repository.dart';

class DevicesListPage extends StatefulWidget {
  final String? initialFilter;
  final String? initialSearch;

  const DevicesListPage({super.key, this.initialFilter, this.initialSearch});

  @override
  State<DevicesListPage> createState() => _DevicesListPageState();
}

class _DevicesListPageState extends State<DevicesListPage> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  int _currentPage = 0;
  final int _pageSize = 10; // Load 10 items per page for infinite scroll
  String _searchQuery = '';
  String _statusFilter = 'All'; // 'All', 'Online', 'Offline'
  Timer? _debounceTimer;

  // Cache list and pagination counts to manage appending states smoothly
  List<DeviceEntity> _cachedDevices = [];
  int _cachedTotalPages = 1;
  int? _totalDevices;

  final Set<String> _expandedDeviceIds = {};

  @override
  void initState() {
    super.initState();
    if (widget.initialFilter != null) {
      // Map 'Offline' and 'Online' values to filters
      _statusFilter = widget.initialFilter!;
    }
    if (widget.initialSearch != null && widget.initialSearch!.isNotEmpty) {
      _searchQuery = widget.initialSearch!;
      _searchController.text = widget.initialSearch!;
    }
    _scrollController.addListener(_onScroll);
    _fetchDevices();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _debounceTimer?.cancel();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      final state = context.read<AdminBloc>().state;
      if (state is! AdminLoading && _currentPage < _cachedTotalPages - 1) {
        setState(() {
          _currentPage++;
        });
        _fetchDevices(isLoadMore: true);
      }
    }
  }

  void _fetchDevices({bool isLoadMore = false}) {
    if (!isLoadMore) {
      setState(() {
        _currentPage = 0;
      });
    }
    context.read<AdminBloc>().add(
          LoadDevices(
            page: _currentPage,
            size: _pageSize,
            search: _searchQuery.isEmpty ? null : _searchQuery,
          ),
        );
  }

  void _onSearchChanged(String value) {
    if (_debounceTimer?.isActive ?? false) _debounceTimer!.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _searchQuery = value.trim();
        });
        _fetchDevices();
      }
    });
  }

  // Get the fully searched and filtered list of devices
  List<DeviceEntity> get _filteredDevices {
    return _cachedDevices.where((device) {
      // 1. Search Query Filter
      if (_searchQuery.isNotEmpty) {
        final query = _searchQuery.toLowerCase();
        final matchCode = device.deviceCode.toLowerCase().contains(query);
        final matchName = device.deviceName.toLowerCase().contains(query);
        final matchImei = device.imeiNo.toLowerCase().contains(query);
        final matchSim = device.simNo.toLowerCase().contains(query);
        if (!matchCode && !matchName && !matchImei && !matchSim) {
          return false;
        }
      }

      // 2. Status Filter
      if (_statusFilter == 'Online') return device.active;
      if (_statusFilter == 'Offline') return !device.active;

      return true;
    }).toList();
  }

  void _showDeviceDetails(String deviceId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return BlocProvider.value(
          value: context.read<AdminBloc>(),
          child: _DeviceDetailBottomSheet(deviceId: deviceId),
        );
      },
    ).then((_) {
      // Refresh registry list upon closing the detail sheet (captures updates)
      _fetchDevices();
    });
  }

  void _showAddDevice() {
    context.push(AppRoutes.adminAddSite).then((_) {
      // Refresh list to show the newly created device
      _fetchDevices();
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('All Registered Devices'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        actions: [
          BlocBuilder<AdminBloc, AdminState>(
            builder: (context, state) {
              final count =
                  state is DevicesLoaded ? state.totalItems : _totalDevices;
              if (count != null) {
                return Padding(
                  padding: EdgeInsets.only(right: 16.w),
                  child: Center(
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12.r),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.3),
                          width: 1.r,
                        ),
                      ),
                      child: Text(
                        'Total: $count',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: BlocConsumer<AdminBloc, AdminState>(
          listener: (context, state) {
            if (state is AdminActionSuccess) {
              _fetchDevices();
            } else if (state is DevicesLoaded) {
              setState(() {
                _totalDevices = state.totalItems;
              });
            }
          },
          builder: (context, state) {
            final bool isLoading = state is AdminLoading;

            if (state is DevicesLoaded) {
              if (state.currentPage == 0) {
                _cachedDevices = List.from(state.devices);
              } else {
                // Append and prevent duplicates
                final existingIds =
                    _cachedDevices.map((d) => d.deviceId).toSet();
                final newUnique = state.devices
                    .where((d) => !existingIds.contains(d.deviceId));
                _cachedDevices.addAll(newUnique);
              }
              _cachedTotalPages = state.totalPages;
            }

            final filteredList = _filteredDevices;

            // Auto-prefetch next page if status filter is active, screen is not filled, and more pages exist
            if (_statusFilter != 'All' &&
                filteredList.length < _pageSize &&
                _currentPage < _cachedTotalPages - 1 &&
                !isLoading) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                setState(() {
                  _currentPage++;
                });
                _fetchDevices(isLoadMore: true);
              });
            }

            return Column(
              children: [
                // Search Input Header
                Container(
                  color: colors.surface,
                  padding: EdgeInsets.fromLTRB(12.w, 8.h, 12.w, 4.h),
                  child: TextFormField(
                    controller: _searchController,
                    onChanged: _onSearchChanged,
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: colors.textPrimary,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Search by code, name, imei, or sim...',
                      hintStyle: TextStyle(
                        color: colors.textMuted,
                        fontSize: 13.sp,
                      ),
                      prefixIcon: Icon(
                        Icons.search_rounded,
                        color: colors.textSecondary,
                        size: 20.r,
                      ),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: Icon(
                                Icons.cancel_rounded,
                                color: colors.textMuted,
                                size: 18.r,
                              ),
                              onPressed: () {
                                _searchController.clear();
                                _onSearchChanged('');
                                setState(() {});
                              },
                            )
                          : null,
                      fillColor: colors.background,
                      filled: true,
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r),
                        borderSide:
                            BorderSide(color: colors.border, width: 1.r),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r),
                        borderSide:
                            BorderSide(color: colors.border, width: 1.r),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r),
                        borderSide:
                            BorderSide(color: AppColors.primary, width: 1.5.r),
                      ),
                    ),
                  ),
                ),

                // Devices List Content Area
                Expanded(
                  child: _buildListArea(isLoading, state, filteredList),
                ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddDevice,
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: const Text(
          'Add Device',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildListArea(
      bool isLoading, AdminState state, List<DeviceEntity> filteredList) {
    final colors = AppColors.of(context);
    // If loading and cache is empty, show full-screen spinner
    if (isLoading && _cachedDevices.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.primary),
      );
    }

    // Show error if there are no cached devices to display
    if (state is AdminError && _cachedDevices.isEmpty) {
      return ErrorDisplayWidget(
        message: state.message,
        onRetry: () => _fetchDevices(),
      );
    }

    // Show empty state
    if (filteredList.isEmpty && !isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.router_outlined, size: 48.r, color: colors.textMuted),
            SizedBox(height: 12.h),
            Text(
              'No devices found',
              style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                  color: colors.textPrimary),
            ),
            SizedBox(height: 6.h),
            Text(
              'Try modifying your search or filter options.',
              style: TextStyle(fontSize: 12.sp, color: colors.textSecondary),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // Smooth linear progress indicator at the top when searching in background
        if (isLoading && _currentPage == 0)
          LinearProgressIndicator(
            color: AppColors.primary,
            backgroundColor: colors.border,
            minHeight: 3,
          )
        else
          SizedBox(height: 3.h),
        Expanded(
          child: ListView.builder(
            controller: _scrollController,
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            itemCount: filteredList.length + 1,
            itemBuilder: (context, index) {
              if (index == filteredList.length) {
                return _buildBottomLoader(isLoading);
              }
              final device = filteredList[index];
              return _buildDeviceCard(device);
            },
          ),
        ),
      ],
    );
  }

  /*
    Widget _buildFilterChip(String filterName, int count) {
      final isSelected = _statusFilter == filterName;
      Color chipBgColor = AppColors.background;
      Color labelColor = AppColors.textSecondary;
  
      if (isSelected) {
        if (filterName == 'Online') {
          chipBgColor = AppColors.online.withValues(alpha: 0.1);
          labelColor = AppColors.online;
        } else if (filterName == 'Offline') {
          chipBgColor = AppColors.aqiRed.withValues(alpha: 0.1);
          labelColor = AppColors.aqiRed;
        } else {
          chipBgColor = AppColors.primaryLight;
          labelColor = AppColors.primary;
        }
      }
  
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 6.w),
        child: ChoiceChip(
          label: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (filterName == 'Online') ...[
                Container(
                  width: 6.r,
                  height: 6.r,
                  decoration: BoxDecoration(
                    color:
                        isSelected ? AppColors.online : AppColors.textSecondary,
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 4.w),
              ] else if (filterName == 'Offline') ...[
                Container(
                  width: 6.r,
                  height: 6.r,
                  decoration: BoxDecoration(
                    color:
                        isSelected ? AppColors.aqiRed : AppColors.textSecondary,
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 4.w),
              ],
              Text(
                '$filterName ($count)',
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: labelColor,
                ),
              ),
            ],
          ),
          selected: isSelected,
          onSelected: (selected) {
            if (selected) {
              setState(() {
                _statusFilter = filterName;
              });
              _fetchDevices();
            }
          },
          backgroundColor: AppColors.background,
          selectedColor: chipBgColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.r),
            side: BorderSide(
              color: isSelected
                  ? labelColor.withValues(alpha: 0.5)
                  : AppColors.border,
              width: 1.r,
            ),
          ),
          showCheckmark: false,
        ),
      );
    }
  */

  Widget _buildBottomLoader(bool isLoading) {
    if (isLoading) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: 16.h),
        child: const Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );
    }

    if (_currentPage >= _cachedTotalPages - 1) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: 24.h),
        child: Center(
          child: Text(
            'All devices loaded',
            style: TextStyle(
              fontSize: 12.sp,
              color: AppColors.of(context).textMuted,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      );
    }

    return const SizedBox.shrink();
  }

  Widget _buildDeviceCard(DeviceEntity device) {
    final colors = AppColors.of(context);
    final statusColor = device.active ? AppColors.online : AppColors.offline;
    final statusLabel = device.active ? 'ACTIVE' : 'INACTIVE';
    final installDateStr = device.installationDate != null
        ? '${device.installationDate!.day.toString().padLeft(2, '0')}/${device.installationDate!.month.toString().padLeft(2, '0')}/${device.installationDate!.year}'
        : 'Not Set';
    final expiryDateStr = device.expiryDate != null
        ? '${device.expiryDate!.day.toString().padLeft(2, '0')}/${device.expiryDate!.month.toString().padLeft(2, '0')}/${device.expiryDate!.year}'
        : 'Not Set';

    return Padding(
      padding: EdgeInsets.only(bottom: 8.h),
      child: InkWell(
        onTap: () => _showDeviceDetails(device.deviceId),
        borderRadius: BorderRadius.circular(12.r),
        child: ScadaCard(
          padding: EdgeInsets.all(12.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Device Title
                  Expanded(
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 14.r,
                          backgroundColor:
                              AppColors.primary.withValues(alpha: 0.1),
                          child: Text(
                            '#${device.srNo}',
                            style: TextStyle(
                                color: AppColors.primary,
                                fontSize: 11.sp,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                device.deviceName,
                                style: TextStyle(
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.bold,
                                    color: colors.textPrimary),
                              ),
                              Text(
                                device.deviceCode,
                                style: TextStyle(
                                    fontSize: 11.sp,
                                    color: colors.textMuted,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Eye Icon + Active / Inactive Badge
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'View Live Monitoring',
                        icon: AnimatedEyeIcon(
                          color: AppColors.primary,
                          size: 18.r,
                        ),
                        constraints: const BoxConstraints(),
                        padding: EdgeInsets.all(6.r),
                        style: IconButton.styleFrom(
                          backgroundColor:
                              AppColors.primary.withValues(alpha: 0.08),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.r),
                          ),
                        ),
                        onPressed: () {
                          context.push(AppRoutes.adminSiteDetails
                              .replaceAll(':id', device.deviceId));
                        },
                      ),
                      SizedBox(width: 8.w),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(20.r),
                          border: Border.all(
                              color: statusColor.withValues(alpha: 0.2)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (device.active)
                              const _BlinkingStatusDot(color: AppColors.online)
                            else
                              Container(
                                width: 6.r,
                                height: 6.r,
                                decoration: BoxDecoration(
                                  color: statusColor,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            SizedBox(width: 6.w),
                            Text(
                              statusLabel,
                              style: TextStyle(
                                color: statusColor,
                                fontSize: 9.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Divider(height: 12.h, color: colors.border),
              // Details grid
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: _buildDetailItem(
                      icon: Icons.fingerprint_rounded,
                      label: 'IMEI',
                      value: device.imeiNo,
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: _buildDetailItem(
                      icon: Icons.sim_card_outlined,
                      label: 'SIM No',
                      value: device.simNo.isEmpty ? 'N/A' : device.simNo,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8.h),
              Row(
                children: [
                  Expanded(
                    child: _buildDetailItem(
                      icon: Icons.calendar_month_outlined,
                      label: 'Installed On',
                      value: installDateStr,
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: _buildDetailItem(
                      icon: Icons.date_range_outlined,
                      label: 'Expiry Date',
                      value: expiryDateStr,
                    ),
                  ),
                ],
              ),
              if (device.userName != null && device.userName!.isNotEmpty) ...[
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildDetailItem(
                        icon: Icons.person_outline_rounded,
                        // label: 'Allocated Customer',
                        label: 'Allocated To',
                        // value: device.firmName != null &&
                        //         device.firmName!.isNotEmpty
                        //     ? '${device.userName} (${device.firmName})'
                        //     : device.userName!,

                        value: device.firmName != null &&
                                device.firmName!.isNotEmpty
                            ? '${device.firmName}'
                            : '-',
                      ),
                    ),
                  ],
                ),
              ],
              if (device.siteName != null && device.siteName!.isNotEmpty) ...[
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildDetailItem(
                        icon: Icons.domain_rounded,
                        label: 'Site / Project',
                        value: device.projectName != null &&
                                device.projectName!.isNotEmpty
                            ? '${device.siteName} (${device.projectName})'
                            : device.siteName!,
                      ),
                    ),
                  ],
                ),
              ],
              if (device.address != null && device.address!.isNotEmpty) ...[
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Expanded(
                      child: StatefulBuilder(
                        builder: (context, cardSetState) {
                          final isExpanded =
                              _expandedDeviceIds.contains(device.deviceId);
                          final addressText = [
                            device.address,
                            if (device.city != null && device.city!.isNotEmpty)
                              device.city,
                            if (device.state != null &&
                                device.state!.isNotEmpty)
                              device.state
                          ].join(', ');

                          return _buildDetailItem(
                            icon: Icons.location_on_outlined,
                            label: 'Installation Address',
                            value: addressText,
                            maxLines: isExpanded ? null : 2,
                            trailingWidget: GestureDetector(
                              onTap: () {
                                setState(() {
                                  if (isExpanded) {
                                    _expandedDeviceIds.remove(device.deviceId);
                                  } else {
                                    _expandedDeviceIds.add(device.deviceId);
                                  }
                                });
                                cardSetState(() {});
                              },
                              child: Padding(
                                padding: EdgeInsets.only(top: 4.h),
                                child: Text(
                                  isExpanded ? 'See Less' : 'See More',
                                  style: TextStyle(
                                    fontSize: 11.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.primary,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
              SizedBox(height: 8.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: _buildDetailItem(
                      icon: Icons.terminal_rounded,
                      label: 'Firmware',
                      value: device.firmwareVersion,
                    ),
                  ),
                  if (device.createdAt != null)
                    Text(
                      'Created: ${device.createdAt!.year}-${device.createdAt!.month.toString().padLeft(2, '0')}-${device.createdAt!.day.toString().padLeft(2, '0')}',
                      style: TextStyle(
                          fontSize: 10.sp, color: AppColors.textMuted),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailItem({
    required IconData icon,
    required String label,
    required String value,
    int? maxLines,
    Widget? trailingWidget,
  }) {
    final colors = AppColors.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 14.r, color: colors.textSecondary),
        SizedBox(width: 6.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: colors.textSecondary,
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                value,
                maxLines: maxLines,
                overflow: maxLines != null ? TextOverflow.ellipsis : null,
                style: TextStyle(
                  color: colors.textPrimary,
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (trailingWidget != null) trailingWidget,
            ],
          ),
        ),
      ],
    );
  }
}

class _BlinkingStatusDot extends StatefulWidget {
  final Color color;

  const _BlinkingStatusDot({required this.color});

  @override
  State<_BlinkingStatusDot> createState() => _BlinkingStatusDotState();
}

class _BlinkingStatusDotState extends State<_BlinkingStatusDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
    _animation = Tween<double>(begin: 0.2, end: 1.0).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: Container(
        width: 6.r,
        height: 6.r,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: widget.color.withValues(alpha: 0.6),
              blurRadius: 4.r,
              spreadRadius: 1.r,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Bottom Sheet for Device Details & Edit Form ─────────────────────────
class _DeviceDetailBottomSheet extends StatefulWidget {
  final String deviceId;

  const _DeviceDetailBottomSheet({required this.deviceId});

  @override
  State<_DeviceDetailBottomSheet> createState() =>
      _DeviceDetailBottomSheetState();
}

class _DeviceDetailBottomSheetState extends State<_DeviceDetailBottomSheet> {
  bool _isEditing = false;
  bool _isAddressExpanded = false;
  bool _fieldsInitialized = false;
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameController;
  late TextEditingController _codeController;
  late TextEditingController _imeiController;
  late TextEditingController _simController;
  late TextEditingController _firmwareController;
  late TextEditingController _siteNameController;
  late TextEditingController _projectNameController;
  late TextEditingController _geofenceRadiusController;
  late TextEditingController _latController;
  late TextEditingController _lngController;
  late TextEditingController _addressController;
  late TextEditingController _cityController;
  late TextEditingController _districtController;
  late TextEditingController _stateController;
  late TextEditingController _remarksController;

  DateTime? _installationDate;
  DateTime? _expiryDate;
  bool _active = false;

  String? _selectedCustomerId;
  List<CustomerEntity> _customers = [];
  bool _isLoadingCustomers = false;

  GoogleMapController? _mapController;
  late LatLng _cameraPosition;
  bool _isGeocoding = false;
  DeviceEntity? _loadedDevice;

  @override
  void initState() {
    super.initState();
    _cameraPosition = const LatLng(18.5204, 73.8567);
    _nameController = TextEditingController();
    _codeController = TextEditingController();
    _imeiController = TextEditingController();
    _simController = TextEditingController();
    _firmwareController = TextEditingController();
    _siteNameController = TextEditingController();
    _projectNameController = TextEditingController();
    _geofenceRadiusController = TextEditingController();
    _latController = TextEditingController();
    _lngController = TextEditingController();
    _latController.addListener(_onLatLngTextChanged);
    _lngController.addListener(_onLatLngTextChanged);
    _addressController = TextEditingController();
    _cityController = TextEditingController();
    _districtController = TextEditingController();
    _stateController = TextEditingController();
    _remarksController = TextEditingController();

    _loadCustomers();
    context.read<AdminBloc>().add(LoadDeviceDetail(widget.deviceId));
  }

  Future<void> _loadCustomers() async {
    setState(() {
      _isLoadingCustomers = true;
    });
    try {
      final repository = getIt<CustomerRepository>();
      final result = await repository.getCustomers(page: 0, size: 500);
      if (mounted) {
        setState(() {
          _customers =
              result.where((c) => c.active && c.role == UserRole.user).toList();
          _isLoadingCustomers = false;
          // Re-lookup customer details if device is already loaded
          if (_fieldsInitialized) {
            _updateSelectedCustomerFromDetails();
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingCustomers = false;
        });
      }
      debugPrint('Error loading customers for edit: $e');
    }
  }

  void _updateSelectedCustomerFromDetails() {
    if (_loadedDevice == null) return;
    final device = _loadedDevice!;
    String? foundCustomerId;

    if (_customers.isNotEmpty) {
      // 1. Match by email
      if (device.email != null && device.email!.isNotEmpty) {
        for (final c in _customers) {
          if (c.email.toLowerCase().trim() ==
              device.email!.toLowerCase().trim()) {
            foundCustomerId = c.customerId;
            break;
          }
        }
      }
      // 2. Match by mobile
      if (foundCustomerId == null &&
          device.mobileNo != null &&
          device.mobileNo!.isNotEmpty) {
        final dMobile = device.mobileNo!.replaceAll(RegExp(r'[^0-9]'), '');
        for (final c in _customers) {
          final cMobile = c.mobileNo.replaceAll(RegExp(r'[^0-9]'), '');
          if (cMobile == dMobile) {
            foundCustomerId = c.customerId;
            break;
          }
        }
      }
      // 3. Match by name
      if (foundCustomerId == null &&
          device.userName != null &&
          device.userName!.isNotEmpty) {
        for (final c in _customers) {
          if (c.fullName.toLowerCase().trim() ==
              device.userName!.toLowerCase().trim()) {
            foundCustomerId = c.customerId;
            break;
          }
        }
      }
    }

    _selectedCustomerId = foundCustomerId ?? device.customerId;
    debugPrint(
        '[EditDevice] Customer pre-selection resolved to: $_selectedCustomerId');
  }

  Future<void> _fetchAddressFromCoordinates(double lat, double lng) async {
    if (_isGeocoding) return;
    setState(() {
      _isGeocoding = true;
    });

    try {
      final response = await Dio().get(
        'https://nominatim.openstreetmap.org/reverse',
        queryParameters: {
          'format': 'json',
          'lat': lat,
          'lon': lng,
          'zoom': 18,
          'addressdetails': 1,
        },
        options: Options(
          headers: {
            'User-Agent': 'vasundhara_aqim_admin_app',
          },
        ),
      );

      if (response.statusCode == 200 && response.data != null) {
        final displayName = response.data['display_name'] as String?;
        if (displayName != null) {
          setState(() {
            _addressController.text = displayName;
          });
        }
        final addr = response.data['address'] as Map<String, dynamic>?;
        if (addr != null) {
          final city = addr['city'] ??
              addr['town'] ??
              addr['village'] ??
              addr['municipality'] ??
              addr['suburb'] ??
              '';
          final district = addr['district'] ?? addr['county'] ?? '';
          final state = addr['state'] ?? '';
          setState(() {
            _cityController.text = city.toString();
            _districtController.text = district.toString();
            _stateController.text = state.toString();
          });
        }
      }
    } catch (e) {
      debugPrint('Geocoding error in edit sheet: $e');
    } finally {
      setState(() {
        _isGeocoding = false;
      });
    }
  }

  Future<void> _fetchCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    try {
      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;

      permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return;
      }

      if (permission == LocationPermission.deniedForever) return;

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      setState(() {
        _latController.text = position.latitude.toStringAsFixed(6);
        _lngController.text = position.longitude.toStringAsFixed(6);
        _cameraPosition = LatLng(position.latitude, position.longitude);
      });

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(target: _cameraPosition, zoom: 15.0),
          ),
        );
      }

      await _fetchAddressFromCoordinates(position.latitude, position.longitude);
    } catch (e) {
      debugPrint('Error fetching current location: $e');
    }
  }

  @override
  void dispose() {
    _latController.removeListener(_onLatLngTextChanged);
    _lngController.removeListener(_onLatLngTextChanged);
    _nameController.dispose();
    _codeController.dispose();
    _imeiController.dispose();
    _simController.dispose();
    _firmwareController.dispose();
    _siteNameController.dispose();
    _projectNameController.dispose();
    _geofenceRadiusController.dispose();
    _latController.dispose();
    _lngController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _districtController.dispose();
    _stateController.dispose();
    _remarksController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  void _onLatLngTextChanged() {
    final lat = double.tryParse(_latController.text);
    final lng = double.tryParse(_lngController.text);
    if (lat != null && lng != null) {
      final newPos = LatLng(lat, lng);
      if ((newPos.latitude - _cameraPosition.latitude).abs() > 0.00001 ||
          (newPos.longitude - _cameraPosition.longitude).abs() > 0.00001) {
        _cameraPosition = newPos;
        _mapController?.animateCamera(
          CameraUpdate.newLatLng(newPos),
        );
      }
    }
  }

  void _initFields(DeviceEntity device) {
    _loadedDevice = device;
    _nameController.text = device.deviceName;
    _codeController.text = device.deviceCode;
    _imeiController.text = device.imeiNo;
    _simController.text = device.simNo;
    _firmwareController.text = device.firmwareVersion;
    _installationDate = device.installationDate;
    _expiryDate = device.expiryDate;
    _active = device.active;

    _siteNameController.text = device.siteName ?? '';
    _projectNameController.text = device.projectName ?? '';
    _geofenceRadiusController.text =
        device.geofenceRadius?.toString() ?? '1000';
    _latController.text = device.latitude?.toString() ?? '';
    _lngController.text = device.longitude?.toString() ?? '';
    _addressController.text = device.address ?? '';
    _cityController.text = device.city ?? '';
    _districtController.text = device.district ?? '';
    _stateController.text = device.state ?? '';
    _remarksController.text = device.remarks ?? '';

    final latVal = device.latitude ?? 18.5204;
    final lngVal = device.longitude ?? 73.8567;
    _cameraPosition = LatLng(latVal, lngVal);

    _updateSelectedCustomerFromDetails();
  }

  Future<void> _selectDate(BuildContext context, DateTime initial,
      Function(DateTime) onPicked) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() {
        onPicked(picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final maxSheetHeight = MediaQuery.of(context).size.height * 0.8;
    final colors = AppColors.of(context);

    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxSheetHeight),
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        ),
        padding: EdgeInsets.only(
          left: 16.w,
          right: 16.w,
          top: 6.h,
          bottom: MediaQuery.of(context).viewInsets.bottom + 12.h,
        ),
        child: Material(
          color: Colors.transparent,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle indicator
              Container(
                width: 40.w,
                height: 4.h,
                margin: EdgeInsets.only(bottom: 16.h),
                decoration: BoxDecoration(
                  color: colors.border,
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
              BlocConsumer<AdminBloc, AdminState>(
                listener: (context, state) {
                  if (state is AdminActionSuccess) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Device updated successfully'),
                        backgroundColor: AppColors.online,
                      ),
                    );
                    setState(() {
                      _isEditing = false;
                      _fieldsInitialized = false;
                    });
                    context
                        .read<AdminBloc>()
                        .add(LoadDeviceDetail(widget.deviceId));
                    context.pop();
                  }
                },
                builder: (context, state) {
                  if (state is AdminLoading) {
                    return Padding(
                      padding: EdgeInsets.symmetric(vertical: 40.h),
                      child: const Center(
                        child: CircularProgressIndicator(
                          color: AppColors.primary,
                        ),
                      ),
                    );
                  }

                  if (state is AdminError) {
                    return ErrorDisplayWidget(
                      message: state.message,
                      onRetry: () => context
                          .read<AdminBloc>()
                          .add(LoadDeviceDetail(widget.deviceId)),
                    );
                  }

                  if (state is DeviceDetailLoaded) {
                    final device = state.device;

                    if (!_fieldsInitialized) {
                      _initFields(device);
                      _fieldsInitialized = true;
                    }

                    return Flexible(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    _isEditing
                                        ? 'Edit Device Registry'
                                        : 'Device Specification',
                                    style: TextStyle(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.primary,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      _isEditing
                                          ? Icons.close_rounded
                                          : Icons.edit_rounded,
                                      color: AppColors.primary,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        _isEditing = !_isEditing;
                                        _initFields(device);
                                      });
                                    },
                                  ),
                                ],
                              ),
                              Divider(color: colors.border, height: 16.h),
                              if (_isEditing) ...[
                                // _buildTextField(
                                //   'Device Code / Serial *',
                                //   _codeController,

                                //   validator: (v) =>
                                //       v!.isEmpty ? 'Required' : null,
                                // ),
                                // SizedBox(height: 12.h),
                                _buildTextField(
                                  'Device Custom Name *',
                                  _nameController,
                                  validator: (v) =>
                                      v!.isEmpty ? 'Required' : null,
                                ),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildTextField(
                                          'IMEI Number *', _imeiController,
                                          inputFormatters: [
                                            FilteringTextInputFormatter
                                                .digitsOnly,
                                            LengthLimitingTextInputFormatter(
                                                15),
                                          ],
                                          validator: (v) =>
                                              Validator.validateImei(v)),
                                    ),
                                    SizedBox(width: 12.w),
                                    Expanded(
                                      child: _buildTextField(
                                          'SIM Number', _simController,
                                          inputFormatters: [
                                            FilteringTextInputFormatter
                                                .digitsOnly,
                                            // LengthLimitingTextInputFormatter(
                                            //     16),
                                          ],
                                          validator: (e) => Validator.simNumber(
                                              e, 'Enter SIM number')),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildTextField(
                                        'Firmware',
                                        _firmwareController,
                                        validator: (v) =>
                                            Validator.validateFirmwareVersion(
                                                v),
                                      ),
                                    ),
                                    SizedBox(width: 12.w),
                                    Expanded(
                                      child: SwitchListTile.adaptive(
                                        contentPadding: EdgeInsets.zero,
                                        title: Text(
                                          'Active State',
                                          style: TextStyle(
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        value: _active,
                                        onChanged: (val) =>
                                            setState(() => _active = val),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: OutlinedButton.icon(
                                        icon: const Icon(
                                          Icons.calendar_today_rounded,
                                          size: 14,
                                        ),
                                        label: Text(
                                          _installationDate == null
                                              ? 'Install Date'
                                              : '${_installationDate!.day}/${_installationDate!.month}/${_installationDate!.year}',
                                          style: TextStyle(fontSize: 11.sp),
                                        ),
                                        onPressed: () => _selectDate(
                                          context,
                                          _installationDate ?? DateTime.now(),
                                          (d) => _installationDate = d,
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 12.w),
                                    Expanded(
                                      child: OutlinedButton.icon(
                                        icon: const Icon(
                                          Icons.date_range_rounded,
                                          size: 14,
                                        ),
                                        label: Text(
                                          _expiryDate == null
                                              ? 'Expiry Date'
                                              : '${_expiryDate!.day}/${_expiryDate!.month}/${_expiryDate!.year}',
                                          style: TextStyle(fontSize: 11.sp),
                                        ),
                                        onPressed: () => _selectDate(
                                          context,
                                          _expiryDate ??
                                              DateTime.now().add(
                                                const Duration(days: 730),
                                              ),
                                          (d) => _expiryDate = d,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12.h),
                                if (_isLoadingCustomers)
                                  const Padding(
                                    padding: EdgeInsets.symmetric(vertical: 8),
                                    child: Center(
                                      child: SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: AppColors.primary,
                                        ),
                                      ),
                                    ),
                                  )
                                else
                                  DropdownButtonFormField<String>(
                                    isExpanded: true,
                                    key: ValueKey(
                                        'customer_dropdown_$_selectedCustomerId'),
                                    initialValue: _selectedCustomerId,
                                    onChanged: (val) {
                                      setState(() {
                                        _selectedCustomerId = val;
                                      });
                                    },
                                    validator: (val) =>
                                        (val == null || val.isEmpty)
                                            ? 'Please select a customer'
                                            : null,
                                    decoration: InputDecoration(
                                      labelText: 'Assign Customer *',
                                      labelStyle: TextStyle(
                                          fontSize: 12.sp,
                                          color: colors.textSecondary),
                                      contentPadding: EdgeInsets.symmetric(
                                          horizontal: 12.w, vertical: 8.h),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.r)),
                                      enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.r),
                                          borderSide:
                                              BorderSide(color: colors.border)),
                                    ),
                                    items: _customers
                                        .map((c) => DropdownMenuItem(
                                              value: c.customerId,
                                              child: Text(
                                                c.firmName != null &&
                                                        c.firmName!.isNotEmpty
                                                    ? "${c.firmName}"
                                                    : "",
                                                style:
                                                    TextStyle(fontSize: 12.sp),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ))
                                        .toList(),
                                  ),
                                SizedBox(height: 12.h),
                                _buildTextField(
                                  'Site / Station Name *',
                                  _siteNameController,
                                  validator: (v) =>
                                      v!.isEmpty ? 'Required' : null,
                                ),
                                SizedBox(height: 12.h),
                                _buildTextField(
                                  'Project Name *',
                                  _projectNameController,
                                  validator: (v) =>
                                      v!.isEmpty ? 'Required' : null,
                                ),
                                SizedBox(height: 12.h),
                                _buildMapSelectionUI(),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildTextField(
                                        'Latitude *',
                                        _latController,
                                        validator: (v) =>
                                            v!.isEmpty ? 'Required' : null,
                                      ),
                                    ),
                                    SizedBox(width: 12.w),
                                    Expanded(
                                      child: _buildTextField(
                                        'Longitude *',
                                        _lngController,
                                        validator: (v) =>
                                            v!.isEmpty ? 'Required' : null,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildTextField(
                                        'Geofence Radius (meters) *',
                                        _geofenceRadiusController,
                                        validator: (v) =>
                                            v!.isEmpty ? 'Required' : null,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12.h),
                                _buildTextField(
                                  'Installation Address *',
                                  _addressController,
                                  validator: (v) =>
                                      v!.isEmpty ? 'Required' : null,
                                ),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildTextField(
                                        'City *',
                                        _cityController,
                                        validator: (v) =>
                                            v!.isEmpty ? 'Required' : null,
                                      ),
                                    ),
                                    SizedBox(width: 8.w),
                                    Expanded(
                                      child: _buildTextField(
                                        'District *',
                                        _districtController,
                                        validator: (v) =>
                                            v!.isEmpty ? 'Required' : null,
                                      ),
                                    ),
                                    SizedBox(width: 8.w),
                                    Expanded(
                                      child: _buildTextField(
                                        'State *',
                                        _stateController,
                                        validator: (v) =>
                                            v!.isEmpty ? 'Required' : null,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12.h),
                                _buildTextField(
                                  'Remarks',
                                  _remarksController,
                                ),
                                SizedBox(height: 24.h),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.primary,
                                    foregroundColor: Colors.white,
                                    minimumSize: Size(double.infinity, 44.h),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.r),
                                    ),
                                  ),
                                  onPressed: () {
                                    if (_formKey.currentState!.validate()) {
                                      final lat =
                                          double.tryParse(_latController.text);
                                      final lng =
                                          double.tryParse(_lngController.text);
                                      final radius = int.tryParse(
                                          _geofenceRadiusController.text);

                                      debugPrint(
                                          '[EditDevice] Saving with customerId=$_selectedCustomerId, deviceId=${device.deviceId}');

                                      final updatedDevice = DeviceEntity(
                                        srNo: device.srNo,
                                        deviceId: device.deviceId,
                                        deviceCode: device.deviceCode,
                                        deviceName: _nameController.text.trim(),
                                        imeiNo: _imeiController.text.trim(),
                                        simNo: _simController.text.trim(),
                                        firmwareVersion:
                                            _firmwareController.text.trim(),
                                        installationDate: _installationDate,
                                        expiryDate: _expiryDate,
                                        active: _active,
                                        createdAt: device.createdAt,
                                        updatedAt: DateTime.now(),
                                        customerId: _selectedCustomerId,
                                        siteName:
                                            _siteNameController.text.trim(),
                                        projectName:
                                            _projectNameController.text.trim(),
                                        latitude: lat,
                                        longitude: lng,
                                        geofenceRadius: radius,
                                        address: _addressController.text.trim(),
                                        city: _cityController.text.trim(),
                                        district:
                                            _districtController.text.trim(),
                                        state: _stateController.text.trim(),
                                        remarks: _remarksController.text.trim(),
                                      );
                                      context
                                          .read<AdminBloc>()
                                          .add(UpdateDevice(updatedDevice));
                                    }
                                  },
                                  child: const Text('Save Update'),
                                ),
                              ] else ...[
                                _buildDetailRow(
                                  'Device Code',
                                  device.deviceCode,
                                  icon: Icons.qr_code_rounded,
                                ),
                                _buildDetailRow(
                                  'Device Name',
                                  device.deviceName,
                                  icon: Icons.router_rounded,
                                ),
                                _buildDetailRow(
                                  'IMEI Number',
                                  device.imeiNo,
                                  icon: Icons.fingerprint_rounded,
                                ),
                                _buildDetailRow(
                                  'SIM Details',
                                  device.simNo.isEmpty
                                      ? 'Not Provided'
                                      : device.simNo,
                                  icon: Icons.sim_card_rounded,
                                ),
                                _buildDetailRow(
                                  'Firmware Version',
                                  device.firmwareVersion,
                                  icon: Icons.terminal_rounded,
                                ),
                                if (device.userName != null &&
                                    device.userName!.isNotEmpty)
                                  _buildDetailRow(
                                    // 'Allocated Customer',
                                    'Allocated To',
                                    // device.firmName != null &&
                                    //         device.firmName!.isNotEmpty
                                    //     ? '${device.userName} (${device.firmName})'
                                    //     : device.userName!,

                                    device.firmName != null &&
                                            device.firmName!.isNotEmpty
                                        ? '${device.firmName}'
                                        : '-',
                                    icon: Icons.person_outline_rounded,
                                  ),
                                if (device.siteName != null &&
                                    device.siteName!.isNotEmpty)
                                  _buildDetailRow(
                                    'Site / Station',
                                    device.siteName!,
                                    icon: Icons.domain_rounded,
                                  ),
                                if (device.projectName != null &&
                                    device.projectName!.isNotEmpty)
                                  _buildDetailRow(
                                    'Project Name',
                                    device.projectName!,
                                    icon: Icons.business_rounded,
                                  ),
                                if (device.latitude != null &&
                                    device.longitude != null)
                                  _buildDetailRow(
                                    'Geofence Coordinate Area',
                                    'Lat: ${device.latitude}, Lng: ${device.longitude} (Radius: ${device.geofenceRadius ?? 100}m)',
                                    icon: Icons.explore_outlined,
                                  ),
                                if (device.address != null &&
                                    device.address!.isNotEmpty)
                                  _buildDetailRow(
                                    'Installation Location',
                                    '',
                                    icon: Icons.location_on_outlined,
                                    customValueWidget: StatefulBuilder(
                                      builder: (context, detailSetState) {
                                        final addressText = [
                                          device.address,
                                          if (device.city != null &&
                                               device.city!.isNotEmpty)
                                            device.city,
                                          if (device.district != null &&
                                              device.district!.isNotEmpty)
                                            device.district,
                                          if (device.state != null &&
                                              device.state!.isNotEmpty)
                                            device.state
                                        ].join(', ');

                                        return Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              addressText,
                                              maxLines:
                                                  _isAddressExpanded ? null : 2,
                                              overflow: _isAddressExpanded
                                                  ? null
                                                  : TextOverflow.ellipsis,
                                              style: TextStyle(
                                                fontSize: 13.sp,
                                                color: AppColors.of(context)
                                                    .textPrimary,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () {
                                                setState(() {
                                                  _isAddressExpanded =
                                                      !_isAddressExpanded;
                                                });
                                                detailSetState(() {});
                                              },
                                              child: Padding(
                                                padding:
                                                    EdgeInsets.only(top: 4.h),
                                                child: Text(
                                                  _isAddressExpanded
                                                      ? 'See Less'
                                                      : 'See More',
                                                  style: TextStyle(
                                                    fontSize: 11.sp,
                                                    fontWeight: FontWeight.bold,
                                                    color: AppColors.primary,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        );
                                      },
                                    ),
                                  ),
                                if (device.remarks != null &&
                                    device.remarks!.isNotEmpty)
                                  _buildDetailRow(
                                    'Remarks / Comments',
                                    device.remarks!,
                                    icon: Icons.comment_outlined,
                                  ),
                                _buildDetailRow(
                                  'Status Badge',
                                  device.active ? 'ACTIVE' : 'INACTIVE',
                                  icon: Icons.check_circle_outline_rounded,
                                  customValueWidget: Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 8.w,
                                      vertical: 2.h,
                                    ),
                                    decoration: BoxDecoration(
                                      color: (device.active
                                              ? AppColors.online
                                              : AppColors.offline)
                                          .withValues(alpha: 0.1),
                                      borderRadius: BorderRadius.circular(12.r),
                                    ),
                                    child: Text(
                                      device.active ? 'ACTIVE' : 'INACTIVE',
                                      style: TextStyle(
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.bold,
                                        color: device.active
                                            ? AppColors.online
                                            : AppColors.offline,
                                      ),
                                    ),
                                  ),
                                ),
                                _buildDetailRow(
                                  'Installation Details',
                                  device.installationDate == null
                                      ? 'Not Configured'
                                      : '${device.installationDate!.day.toString().padLeft(2, '0')}/${device.installationDate!.month.toString().padLeft(2, '0')}/${device.installationDate!.year}',
                                  icon: Icons.calendar_month_rounded,
                                ),
                                _buildDetailRow(
                                  'Expiry Details',
                                  device.expiryDate == null
                                      ? 'Not Configured'
                                      : '${device.expiryDate!.day.toString().padLeft(2, '0')}/${device.expiryDate!.month.toString().padLeft(2, '0')}/${device.expiryDate!.year}',
                                  icon: Icons.date_range_rounded,
                                ),
                                if (device.createdAt != null)
                                  _buildDetailRow(
                                    'Registry Timestamp',
                                    device.createdAt.toString().split('.')[0],
                                    icon: Icons.history_toggle_off_rounded,
                                  ),
                                SizedBox(height: 20.h),
                                ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.aqiRed,
                                    foregroundColor: Colors.white,
                                    minimumSize: Size(double.infinity, 44.h),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.r),
                                    ),
                                  ),
                                  icon:
                                      const Icon(Icons.delete_outline_rounded),
                                  label: const Text('Deassign Device'),
                                  onPressed: () {
                                    _confirmDeleteDevice(
                                        context,
                                        device.deviceId,
                                        device.deviceName,
                                        device.deviceCode);
                                  },
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  }

                  return const SizedBox.shrink();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmDeleteDevice(BuildContext context, String deviceId,
      String deviceName, String deviceCode) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Deallocate / Delete Device?'),
          content: Text(
            'Are you sure you want to remove $deviceName ($deviceCode) from customer allocation?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                final messenger = ScaffoldMessenger.of(context);
                Navigator.pop(dialogContext); // close dialog

                try {
                  await getIt<CustomerRepository>().removeDevice(deviceId);
                  if (context.mounted) {
                    Navigator.pop(context); // close bottom sheet
                  }
                  messenger.showSnackBar(
                    const SnackBar(
                      content: Text('Device deallocated successfully!'),
                      backgroundColor: AppColors.online,
                    ),
                  );
                } catch (e) {
                  messenger.showSnackBar(
                    SnackBar(
                      content: Text('Failed to deallocate device: $e'),
                      backgroundColor: AppColors.aqiRed,
                    ),
                  );
                }
              },
              style: TextButton.styleFrom(
                foregroundColor: AppColors.aqiRed,
              ),
              child: const Text('Deallocate'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildMapSelectionUI() {
    final colors = AppColors.of(context);
    final double initialLat = double.tryParse(_latController.text) ?? 18.5204;
    final double initialLng = double.tryParse(_lngController.text) ?? 73.8567;

    return Container(
      height: 200.h,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: colors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: GestureDetector(
        onVerticalDragStart: (_) {},
        onVerticalDragUpdate: (_) {},
        child: Stack(
          children: [
            GoogleMap(
              style: Theme.of(context).brightness == Brightness.dark
                  ? MapStyles.dark
                  : MapStyles.silver,
              initialCameraPosition: CameraPosition(
                target: LatLng(initialLat, initialLng),
                zoom: 15.0,
              ),
              onMapCreated: (GoogleMapController controller) {
                _mapController = controller;
                _mapController!.animateCamera(
                  CameraUpdate.newCameraPosition(
                    CameraPosition(target: _cameraPosition, zoom: 15.0),
                  ),
                );
              },
              onCameraMove: (position) {
                _cameraPosition = position.target;
              },
              onCameraIdle: () {
                setState(() {
                  _latController.text =
                      _cameraPosition.latitude.toStringAsFixed(6);
                  _lngController.text =
                      _cameraPosition.longitude.toStringAsFixed(6);
                });

                bool shouldFetchAddress = true;
                if (_loadedDevice != null &&
                    _loadedDevice!.latitude != null &&
                    _loadedDevice!.longitude != null &&
                    _addressController.text.trim().isNotEmpty) {
                  final double latDiff =
                      (_cameraPosition.latitude - _loadedDevice!.latitude!)
                          .abs();
                  final double lngDiff =
                      (_cameraPosition.longitude - _loadedDevice!.longitude!)
                          .abs();
                  if (latDiff < 0.0001 && lngDiff < 0.0001) {
                    shouldFetchAddress = false;
                  }
                }

                if (shouldFetchAddress) {
                  _fetchAddressFromCoordinates(
                      _cameraPosition.latitude, _cameraPosition.longitude);
                }
              },
              onTap: (LatLng tappedPoint) {
                setState(() {
                  _cameraPosition = tappedPoint;
                  _latController.text = tappedPoint.latitude.toStringAsFixed(6);
                  _lngController.text =
                      tappedPoint.longitude.toStringAsFixed(6);
                });
                _mapController?.animateCamera(
                  CameraUpdate.newLatLng(tappedPoint),
                );
                _fetchAddressFromCoordinates(
                    tappedPoint.latitude, tappedPoint.longitude);
              },
              zoomControlsEnabled: false,
              scrollGesturesEnabled: true,
              zoomGesturesEnabled: true,
              rotateGesturesEnabled: false,
              tiltGesturesEnabled: false,
              mapToolbarEnabled: false,
              myLocationEnabled: false,
              myLocationButtonEnabled: false,
            ),
            Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 30.h),
                child: Icon(
                  Icons.location_on_rounded,
                  size: 36.r,
                  color: AppColors.aqiRed,
                  shadows: [
                    Shadow(
                      color: Colors.black.withValues(alpha: 0.25),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 8.h,
              right: 8.w,
              child: Column(
                children: [
                  _buildMapZoomButton(Icons.add_rounded, () {
                    _mapController?.animateCamera(CameraUpdate.zoomIn());
                  }),
                  SizedBox(height: 4.h),
                  _buildMapZoomButton(Icons.remove_rounded, () {
                    _mapController?.animateCamera(CameraUpdate.zoomOut());
                  }),
                ],
              ),
            ),
            Positioned(
              bottom: 8.h,
              right: 8.w,
              child: FloatingActionButton.small(
                heroTag: 'detect_location_edit_btn',
                onPressed: _fetchCurrentLocation,
                backgroundColor: Colors.white,
                foregroundColor: AppColors.primary,
                child: Icon(Icons.my_location_rounded, size: 18.r),
              ),
            ),
            if (_isGeocoding)
              Positioned(
                top: 8.h,
                left: 8.w,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16.r),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 10.r,
                        height: 10.r,
                        child: const CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.primary,
                        ),
                      ),
                      SizedBox(width: 6.w),
                      Text(
                        'Updating address...',
                        style: TextStyle(
                            fontSize: 9.sp,
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMapZoomButton(IconData icon, VoidCallback onPressed) {
    final colors = AppColors.of(context);
    return Material(
      color: colors.surface,
      borderRadius: BorderRadius.circular(8.r),
      elevation: 2,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(8.r),
        child: SizedBox(
          width: 32.r,
          height: 32.r,
          child: Icon(icon, size: 18.r, color: colors.textPrimary),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController ctrl,
      {String? Function(String?)? validator,
      List<TextInputFormatter>? inputFormatters}) {
    final colors = AppColors.of(context);
    return TextFormField(
      controller: ctrl,
      validator: validator,
      style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w500),
      inputFormatters: inputFormatters,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(fontSize: 12.sp, color: colors.textSecondary),
        contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.r)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.r),
            borderSide: BorderSide(color: colors.border)),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value,
      {required IconData icon, Widget? customValueWidget}) {
    final colors = AppColors.of(context);
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16.r, color: AppColors.primary),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 10.sp,
                        color: colors.textSecondary,
                        fontWeight: FontWeight.w500)),
                SizedBox(height: 2.h),
                customValueWidget ??
                    Text(value,
                        style: TextStyle(
                            fontSize: 13.sp,
                            color: colors.textPrimary,
                            fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Bottom Sheet for Adding / Registering a New Device ──────────────────
class _AddDeviceBottomSheet extends StatefulWidget {
  const _AddDeviceBottomSheet();

  @override
  State<_AddDeviceBottomSheet> createState() => _AddDeviceBottomSheetState();
}

class _AddDeviceBottomSheetState extends State<_AddDeviceBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _codeController = TextEditingController();
  final _imeiController = TextEditingController();
  final _simController = TextEditingController();
  final _firmwareController = TextEditingController(text: 'v1.0.0');

  DateTime _installationDate = DateTime.now();
  DateTime _expiryDate =
      DateTime.now().add(const Duration(days: 730)); // 2 years expiry default
  bool _active = true;
  DeviceEntity? _pendingDevice;

  @override
  void dispose() {
    _nameController.dispose();
    _codeController.dispose();
    _imeiController.dispose();
    _simController.dispose();
    _firmwareController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context, DateTime initial,
      Function(DateTime) onPicked) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() {
        onPicked(picked);
      });
    }
  }

  void _showDuplicateDeviceDialog(
      BuildContext context, DeviceDuplicateState state) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        if (state.isCurrentlyActive) {
          return AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.warning_amber_rounded, color: AppColors.aqiOrange),
                SizedBox(width: 8),
                Text('Device Already Active'),
              ],
            ),
            content: Text(state.message),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('OK'),
              ),
            ],
          );
        } else {
          return AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.help_outline_rounded, color: AppColors.primary),
                SizedBox(width: 8),
                Text('Reactivate Device?'),
              ],
            ),
            content: Text(state.message),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('No'),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.of(dialogContext).pop();
                  final deviceToReactivate = state.existingDevice.copyWith(
                    customerId: _pendingDevice?.customerId,
                    siteName: _pendingDevice?.siteName,
                    projectName: _pendingDevice?.projectName,
                    latitude: _pendingDevice?.latitude,
                    longitude: _pendingDevice?.longitude,
                    geofenceRadius: _pendingDevice?.geofenceRadius,
                    address: _pendingDevice?.address,
                    city: _pendingDevice?.city,
                    district: _pendingDevice?.district,
                    state: _pendingDevice?.state,
                    remarks: _pendingDevice?.remarks,
                  );
                  context.read<AdminBloc>().add(
                        AddDevice(
                          deviceToReactivate,
                          isDeviceReactivate: true,
                        ),
                      );
                },
                child: const Text('Yes, Reactivate'),
              ),
            ],
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final maxSheetHeight = MediaQuery.of(context).size.height * 0.8;
    final colors = AppColors.of(context);

    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxSheetHeight),
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        ),
        padding: EdgeInsets.only(
          left: 16.w,
          right: 16.w,
          top: 6.h,
          bottom: MediaQuery.of(context).viewInsets.bottom + 12.h,
        ),
        child: Material(
          color: Colors.transparent,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle indicator
              Container(
                width: 40.w,
                height: 4.h,
                margin: EdgeInsets.only(bottom: 16.h),
                decoration: BoxDecoration(
                  color: colors.border,
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Register New Device',
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primary,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded,
                        color: AppColors.primary),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
              Divider(color: colors.border, height: 16.h),
              BlocConsumer<AdminBloc, AdminState>(
                listener: (context, state) {
                  if (state is AdminActionSuccess) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('New device successfully registered'),
                        backgroundColor: AppColors.online,
                      ),
                    );
                    Navigator.of(context).pop();
                  } else if (state is DeviceDuplicateState) {
                    _showDuplicateDeviceDialog(context, state);
                  }
                },
                builder: (context, state) {
                  if (state is AdminLoading) {
                    return Padding(
                      padding: EdgeInsets.symmetric(vertical: 40.h),
                      child: const Center(
                        child: CircularProgressIndicator(
                          color: AppColors.primary,
                        ),
                      ),
                    );
                  }

                  if (state is AdminError) {
                    return Container(
                      margin: EdgeInsets.symmetric(vertical: 12.h),
                      padding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 12.h,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.aqiRed.withAlpha(20),
                        borderRadius: BorderRadius.circular(12.r),
                        border:
                            Border.all(color: AppColors.aqiRed.withAlpha(40)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.error_outline_rounded,
                            color: AppColors.aqiRed,
                            size: 20.r,
                          ),
                          SizedBox(width: 10.w),
                          Expanded(
                            child: Text(
                              state.message,
                              style: TextStyle(
                                fontSize: 12.sp,
                                color: AppColors.aqiRed,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  return Flexible(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            // _buildTextField(
                            //     'Device Code / Serial *', _codeController,
                            //     validator: (v) =>
                            //         v!.isEmpty ? 'Required' : null,
                            //     isreadOnly: true),
                            // SizedBox(height: 12.h),
                            _buildTextField(
                              'Device Custom Name *',
                              _nameController,
                              validator: (v) => v!.isEmpty ? 'Required' : null,
                            ),
                            SizedBox(height: 12.h),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildTextField(
                                      'IMEI Number *', _imeiController,
                                      inputFormatters: [
                                        FilteringTextInputFormatter.digitsOnly,
                                        LengthLimitingTextInputFormatter(15),
                                      ],
                                      validator: (v) =>
                                          // v!.isEmpty ? 'Required' : null,
                                          Validator.validateImei(v,
                                              msg: "Required")),
                                ),
                                SizedBox(width: 12.w),
                                Expanded(
                                  child: _buildTextField(
                                      'SIM Number', _simController,
                                      inputFormatters: [
                                        FilteringTextInputFormatter.digitsOnly,
                                        // LengthLimitingTextInputFormatter(16),
                                      ]),
                                ),
                              ],
                            ),
                            SizedBox(height: 12.h),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildTextField(
                                    'Firmware Version',
                                    _firmwareController,
                                  ),
                                ),
                                SizedBox(width: 12.w),
                                Expanded(
                                  child: SwitchListTile.adaptive(
                                    contentPadding: EdgeInsets.zero,
                                    title: Text(
                                      'Active State',
                                      style: TextStyle(
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    value: _active,
                                    onChanged: (val) =>
                                        setState(() => _active = val),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12.h),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    icon: const Icon(
                                      Icons.calendar_today_rounded,
                                      size: 14,
                                    ),
                                    label: Text(
                                      'Installed: ${_installationDate.day}/${_installationDate.month}/${_installationDate.year}',
                                      style: TextStyle(fontSize: 11.sp),
                                    ),
                                    onPressed: () => _selectDate(
                                      context,
                                      _installationDate,
                                      (d) => _installationDate = d,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12.w),
                                Expanded(
                                  child: OutlinedButton.icon(
                                    icon: const Icon(
                                      Icons.date_range_rounded,
                                      size: 14,
                                    ),
                                    label: Text(
                                      'Expiry: ${_expiryDate.day}/${_expiryDate.month}/${_expiryDate.year}',
                                      style: TextStyle(fontSize: 11.sp),
                                    ),
                                    onPressed: () => _selectDate(
                                      context,
                                      _expiryDate,
                                      (d) => _expiryDate = d,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 24.h),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                foregroundColor: Colors.white,
                                minimumSize: Size(double.infinity, 44.h),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.r),
                                ),
                              ),
                              onPressed: () {
                                if (_formKey.currentState!.validate()) {
                                  final newDevice = DeviceEntity(
                                    srNo: 0,
                                    deviceId: '', // Backend generates UUID
                                    deviceCode: '',
                                    deviceName: _nameController.text.trim(),
                                    imeiNo: _imeiController.text.trim(),
                                    simNo: _simController.text.trim(),
                                    firmwareVersion:
                                        _firmwareController.text.trim(),
                                    installationDate: _installationDate,
                                    expiryDate: _expiryDate,
                                    active: _active,
                                    createdAt: DateTime.now(),
                                    updatedAt: DateTime.now(),
                                  );
                                  _pendingDevice = newDevice;
                                  context
                                      .read<AdminBloc>()
                                      .add(AddDevice(newDevice));
                                }
                              },
                              child: const Text('Register Device'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController ctrl,
      {String? Function(String?)? validator,
      bool isreadOnly = false,
      List<TextInputFormatter>? inputFormatters}) {
    final colors = AppColors.of(context);
    return TextFormField(
      controller: ctrl,
      validator: validator,
      readOnly: isreadOnly,
      inputFormatters: inputFormatters,
      style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w500),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(fontSize: 12.sp, color: colors.textSecondary),
        contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.r)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.r),
            borderSide: BorderSide(color: colors.border)),
      ),
    );
  }
}
