// features/admin/presentation/pages/admin_dashboard.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:carousel_slider/carousel_slider.dart';
import '../../../../config/theme/colors.dart';
import '../../../../config/theme/map_styles.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../../shared/widgets/map_marker_helper.dart';
import '../bloc/admin_bloc.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../../../contractor/presentation/bloc/sites_bloc.dart';
import '../../../contractor/domain/repositories/sites_repository.dart';
import '../../../contractor/presentation/widgets/contractor_device_detail_sheet.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard>
    with TickerProviderStateMixin {
  Map<String, BitmapDescriptor> _customMarkers = {};
  late AnimationController _blinkingController;
  late Animation<double> _blinkingAnimation;

  // Device carousel state (matching contractor dashboard pattern)
  int _deviceCarouselIndex = 0;
  final CarouselSliderController _carouselController =
      CarouselSliderController();
  late AnimationController _bounceController;
  late Animation<double> _bounceAnimation;
  final Set<String> _expandedSiteAddresses = {};

  void _loadCustomMarkers(List<SiteEntity> sites) async {
    final Map<String, BitmapDescriptor> loadedMarkers = {};
    context.read<SitesBloc>().add(const FetchLiveData());
    for (final site in sites) {
      final aqiText = site.aqi?.toString() ?? 'Offline';
      final color = AppColors.getAqiColor(site.aqi);
      try {
        final marker = await MapMarkerHelper.createAqiMarker(aqiText, color);
        loadedMarkers[site.id] = marker;
      } catch (e) {
        debugPrint('Error generating custom marker: $e');
      }
    }
    if (mounted) {
      setState(() {
        _customMarkers = loadedMarkers;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    context.read<AdminBloc>().add(LoadAdminDashboard());
    context.read<SitesBloc>().add(LoadSites());

    // Load initial markers if Bloc already has data loaded
    final sitesState = context.read<SitesBloc>().state;
    if (sitesState is SitesLoaded) {
      _loadCustomMarkers(sitesState.sites);
    }

    // Initialize blinking controller and animation
    _blinkingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
    _blinkingAnimation =
        Tween<double>(begin: 0.2, end: 1.0).animate(_blinkingController);

    // Bounce animation for map pin icon in device cards
    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _bounceAnimation = Tween<double>(begin: 0.0, end: -6.0).animate(
      CurvedAnimation(parent: _bounceController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _blinkingController.dispose();
    _bounceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      // appBar: AdminDashboardAppBar(
      //     blinkingAnimation: _blinkingAnimation,
      //     onNotificationTap: () {},
      //     onProfileTap: () {}),
      appBar: AppBar(
        //in this section i want to replace -AQI name with the image add the blick effect for this image
        title: Row(
          children: [
            FadeTransition(
              opacity: _blinkingAnimation,
              child: Image.asset(
                'assets/icons/AQI.png',
                height: 30.h,
                width: 60.w,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(width: 8.w),
            Text(
              'Admin Dashboard',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16.sp,
                fontFamily: 'Poppins',
              ),
            ),
          ],
        ),

        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
            ),
            child: IconButton(
              padding: EdgeInsets.zero,
              constraints: BoxConstraints(
                minWidth: 36.r,
                minHeight: 36.r,
              ),
              icon: Icon(Icons.notifications_outlined,
                  size: 18.r, color: Colors.white),
              onPressed: () => context.push(AppRoutes.adminAlerts),
            ),
          ),
          SizedBox(width: 6.w),
          Container(
            margin: EdgeInsets.only(right: 16.w),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
            ),
            child: IconButton(
              padding: EdgeInsets.zero,
              constraints: BoxConstraints(
                minWidth: 36.r,
                minHeight: 36.r,
              ),
              icon: Icon(Icons.person_outline_rounded,
                  size: 18.r, color: Colors.white),
              onPressed: () {
                context.push(AppRoutes.adminProfile);
              },
            ),
          ),
        ],
      ),

      body: MultiBlocListener(
        listeners: [
          BlocListener<AuthBloc, AuthState>(
            listener: (context, state) {
              if (state is AuthUnauthenticated) {
                context.go(AppRoutes.login);
              }
            },
          ),
          BlocListener<SitesBloc, SitesState>(
            listener: (context, state) {
              if (state is SitesLoaded) {
                _loadCustomMarkers(state.sites);
              }
            },
          ),
        ],
        child: BlocBuilder<AdminBloc, AdminState>(
          builder: (context, state) {
            if (state is AdminLoading) {
              return const Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              );
            }
            if (state is AdminError) {
              return ErrorDisplayWidget(
                message: state.message,
                onRetry: () {
                  context.read<AdminBloc>().add(LoadAdminDashboard());
                },
              );
            }
            if (state is AdminDashboardLoaded) {
              return RefreshIndicator(
                onRefresh: () async {
                  context.read<AdminBloc>().add(LoadAdminDashboard());
                },
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding:
                      EdgeInsets.symmetric(horizontal: 10.0.w, vertical: 8.0.h),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // KPI Grid (6 Cards)
                      _buildKpiGrid(state),

                      SizedBox(height: 12.h),

                      // Horizontal Device Carousel
                      _buildDeviceCarouselSection(context),

                      SizedBox(height: 12.h),

                      // India Monitoring Map Container
                      Text(
                        'Map View',
                        style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                            color: colors.textPrimary),
                      ),
                      //SizedBox(height: 8.h),
                      _buildMapCard(context),

                      SizedBox(height: 10.h),
                    ],
                  ),
                ),
              );
            }
            return const Center(child: Text('Failed to load admin dashboard.'));
          },
        ),
      ),
    );
  }

  Widget _buildKpiGrid(AdminDashboardLoaded state) {
    final colors = AppColors.of(context);
    final list = [
      {
        //'label': 'Users',
        'val': '${state.totalContractors}',
        'color': AppColors.primary,
        'icon': Icons.people_rounded,
        'route': AppRoutes.adminContractors,
      },
      {
        //'label': 'Devices',
        'val': '${state.totalSites}',
        'color': AppColors.accent,
        'icon': Icons.router_rounded,
        'route': AppRoutes.adminDevices,
      },
      // {
      //   'label': 'Critical Devices',
      //   'val': '${state.criticalSites}',
      //   'color': AppColors.aqiRed,
      //   'icon': Icons.warning_amber_rounded,
      //   'route': '${AppRoutes.adminDevices}?filter=Offline',
      // },
      {
        // 'label': 'Sprinks ON',
        'val': '${state.activeSprinklers}',
        'color': AppColors.online,
        'icon': Icons.water_drop_rounded,
        'route': '${AppRoutes.adminDevices}?filter=Online',
      },

      // {
      //   'label': 'Active Alerts',
      //   'val': '${state.recentAlertSites.length}',
      //   'color': AppColors.aqiOrange,
      //   'icon': Icons.notifications_active_rounded,
      //   'route': AppRoutes.adminAlerts,
      // },
    ];

    return GridView.builder(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: list.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1,
        crossAxisSpacing: 4.w,
        mainAxisSpacing: 8.h,
        mainAxisExtent: 50.h,
      ),
      itemBuilder: (context, index) {
        final item = list[index];
        final color = item['color'] as Color;
        final icon = item['icon'] as IconData;
        final route = item['route'] as String;

        return GestureDetector(
          onTap: () => context.push(route),
          child: Container(
            decoration: BoxDecoration(
              color: colors.surface,
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: colors.border.withValues(alpha: 0.8)),
              boxShadow: [
                BoxShadow(
                  color: color.withValues(alpha: 0.04),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                )
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12.r),
              child: Row(
                children: [
                  // Left accent vertical color bar
                  Container(
                    width: 4.w,
                    color: color,
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                item['val'] as String,
                                style: TextStyle(
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.bold,
                                  color: colors.textPrimary,
                                ),
                              ),
                              // SizedBox(height: 10.h),
                              // Text(
                              //   item['label'] as String,
                              //   style: TextStyle(
                              //     fontSize: 11.sp,
                              //     fontWeight: FontWeight.w600,
                              //     color: colors.textSecondary,
                              //   ),
                              // ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 8.w),
                          padding: EdgeInsets.all(6.r),
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.08),
                            shape: BoxShape.circle,
                          ),
                          child: icon == Icons.water_drop_rounded &&
                                  state.activeSprinklers > 0
                              ? AnimatedSprinklerIcon(
                                  isRunning: true,
                                  size: 16.r,
                                )
                              : Icon(
                                  icon,
                                  color: color,
                                  size: 18.r,
                                ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDeviceCarouselSection(BuildContext context) {
    final colors = AppColors.of(context);
    return BlocBuilder<SitesBloc, SitesState>(
      builder: (context, state) {
        if (state is! SitesLoaded || state.sites.isEmpty) {
          return const SizedBox.shrink();
        }
        final sites = state.sites;
        // Ensure index is within range
        if (_deviceCarouselIndex >= sites.length) {
          _deviceCarouselIndex = 0;
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header row: Title + counter
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'All Devices',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: colors.textPrimary,
                  ),
                ),
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(
                        color: AppColors.primary.withValues(alpha: 0.2),
                        width: 1.r),
                  ),
                  child: Text(
                    '${_deviceCarouselIndex + 1} / ${sites.length}',
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8.h),

            // Carousel — height adjusts when address is expanded
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeInOut,
              height: _expandedSiteAddresses
                      .contains(sites[_deviceCarouselIndex].id)
                  ? 130.h
                  : 80.h,
              child: CarouselSlider.builder(
                carouselController: _carouselController,
                itemCount: sites.length,
                options: CarouselOptions(
                  height: double.infinity,
                  viewportFraction: 1.0,
                  enableInfiniteScroll: false,
                  initialPage: _deviceCarouselIndex,
                  onPageChanged: (index, reason) {
                    setState(() {
                      _deviceCarouselIndex = index;
                    });
                  },
                ),
                itemBuilder: (context, index, realIndex) {
                  final site = sites[index];
                  return Padding(
                    padding: EdgeInsets.only(top: 4.h, bottom: 4.h),
                    child: _buildDeviceIndicatorCard(context, site),
                  );
                },
              ),
            ),
            SizedBox(height: 8.h),
            Center(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    sites.length,
                    (index) => GestureDetector(
                      onTap: () => _carouselController.animateToPage(index),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        width: _deviceCarouselIndex == index ? 16.w : 6.w,
                        height: 6.h,
                        margin: EdgeInsets.symmetric(horizontal: 4.w),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(3.r),
                          color: _deviceCarouselIndex == index
                              ? AppColors.primary
                              : colors.textSecondary.withValues(alpha: 0.25),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  /// Device info card shown inside the carousel — tapping navigates to site
  /// details; the pin icon navigates to the map centered on this device.
  Widget _buildDeviceIndicatorCard(BuildContext context, SiteEntity site) {
    final colors = AppColors.of(context);
    return GestureDetector(
      onTap: () {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (sheetContext) =>
              ContractorDeviceDetailSheet(deviceId: site.id),
        );
      },
      child: ScadaCard(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      context
                          .go('${AppRoutes.adminSitesMap}?siteId=${site.id}');
                    },
                    child: AnimatedBuilder(
                      animation: _bounceAnimation,
                      builder: (context, child) {
                        return Transform.translate(
                          offset: Offset(0, _bounceAnimation.value),
                          child: child,
                        );
                      },
                      child: Icon(Icons.pin_drop_rounded,
                          color: AppColors.primary, size: 28.r),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          site.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.bold,
                            color: colors.textPrimary,
                          ),
                        ),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final span = TextSpan(
                              text: site.address,
                              style: TextStyle(
                                fontSize: 11.sp,
                                color: colors.textSecondary,
                                fontWeight: FontWeight.w500,
                              ),
                            );
                            final tp = TextPainter(
                              text: span,
                              maxLines: 1,
                              textDirection: TextDirection.ltr,
                            );
                            tp.layout(maxWidth: constraints.maxWidth);
                            final isOverflowing = tp.didExceedMaxLines;
                            final isExpanded =
                                _expandedSiteAddresses.contains(site.id);

                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  site.address,
                                  maxLines: isExpanded ? null : 1,
                                  overflow: isExpanded
                                      ? TextOverflow.visible
                                      : TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 11.sp,
                                    color: colors.textSecondary,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                if (isOverflowing)
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        if (isExpanded) {
                                          _expandedSiteAddresses
                                              .remove(site.id);
                                        } else {
                                          _expandedSiteAddresses.add(site.id);
                                        }
                                      });
                                    },
                                    child: Padding(
                                      padding: EdgeInsets.only(top: 2.h),
                                      child: Text(
                                        isExpanded ? 'See Less' : 'See More',
                                        style: TextStyle(
                                          fontSize: 10.sp,
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 12.w),
            IconButton(
              onPressed: () {
                context.push('/admin/sites/${site.id}');
              },
              icon: AnimatedEyeIcon(
                color: AppColors.primary,
                size: 20.r,
              ),
              constraints: const BoxConstraints(),
              padding: EdgeInsets.all(8.r),
              style: IconButton.styleFrom(
                backgroundColor: AppColors.primary.withValues(alpha: 0.08),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.r),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMapCard(BuildContext context) {
    return ScadaCard(
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16.r),
        child: SizedBox(
          height: 250.h,
          child: Stack(
            children: [
              BlocBuilder<SitesBloc, SitesState>(
                builder: (context, state) {
                  List<SiteEntity> sites = [];
                  if (state is SitesLoaded) {
                    sites = state.sites;
                  }

                  final markers = sites.map((site) {
                    final double hue = site.aqi == null
                        ? BitmapDescriptor.hueRed
                        : (site.aqi! > 150
                            ? BitmapDescriptor.hueRed
                            : (site.aqi! > 100
                                ? BitmapDescriptor.hueOrange
                                : (site.aqi! > 50
                                    ? BitmapDescriptor.hueYellow
                                    : BitmapDescriptor.hueGreen)));

                    final customIcon = _customMarkers[site.id];

                    return Marker(
                      markerId: MarkerId(site.id),
                      position: LatLng(site.latitude, site.longitude),
                      icon: customIcon ??
                          BitmapDescriptor.defaultMarkerWithHue(hue),
                      infoWindow: InfoWindow(
                        title: site.name,
                        snippet: 'AQI: ${site.aqi ?? "Offline"}',
                      ),
                    );
                  }).toSet();

                  return GoogleMap(
                    initialCameraPosition: const CameraPosition(
                      target: LatLng(18.5204, 73.8567),
                      zoom: 11.0,
                    ),
                    markers: markers,
                    style: Theme.of(context).brightness == Brightness.dark
                        ? MapStyles.dark
                        : MapStyles.silver,
                    zoomControlsEnabled: false,
                    myLocationButtonEnabled: false,
                    zoomGesturesEnabled: false,
                    scrollGesturesEnabled: false,
                    rotateGesturesEnabled: false,
                    tiltGesturesEnabled: false,
                  );
                },
              ),
              // Glassmorphic / Premium Overlay Button to open the full interactive map screen
              Positioned.fill(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => context.go(AppRoutes.adminSitesMap),
                    child: Container(
                      padding: EdgeInsets.all(12.r),
                      alignment: Alignment.bottomRight,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 12.w, vertical: 8.h),
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(12.r),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withValues(alpha: 0.3),
                              blurRadius: 8,
                              offset: Offset(0, 3.h),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.fullscreen_rounded,
                                color: Colors.white, size: 16.r),
                            SizedBox(width: 4.w),
                            Text(
                              'Open Full Map',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
