import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../bloc/admin_bloc.dart';

class ContractorDetailsPage extends StatelessWidget {
  final String contractorId;

  const ContractorDetailsPage({super.key, required this.contractorId});

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('Contractor Profile'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, size: 20.r),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: BlocBuilder<AdminBloc, AdminState>(
          builder: (context, state) {
            // Find contractor in bloc list if loaded
            ContractorEntity? contractor;
            if (state is ContractorsLoaded) {
              contractor =
                  state.contractors.firstWhere((c) => c.id == contractorId);
            } else {
              // Fallback default
              contractor = const ContractorEntity(
                id: 'c_1',
                name: 'Contractor A',
                email: 'john@buildwell.com',
                phone: '+91 xxxxx xxxxx',
                companyName: 'BuildWell Pvt. Ltd.',
                sitesCount: 14,
              );
            }

            final isSuspended = contractor.isSuspended;

            return SingleChildScrollView(
              padding: EdgeInsets.all(24.0.r),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile Overview Header
                  ScadaCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                contractor.companyName,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                            AqiStatusChip(
                              label: isSuspended ? 'SUSPENDED' : 'ACTIVE',
                              color: isSuspended
                                  ? AppColors.aqiRed
                                  : AppColors.online,
                            ),
                          ],
                        ),
                        SizedBox(height: 8.h),
                        Text('Representative: ${contractor.name}',
                            style: TextStyle(
                                fontSize: 13.sp,
                                color: AppColors.textSecondary)),
                        Text('Email: ${contractor.email}',
                            style: TextStyle(
                                fontSize: 12.sp,
                                color: AppColors.textSecondary)),
                        Text('Phone: ${contractor.phone}',
                            style: TextStyle(
                                fontSize: 12.sp,
                                color: AppColors.textSecondary)),
                      ],
                    ),
                  ),

                  SizedBox(height: 20.h),

                  // Summary grid
                  Text('Platform Statistics',
                      style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary)),
                  SizedBox(height: 12.h),
                  Row(
                    children: [
                      Expanded(
                        child: ScadaCard(
                          padding: EdgeInsets.all(12.r),
                          child: Column(
                            children: [
                              Text('Total Devices',
                                  style: TextStyle(
                                      fontSize: 11.sp,
                                      color: AppColors.textSecondary)),
                              SizedBox(height: 6.h),
                              Text('${contractor.sitesCount}',
                                  style: TextStyle(
                                      fontSize: 20.sp,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.primary)),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: ScadaCard(
                          padding: EdgeInsets.all(12.r),
                          child: Column(
                            children: [
                              Text('Online Devices',
                                  style: TextStyle(
                                      fontSize: 11.sp,
                                      color: AppColors.textSecondary)),
                              SizedBox(height: 6.h),
                              Text('${contractor.sitesCount - 1}',
                                  style: TextStyle(
                                      fontSize: 20.sp,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.online)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 24.h),

                  Text('Associated Sites List',
                      style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary)),
                  SizedBox(height: 12.h),
                  _buildSitesList(context),

                  SizedBox(height: 32.h),

                  // Administrative Actions
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isSuspended
                            ? AppColors.online
                            : const Color(0xFFFEF2F2),
                        foregroundColor:
                            isSuspended ? Colors.white : AppColors.aqiRed,
                        elevation: 0,
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                          side: BorderSide(
                            color: isSuspended
                                ? AppColors.online
                                : const Color(0xFFFEE2E2),
                            width: 1.5.r,
                          ),
                        ),
                      ),
                      onPressed: () {
                        context.read<AdminBloc>().add(SuspendContractor(
                              contractorId: contractorId,
                              suspend: !isSuspended,
                            ));
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(isSuspended
                                ? 'Contractor Reactivated!'
                                : 'Contractor Suspended!'),
                            backgroundColor: isSuspended
                                ? AppColors.online
                                : AppColors.aqiRed,
                          ),
                        );
                        context.pop();
                      },
                      child: Text(
                        isSuspended
                            ? 'Reactivate Profile'
                            : 'Suspend Contractor',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(height: 40.h),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildSitesList(BuildContext context) {
    final sites = [
      {
        'name': 'Construction Site A',
        'address': 'Sector 63, Noida',
        'aqi': '319 (Very Poor)'
      },
      {
        'name': 'Plant 2 - Area B',
        'address': 'Phase II, Noida',
        'aqi': '72 (Moderate)'
      },
      {
        'name': 'Factory Site C',
        'address': 'Sector 82, Noida',
        'aqi': '126 (Poor)'
      },
    ];

    return Column(
      children: sites.map((s) {
        return Container(
          margin: EdgeInsets.only(bottom: 10.h),
          padding: EdgeInsets.all(14.r),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s['name']!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 13.sp,
                            color: AppColors.textPrimary)),
                    Text(s['address']!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 11.sp, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Text(
                s['aqi']!,
                style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
