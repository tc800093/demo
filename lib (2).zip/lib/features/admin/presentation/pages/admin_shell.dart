// features/admin/presentation/pages/admin_shell.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../config/theme/colors.dart';

class AdminShell extends StatelessWidget {
  final Widget child;

  const AdminShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: child,
      bottomNavigationBar: Builder(
        builder: (context) {
          final colors = AppColors.of(context);
          return Container(
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: colors.border, width: 1)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.02),
                  blurRadius: 10,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: BottomNavigationBar(
              currentIndex: _getSelectedIndex(context),
              onTap: (index) => _onItemTapped(index, context),
              type: BottomNavigationBarType.fixed,
              backgroundColor: AppColors.primary,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.white.withValues(alpha: 0.6),
              selectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                fontFamily: 'Poppins',
              ),
              unselectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 12,
                  fontFamily: 'Poppins'),
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.dashboard_outlined),
                  activeIcon: Icon(Icons.dashboard_rounded),
                  label: 'Dashboard',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.people_outline_rounded),
                  activeIcon: Icon(Icons.people_rounded),
                  label: 'Users',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.view_list_outlined),
                  activeIcon: Icon(Icons.view_list_rounded),
                  label: 'All Devices',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.place_outlined),
                  activeIcon: Icon(Icons.place_rounded),
                  label: 'Map view',
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  int _getSelectedIndex(BuildContext context) {
    final state = GoRouterState.of(context);
    final location = state.matchedLocation;

    if (location.startsWith('/admin/dashboard')) return 0;
    if (location.startsWith('/admin/contractors')) return 1;
    if (location.startsWith('/admin/devices')) return 2;
    if (location.startsWith('/admin/sites')) return 3;
    return 0;
  }

  void _onItemTapped(int index, BuildContext context) {
    switch (index) {
      case 0:
        context.go('/admin/dashboard');
        break;
      case 1:
        context.go('/admin/contractors');
        break;
      case 2:
        context.go('/admin/devices');
        break;
      case 3:
        context.go('/admin/sites');
        break;
    }
  }
}
