import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../../contractor/domain/repositories/sites_repository.dart';
import '../../domain/entities/contractor_entity.dart';
import '../../domain/entities/device_entity.dart';
import '../../domain/repositories/admin_repository.dart';
import '../../../customer/domain/repositories/customer_repository.dart';
import '../../../auth/domain/repositories/auth_repository.dart';
import '../../../../core/di/injection.dart';

export '../../domain/entities/contractor_entity.dart';
export '../../domain/entities/device_entity.dart';

// --- Events ---
abstract class AdminEvent extends Equatable {
  const AdminEvent();

  @override
  List<Object?> get props => [];
}

class LoadAdminDashboard extends AdminEvent {}

class ClearAdminCache extends AdminEvent {}

class LoadContractors extends AdminEvent {}

class SuspendContractor extends AdminEvent {
  final String contractorId;
  final bool suspend;

  const SuspendContractor({required this.contractorId, required this.suspend});

  @override
  List<Object?> get props => [contractorId, suspend];
}

class AddContractor extends AdminEvent {
  final ContractorEntity contractor;

  const AddContractor(this.contractor);

  @override
  List<Object?> get props => [contractor];
}

class LoadDevices extends AdminEvent {
  final int page;
  final int size;
  final String? search;

  const LoadDevices({
    required this.page,
    required this.size,
    this.search,
  });

  @override
  List<Object?> get props => [page, size, search];
}

class AddDevice extends AdminEvent {
  final DeviceEntity device;
  final bool isDeviceReactivate;

  const AddDevice(this.device, {this.isDeviceReactivate = false});

  @override
  List<Object?> get props => [device, isDeviceReactivate];
}

class UpdateDevice extends AdminEvent {
  final DeviceEntity device;

  const UpdateDevice(this.device);

  @override
  List<Object?> get props => [device];
}

class LoadDeviceDetail extends AdminEvent {
  final String deviceId;

  const LoadDeviceDetail(this.deviceId);

  @override
  List<Object?> get props => [deviceId];
}

// --- States ---
abstract class AdminState extends Equatable {
  const AdminState();

  @override
  List<Object?> get props => [];
}

class AdminInitial extends AdminState {}

class AdminLoading extends AdminState {}

class AdminDashboardLoaded extends AdminState {
  final int totalContractors;
  final int totalSites;
  final int criticalSites;
  final int totalDevices;
  final int activeSprinklers;
  final List<SiteEntity> recentAlertSites;

  const AdminDashboardLoaded({
    required this.totalContractors,
    required this.totalSites,
    required this.criticalSites,
    required this.totalDevices,
    required this.activeSprinklers,
    required this.recentAlertSites,
  });

  @override
  List<Object?> get props => [
        totalContractors,
        totalSites,
        criticalSites,
        totalDevices,
        activeSprinklers,
        recentAlertSites,
      ];
}

class ContractorsLoaded extends AdminState {
  final List<ContractorEntity> contractors;

  const ContractorsLoaded(this.contractors);

  @override
  List<Object?> get props => [contractors];
}

class DevicesLoaded extends AdminState {
  final List<DeviceEntity> devices;
  final int currentPage;
  final int pageSize;
  final int totalItems;
  final int totalPages;
  final String? searchQuery;
  final int totalActive;
  final int totalInactive;

  const DevicesLoaded({
    required this.devices,
    required this.currentPage,
    required this.pageSize,
    required this.totalItems,
    required this.totalPages,
    this.searchQuery,
    required this.totalActive,
    required this.totalInactive,
  });

  @override
  List<Object?> get props => [
        devices,
        currentPage,
        pageSize,
        totalItems,
        totalPages,
        searchQuery,
        totalActive,
        totalInactive,
      ];
}

class DeviceDetailLoaded extends AdminState {
  final DeviceEntity device;

  const DeviceDetailLoaded(this.device);

  @override
  List<Object?> get props => [device];
}

class AdminActionSuccess extends AdminState {}

class AdminError extends AdminState {
  final String message;

  const AdminError(this.message);

  @override
  List<Object?> get props => [message];
}

class DeviceDuplicateState extends AdminState {
  final String message;
  final bool isCurrentlyActive;
  final DeviceEntity existingDevice;

  const DeviceDuplicateState({
    required this.message,
    required this.isCurrentlyActive,
    required this.existingDevice,
  });

  @override
  List<Object?> get props => [message, isCurrentlyActive, existingDevice];
}

// --- Bloc ---
class AdminBloc extends Bloc<AdminEvent, AdminState> {
  final SitesRepository _sitesRepository;
  final AdminRepository _adminRepository;
  final List<ContractorEntity> _contractors = [];
  AdminDashboardLoaded? _cachedDashboard;

  List<ContractorEntity> get contractors => _contractors;

  AdminBloc(this._sitesRepository, this._adminRepository) : super(AdminInitial()) {
    on<LoadAdminDashboard>(_onLoadAdminDashboard);
    on<LoadContractors>(_onLoadContractors);
    on<SuspendContractor>(_onSuspendContractor);
    on<AddContractor>(_onAddContractor);
    on<LoadDevices>(_onLoadDevices);
    on<AddDevice>(_onAddDevice);
    on<UpdateDevice>(_onUpdateDevice);
    on<LoadDeviceDetail>(_onLoadDeviceDetail);
    on<ClearAdminCache>(_onClearAdminCache);
  }

  void _onClearAdminCache(ClearAdminCache event, Emitter<AdminState> emit) {
    _cachedDashboard = null;
    _contractors.clear();
    emit(AdminInitial());
  }

  Future<void> _onLoadAdminDashboard(
      LoadAdminDashboard event, Emitter<AdminState> emit) async {
    if (_cachedDashboard != null) {
      emit(_cachedDashboard!);
    } else {
      emit(AdminLoading());
    }
    try {
      final customers = await getIt<CustomerRepository>().getCustomers(page: 0, size: 200);
      final contractorsList = customers.map((c) => ContractorEntity(
        id: c.customerId,
        name: c.fullName,
        email: c.email,
        phone: c.mobileNo,
        companyName: c.firmName ?? '',
        sitesCount: 0,
        isSuspended: !c.active,
      )).toList();
      _contractors.clear();
      _contractors.addAll(contractorsList);

      final sites = await _sitesRepository.getSites();

      // Fetch devices from real API to count total devices
      final devicesResponse = await _adminRepository.getDevices(page: 0, size: 100);

      final critical = sites.where((s) => s.aqi != null && s.aqi! > 200).length;
      final totalDevices = devicesResponse.totalItems;
      final activeSprinklers = sites.where((s) => s.isSprinklerRunning).length;

      final loadedState = AdminDashboardLoaded(
        totalContractors: _contractors.length,
        totalSites: sites.length,
        criticalSites: critical,
        totalDevices: totalDevices,
        activeSprinklers: activeSprinklers,
        recentAlertSites:
            sites.where((s) => s.aqi != null && s.aqi! > 100).toList(),
      );
      _cachedDashboard = loadedState;
      emit(loadedState);
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onLoadContractors(
      LoadContractors event, Emitter<AdminState> emit) async {
    emit(AdminLoading());
    try {
      final customers = await getIt<CustomerRepository>().getCustomers(page: 0, size: 200);
      final contractorsList = customers.map((c) => ContractorEntity(
        id: c.customerId,
        name: c.fullName,
        email: c.email,
        phone: c.mobileNo,
        companyName: c.firmName ?? '',
        sitesCount: 0,
        isSuspended: !c.active,
      )).toList();
      _contractors.clear();
      _contractors.addAll(contractorsList);
      emit(ContractorsLoaded(List.unmodifiable(_contractors)));
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onSuspendContractor(
      SuspendContractor event, Emitter<AdminState> emit) async {
    _cachedDashboard = null; // Clear cached dashboard metrics
    emit(AdminLoading());
    try {
      final customerRepo = getIt<CustomerRepository>();
      final customer = await customerRepo.getCustomerDetails(event.contractorId);
      final updatedCustomer = customer.copyWith(active: !event.suspend);
      await customerRepo.updateCustomer(updatedCustomer);

      final customers = await customerRepo.getCustomers(page: 0, size: 200);
      final contractorsList = customers.map((c) => ContractorEntity(
        id: c.customerId,
        name: c.fullName,
        email: c.email,
        phone: c.mobileNo,
        companyName: c.firmName ?? '',
        sitesCount: 0,
        isSuspended: !c.active,
      )).toList();
      _contractors.clear();
      _contractors.addAll(contractorsList);
      emit(AdminActionSuccess());
      emit(ContractorsLoaded(List.unmodifiable(_contractors)));
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onAddContractor(
      AddContractor event, Emitter<AdminState> emit) async {
    _cachedDashboard = null; // Clear cached dashboard metrics
    emit(AdminLoading());
    try {
      final customerRepo = getIt<CustomerRepository>();
      await customerRepo.saveCustomer(
        fullName: event.contractor.name,
        firmName: event.contractor.companyName,
        mobileNo: event.contractor.phone,
        email: event.contractor.email,
        password: 'defaultPassword123',
        role: UserRole.user,
        active: !event.contractor.isSuspended,
      );

      final customers = await customerRepo.getCustomers(page: 0, size: 200);
      final contractorsList = customers.map((c) => ContractorEntity(
        id: c.customerId,
        name: c.fullName,
        email: c.email,
        phone: c.mobileNo,
        companyName: c.firmName ?? '',
        sitesCount: 0,
        isSuspended: !c.active,
      )).toList();
      _contractors.clear();
      _contractors.addAll(contractorsList);
      emit(AdminActionSuccess());
      emit(ContractorsLoaded(List.unmodifiable(_contractors)));
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onLoadDevices(
      LoadDevices event, Emitter<AdminState> emit) async {
    emit(AdminLoading());
    try {
      final response = await _adminRepository.getDevices(
        page: event.page,
        size: event.size,
        search: event.search,
      );

      // Fetch all devices matching the search query to get accurate active and inactive counts for filter indicators
      final allResponse = await _adminRepository.getDevices(
        page: 0,
        size: 1000,
        search: event.search,
      );
      final totalActive = allResponse.devices.where((d) => d.active).length;
      final totalInactive = allResponse.devices.where((d) => !d.active).length;

      emit(DevicesLoaded(
        devices: response.devices,
        currentPage: response.currentPage,
        pageSize: response.pageSize,
        totalItems: response.totalItems,
        totalPages: response.totalPages,
        searchQuery: event.search,
        totalActive: totalActive,
        totalInactive: totalInactive,
      ));
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onAddDevice(
      AddDevice event, Emitter<AdminState> emit) async {
    _cachedDashboard = null; // Reset cached dashboard so totals recalculate
    emit(AdminLoading());
    try {
      await _adminRepository.createDevice(event.device, isDeviceReactivate: event.isDeviceReactivate);

      String customerName = 'Unknown';
      if (event.device.customerId != null && event.device.customerId!.isNotEmpty) {
        try {
          final customerRepo = getIt<CustomerRepository>();
          final customer = await customerRepo.getCustomerDetails(event.device.customerId!);
          customerName = customer.fullName;
        } catch (e) {
          debugPrint('Error fetching customer details for SiteEntity: $e');
        }
      }

      final newSite = SiteEntity(
        id: event.device.deviceId.isNotEmpty ? event.device.deviceId : 'site_${DateTime.now().millisecondsSinceEpoch}',
        name: (event.device.siteName != null && event.device.siteName!.isNotEmpty)
            ? event.device.siteName!
            : event.device.deviceName,
        projectName: event.device.projectName ?? '',
        projectType: 'Construction',
        address: event.device.address ?? '',
        latitude: event.device.latitude ?? 18.5204,
        longitude: event.device.longitude ?? 73.8567,
        contractorId: event.device.customerId ?? '',
        contractorName: customerName,
        aqi: 55,
        parameters: const {
          'PM1': SensorReading(12, 'µg/m³'),
          'PM2.5': SensorReading(35, 'µg/m³'),
          'PM10': SensorReading(45, 'µg/m³'),
          'TSP': SensorReading(60, 'µg/m³'),
          'Temp': SensorReading(26.0, '°C'),
          'Humidity': SensorReading(60, '%'),
          'CO': SensorReading(0.1, 'ppm'),
          'CO₂': SensorReading(360, 'ppm'),
          'NO₂': SensorReading(8, 'ppb'),
          'SO₂': SensorReading(4, 'ppb'),
          'O₃': SensorReading(20, 'ppb'),
          'VOC': SensorReading(0.1, 'ppm'),
        },
        deviceSerial: event.device.deviceCode,
        imeiNo: event.device.imeiNo,
        isDeviceOnline: true,
        signalStrength: 85,
        batteryLevel: 100,
        isGpsConnected: true,
        is4gConnected: true,
        firmwareVersion: event.device.firmwareVersion,
        lastSyncTime: DateTime.now(),
        sprinklerMode: 'Auto',
        isSprinklerRunning: false,
        sprinklerRunDurationMinutes: 0,
        sprinklerHistory: const [],
        maintenanceHistory: const [],
        calibrationHistory: const [],
      );

      await _sitesRepository.addSite(newSite);
      emit(AdminActionSuccess());
    } on DeviceDuplicateException catch (e) {
      emit(DeviceDuplicateState(
        message: e.message,
        isCurrentlyActive: e.isCurrentlyActive,
        existingDevice: e.existingDevice,
      ));
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onUpdateDevice(
      UpdateDevice event, Emitter<AdminState> emit) async {
    emit(AdminLoading());
    try {
      await _adminRepository.updateDevice(event.device);
      emit(AdminActionSuccess());
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }

  Future<void> _onLoadDeviceDetail(
      LoadDeviceDetail event, Emitter<AdminState> emit) async {
    emit(AdminLoading());
    try {
      final device = await _adminRepository.getDeviceDetail(event.deviceId);
      emit(DeviceDetailLoaded(device));
    } catch (e) {
      emit(AdminError(AppException.from(e).toString()));
    }
  }
}
