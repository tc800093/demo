import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vasundhara_maha_aqim/config/theme/colors.dart';

class AdminDashboardAppBar extends StatelessWidget
    implements PreferredSizeWidget {
  final Animation<double> blinkingAnimation;
  final VoidCallback onNotificationTap;
  final VoidCallback onProfileTap;

  const AdminDashboardAppBar({
    super.key,
    required this.blinkingAnimation,
    required this.onNotificationTap,
    required this.onProfileTap,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.primary,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      titleSpacing: 16.w,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          /// Blinking AQI Logo
          FadeTransition(
            opacity: blinkingAnimation,
            child: Image.asset(
              'assets/icons/AQI.png',
              height: 30.h,
              width: 60.w,
              fit: BoxFit.contain,
            ),
          ),
          SizedBox(width: 10.w),

          /// Title Text
          Expanded(
            child: Text(
              'Admin Dashboard',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 18.sp,
                fontFamily: 'Poppins',
                color: Colors.white,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ],
      ),
      actions: [
        /// Notification Icon Button
        _buildActionButton(
          icon: Icons.notifications_outlined,
          onPressed: onNotificationTap,
        ),
        SizedBox(width: 8.w),

        /// Profile Icon Button
        _buildActionButton(
          icon: Icons.person_outline_rounded,
          onPressed: onProfileTap,
        ),
        SizedBox(width: 16.w),
      ],
    );
  }

  /// Reusable Styled Action Button
  Widget _buildActionButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      width: 38.r,
      height: 38.r,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.25),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12.r),
          onTap: onPressed,
          child: Center(
            child: Icon(
              icon,
              size: 20.r,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
