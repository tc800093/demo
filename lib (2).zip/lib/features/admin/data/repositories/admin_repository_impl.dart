import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_config.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../domain/entities/contractor_entity.dart';
import '../../domain/entities/device_entity.dart';
import '../../domain/repositories/admin_repository.dart';
import '../models/device_model.dart';

class AdminRepositoryImpl implements AdminRepository {
  final ApiClient _apiClient;

  // Local list to persist mock contractors operations during session
  final List<ContractorEntity> _localContractors = [];

  AdminRepositoryImpl(this._apiClient) {
    // _initMockContractors();
  }

  void _initMockContractors() {
    _localContractors.addAll([
      const ContractorEntity(
          id: 'c_1',
          name: 'Contractor 1',
          email: 'contractor1@buildwell.com',
          phone: '+91 98765 00001',
          companyName: 'BuildWell Pvt. Ltd.',
          sitesCount: 14),
      const ContractorEntity(
          id: 'c_2',
          name: 'Contractor 2',
          email: 'contractor2@greeninfra.com',
          phone: '+91 98765 00002',
          companyName: 'Green Infra',
          sitesCount: 11),
      const ContractorEntity(
          id: 'c_3',
          name: 'Contractor 3',
          email: 'contractor3@urbanbuild.com',
          phone: '+91 98765 00003',
          companyName: 'Urban Builders',
          sitesCount: 9),
      const ContractorEntity(
          id: 'c_4',
          name: 'Contractor 4',
          email: 'contractor4@happyconst.com',
          phone: '+91 98765 00004',
          companyName: 'Happy Construction',
          sitesCount: 7),
    ]);
  }

  @override
  Future<List<ContractorEntity>> getContractors() async {
    // Return the current local memory contractors list.
    // This will be replaced with real API once provided.
    await Future.delayed(const Duration(milliseconds: 200));
    return List.unmodifiable(_localContractors);
  }

  @override
  Future<void> suspendContractor(String contractorId, bool suspend) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final index = _localContractors.indexWhere((c) => c.id == contractorId);
    if (index != -1) {
      _localContractors[index] =
          _localContractors[index].copyWith(isSuspended: suspend);
    } else {
      throw AppException('Contractor not found');
    }
  }

  @override
  Future<void> addContractor(ContractorEntity contractor) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _localContractors.add(contractor);
  }

  @override
  Future<PaginatedDevicesResponse> getDevices({
    required int page,
    required int size,
    String? search,
  }) async {
    final url = ApiConfig.getDeviceList(page, size, search: search);
    try {
      final response = await _apiClient.dio.get(url);
      if (response.statusCode == 200 && response.data != null) {
        final Map<String, dynamic> responseData =
            response.data as Map<String, dynamic>;

        final List<dynamic> listJson =
            responseData['devices'] as List<dynamic>? ??
                responseData['data'] as List<dynamic>? ??
                [];
        final List<DeviceEntity> devices = listJson
            .map((item) => DeviceModel.fromJson(item as Map<String, dynamic>))
            .toList();

        final int currentPage = responseData['current_page'] as int? ?? page;
        final int pageSize = responseData['page_size'] as int? ?? size;
        final int totalItems =
            responseData['total_items'] as int? ?? devices.length;
        final int totalPages = responseData['total_pages'] as int? ?? 1;

        return PaginatedDevicesResponse(
          devices: devices,
          currentPage: currentPage,
          pageSize: pageSize,
          totalItems: totalItems,
          totalPages: totalPages,
        );
      } else {
        throw AppException(
            'Failed to fetch devices: Server returned status ${response.statusCode}');
      }
    } catch (e) {
      throw AppException.from(e, 'Error loading devices');
    }
  }

  @override
  Future<DeviceEntity> getDeviceDetail(String deviceId) async {
    final url = ApiConfig.getDeviceDetail(deviceId);
    try {
      final response = await _apiClient.dio.get(url);
      if (response.statusCode == 200 && response.data != null) {
        final Map<String, dynamic> responseData =
            response.data as Map<String, dynamic>;
        final Map<String, dynamic> deviceJson =
            responseData['data'] as Map<String, dynamic>? ?? responseData;
        return DeviceModel.fromJson(deviceJson);
      } else {
        throw AppException(
            'Failed to load device details: Server returned status ${response.statusCode}');
      }
    } catch (e) {
      throw AppException.from(e, 'Error loading device details');
    }
  }

  @override
  Future<void> createDevice(DeviceEntity device, {bool isDeviceReactivate = false}) async {
    final url = ApiConfig.createDeviceUrl(isDeviceReactivate: isDeviceReactivate);
    final model = DeviceModel(
      srNo: device.srNo,
      deviceId: device.deviceId,
      deviceCode: device.deviceCode,
      deviceName: device.deviceName,
      imeiNo: device.imeiNo,
      simNo: device.simNo,
      firmwareVersion: device.firmwareVersion,
      installationDate: device.installationDate,
      expiryDate: device.expiryDate,
      active: device.active,
      createdAt: device.createdAt,
      updatedAt: device.updatedAt,
      customerId: device.customerId,
      siteName: device.siteName,
      projectName: device.projectName,
      latitude: device.latitude,
      longitude: device.longitude,
      geofenceRadius: device.geofenceRadius,
      address: device.address,
      city: device.city,
      district: device.district,
      state: device.state,
      remarks: device.remarks,
    );
    try {
      final response = await _apiClient.dio.post(url, data: model.toJson());
      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = response.data;
        if (data != null && data is Map<String, dynamic>) {
          final String? msg = data['message'] as String?;
          if (msg != null && msg.contains('Device already exists')) {
            final details = data['deviceDetails'];
            final bool isCurrentlyActive =
                msg.toLowerCase().contains('active') &&
                !msg.toLowerCase().contains('inactive');
            throw DeviceDuplicateException(
              message: msg,
              isCurrentlyActive: isCurrentlyActive,
              existingDevice: details != null
                  ? DeviceModel.fromJson(details as Map<String, dynamic>)
                  : device,
            );
          }
        }
      }
      if (response.statusCode != 200 && response.statusCode != 201) {
        throw AppException(
            'Failed to create device: Server returned status ${response.statusCode}');
      }
    } catch (e) {
      if (e is DeviceDuplicateException) rethrow;
      throw AppException.from(e, 'Error creating device');
    }
  }

  @override
  Future<void> updateDevice(DeviceEntity device) async {
    final url = ApiConfig.updateDevice;
    final model = DeviceModel(
      srNo: device.srNo,
      deviceId: device.deviceId,
      deviceCode: device.deviceCode,
      deviceName: device.deviceName,
      imeiNo: device.imeiNo,
      simNo: device.simNo,
      firmwareVersion: device.firmwareVersion,
      installationDate: device.installationDate,
      expiryDate: device.expiryDate,
      active: device.active,
      createdAt: device.createdAt,
      updatedAt: device.updatedAt,
      customerId: device.customerId,
      siteName: device.siteName,
      projectName: device.projectName,
      latitude: device.latitude,
      longitude: device.longitude,
      geofenceRadius: device.geofenceRadius,
      address: device.address,
      city: device.city,
      district: device.district,
      state: device.state,
      remarks: device.remarks,
    );
    try {
      final jsonPayload = model.toUpdateJson();
      debugPrint('[UpdateDevice] PUT $url');
      debugPrint('[UpdateDevice] Payload: $jsonPayload');
      final response = await _apiClient.dio.put(url, data: jsonPayload);
      debugPrint('[UpdateDevice] Response status=${response.statusCode}');
      
      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = response.data;
        if (data is Map<String, dynamic>) {
          final message = data['message']?.toString();
          if (message != null && message.contains('Unable to')) {
            throw AppException(message);
          }
        }
      } else {
        String errorMsg = 'Failed to update device';
        final data = response.data;
        if (data is Map<String, dynamic>) {
          if (data['message'] != null) {
            errorMsg = data['message'].toString();
            if (data['errors'] != null && data['errors'] is Map) {
              final errors = data['errors'] as Map;
              final errorDetails = errors.entries.map((e) => '${e.key}: ${e.value}').join(', ');
              errorMsg = '$errorMsg ($errorDetails)';
            }
          }
        } else {
          errorMsg = 'Failed to update device: Server returned status ${response.statusCode}';
        }
        throw AppException(errorMsg);
      }
    } catch (e) {
      throw AppException.from(e, 'Error updating device');
    }
  }
}
