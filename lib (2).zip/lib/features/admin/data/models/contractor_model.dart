import '../../domain/entities/contractor_entity.dart';

class ContractorModel extends ContractorEntity {
  const ContractorModel({
    required super.id,
    required super.name,
    required super.email,
    required super.phone,
    required super.companyName,
    required super.sitesCount,
    super.isSuspended = false,
  });

  factory ContractorModel.fromJson(Map<String, dynamic> json) {
    return ContractorModel(
      id: json['id']?.toString() ?? json['contractorId']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      companyName: json['companyName']?.toString() ?? json['company_name']?.toString() ?? '',
      sitesCount: json['sitesCount'] as int? ?? json['sites_count'] as int? ?? 0,
      isSuspended: json['isSuspended'] as bool? ?? json['is_suspended'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'companyName': companyName,
      'sitesCount': sitesCount,
      'isSuspended': isSuspended,
    };
  }
}
