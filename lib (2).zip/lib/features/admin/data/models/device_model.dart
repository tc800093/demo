import '../../domain/entities/device_entity.dart';

class DeviceModel extends DeviceEntity {
  const DeviceModel({
    required super.srNo,
    required super.deviceId,
    required super.deviceCode,
    required super.deviceName,
    required super.imeiNo,
    required super.simNo,
    required super.firmwareVersion,
    super.installationDate,
    super.expiryDate,
    required super.active,
    super.createdAt,
    super.updatedAt,
    super.customerId,
    super.siteName,
    super.projectName,
    super.latitude,
    super.longitude,
    super.geofenceRadius,
    super.address,
    super.city,
    super.district,
    super.state,
    super.remarks,
    super.userName,
    super.firmName,
    super.mobileNo,
    super.email,
  });

  static DateTime? _parseDateTime(dynamic v) {
    if (v == null) return null;
    return DateTime.tryParse(v.toString());
  }

  static double? _parseDouble(dynamic v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }

  static int? _parseInt(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString());
  }

  factory DeviceModel.fromJson(Map<String, dynamic> json) {
    return DeviceModel(
      srNo: _parseInt(json['sr_no']) ?? 0,
      deviceId: json['device_id']?.toString() ?? '',
      deviceCode: json['device_code']?.toString() ?? '',
      deviceName: json['device_name']?.toString() ?? '',
      imeiNo: json['imei_no']?.toString() ?? '',
      simNo: json['sim_no']?.toString() ?? '',
      firmwareVersion: json['firmware_version']?.toString() ?? '',
      installationDate: _parseDateTime(json['installation_date']),
      expiryDate: _parseDateTime(json['expiry_date']),
      active: json['active'] as bool? ?? true,
      createdAt: _parseDateTime(json['created_at']),
      updatedAt: _parseDateTime(json['updated_at']),
      customerId:
          json['customer_id']?.toString() ?? json['created_by']?.toString(),
      siteName: json['site_name']?.toString(),
      projectName: json['project_name']?.toString(),
      latitude: _parseDouble(json['latitude']),
      longitude: _parseDouble(json['longitude']),
      geofenceRadius: _parseInt(json['geofence_radius']),
      address: json['address']?.toString(),
      city: json['city']?.toString(),
      district: json['district']?.toString(),
      state: json['state']?.toString(),
      remarks: json['remarks']?.toString(),
      userName: (json['user_name'] ?? json['full_name'])?.toString(),
      firmName: json['firm_name']?.toString(),
      mobileNo: json['mobile_no']?.toString(),
      email: json['email']?.toString(),
    );
  }

  static String? _formatLocalDateTime(DateTime? dt) {
    if (dt == null) return null;
    final year = dt.year;
    final month = dt.month.toString().padLeft(2, '0');
    final day = dt.day.toString().padLeft(2, '0');
    final hour = dt.hour.toString().padLeft(2, '0');
    final minute = dt.minute.toString().padLeft(2, '0');
    final second = dt.second.toString().padLeft(2, '0');
    return '$year-$month-${day}T$hour:$minute:$second';
  }

  Map<String, dynamic> toJson() {
    return {
      'sr_no': srNo,
      if (deviceId.isNotEmpty) 'device_id': deviceId,
      'device_code': null,
      'device_name': deviceName,
      'imei_no': imeiNo,
      'sim_no': simNo,
      'firmware_version': firmwareVersion,
      'installation_date': _formatLocalDateTime(installationDate),
      'expiry_date': _formatLocalDateTime(expiryDate),
      'active': active,
      'created_at': _formatLocalDateTime(createdAt),
      'updated_at': _formatLocalDateTime(updatedAt),
      if (customerId != null) ...{
        'customer_id': customerId,
        'created_by': customerId,
        'updated_by': customerId,
      },
      if (siteName != null) 'site_name': siteName,
      if (projectName != null) 'project_name': projectName,
      if (latitude != null) 'latitude': latitude,
      if (longitude != null) 'longitude': longitude,
      if (geofenceRadius != null) 'geofence_radius': geofenceRadius,
      if (address != null) 'address': address,
      if (city != null) 'city': city,
      if (district != null) 'district': district,
      if (state != null) 'state': state,
      if (remarks != null) 'remarks': remarks,
    };
  }

  Map<String, dynamic> toUpdateJson() {
    String? emptyToNull(String? val) {
      if (val == null || val.trim().isEmpty) return null;
      return val.trim();
    }

    return {
      'device_id': emptyToNull(deviceId),
      // 'device_code': emptyToNull(deviceCode),
      'device_code': null,
      'device_name': emptyToNull(deviceName),
      'imei_no': emptyToNull(imeiNo),
      'sim_no': emptyToNull(simNo),
      'firmware_version': emptyToNull(firmwareVersion),
      'installation_date': _formatLocalDateTime(installationDate),
      'expiry_date': _formatLocalDateTime(expiryDate),
      'customer_id': emptyToNull(customerId),
      'site_name': emptyToNull(siteName),
      'project_name': emptyToNull(projectName),
      'latitude': latitude,
      'longitude': longitude,
      'geofence_radius': geofenceRadius,
      'address': emptyToNull(address),
      'city': emptyToNull(city),
      'district': emptyToNull(district),
      'state': emptyToNull(state),
      'remarks': emptyToNull(remarks),
      'active': active,
    };
  }
}
