import 'dart:async';
import 'dart:io';
import 'package:hive/hive.dart';
import 'package:vasundhara_maha_aqim/core/services/notifications/token_manager.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../../../core/di/injection.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_config.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../../../core/services/notifications/notification_service.dart';
import '../../../contractor/domain/repositories/sites_repository.dart';

/// Implementation of the [AuthRepository] contacting remote backend REST endpoints.
class AuthRepositoryImpl implements AuthRepository {
  final ApiClient _apiClient;
  final StreamController<UserEntity?> _userStreamController =
      StreamController<UserEntity?>.broadcast();
  UserEntity? _cachedUser;

  AuthRepositoryImpl(this._apiClient) {
    // Start as unauthenticated
    _userStreamController.add(null);
  }

  @override
  Stream<UserEntity?> get currentUser => _userStreamController.stream;

  UserRole _parseRole(String? roleStr) {
    if (roleStr == null) return UserRole.user;
    final clean = roleStr.toLowerCase().trim();
    if (clean == 'admin') return UserRole.admin;
    if (clean == 'subadmin' || clean == 'sub_admin') return UserRole.subAdmin;
    if (clean == 'subuser' || clean == 'sub_user') return UserRole.subUser;
    return UserRole.user;
  }

  @override
  Future<OtpResponse> sendOtp(String phone) async {
    final url = ApiConfig.authLogin;
    try {
      final response = await _apiClient.dio.post(
        url,
        data: {
          "mobileNo": phone.trim(),
          "imeiNo": "359881234567890",
          "lattitude": 18.520430,
          "longitude": 73.856743,
          "appVersionNo": "1.0.0",
        },
      );

      if (response.statusCode == 200 && response.data != null) {
        final data = response.data as Map<String, dynamic>;

        final status = data['status'] as String? ?? 'OTP_SENT';
        final message = data['message'] as String? ?? 'OTP sent';
        final otpId = data['otpId'] as String?;
        final otp = data['otp'] as String?;

        if (otpId == null) {
          throw AppException('Server did not return a valid OTP session ID.');
        }

        return OtpResponse(
          status: status,
          message: message,
          otpId: otpId,
          otp: otp,
        );
      } else {
        throw AppException(
            'Failed to request verification code. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<UserEntity> loginWithPhoneAndOtp({
    required String phone,
    required String otp,
    required String otpId,
    bool rememberMe = true,
  }) async {
    final url = ApiConfig.authValidate;
    final String? fcmToken = await TokenManager().getAndSaveToken();
    try {
      final response = await _apiClient.dio.post(
        url,
        data: {
          "otpId": otpId,
          "otp": otp,
        },
      );

      if (response.statusCode == 200 && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        final status = data['status'] as String? ?? 'SUCCESS';

        if (status != 'SUCCESS') {
          final errorMsg = data['message'] as String? ?? 'Verification failed';
          throw AppException(errorMsg);
        }

        final token = data['token'] as String?;
        if (token == null || token.isEmpty) {
          throw AppException(
              'Authentication token is missing from validation response.');
        }

        final details = data['details'] as Map<String, dynamic>?;
        if (details == null) {
          throw AppException(
              'User details are missing from validation response.');
        }

        final id = details['customerId'] as String? ??
            details['customer_id'] as String? ??
            details['id'] as String? ??
            'usr_unknown';
        final fullName = details['fullName'] as String? ?? 'No Name';
        final firmName = details['firmName'] as String?;
        final mobileNo = details['mobileNo'] as String? ?? phone;
        final email = details['email'] as String? ?? '';
        final validated = details['validated'] as bool? ?? true;
        final roleStr = details['role'] as String? ?? 'user';

        final role = _parseRole(roleStr);

        _cachedUser = UserEntity(
          id: id,
          name: fullName,
          email: email,
          phone: mobileNo,
          role: role,
          companyName: firmName,
          isProfileCompleted: validated,
        );

        // Save verification token and user details to Hive's settings box
        final box = Hive.box('settings');
        await box.put('auth_token', token);
        await box.put('is_logged_in', rememberMe);
        await box.put('user_id', id);
        await box.put('user_name', fullName);
        await box.put('user_email', email);
        await box.put('user_phone', mobileNo);
        await box.put('user_role', roleStr);
        await box.put('user_company', firmName);

        _userStreamController.add(_cachedUser);
        registoerFCMTokenRepo(userID: id, fcmToken: fcmToken.toString());
        return _cachedUser!;
      } else {
        throw AppException(
            'Failed to verify OTP code. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<UserEntity?> checkAuthStatus() async {
    if (_cachedUser != null) return _cachedUser;

    try {
      final box = Hive.box('settings');
      final token = box.get('auth_token') as String?;
      final isLoggedIn = token != null && token.isNotEmpty;
      if (isLoggedIn) {
        final phone = box.get('user_phone') as String? ?? '';
        final name = box.get('user_name') as String? ?? '';
        final email = box.get('user_email') as String? ?? '';
        final company = box.get('user_company') as String? ?? '';
        final roleStr = box.get('user_role') as String? ?? 'user';

        final role = _parseRole(roleStr);

        _cachedUser = UserEntity(
          id: box.get('user_id') as String? ??
              (role == UserRole.admin || role == UserRole.subAdmin
                  ? 'usr_admin'
                  : 'usr_user'),
          name: name,
          email: email,
          phone: phone,
          role: role,
          companyName: company,
          isProfileCompleted: true,
        );
        _userStreamController.add(_cachedUser);
        return _cachedUser;
      }
    } catch (e) {
      // ignore
    }

    return null;
  }

  @override
  Future<void> logout() async {
    await Future.delayed(const Duration(milliseconds: 500));
    _cachedUser = null;

    try {
      final box = Hive.box('settings');
      await box.delete('auth_token');
      await box.delete('is_logged_in');
      await box.delete('user_id');
      await box.delete('user_name');
      await box.delete('user_email');
      await box.delete('user_phone');
      await box.delete('user_role');
      await box.delete('user_company');

      // Clean up FCM Token on logout
      if (getIt.isRegistered<NotificationService>()) {
        await getIt<NotificationService>().tokenManager.deleteToken();
      }

      // Clear in-memory caches of singletons on logout
      if (getIt.isRegistered<SitesRepository>()) {
        getIt<SitesRepository>().clearCache();
      }
    } catch (e) {
      // ignore
    }
    getIt<SitesRepository>().disconnectWebSocket();

    _userStreamController.add(null);
  }

  @override
  Future<bool> registoerFCMTokenRepo(
      {required String userID, required String fcmToken}) async {
    final url = ApiConfig.registerFCMToke();
    try {
      final response = await _apiClient.dio.post(
        url,
        data: {
          "user_id": userID,
          "fcm_token": fcmToken,
          "platform": Platform.isAndroid
              ? "ANDROID"
              : Platform.isIOS
                  ? "IOS"
                  : ""
        },
      );

      if (response.statusCode == 200 && response.data != null) {
        return true;
      } else {
        throw AppException(
            'Failed to registor fcm token. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
