// features/auth/presentation/pages/login_page.dart
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../bloc/auth_bloc.dart';
import '../widgets/footer_widget.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  final _phoneFocusNode = FocusNode();
  final _otpFocusNode = FocusNode();

  String? _phoneError;
  String? _otpError;
  String? _otpId;
  String? _receivedOtp;
  bool _rememberMe = true;
  bool _otpSent = false;

  Timer? _timer;
  int _secondsRemaining = 0;
  late AnimationController _footerAnimationController;

  @override
  void initState() {
    super.initState();
    _footerAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..forward();
    _phoneFocusNode.addListener(() {
      if (mounted) setState(() {});
    });
    _otpFocusNode.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _phoneController.dispose();
    _otpController.dispose();
    _phoneFocusNode.dispose();
    _otpFocusNode.dispose();
    _footerAnimationController.dispose();
    super.dispose();
  }

  void _startResendTimer() {
    setState(() {
      _secondsRemaining = 120;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          if (_secondsRemaining > 0) {
            _secondsRemaining--;
          } else {
            _timer?.cancel();
          }
        });
      }
    });
  }

  String _formatRemainingTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  void _submitPhone() {
    setState(() {
      _phoneError = null;
    });

    final phone = _phoneController.text.trim();

    if (phone.isEmpty) {
      setState(() {
        _phoneError = 'Please enter your mobile number';
      });
      return;
    }

    // Basic 10-digit validation
    final phoneRegex = RegExp(r'^\d{10}$');
    if (!phoneRegex.hasMatch(phone)) {
      setState(() {
        _phoneError = 'Please enter a valid 10-digit mobile number';
      });
      return;
    }

    context.read<AuthBloc>().add(AuthSendOtpRequested(phone: phone));
  }

  void _submitOtp() {
    setState(() {
      _otpError = null;
    });

    final phone = _phoneController.text.trim();
    final otp = _otpController.text.trim();

    if (otp.isEmpty) {
      setState(() {
        _otpError = 'Please enter the OTP code';
      });
      return;
    }

    if (otp.length != 6) {
      setState(() {
        _otpError = 'Please enter a 6-digit OTP code';
      });
      return;
    }

    if (_otpId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('OTP session expired. Please request OTP again.'),
          backgroundColor: AppColors.aqiRed,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.r),
          ),
        ),
      );
      return;
    }

    context.read<AuthBloc>().add(AuthLoginRequested(
          phone: phone,
          otp: otp,
          otpId: _otpId!,
          rememberMe: _rememberMe,
        ));
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      body: Stack(
        children: [
          // 1. Mesh Gradient Background
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: Theme.of(context).brightness == Brightness.light
                      ? [
                          const Color(0xFFF8FAFC),
                          const Color(0xFFF1F5F9),
                          const Color(0xFFE2E8F0),
                        ]
                      : [
                          colors.background,
                          colors.surface,
                          colors.background,
                        ],
                ),
              ),
            ),
          ),

          // Glowing Ambient Blob 1 (Top Right)
          Positioned(
            top: -80.h,
            right: -80.w,
            child: Container(
              width: 260.r,
              height: 260.r,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primary.withValues(alpha: 0.12),
              ),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 90, sigmaY: 90),
                child: Container(color: Colors.transparent),
              ),
            ),
          ),

          // Glowing Ambient Blob 2 (Bottom Left)
          Positioned(
            bottom: -100.h,
            left: -80.w,
            child: Container(
              width: 300.r,
              height: 300.r,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF0D9488).withValues(alpha: 0.08),
              ),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 100, sigmaY: 100),
                child: Container(color: Colors.transparent),
              ),
            ),
          ),

          // 2. Main Content
          Positioned.fill(
            child: BlocListener<AuthBloc, AuthState>(
              listener: (context, state) {
                if (state is AuthOtpSent) {
                  setState(() {
                    _otpSent = true;
                    _otpError = null;
                    _otpId = state.otpId;
                    _receivedOtp = state.mockOtp;
                    _otpController.clear();
                  });
                  _startResendTimer();
                  final message = state.mockOtp != null
                      ? 'Verification Code Sent. Test OTP is ${state.mockOtp}'
                      : 'Verification Code Sent.';
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(message),
                      backgroundColor: AppColors.primary,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                    ),
                  );
                } else if (state is AuthAuthenticated) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content:
                          const Text('Login Successful! Welcome to Maha AQI.'),
                      backgroundColor: AppColors.online,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                    ),
                  );
                  // Direct navigation based on authenticated role
                  context.go((state.user.role == UserRole.admin ||
                          state.user.role == UserRole.subAdmin)
                      ? AppRoutes.adminDashboard
                      : AppRoutes.contractorDashboard);
                } else if (state is AuthError) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(state.message),
                      backgroundColor: AppColors.aqiRed,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                    ),
                  );
                }
              },
              child: SafeArea(
                child: Column(
                  children: [
                    // Custom Header / AppBar back button
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.only(left: 16.w, top: 8.h),
                        child: GestureDetector(
                          onTap: () {
                            if (_otpSent) {
                              setState(() {
                                _otpSent = false;
                                _otpError = null;
                                _timer?.cancel();
                              });
                            } else {
                              context.go(AppRoutes.onboarding);
                            }
                          },
                          child: Container(
                            width: 38.r,
                            height: 38.r,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withValues(alpha: 0.85),
                              border: Border.all(
                                color: Colors.white,
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.04),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                )
                              ],
                            ),
                            child: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              size: 15.r,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ),
                    ),

                    Expanded(
                      child: AutofillGroup(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.symmetric(horizontal: 16.w),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Illustration image centered
                              Center(
                                child: Container(
                                  height: 170.h,
                                  margin:
                                      EdgeInsets.only(top: 8.h, bottom: 12.h),
                                  child: Image.asset(
                                    'assets/images/login_gif_withoutbg.gif',
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ),

                              // Glassmorphic Login Card
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 16.w, vertical: 16.h),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? AppColors.surface
                                          .withValues(alpha: 0.85)
                                      : Colors.white.withValues(alpha: 0.88),
                                  borderRadius: BorderRadius.circular(20.r),
                                  border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? AppColors.border
                                            .withValues(alpha: 0.4)
                                        : Colors.white.withValues(alpha: 0.6),
                                    width: 1.5.r,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.textPrimary
                                          .withValues(alpha: 0.04),
                                      blurRadius: 20,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _otpSent
                                          ? 'Verification Code'
                                          : 'Welcome!',
                                      style: TextStyle(
                                        fontSize: 22.sp,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textPrimary,
                                        letterSpacing: -0.3,
                                      ),
                                    ),
                                    SizedBox(height: 4.h),
                                    // Text(
                                    //   _otpSent
                                    //       ? 'Enter the 6-digit verification code sent to your phone.'
                                    //       : 'Sign in using your mobile number and verification code.',
                                    //   style: TextStyle(
                                    //     fontSize: 13.sp,
                                    //     color: AppColors.textSecondary,
                                    //     height: 1.4,
                                    //   ),
                                    // ),
                                    SizedBox(height: 12.h),
                                    if (!_otpSent) ...[
                                      // Phone Input Stage
                                      _buildTextField(
                                        controller: _phoneController,
                                        focusNode: _phoneFocusNode,
                                        label: 'Mobile Number',
                                        hint: 'Enter 10-digit number',
                                        prefixIcon: Icons.phone_iphone_rounded,
                                        obscureText: false,
                                        errorText: _phoneError,
                                        keyboardType: TextInputType.phone,
                                        autofillHints: [
                                          AutofillHints.telephoneNumberLocal
                                        ],
                                        maxLength: 10,
                                        inputFormatters: [
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          LengthLimitingTextInputFormatter(10),
                                        ],
                                        suffixIcon: _phoneController
                                                    .text.isNotEmpty &&
                                                _phoneFocusNode.hasFocus
                                            ? IconButton(
                                                icon: Icon(
                                                  Icons.clear_rounded,
                                                  size: 18.r,
                                                  color:
                                                      AppColors.textSecondary,
                                                ),
                                                onPressed: () {
                                                  _phoneController.clear();
                                                  setState(() {});
                                                },
                                              )
                                            : null,
                                      ),
                                      SizedBox(height: 14.h),

                                      // Remember Me Checkbox Row
                                      GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            _rememberMe = !_rememberMe;
                                          });
                                        },
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              height: 22.r,
                                              width: 22.r,
                                              child: Checkbox(
                                                value: _rememberMe,
                                                activeColor: AppColors.primary,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          4.r),
                                                ),
                                                materialTapTargetSize:
                                                    MaterialTapTargetSize
                                                        .shrinkWrap,
                                                visualDensity:
                                                    VisualDensity.compact,
                                                onChanged: (val) {
                                                  setState(() {
                                                    _rememberMe = val ?? false;
                                                  });
                                                },
                                              ),
                                            ),
                                            SizedBox(width: 8.w),
                                            Text(
                                              'Remember Me',
                                              style: TextStyle(
                                                fontSize: 13.sp,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.textSecondary,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      SizedBox(height: 20.h),

                                      // Send OTP Button
                                      BlocBuilder<AuthBloc, AuthState>(
                                        builder: (context, state) {
                                          return PrimaryButton(
                                            text: 'Send Verification Code',
                                            isLoading: state is AuthLoading,
                                            icon: Icons.send_rounded,
                                            onPressed: _submitPhone,
                                          );
                                        },
                                      ),
                                    ] else ...[
                                      // OTP Input Stage
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Icon(
                                                Icons.phone_iphone_rounded,
                                                size: 16.r,
                                                color: AppColors.primary,
                                              ),
                                              SizedBox(width: 4.w),
                                              Text(
                                                '+91 ${_phoneController.text}',
                                                style: TextStyle(
                                                  fontSize: 14.sp,
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.textPrimary,
                                                ),
                                              ),
                                            ],
                                          ),
                                          TextButton.icon(
                                            onPressed: () {
                                              setState(() {
                                                _otpSent = false;
                                                _otpError = null;
                                                _timer?.cancel();
                                              });
                                            },
                                            icon: Icon(Icons.edit_rounded,
                                                size: 14.r),
                                            label: Text(
                                              'Edit',
                                              style: TextStyle(fontSize: 13.sp),
                                            ),
                                            style: TextButton.styleFrom(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 8.w),
                                              tapTargetSize:
                                                  MaterialTapTargetSize
                                                      .shrinkWrap,
                                              minimumSize: Size.zero,
                                              foregroundColor:
                                                  AppColors.primary,
                                            ),
                                          ),
                                        ],
                                      ),

                                      SizedBox(height: 16.h),

                                      // OTP Fields Label
                                      Text(
                                        'OTP Verification',
                                        style: TextStyle(
                                          fontSize: 13.sp,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),

                                      SizedBox(height: 8.h),

                                      // Custom 6-digit individual box layout with transparent textfield overlay
                                      _buildOtpInputLayout(),

                                      if (_otpError != null) ...[
                                        SizedBox(height: 5.h),
                                        Padding(
                                          padding: EdgeInsets.only(left: 6.w),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.error_outline_rounded,
                                                color: AppColors.aqiRed,
                                                size: 14.r,
                                              ),
                                              SizedBox(width: 4.w),
                                              Flexible(
                                                child: Text(
                                                  _otpError!,
                                                  style: TextStyle(
                                                    color: AppColors.aqiRed,
                                                    fontSize: 11.sp,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                      SizedBox(height: 16.h),

                                      Wrap(
                                        alignment: WrapAlignment.center,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.center,
                                        children: [
                                          Text(
                                            "Didn't receive verification code? ",
                                            style: TextStyle(
                                              fontSize: 12.sp,
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                          // Spacer(),
                                          _secondsRemaining > 0
                                              ? Text(
                                                  'Resend in ${_formatRemainingTime(_secondsRemaining)}',
                                                  style: TextStyle(
                                                    fontSize: 12.sp,
                                                    fontWeight: FontWeight.w600,
                                                    color: AppColors.textMuted,
                                                  ),
                                                )
                                              : GestureDetector(
                                                  onTap: () {
                                                    context
                                                        .read<AuthBloc>()
                                                        .add(
                                                          AuthSendOtpRequested(
                                                            phone:
                                                                _phoneController
                                                                    .text
                                                                    .trim(),
                                                          ),
                                                        );
                                                  },
                                                  child: Text(
                                                    'Resend OTP',
                                                    style: TextStyle(
                                                      fontSize: 12.sp,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: AppColors.primary,
                                                    ),
                                                  ),
                                                ),
                                        ],
                                      ),
                                      SizedBox(height: 20.h),

                                      // Login Button
                                      BlocBuilder<AuthBloc, AuthState>(
                                        builder: (context, state) {
                                          return PrimaryButton(
                                            text: 'Verify & Log In',
                                            isLoading: state is AuthLoading,
                                            icon: Icons.verified_user_rounded,
                                            onPressed: _submitOtp,
                                          );
                                        },
                                      ),

                                      SizedBox(height: 4.h),
                                      // Test credentials helper tip
                                      Container(
                                        padding: EdgeInsets.all(12.r),
                                        decoration: BoxDecoration(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.blue
                                                  .withValues(alpha: 0.15)
                                              : AppColors.primaryLight
                                                  .withValues(alpha: 0.3),
                                          borderRadius:
                                              BorderRadius.circular(10.r),
                                          border: Border.all(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.blue
                                                        .withValues(alpha: 0.25)
                                                    : AppColors.primaryLight,
                                            width: 1,
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.info_outline_rounded,
                                              size: 16.r,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.blue[300]
                                                  : AppColors.primary,
                                            ),
                                            SizedBox(width: 8.w),
                                            //show otp here for
                                            Expanded(
                                              child: Text(
                                                'For testing, use the OTP code ${_receivedOtp ?? ""}',
                                                style: TextStyle(
                                                  fontSize: 11.sp,
                                                  fontWeight: FontWeight.w500,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.blue[200]
                                                      : AppColors.primary,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                              SizedBox(height: 10.h),

                              // Footer note
                              FooterWidget(
                                controller: _footerAnimationController,
                                showInfoCards: !_otpSent,
                              ),
                              SizedBox(height: 10.h),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOtpInputLayout() {
    final colors = AppColors.of(context);
    final otpText = _otpController.text;
    final isFocused = _otpFocusNode.hasFocus;

    return Stack(
      children: [
        // Individual visual boxes
        Row(
          children: List.generate(6, (index) {
            final hasDigit = index < otpText.length;
            final digit = hasDigit ? otpText[index] : '';
            final isCurrent = index == otpText.length;

            return Expanded(
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 4.w),
                height: 48.h,
                decoration: BoxDecoration(
                  color: isFocused && isCurrent
                      ? colors.surface
                      : colors.background,
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(
                    color: _otpError != null
                        ? AppColors.aqiRed
                        : (isFocused && isCurrent
                            ? AppColors.primary
                            : (hasDigit
                                ? AppColors.primary.withValues(alpha: 0.4)
                                : colors.border)),
                    width: (isFocused && isCurrent || _otpError != null)
                        ? 1.5.r
                        : 1.0.r,
                  ),
                  boxShadow: isFocused && isCurrent && _otpError == null
                      ? [
                          BoxShadow(
                            color: AppColors.primary.withValues(alpha: 0.10),
                            blurRadius: 6,
                            offset: Offset(0, 2.h),
                          )
                        ]
                      : null,
                ),
                child: Center(
                  child: Text(
                    digit,
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
        // Hidden Text Field overlay
        Positioned.fill(
          child: Opacity(
            opacity: 0.0,
            child: TextField(
              controller: _otpController,
              focusNode: _otpFocusNode,
              keyboardType: TextInputType.number,
              maxLength: 6,
              onChanged: (val) {
                setState(() {});
              },
              decoration: const InputDecoration(
                counterText: '',
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String label,
    required String hint,
    required IconData prefixIcon,
    required bool obscureText,
    required String? errorText,
    Widget? suffixIcon,
    TextInputType keyboardType = TextInputType.text,
    Iterable<String>? autofillHints,
    int? maxLength,
    List<TextInputFormatter>? inputFormatters,
  }) {
    final colors = AppColors.of(context);
    final hasFocus = focusNode.hasFocus;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13.sp,
            fontWeight: FontWeight.w600,
            color: colors.textPrimary,
          ),
        ),
        SizedBox(height: 6.h),
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 45.h,
          decoration: BoxDecoration(
            color: hasFocus ? colors.surface : colors.background,
            borderRadius: BorderRadius.circular(14.r),
            border: Border.all(
              color: errorText != null
                  ? AppColors.aqiRed
                  : (hasFocus ? AppColors.primary : colors.border),
              width: (hasFocus || errorText != null) ? 1.5.r : 1.0.r,
            ),
            boxShadow: hasFocus && errorText == null
                ? [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: 0.10),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    )
                  ]
                : (errorText != null
                    ? [
                        BoxShadow(
                          color: AppColors.aqiRed.withValues(alpha: 0.06),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        )
                      ]
                    : null),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(width: 14.w),
              Icon(
                prefixIcon,
                color: errorText != null
                    ? AppColors.aqiRed
                    : (hasFocus ? AppColors.primary : AppColors.textSecondary),
                size: 20.r,
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: Theme(
                  data: Theme.of(context).copyWith(
                    inputDecorationTheme: const InputDecorationTheme(
                      filled: false,
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      focusedErrorBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  child: Center(
                    child: TextFormField(
                      controller: controller,
                      focusNode: focusNode,
                      obscureText: obscureText,
                      keyboardType: keyboardType,
                      autofillHints: autofillHints,
                      maxLength: maxLength,
                      inputFormatters: inputFormatters,
                      onChanged: (val) {
                        setState(() {});
                      },
                      style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textPrimary,
                      ),
                      decoration: InputDecoration(
                        hintText: hint,
                        hintStyle: TextStyle(
                          color: AppColors.textMuted,
                          fontWeight: FontWeight.normal,
                          fontSize: 14.sp,
                        ),
                        isCollapsed: true,
                        counterText: '',
                        border: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                ),
              ),
              if (suffixIcon != null) ...[
                suffixIcon,
                SizedBox(width: 4.w),
              ],
            ],
          ),
        ),
        if (errorText != null) ...[
          SizedBox(height: 5.h),
          Padding(
            padding: EdgeInsets.only(left: 6.w),
            child: Row(
              children: [
                Icon(
                  Icons.error_outline_rounded,
                  color: AppColors.aqiRed,
                  size: 14.r,
                ),
                SizedBox(width: 4.w),
                Flexible(
                  child: Text(
                    errorText,
                    style: TextStyle(
                      color: AppColors.aqiRed,
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
