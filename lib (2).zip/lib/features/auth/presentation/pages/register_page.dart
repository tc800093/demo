// Deprecated: This file is no longer used. Registration is removed.
