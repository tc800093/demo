import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:dio/dio.dart';
import '../../../../core/network/api_config.dart';
import '../../../../core/di/injection.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../../app/router/router.dart';
import '../bloc/auth_bloc.dart';

/// Splash Screen with dark industrial layout and entry animations.
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  bool _animationCompleted = false;
  String? _connectionError;
  bool _isCheckingConnection = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );

    _checkServerConnection();

    _controller.forward().then((_) {
      if (mounted) {
        setState(() {
          _animationCompleted = true;
        });
        _navigateBasedOnAuth();
      }
    });
  }

  Future<void> _checkServerConnection() async {
    setState(() {
      _isCheckingConnection = true;
      _connectionError = null;
    });

    try {
      final dio = getIt<Dio>();
      const baseUrl = ApiConfig.defaultBaseUrl;
      
      // Perform a quick connection test with a short timeout
      await dio.get(
        baseUrl,
        options: Options(
          connectTimeout: const Duration(seconds: 4),
          receiveTimeout: const Duration(seconds: 4),
        ),
      );
      
      if (mounted) {
        setState(() {
          _isCheckingConnection = false;
        });
        _navigateBasedOnAuth();
      }
    } catch (e) {
      bool isServerRunning = false;
      if (e is DioException) {
        // If the server responded with any HTTP status code, it is online
        if (e.response != null) {
          isServerRunning = true;
        }
      }
      
      if (isServerRunning) {
        if (mounted) {
          setState(() {
            _isCheckingConnection = false;
          });
          _navigateBasedOnAuth();
        }
      } else {
        if (mounted) {
          setState(() {
            _isCheckingConnection = false;
            _connectionError = "Unable to connect to the backend server. Please verify if the server is running and reachable.";
          });
        }
      }
    }
  }

  void _navigateBasedOnAuth() {
    if (!_animationCompleted) return;
    if (_isCheckingConnection || _connectionError != null) return;

    final authState = context.read<AuthBloc>().state;
    if (authState is AuthInitial || authState is AuthLoading) {
      // Still checking, wait for BlocListener to handle navigation
      return;
    }

    if (authState is AuthAuthenticated) {
      if (authState.user.role == UserRole.admin) {
        context.go(AppRoutes.adminDashboard);
      } else {
        context.go(AppRoutes.contractorDashboard);
      }
    } else {
      context.go(AppRoutes.onboarding);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_connectionError != null) {
      return Scaffold(
        backgroundColor: const Color(0xFF0B1220),
        body: Center(
          child: SingleChildScrollView(
            child: ErrorDisplayWidget(
              message: _connectionError!,
              onRetry: () {
                _checkServerConnection();
              },
            ),
          ),
        ),
      );
    }

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is AuthAuthenticated ||
            state is AuthUnauthenticated ||
            state is AuthError) {
          _navigateBasedOnAuth();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0B1220), // Fallback dark background
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Background Image
              Positioned.fill(
                child: Image.asset(
                  'assets/images/splashscreen_bg.png',
                  fit: BoxFit.cover,
                ),
              ),

              // Subtle dark overlay to improve text readability
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.45),
                        Colors.transparent,
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.65),
                      ],
                      stops: const [0.0, 0.25, 0.70, 1.0],
                    ),
                  ),
                ),
              ),

              // Top Header: Logo, Title, Subtitle & Tagline
              Positioned(
                top: MediaQuery.of(context).size.height * 0.12,
                left: 24.w,
                right: 24.w,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(
                      'assets/icons/AQI.png',
                      height: 80.r,
                      fit: BoxFit.contain,
                    ),
                    SizedBox(height: 16.h),
                    Text(
                      'Air Quality Monitoring',
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                        letterSpacing: 0.5,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      'Monitor. Analyze. Protect.',
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.white70,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),

              // Bottom Progress Indicator & Text
              Positioned(
                bottom: MediaQuery.of(context).size.height * 0.08,
                left: 24.w,
                right: 24.w,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Initializing Monitoring System...',
                      style: TextStyle(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white70,
                        letterSpacing: 0.5,
                      ),
                    ),
                    SizedBox(height: 16.h),
                    // Glowing customized progress bar
                    AnimatedBuilder(
                      animation: _controller,
                      builder: (context, child) {
                        return Container(
                          width: 250.w,
                          height: 6.h,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(3.r),
                          ),
                          child: Stack(
                            children: [
                              Container(
                                width: 250.w * _controller.value,
                                height: 6.h,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [
                                      Color(0xFF00C6FF),
                                      Color(0xFF0072FF),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(3.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFF00C6FF)
                                          .withValues(alpha: 0.4),
                                      blurRadius: 6.r,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
