// Deprecated: This file is no longer used. Registration success screen is removed.
