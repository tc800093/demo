import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;

  final List<Map<String, dynamic>> _onboardingData = [
    {
      'number': '01',
      'color': AppColors.primary,
      'titleHighlight': 'Real-time Environmental Monitoring',
      'titleRest': '',
      'isRestColored': false,
      'description':
          'Monitor air quality in real-time from your connected IoT devices.',
      'image': 'assets/images/onboarding/onboarding_bg1.png',
    },
    {
      'number': '02',
      'color': const Color(0xFF16A34A),
      'titleHighlight': 'Smart Analytics',
      'titleRest': '',
      'isRestColored': false,
      'description': 'Get insights, trends and performance analytics.',
      'image': 'assets/images/onboarding/onboarding_bg2.png',
    },
    {
      'number': '03',
      'color': const Color(0xFFE65100),
      'titleHighlight': 'Instant Alerts',
      'titleRest': '',
      'isRestColored': true,
      'description': 'Receive instant alerts when thresholds are exceeded.',
      'image': 'assets/images/onboarding/onboarding_bg3.png',
    },
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onNext() {
    if (_currentIndex < _onboardingData.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      // role selection page route remove -defaulet role is contractor/user
      context.go(AppRoutes.login);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      body: Stack(
        children: [
          // 1. Sliding Pages with Background Images
          PageView.builder(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            itemCount: _onboardingData.length,
            itemBuilder: (context, index) {
              final data = _onboardingData[index];
              return Stack(
                children: [
                  Positioned.fill(
                    child: Image.asset(
                      data['image'] as String,
                      fit: BoxFit.cover,
                    ),
                  ),

                  // Theme-dependent Overlay to guarantee text legibility
                  // Positioned.fill(
                  //   child: Container(
                  //     color: Theme.of(context).brightness == Brightness.dark
                  //         ? Colors.black.withValues(alpha: 0.6)
                  //         : Colors.white.withValues(alpha: 0.6),
                  //   ),
                  // ),

                  // Content overlaid on top
                  SafeArea(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 20.h),
                          // Badge
                          Container(
                            width: 40.r,
                            height: 40.r,
                            decoration: BoxDecoration(
                              color: data['color'] as Color,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                data['number'] as String,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16.sp,
                                ),
                              ),
                            ),
                          ),
                          const Spacer(),
                          // Title
                          RichText(
                            overflow: TextOverflow.visible,
                            text: TextSpan(
                              style: TextStyle(
                                  fontSize: 24.sp,
                                  fontWeight: FontWeight.w900,
                                  height: 1.2,
                                  fontFamily: 'Inter'),
                              children: [
                                TextSpan(
                                  text: data['titleHighlight'] as String,
                                  style:
                                      TextStyle(color: data['color'] as Color),
                                ),
                                TextSpan(
                                  text: data['titleRest'] as String,
                                  style: TextStyle(
                                    color: (data['isRestColored'] as bool)
                                        ? data['color'] as Color
                                        : colors.textPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10.h),
                          // Description
                          Text(
                            overflow: TextOverflow.visible,
                            data['description'] as String,
                            style: TextStyle(
                              fontSize: 15.sp,
                              color: colors.textSecondary,
                              height: 1.5,
                            ),
                          ),
                          SizedBox(height: 10.h),
                          // Indicator aligned left
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: List.generate(
                              _onboardingData.length,
                              (dotIndex) => AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                margin: EdgeInsets.only(right: 8.w),
                                width: 8.r,
                                height: 8.r,
                                decoration: BoxDecoration(
                                  color: _currentIndex == dotIndex
                                      ? data['color'] as Color
                                      : colors.border,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 80.h),
                          // Spacing to avoid overlap with bottom action buttons
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),

          // 2. Fixed Bottom Action Buttons
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () {
                        context.go(AppRoutes.login);
                      },
                      child: Text(
                        'Skip',
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: colors.textSecondary,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 150.w,
                      height: 45.h,
                      child: PrimaryButton(
                        text: _currentIndex == _onboardingData.length - 1
                            ? 'Get Started'
                            : 'Next',
                        onPressed: _onNext,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
