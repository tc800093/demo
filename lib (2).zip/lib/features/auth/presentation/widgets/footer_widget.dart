import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../../../config/theme/colors.dart';

class AuthInfoCardWIdget extends StatelessWidget {
  final AnimationController controller;
  final IconData iconData;
  final String title;
  final Color colorData;

  const AuthInfoCardWIdget({
    super.key,
    required this.controller,
    required this.iconData,
    required this.title,
    required this.colorData,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: FadeTransition(
        opacity: CurvedAnimation(
          parent: controller,
          curve: Curves.easeIn,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              iconData,
              color: colorData,
              size: 22.r,
            ),
            SizedBox(height: 6.h),
            Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10.sp,
                fontWeight: FontWeight.w600,
                color: AppColors.of(context).textSecondary,
                fontFamily: 'Poppins',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FooterWidget extends StatelessWidget {
  final AnimationController? controller;
  final bool showInfoCards;

  const FooterWidget({
    super.key,
    this.controller,
    this.showInfoCards = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (showInfoCards) ...[
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: Colors.grey.withValues(alpha: 0.2),
                  width: 1.r,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AuthInfoCardWIdget(
                    controller: controller!,
                    iconData: Icons.speed,
                    title: 'Real-time Monitoring',
                    colorData: Colors.green,
                  ),
                  SizedBox(
                    height: 36.h,
                    child: VerticalDivider(
                      thickness: 1.r,
                      color: Colors.grey.withValues(alpha: 0.2),
                    ),
                  ),
                  AuthInfoCardWIdget(
                    controller: controller!,
                    iconData: Icons.notifications_active,
                    title: 'Instant Alerts',
                    colorData: Colors.lightBlue,
                  ),
                  SizedBox(
                    height: 36.h,
                    child: VerticalDivider(
                      thickness: 1.r,
                      color: Colors.grey.withValues(alpha: 0.2),
                    ),
                  ),
                  AuthInfoCardWIdget(
                    controller: controller!,
                    iconData: Icons.bar_chart_outlined,
                    title: 'AI Analytics',
                    colorData: Colors.deepPurple,
                  ),
                ],
              ),
            ),
            SizedBox(height: 10.h),
          ],
          Text(
            "Vasundhara IT Private Limited",
            textAlign: TextAlign.center,
            style: theme.textTheme.bodySmall!.copyWith(
              color: theme.colorScheme.primary,
              fontWeight: FontWeight.bold,
              fontSize: 14.sp,
              fontFamily: 'Poppins',
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            "Service is our strength",
            textAlign: TextAlign.center,
            style: theme.textTheme.bodySmall!.copyWith(
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
              color: Colors.red,
              fontFamily: 'MonotypeCorsiva',
            ),
          ),
          SizedBox(height: 6.h),
          FutureBuilder<PackageInfo>(
            future: PackageInfo.fromPlatform(),
            builder: (context, snapshot) {
              final version = snapshot.data?.version ?? '1.0.0';
              return Text(
                "Version No. $version",
                textAlign: TextAlign.center,
                style: theme.textTheme.bodySmall!.copyWith(
                  fontSize: 10.sp,
                  color: Colors.grey,
                  fontFamily: 'Poppins',
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
