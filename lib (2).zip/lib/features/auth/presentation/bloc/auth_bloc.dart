import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../domain/repositories/auth_repository.dart';
export '../../domain/repositories/auth_repository.dart';

// --- Events ---
abstract class AuthEvent extends Equatable {
  const AuthEvent();
  
  @override
  List<Object?> get props => [];
}

class AuthCheckRequested extends AuthEvent {}



class AuthSendOtpRequested extends AuthEvent {
  final String phone;

  const AuthSendOtpRequested({required this.phone});

  @override
  List<Object?> get props => [phone];
}

class AuthLoginRequested extends AuthEvent {
  final String phone;
  final String otp;
  final String otpId;
  final bool rememberMe;

  const AuthLoginRequested({
    required this.phone,
    required this.otp,
    required this.otpId,
    this.rememberMe = false,
  });

  @override
  List<Object?> get props => [phone, otp, otpId, rememberMe];
}

class AuthLogoutRequested extends AuthEvent {}

// --- States ---
abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class AuthAuthenticated extends AuthState {
  final UserEntity user;

  const AuthAuthenticated(this.user);

  @override
  List<Object?> get props => [user];
}

class AuthUnauthenticated extends AuthState {}

class AuthOtpSent extends AuthState {
  final String phone;
  final String otpId;
  final String? mockOtp;

  const AuthOtpSent({
    required this.phone,
    required this.otpId,
    this.mockOtp,
  });

  @override
  List<Object?> get props => [phone, otpId, mockOtp];
}

class AuthError extends AuthState {
  final String message;

  const AuthError(this.message);

  @override
  List<Object?> get props => [message];
}

// --- Bloc ---
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository _authRepository;

  AuthBloc(this._authRepository) : super(AuthInitial()) {
    on<AuthCheckRequested>(_onAuthCheckRequested);
    on<AuthSendOtpRequested>(_onAuthSendOtpRequested);
    on<AuthLoginRequested>(_onAuthLoginRequested);
    on<AuthLogoutRequested>(_onAuthLogoutRequested);
  }

  Future<void> _onAuthCheckRequested(
    AuthCheckRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.checkAuthStatus();
      if (user != null) {
        emit(AuthAuthenticated(user));
      } else {
        emit(AuthUnauthenticated());
      }
    } catch (e) {
      emit(AuthError(AppException.from(e).toString()));
    }
  }

  Future<void> _onAuthSendOtpRequested(
    AuthSendOtpRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final response = await _authRepository.sendOtp(event.phone);
      emit(AuthOtpSent(
        phone: event.phone,
        otpId: response.otpId,
        mockOtp: response.otp,
      ));
    } catch (e) {
      emit(AuthError(AppException.from(e).toString()));
    }
  }

  Future<void> _onAuthLoginRequested(
    AuthLoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.loginWithPhoneAndOtp(
        phone: event.phone,
        otp: event.otp,
        otpId: event.otpId,
        rememberMe: event.rememberMe,
      );
      emit(AuthAuthenticated(user));
    } catch (e) {
      emit(AuthError(AppException.from(e).toString()));
    }
  }

  Future<void> _onAuthLogoutRequested(
    AuthLogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    await _authRepository.logout();
    emit(AuthUnauthenticated());
  }
}
