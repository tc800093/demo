import 'package:equatable/equatable.dart';

/// User roles in the platform.
enum UserRole { admin, subAdmin, user, subUser }

/// Response returned when requesting login OTP.
class OtpResponse extends Equatable {
  final String status;
  final String message;
  final String otpId;
  final String? otp;

  const OtpResponse({
    required this.status,
    required this.message,
    required this.otpId,
    this.otp,
  });

  @override
  List<Object?> get props => [status, message, otpId, otp];
}

/// Entity representing the authenticated user.
class UserEntity extends Equatable {
  final String id;
  final String name;
  final String email;
  final String phone;
  final UserRole role;
  final String? companyName;
  final bool isProfileCompleted;

  const UserEntity({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.role,
    this.companyName,
    this.isProfileCompleted = false,
  });

  @override
  List<Object?> get props =>
      [id, name, email, phone, role, companyName, isProfileCompleted];
}

/// Interface for Authentication operations.
abstract class AuthRepository {
  /// Stream of current authenticated user.
  Stream<UserEntity?> get currentUser;

  /// Requests OTP code to be sent to a phone number.
  Future<OtpResponse> sendOtp(String phone);

  /// Log in with phone number, OTP, and otpId.
  Future<UserEntity> loginWithPhoneAndOtp({
    required String phone,
    required String otp,
    required String otpId,
    bool rememberMe = false,
  });

  /// Log out from the application.
  Future<void> logout();

  /// Checks if a user is currently authenticated.
  Future<UserEntity?> checkAuthStatus();

  /// Save Fcm token for the user id
  Future<bool> registoerFCMTokenRepo(
      {required String userID, required String fcmToken});
}
