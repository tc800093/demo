import 'package:equatable/equatable.dart';

class AnalyticsDayWiseEntity extends Equatable {
  final String? aqiDate;
  final int? minAqi;
  final int? maxAqi;
  final double? avgAqi;

  const AnalyticsDayWiseEntity({
    this.aqiDate,
    this.minAqi,
    this.maxAqi,
    this.avgAqi,
  });

  @override
  List<Object?> get props => [
        aqiDate,
        minAqi,
        maxAqi,
        avgAqi,
      ];
}
