import 'package:equatable/equatable.dart';

class NotificationHistoryEntity extends Equatable {
  final int? srNo;
  final int? notificationId;
  final String? source;
  final String? title;
  final String? description;
  final int? priority;
  final String? lineNo;
  final String? layerName;
  final String? username;
  final String? eventType;
  final bool? sendNotification;
  final bool? sendAlert;
  final String? topic;
  final String? aliasDept;
  final String? solution;
  final String? createdAt;

  const NotificationHistoryEntity({
    this.srNo,
    this.notificationId,
    this.source,
    this.title,
    this.description,
    this.priority,
    this.lineNo,
    this.layerName,
    this.username,
    this.eventType,
    this.sendNotification,
    this.sendAlert,
    this.topic,
    this.aliasDept,
    this.solution,
    this.createdAt,
  });

  NotificationHistoryEntity copyWith({
    int? srNo,
    int? notificationId,
    String? source,
    String? title,
    String? description,
    int? priority,
    String? lineNo,
    String? layerName,
    String? username,
    String? eventType,
    bool? sendNotification,
    bool? sendAlert,
    String? topic,
    String? aliasDept,
    String? solution,
    String? createdAt,
  }) {
    return NotificationHistoryEntity(
      srNo: srNo ?? this.srNo,
      notificationId: notificationId ?? this.notificationId,
      source: source ?? this.source,
      title: title ?? this.title,
      description: description ?? this.description,
      priority: priority ?? this.priority,
      lineNo: lineNo ?? this.lineNo,
      layerName: layerName ?? this.layerName,
      username: username ?? this.username,
      eventType: eventType ?? this.eventType,
      sendNotification: sendNotification ?? this.sendNotification,
      sendAlert: sendAlert ?? this.sendAlert,
      topic: topic ?? this.topic,
      aliasDept: aliasDept ?? this.aliasDept,
      solution: solution ?? this.solution,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  List<Object?> get props => [
        srNo,
        notificationId,
        source,
        title,
        description,
        priority,
        lineNo,
        layerName,
        username,
        eventType,
        sendNotification,
        sendAlert,
        topic,
        aliasDept,
        solution,
        createdAt,
      ];
}
