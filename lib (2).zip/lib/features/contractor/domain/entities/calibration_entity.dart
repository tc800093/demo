import 'package:equatable/equatable.dart';

class CalibrationHistoryEntity extends Equatable {
  final int? srNo;
  final String? calibrationInfoId;
  final String? deviceId;
  final DateTime? calibrationDate;
  final String? calibratedBy;
  final String? certificateNo;
  final DateTime? nextDueDate;
  final String? remarks;
  final String? createdAt;

  const CalibrationHistoryEntity({
    this.srNo,
    this.calibrationInfoId,
    this.deviceId,
    this.calibrationDate,
    this.calibratedBy,
    this.certificateNo,
    this.nextDueDate,
    this.remarks,
    this.createdAt,
  });

  @override
  List<Object?> get props => [
        srNo,
        calibrationInfoId,
        deviceId,
        calibrationDate,
        calibratedBy,
        certificateNo,
        nextDueDate,
        remarks,
        createdAt,
      ];
}
