import 'package:equatable/equatable.dart';

class AnalyticsDailyIntervalEntity extends Equatable {
  final DailySummaryEntity? dailySummary;
  final List<IntervalEntity>? intervals;

  const AnalyticsDailyIntervalEntity({
    this.dailySummary,
    this.intervals,
  });

  AnalyticsDailyIntervalEntity copyWith({
    DailySummaryEntity? dailySummary,
    List<IntervalEntity>? intervals,
  }) {
    return AnalyticsDailyIntervalEntity(
      dailySummary: dailySummary ?? this.dailySummary,
      intervals: intervals ?? this.intervals,
    );
  }

  @override
  List<Object?> get props => [
        dailySummary,
        intervals,
      ];
}

class DailySummaryEntity extends Equatable {
  final int? minAqi;
  final int? maxAqi;
  final double? avgAqi;

  const DailySummaryEntity({
    this.minAqi,
    this.maxAqi,
    this.avgAqi,
  });

  DailySummaryEntity copyWith({
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) {
    return DailySummaryEntity(
      minAqi: minAqi ?? this.minAqi,
      maxAqi: maxAqi ?? this.maxAqi,
      avgAqi: avgAqi ?? this.avgAqi,
    );
  }

  @override
  List<Object?> get props => [
        minAqi,
        maxAqi,
        avgAqi,
      ];
}

class IntervalEntity extends Equatable {
  final String? intervalStart;
  final String? intervalEnd;
  final int? minAqi;
  final int? maxAqi;
  final double? avgAqi;

  const IntervalEntity({
    this.intervalStart,
    this.intervalEnd,
    this.minAqi,
    this.maxAqi,
    this.avgAqi,
  });

  IntervalEntity copyWith({
    String? intervalStart,
    String? intervalEnd,
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) {
    return IntervalEntity(
      intervalStart: intervalStart ?? this.intervalStart,
      intervalEnd: intervalEnd ?? this.intervalEnd,
      minAqi: minAqi ?? this.minAqi,
      maxAqi: maxAqi ?? this.maxAqi,
      avgAqi: avgAqi ?? this.avgAqi,
    );
  }

  @override
  List<Object?> get props => [
        intervalStart,
        intervalEnd,
        minAqi,
        maxAqi,
        avgAqi,
      ];
}
