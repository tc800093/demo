import 'package:equatable/equatable.dart';

class CalibrationScheduleEntity extends Equatable {
  final int? srNo;
  final String? calibrationScheduleId;
  final String? deviceId;
  final DateTime? scheduledDate;
  final String? status;
  final String? createdAt;
  final DateTime? actualScheduledDate;

  const CalibrationScheduleEntity({
    this.srNo,
    this.calibrationScheduleId,
    this.deviceId,
    this.scheduledDate,
    this.status,
    this.createdAt,
    this.actualScheduledDate,
  });

  CalibrationScheduleEntity copyWith({
    int? srNo,
    String? calibrationScheduleId,
    String? deviceId,
    DateTime? scheduledDate,
    String? status,
    String? createdAt,
    DateTime? actualScheduledDate,
  }) {
    return CalibrationScheduleEntity(
      srNo: srNo ?? this.srNo,
      calibrationScheduleId:
          calibrationScheduleId ?? this.calibrationScheduleId,
      deviceId: deviceId ?? this.deviceId,
      scheduledDate: scheduledDate ?? this.scheduledDate,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      actualScheduledDate: actualScheduledDate ?? this.actualScheduledDate,
    );
  }

  @override
  List<Object?> get props => [
        srNo,
        calibrationScheduleId,
        deviceId,
        scheduledDate,
        status,
        createdAt,
        actualScheduledDate,
      ];
}
