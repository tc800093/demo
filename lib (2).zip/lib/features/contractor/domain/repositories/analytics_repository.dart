import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_daily_interval_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_day_wise_entity.dart';

/// Interface for Sites actions.
abstract class AnalyticsRepository {
  /// Retrieve AQI analytics  for a device by date.
  Future<AnalyticsDailyIntervalEntity?> fetchAQIAnalyticsRepo(
      String deviceId, String date, String interval);

  /// Retrieve AQI analytics  for a device by Day Wise fromDate and ToDate.
  Future<List<AnalyticsDayWiseEntity>> fetchAQIDayWiseAnalyticsRepo(
      String deviceId, String fromDate, String toDate);
}
