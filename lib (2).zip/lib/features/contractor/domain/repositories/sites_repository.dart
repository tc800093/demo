import 'package:equatable/equatable.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/calibration_schedule_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_schedule_entity.dart';
import '../../data/models/aqi_telemetry_model.dart';

/// Sensor parameters.
class SensorReading extends Equatable {
  final double? value;
  final String unit;

  const SensorReading(this.value, this.unit);

  @override
  List<Object?> get props => [value, unit];
}

/// Sprinkler execution log.
class SprinklerLog extends Equatable {
  final DateTime timestamp;
  final String status; // Started / Stopped
  final String triggeredBy; // Auto / Contractor Name
  final int durationSeconds;

  const SprinklerLog({
    required this.timestamp,
    required this.status,
    required this.triggeredBy,
    required this.durationSeconds,
  });

  @override
  List<Object?> get props => [timestamp, status, triggeredBy, durationSeconds];
}

/// Maintenance Log item.
class MaintenanceLog extends Equatable {
  final DateTime date;
  final String technician;
  final String remarks;
  final String serviceType;

  const MaintenanceLog({
    required this.date,
    required this.technician,
    required this.remarks,
    required this.serviceType,
  });

  @override
  List<Object?> get props => [date, technician, remarks, serviceType];
}

/// Calibration Log item.
class CalibrationLog extends Equatable {
  final DateTime date;
  final String technician;
  final String
      calibrationType; // Zero Calibration, Span Calibration, Field Calibration
  final String parameters; // PM2.5, PM10, CO2, etc.
  final String status; // Passed, Failed, Pending
  final String remarks;

  const CalibrationLog({
    required this.date,
    required this.technician,
    required this.calibrationType,
    required this.parameters,
    required this.status,
    required this.remarks,
  });

  @override
  List<Object?> get props => [
        date,
        technician,
        calibrationType,
        parameters,
        status,
        remarks,
      ];
}

/// Site parameters entity.
class SiteEntity extends Equatable {
  final String id;
  final String name;
  final String projectName;
  final String projectType;
  final String address;
  final double latitude;
  final double longitude;

  // Contractor association (each site belongs to one contractor)
  final String contractorId;
  final String contractorName;

  // AQI
  final int? aqi;

  // Detailed parameters
  final Map<String, SensorReading> parameters;

  // Device Details
  final String deviceSerial;
  final String imeiNo;
  final bool isDeviceOnline;
  final int signalStrength;
  final int batteryLevel;
  final bool isGpsConnected;
  final bool is4gConnected;
  final String firmwareVersion;
  final DateTime lastSyncTime;

  // Sprinkler details
  final String sprinklerMode; // Auto / Manual
  final bool isSprinklerRunning;
  final DateTime? sprinklerLastTriggerTime;
  final int sprinklerRunDurationMinutes;
  final List<SprinklerLog> sprinklerHistory;

  // Maintenance details
  final List<MaintenanceLog> maintenanceHistory;

  // Calibration & Installation details
  final DateTime? installationDate;
  final DateTime? lastCalibrationDate;
  final DateTime? nextCalibrationDate;
  final List<CalibrationHistoryEntity> calibrationHistory;

  final List<CalibrationScheduleModel> calibrationScheduleList;

  DateTime get displayInstallationDate =>
      installationDate ?? lastSyncTime.subtract(const Duration(days: 180));
  DateTime get displayLastCalibrationDate =>
      lastCalibrationDate ?? lastSyncTime.subtract(const Duration(days: 30));
  DateTime get displayNextCalibrationDate =>
      nextCalibrationDate ?? lastSyncTime.add(const Duration(days: 150));

  const SiteEntity(
      {required this.id,
      required this.name,
      required this.projectName,
      required this.projectType,
      required this.address,
      required this.latitude,
      required this.longitude,
      this.contractorId = '',
      this.contractorName = '',
      this.aqi,
      required this.parameters,
      required this.deviceSerial,
      this.imeiNo = '',
      required this.isDeviceOnline,
      required this.signalStrength,
      required this.batteryLevel,
      required this.isGpsConnected,
      required this.is4gConnected,
      required this.firmwareVersion,
      required this.lastSyncTime,
      required this.sprinklerMode,
      required this.isSprinklerRunning,
      this.sprinklerLastTriggerTime,
      required this.sprinklerRunDurationMinutes,
      required this.sprinklerHistory,
      required this.maintenanceHistory,
      this.installationDate,
      this.lastCalibrationDate,
      this.nextCalibrationDate,
      this.calibrationHistory = const [],
      this.calibrationScheduleList = const []});

  @override
  List<Object?> get props => [
        id,
        name,
        projectName,
        projectType,
        address,
        latitude,
        longitude,
        contractorId,
        contractorName,
        aqi,
        parameters,
        deviceSerial,
        imeiNo,
        isDeviceOnline,
        signalStrength,
        batteryLevel,
        isGpsConnected,
        is4gConnected,
        firmwareVersion,
        lastSyncTime,
        sprinklerMode,
        isSprinklerRunning,
        sprinklerLastTriggerTime,
        sprinklerRunDurationMinutes,
        sprinklerHistory,
        maintenanceHistory,
        installationDate,
        lastCalibrationDate,
        nextCalibrationDate,
        calibrationHistory,
        calibrationScheduleList
      ];

  SiteEntity copyWith({
    String? name,
    String? projectName,
    String? projectType,
    String? address,
    double? latitude,
    double? longitude,
    String? contractorId,
    String? contractorName,
    int? aqi,
    Map<String, SensorReading>? parameters,
    String? deviceSerial,
    String? imeiNo,
    bool? isDeviceOnline,
    int? signalStrength,
    int? batteryLevel,
    bool? isGpsConnected,
    bool? is4gConnected,
    String? firmwareVersion,
    DateTime? lastSyncTime,
    String? sprinklerMode,
    bool? isSprinklerRunning,
    DateTime? sprinklerLastTriggerTime,
    int? sprinklerRunDurationMinutes,
    List<SprinklerLog>? sprinklerHistory,
    List<MaintenanceLog>? maintenanceHistory,
    DateTime? installationDate,
    DateTime? lastCalibrationDate,
    DateTime? nextCalibrationDate,
    List<CalibrationHistoryEntity>? calibrationHistory,
    List<CalibrationScheduleModel>? calibrationScheduleList,
  }) {
    return SiteEntity(
        id: id,
        name: name ?? this.name,
        projectName: projectName ?? this.projectName,
        projectType: projectType ?? this.projectType,
        address: address ?? this.address,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
        contractorId: contractorId ?? this.contractorId,
        contractorName: contractorName ?? this.contractorName,
        aqi: aqi ?? this.aqi,
        parameters: parameters ?? this.parameters,
        deviceSerial: deviceSerial ?? this.deviceSerial,
        imeiNo: imeiNo ?? this.imeiNo,
        isDeviceOnline: isDeviceOnline ?? this.isDeviceOnline,
        signalStrength: signalStrength ?? this.signalStrength,
        batteryLevel: batteryLevel ?? this.batteryLevel,
        isGpsConnected: isGpsConnected ?? this.isGpsConnected,
        is4gConnected: is4gConnected ?? this.is4gConnected,
        firmwareVersion: firmwareVersion ?? this.firmwareVersion,
        lastSyncTime: lastSyncTime ?? this.lastSyncTime,
        sprinklerMode: sprinklerMode ?? this.sprinklerMode,
        isSprinklerRunning: isSprinklerRunning ?? this.isSprinklerRunning,
        sprinklerLastTriggerTime:
            sprinklerLastTriggerTime ?? this.sprinklerLastTriggerTime,
        sprinklerRunDurationMinutes:
            sprinklerRunDurationMinutes ?? this.sprinklerRunDurationMinutes,
        sprinklerHistory: sprinklerHistory ?? this.sprinklerHistory,
        maintenanceHistory: maintenanceHistory ?? this.maintenanceHistory,
        installationDate: installationDate ?? this.installationDate,
        lastCalibrationDate: lastCalibrationDate ?? this.lastCalibrationDate,
        nextCalibrationDate: nextCalibrationDate ?? this.nextCalibrationDate,
        calibrationHistory: calibrationHistory ?? this.calibrationHistory,
        calibrationScheduleList:
            calibrationScheduleList ?? this.calibrationScheduleList);
  }
}

/// Interface for Sites actions.
abstract class SitesRepository {
  /// Stream of active site updates.
  Stream<List<SiteEntity>> get sitesStream;

  /// Retrieve all sites.
  Future<List<SiteEntity>> getSites();

  /// get live data
  Future<void> connectWebSocket();

  Future<void> initializeWebSocket();

  Stream<List<SiteEntity>> get liveDataStream;

  Future<void> disconnectWebSocket();

  /// Retrieve details for a specific site.
  Future<SiteEntity> getSiteDetails(String id);

  /// Add a new site.
  Future<void> addSite(SiteEntity site);

  /// Toggle sprinkler running state.
  Future<SiteEntity> toggleSprinkler(String siteId, bool isRunning);

  /// Toggle sprinkler mode (Auto / Manual).
  Future<SiteEntity> setSprinklerMode(String siteId, String mode);

  /// Record a new calibration for a device.
  Future<void> recordCalibration(String siteId, CalibrationHistoryEntity log);

  /// Update the calibration for device
  Future<void> updateCalibrationRecord(
      String siteId, CalibrationHistoryEntity log);

  Future<void> updateCalibrationSchedule(
      String siteId, CalibrationScheduleEntity schedule);

  /// Retrieve telemetry history for a specific device.
  Future<List<AqiTelemetryModel>> getAqiHistory(String deviceId,
      {int page = 0, int size = 2000});

  /// Retrieve telemetry history for a device within a specific date range.
  Future<List<AqiTelemetryModel>> getAqiHistoryRange(
      String deviceId, String from, String to,
      {int page = 0, int size = 2000});

  /// Clear the local in-memory cache and state.
  void clearCache();
}
