import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/notification_history_entity.dart';

/// Interface for Notificaiton action.
abstract class NotificationRespository {
  /// Retrieve AQI analytics  for a device by date.

  /// Retrieve AQI analytics  for a device by Day Wise fromDate and ToDate.
  Future<List<NotificationHistoryEntity>>
      fetchNotificationRangeWithStartAndEndRepo(
          {String? page,
          String? size,
          required String fromDate,
          required String toDate});
}
