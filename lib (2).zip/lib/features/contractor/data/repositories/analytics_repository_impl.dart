import 'package:vasundhara_maha_aqim/core/exceptions/app_exception.dart';
import 'package:vasundhara_maha_aqim/core/network/api_client.dart';
import 'package:vasundhara_maha_aqim/core/network/api_config.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/analytics_daily_inteval_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/analytics_day_wise_model.dart';

import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/analytics_repository.dart';

class AnalyticsRepositoryImpl implements AnalyticsRepository {
  final ApiClient _apiClient;
  AnalyticsRepositoryImpl(
    this._apiClient,
  );

  @override
  Future<AnalyticsDailyIntervalModel?> fetchAQIAnalyticsRepo(
      String deviceId, String date, String interval) async {
    final url =
        ApiConfig.fetchintervialAnalyticsBydate(deviceId, date, interval);
    try {
      final response = await _apiClient.dio.get(url);

      if (response.statusCode == 200) {
        AnalyticsDailyIntervalModel intervalmodel =
            AnalyticsDailyIntervalModel.fromJson(response.data);

        return intervalmodel;
      } else {
        return null;
      }
    } catch (e) {
      throw AppException('Data not found');
    }
  }

  @override
  Future<List<AnalyticsDayWiseModel>> fetchAQIDayWiseAnalyticsRepo(
      String deviceId, String fromDate, String toDate) async {
    final url = ApiConfig.fetchAnalyticsDayWiseByFromDateAndToDate(
        deviceId, fromDate, toDate);
    try {
      final response = await _apiClient.dio.get(url);

      if (response.statusCode == 200) {
        List<AnalyticsDayWiseModel> dayWiseAnalytics =
            (response.data['details'] as List<dynamic>)
                .map<AnalyticsDayWiseModel>(
                    (d) => AnalyticsDayWiseModel.fromJson(d))
                .toList();

        return dayWiseAnalytics;
      } else {
        return const [];
      }
    } catch (e) {
      throw AppException('Data not found');
    }
  }
}
