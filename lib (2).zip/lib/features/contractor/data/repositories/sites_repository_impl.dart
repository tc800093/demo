import 'dart:async';
import 'dart:developer';
import 'dart:convert' show json;
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/core/network/websocket_service.dart';
import '../models/sprinkler_history_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/calibration_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/calibration_schedule_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_schedule_entity.dart';

import '../../../../core/network/api_client.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../../../core/network/api_config.dart';
import '../../../../core/network/sse_service.dart';
import '../../domain/repositories/sites_repository.dart';
import '../models/aqi_telemetry_model.dart';
import '../../../admin/domain/entities/device_entity.dart';
import '../../../admin/data/models/device_model.dart';
import '../../../auth/domain/repositories/auth_repository.dart';
import '../../../../core/di/injection.dart';

/// Implementation of [SitesRepository] integrated with real-time REST and SSE APIs.
///
/// On construction the repository:
/// 1. Populates an internal list of sites with default/fallback data.
/// 2. Subscribes to the injected [SseService] for live telemetry updates.
///
/// The SSE service is injected rather than created internally, keeping
/// SSE concerns decoupled and independently testable.
class SitesRepositoryImpl implements SitesRepository {
  final ApiClient _apiClient;
  final SseService _sseService;
  final WebsocketService _websocketService;

  final List<SiteEntity> _sites = [];
  final StreamController<List<SiteEntity>> _sitesStreamController =
      StreamController<List<SiteEntity>>.broadcast();

  StreamSubscription<SseEvent>? _sseSubscription;
  StreamSubscription<WebSocketEvent>? _webSocketSubscription;
  String? _lastCustomerId;

  // Track client-side manual sprinkler triggers to prevent SSE telemetry loops from overriding simulation state
  final Map<String, DateTime> _lastManualToggleTimes = {};
  final Map<String, bool> _manualSprinklerStates = {};

  // Guard flag to prevent duplicate WebSocket subscriptions
  bool _isWebSocketSubscribed = false;

  static const Set<String> _mockDeviceIds = {
    '123456',
    'AQI-LOG-8827361524',
    'AQI-HWY-0987654321',
    'AQI-STO-1928374650',
  };

  static const Map<String, SensorReading> _defaultParameters = {
    'PM1': SensorReading(0, 'µg/m³'),
    'PM2.5': SensorReading(0, 'µg/m³'),
    'PM10': SensorReading(0, 'µg/m³'),
    'TSP': SensorReading(0, 'µg/m³'),
    'Temp': SensorReading(0.0, '°C'),
    'Humidity': SensorReading(0, '%'),
    'CO': SensorReading(null, 'ppm'),
    'CO₂': SensorReading(null, 'ppm'),
    'NO₂': SensorReading(null, 'ppb'),
    'SO₂': SensorReading(null, 'ppb'),
    'O₃': SensorReading(null, 'ppb'),
    'VOC': SensorReading(null, 'ppm'),
    'Noise': SensorReading(null, 'dB'),
  };

  SitesRepositoryImpl(
      this._apiClient, this._sseService, this._websocketService) {
    _initSiteData();
    // _subscribeSse();
    // _subscribeWebSocket();
    Future.microtask(() {
      initializeWebSocket();
    });
  }

  // ─── Public API ────────

  @override
  Stream<List<SiteEntity>> get sitesStream => _sitesStreamController.stream;

  @override
  Future<List<SiteEntity>> getSites() async {
    try {
      final authRepo = getIt<AuthRepository>();
      final currentUser = await authRepo.checkAuthStatus();

      final currentId = currentUser?.id;
      if (currentId != _lastCustomerId) {
        debugPrint(
            '[Repository] User changed from $_lastCustomerId to $currentId. Clearing sites cache and reconnecting SSE.');
        _sites.clear();
        _lastCustomerId = currentId;
        // _sseService.forceReconnect();
      }

      String url;
      if (currentUser != null &&
          (currentUser.role == UserRole.user ||
              currentUser.role == UserRole.subUser)) {
        url = ApiConfig.getAllocatedDevices(
          currentUser.id,
          page: 0,
          size: 20,
          role: currentUser.role == UserRole.subUser ? 'Sub_User' : null,
        );
      } else {
        url = ApiConfig.getDeviceList(0, 100);
      }
      final response = await _apiClient.dio.get(url);
      if (response.statusCode == 200 && response.data != null) {
        final Map<String, dynamic> responseData =
            response.data as Map<String, dynamic>;
        final List<dynamic> listJson =
            responseData['devices'] as List<dynamic>? ??
                responseData['data'] as List<dynamic>? ??
                [];

        final List<DeviceEntity> devices = listJson
            .map((item) => DeviceModel.fromJson(item as Map<String, dynamic>))
            .toList();

        final List<SiteEntity> newSites = [];
        for (final device in devices) {
          final existingIndex =
              _sites.indexWhere((s) => s.id == device.deviceId);
          SiteEntity site;
          if (existingIndex != -1) {
            final existing = _sites[existingIndex];
            site = existing.copyWith(
              name: (device.siteName != null && device.siteName!.isNotEmpty)
                  ? device.siteName!
                  : device.deviceName,
              projectName: device.projectName ?? '',
              address: device.address ?? '',
              latitude: (device.latitude != null && device.latitude != 0.0)
                  ? device.latitude!
                  : existing.latitude,
              longitude: (device.longitude != null && device.longitude != 0.0)
                  ? device.longitude!
                  : existing.longitude,
              deviceSerial: device.deviceCode,
              imeiNo: device.imeiNo,
              firmwareVersion: device.firmwareVersion,
              contractorName: device.userName ?? existing.contractorName,
            );
          } else {
            site = SiteEntity(
              id: device.deviceId,
              name: (device.siteName != null && device.siteName!.isNotEmpty)
                  ? device.siteName!
                  : device.deviceName,
              projectName: device.projectName ?? '',
              projectType: 'Construction',
              address: device.address ?? '',
              latitude: (device.latitude != null && device.latitude != 0.0)
                  ? device.latitude!
                  : 18.5204,
              longitude: (device.longitude != null && device.longitude != 0.0)
                  ? device.longitude!
                  : 73.8567,
              contractorId: device.customerId ?? '',
              contractorName: device.userName ?? 'Customer',
              deviceSerial: device.deviceCode,
              imeiNo: device.imeiNo,
              isDeviceOnline: device.active,
              sprinklerMode: 'Auto',
              isSprinklerRunning: false,
              sprinklerHistory: const [],
              calibrationHistory: const [],
              maintenanceHistory: const [],
              parameters: _defaultParameters,
              batteryLevel: 100,
              firmwareVersion: device.firmwareVersion.isNotEmpty
                  ? device.firmwareVersion
                  : 'v1.0.0',
              is4gConnected: true,
              isGpsConnected: true,
              lastSyncTime: DateTime.now(),
              signalStrength: 80,
              sprinklerRunDurationMinutes: 15,
            );
          }
          newSites.add(site);
        }

        _sites.clear();
        _sites.addAll(newSites);

        final List<Future<void>> futures = [];
        for (int i = 0; i < _sites.length; i++) {
          futures.add(_fetchLatestForSite(i));
        }
        if (futures.isNotEmpty) {
          await Future.wait(futures);
        }
      }
    } catch (e) {
      debugPrint('Error fetching real sites: $e');
    }
    await _loadSprinklerDataFromAsset();
    return List.unmodifiable(_sites);
  }

  @override
  Future<SiteEntity> getSiteDetails(String id) async {
    int index = _sites.indexWhere((s) => s.id == id);
    if (index == -1) {
      final url = ApiConfig.getDeviceDetail(id);
      try {
        final response = await _apiClient.dio.get(url);

        if (response.statusCode == 200 && response.data != null) {
          final Map<String, dynamic> responseData =
              response.data as Map<String, dynamic>;
          final Map<String, dynamic> deviceJson =
              responseData['data'] as Map<String, dynamic>? ?? responseData;
          final device = DeviceModel.fromJson(deviceJson);

          final site = SiteEntity(
            id: device.deviceId,
            name: (device.siteName != null && device.siteName!.isNotEmpty)
                ? device.siteName!
                : device.deviceName,
            projectName: device.projectName ?? '',
            projectType: 'Construction',
            address: device.address ?? '',
            latitude: device.latitude ?? 18.5204,
            longitude: device.longitude ?? 73.8567,
            contractorId: device.customerId ?? '',
            contractorName: device.userName ?? 'Customer',
            deviceSerial: device.deviceCode,
            imeiNo: device.imeiNo,
            isDeviceOnline: device.active,
            sprinklerMode: 'Auto',
            isSprinklerRunning: false,
            sprinklerHistory: const [],
            calibrationHistory: const [],
            maintenanceHistory: const [],
            parameters: _defaultParameters,
            batteryLevel: 100,
            firmwareVersion: device.firmwareVersion.isNotEmpty
                ? device.firmwareVersion
                : 'v1.0.0',
            is4gConnected: true,
            isGpsConnected: true,
            lastSyncTime: DateTime.now(),
            
            signalStrength: 80,
            sprinklerRunDurationMinutes: 15,
          );
          _sites.add(site);
          index = _sites.length - 1;
        } else {
          throw AppException('Site details not found');
        }
      } catch (e) {
        throw AppException('Error loading site details: $e');
      }
    } else {}

    // await connectWebSocket();
    // await fetchAQIAnalyticsRepo(
    //     _sites[index].imeiNo, DateFormat('dd-MM-yyyy').format(DateTime.now()));
    await _fetchCalibrationSchedule(index);
    await _fetchCalibrationInfo(index);

    await _fetchLatestForSite(index);
    await _loadSprinklerDataFromAsset();
    return _sites[index];
  }

  @override
  Future<void> addSite(SiteEntity site) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _sites.add(site);
  }

  @override
  Future<SiteEntity> toggleSprinkler(String siteId, bool isRunning) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final index = _sites.indexWhere((s) => s.id == siteId);
    if (index == -1) throw AppException('Site not found');

    final site = _sites[index];
    final history = List<SprinklerLog>.from(site.sprinklerHistory);
    history.insert(
      0,
      SprinklerLog(
        timestamp: DateTime.now(),
        status: isRunning ? 'Started' : 'Stopped',
        triggeredBy: 'Manual Mode',
        durationSeconds: isRunning ? 0 : 600,
      ),
    );

    final updatedSite = site.copyWith(
      isSprinklerRunning: isRunning,
      sprinklerLastTriggerTime:
          isRunning ? DateTime.now() : site.sprinklerLastTriggerTime,
      sprinklerHistory: history,
    );
    _sites[index] = updatedSite;

    // Record manual trigger state and timestamp
    _lastManualToggleTimes[siteId] = DateTime.now();
    _manualSprinklerStates[siteId] = isRunning;

    return updatedSite;
  }

  @override
  Future<SiteEntity> setSprinklerMode(String siteId, String mode) async {
    await Future.delayed(const Duration(milliseconds: 100));
    final index = _sites.indexWhere((s) => s.id == siteId);
    if (index == -1) throw AppException('Site not found');

    final updatedSite = _sites[index].copyWith(sprinklerMode: mode);
    _sites[index] = updatedSite;
    return updatedSite;
  }

  /// old record function to add calibration
  // @override
  // Future<SiteEntity> recordCalibration(
  //     String siteId, CalibrationHistoryModel log) async {
  //   await Future.delayed(const Duration(milliseconds: 300));
  //   final index = _sites.indexWhere((s) => s.id == siteId);
  //   if (index == -1) throw AppException('Site not found');

  //   final site = _sites[index];
  //   final history = List<CalibrationHistoryModel>.from(site.calibrationHistory);
  //   history.insert(0, log);

  //   final updatedSite = site.copyWith(
  //     lastCalibrationDate: log.calibrationDate,
  //     nextCalibrationDate: log.nextDueDate,
  //     calibrationHistory: history,
  //   );
  //   _sites[index] = updatedSite;
  //   _sitesStreamController.add(List.unmodifiable(_sites));
  //   return updatedSite;
  // }

  @override
  Future<void> recordCalibration(
      String siteId, CalibrationHistoryEntity record) async {
    final url = ApiConfig.saveClilbaratoinInfo();
    final body = record.nextDueDate != null
        ? {
            "device_id": record.deviceId ?? siteId,
            "calibration_date": DateFormat('yyyy-MM-dd')
                .format(record.calibrationDate!), //"2026-07-14",
            "calibrated_by": record.calibratedBy,
            "certificate_no": record.certificateNo,
            "next_due_date": DateFormat('yyyy-MM-dd')
                .format(record.nextDueDate!), //"2027-01-01",
            "remarks": record.remarks
          }
        : {
            "device_id": record.deviceId ?? siteId,
            "calibration_date": DateFormat('yyyy-MM-dd')
                .format(record.calibrationDate!), //"2026-07-14",
            "calibrated_by": record.calibratedBy,
            "certificate_no": record.certificateNo,
            "remarks": record.remarks
          };

    try {
      final response = await _apiClient.dio.post(url, data: body);

      final responseData = response.data;
      if (response.statusCode != null &&
          response.statusCode! >= 200 &&
          response.statusCode! < 300 &&
          responseData != null) {}
    } catch (e) {}
  }

  @override
  Future<void> updateCalibrationRecord(
      String siteId, CalibrationHistoryEntity record) async {
    final url = ApiConfig.updateClilbaratoinInfo();
    final body = {
      "calibration_info_id": record.calibrationInfoId,
      "device_id": record.deviceId ?? siteId,
      "calibration_date": DateFormat('yyyy-MM-dd')
          .format(record.calibrationDate!), //"2026-07-14",
      "calibrated_by": record.calibratedBy,
      "certificate_no": record.certificateNo,
      "next_due_date": record.nextDueDate != null
          ? DateFormat('yyyy-MM-dd').format(record.nextDueDate!)
          : null, //"2027-01-01",
      "remarks": record.remarks
    };

    try {
      final response = await _apiClient.dio.put(url, data: body);

      final responseData = response.data;
      if (response.statusCode != null &&
          response.statusCode! >= 200 &&
          response.statusCode! < 300 &&
          responseData != null) {}
    } catch (e) {}
  }

  @override
  Future<List<AqiTelemetryModel>> getAqiHistory(String deviceId,
      {int page = 0, int size = 2000}) async {
    final url = ApiConfig.aqiHistory(deviceId, page: page, size: size);
    try {
      final response = await _apiClient.dio.get(url);
      if (response.statusCode == 200 && response.data != null) {
        final data = response.data['data'];
        if (data is List) {
          return data
              .map((json) =>
                  AqiTelemetryModel.fromJson(json as Map<String, dynamic>))
              .toList();
        }
      }
      return [];
    } catch (e) {
      debugPrint('Error loading AQI history: $e');
      return [];
    }
  }

  @override
  Future<List<AqiTelemetryModel>> getAqiHistoryRange(
      String deviceId, String from, String to,
      {int page = 0, int size = 1000}) async {
    final requestSize = size > 1000 ? 1000 : size;
    final List<AqiTelemetryModel> allData = [];
    int currentPage = page;
    bool hasNext = true;

    try {
      while (hasNext && (currentPage - page) < 3) {
        final url = ApiConfig.aqiHistoryRange(
          deviceId,
          from,
          to,
          page: currentPage,
          size: requestSize,
        );
        final response = await _apiClient.dio.get(url);
        if (response.statusCode == 200 && response.data != null) {
          final data = response.data['data'];
          if (data is List) {
            final pageList = data
                .map((json) =>
                    AqiTelemetryModel.fromJson(json as Map<String, dynamic>))
                .toList();
            allData.addAll(pageList);

            // If we retrieved less records than requested, we've reached the end
            if (pageList.length < requestSize) {
              hasNext = false;
              break;
            }
          } else {
            hasNext = false;
            break;
          }

          final dynamic hasNextVal = response.data['hasNext'];
          if (hasNextVal is bool) {
            hasNext = hasNextVal;
          } else {
            hasNext = false;
          }
        } else {
          hasNext = false;
        }
        currentPage++;
      }
      return allData;
    } catch (e, trace) {
      debugPrint('Error loading AQI history range: $e \n $trace');
      return allData;
    }
  }

  /// Closes the SSE subscription and stream controller.
  void dispose() {
    _sseSubscription?.cancel();
    _webSocketSubscription?.cancel();
    _sitesStreamController.close();
    _webSocketSubscription = null;
  }

  // ─── SSE Subscription ─────────────────────────────────────────────────────

  void _subscribeSse() {
    _sseSubscription = _sseService.events.listen(
      (event) {
        if (event.data is Map<String, dynamic>) {
          try {
            final telemetry =
                AqiTelemetryModel.fromJson(event.data as Map<String, dynamic>);
            _updateSiteWithTelemetry(telemetry);
          } catch (e) {
            debugPrint('[SitesRepo] SSE telemetry parse error: $e');
          }
        }
      },
      onError: (error) {
        debugPrint('[SitesRepo] SSE stream error: $error');
      },
    );
  }

  Future<void> _subscribeWebSocket() async {
    if (!_isWebSocketSubscribed || _webSocketSubscription == null) {
      _isWebSocketSubscribed = true;
      _webSocketSubscription?.cancel();
      _webSocketSubscription = _websocketService.dataStream.listen(
        (event) {
          debugPrint("WEBSOCKET EVENT RECEIVED ${event.data}");

          try {
            final telemetry = AqiTelemetryModel.fromJson(event.data);

            _updateSiteWithTelemetry(telemetry);
          } catch (e, stack) {
            debugPrint(
              "Telemetry parsing failed $e \n $stack",
            );
          }
        },
        onError: (error) {
          log("WebSocket stream error $error");
        },
      );
    }

    await _websocketService.connectWebSocket();
  }

  // Future<void> _subscribeWebSocket() async {
  //   // Prevent duplicate WebSocket subscriptions from piling up
  //   if (_isWebSocketSubscribed) return;
  //   _isWebSocketSubscribed = true;

  //   // Cancel any stale listener before creating a new one
  //   _webSocketSubscription?.cancel();
  //   _webSocketSubscription = null;

  //   _webSocketSubscription = _websocketService.dataStream.listen(
  //     (event) {
  //       log("WEBSOCKET EVENT RECEIVED $event");

  //       final telemetry = AqiTelemetryModel.fromJson(event.data);

  //       _updateSiteWithTelemetry(telemetry);
  //     },
  //     onError: (error) {
  //       debugPrint('[SitesRepo] WebSocket stream error: $error');
  //     },
  //   );

  //   await connectWebSocket();
  // }
  // ─── REST Fetch ───────────────────────────────────────────────────────────

  /// Fetch Calibration data
  Future<void> _fetchCalibrationInfo(int index) async {
    final site = _sites[index];
    final deviceId = site.id;

    if (deviceId.isEmpty) return;
    if (_mockDeviceIds.contains((deviceId))) {
      return;
    }

    final fetcCalibrationUrl =
        ApiConfig.getClilbaratoinInfoByDeviceID(deviceId);

    try {
      final calibrationInfoResponse =
          await _apiClient.dio.get(fetcCalibrationUrl);
      if (calibrationInfoResponse.statusCode == 200) {
        List<CalibrationHistoryModel> history =
            (calibrationInfoResponse.data['calibration_info'] ?? [])
                .map<CalibrationHistoryModel>(
                  (e) => CalibrationHistoryModel.fromMap(e),
                )
                .toList();

        _sites[index] = _sites[index].copyWith(calibrationHistory: history);
      }
    } catch (e) {
      debugPrint("error while fetching calirbation info $e");
    }
  }

  /// Fetch Calibration Schedule
  Future<void> _fetchCalibrationSchedule(int index) async {
    final site = _sites[index];
    final deviceId = site.id;

    if (deviceId.isEmpty) return;
    if (_mockDeviceIds.contains((deviceId))) {
      return;
    }

    final fetcCalibrationScheduleUrl =
        ApiConfig.getClilbaratoinScheduleByDeviceID(deviceId);

    try {
      final calibrationScheduleResponse =
          await _apiClient.dio.get(fetcCalibrationScheduleUrl);

      if (calibrationScheduleResponse.statusCode == 200) {
        List<CalibrationScheduleModel> calibrationSchedule =
            (calibrationScheduleResponse.data['schedules'] ?? [])
                .map<CalibrationScheduleModel>(
                  (e) => CalibrationScheduleModel.fromMap(e),
                )
                .toList();

        _sites[index] = _sites[index]
            .copyWith(calibrationScheduleList: calibrationSchedule);
      }
    } catch (e) {
      debugPrint("error while fetching calirbation schedule $e");
    }
  }

  /// Fetch latest telemetry for a single site via REST.
  ///
  /// Note: Live data is handled by the single WebSocket subscription
  /// set up in the constructor. Do NOT call _subscribeWebSocket() here
  /// to avoid creating duplicate listeners per site.
  Future<void> _fetchLatestForSite(int index) async {
    final site = _sites[index];
    final deviceId = site.deviceSerial;
    if (deviceId.isEmpty) return;

    // Skip network calls for mock/placeholder devices that don't exist on the backend
    if (_mockDeviceIds.contains(deviceId)) {
      return;
    }

    // REST-based latest fetch is currently disabled in favour of WebSocket.
    // The WebSocket subscription is managed once in the constructor via
    // _subscribeWebSocket() — no per-site subscription needed.
  }

  // ─── Telemetry → SiteEntity Mapping ─────────────────────────────

  void _updateSiteWithTelemetry(AqiTelemetryModel telemetry) {
    final deviceId = telemetry.deviceId.toString().trim();

    if (deviceId.isEmpty) return;

    final index = _sites.indexWhere((s) {
      return (s.imeiNo.isNotEmpty && s.imeiNo == deviceId) ||
          (s.deviceSerial.isNotEmpty && s.deviceSerial == deviceId) ||
          (s.id.isNotEmpty && s.id == deviceId);
    });
    if (index == -1) {
      debugPrint("No matching site found for telemetry deviceId $deviceId!");
      return;
    }

    _applyTelemetryToSite(index, telemetry);
    _sitesStreamController.add(List.unmodifiable(_sites));
  }

  void _applyTelemetryToSite(int index, AqiTelemetryModel telemetry) {
    final site = _sites[index];
    final updatedParams = _buildParameters(telemetry, site.parameters);

    bool isSprinklerRunning =
        telemetry.sprinkler != null && telemetry.sprinkler != 0;

    // Bypass check: if the user manually toggled the sprinkler in-app within the last 5 minutes,
    // preserve the manual choice instead of letting incoming hardware SSE/latest REST payloads overwrite it.
    final lastToggleTime = _lastManualToggleTimes[site.id];
    if (lastToggleTime != null &&
        DateTime.now().difference(lastToggleTime) <
            const Duration(minutes: 5)) {
      isSprinklerRunning =
          _manualSprinklerStates[site.id] ?? isSprinklerRunning;
    }

    final telemetryTime =
        _parseTelemetryDateTime(telemetry.date, telemetry.time);

    final lastSync = telemetryTime ?? DateTime.now();
    final isOnline = telemetryTime != null &&
        DateTime.now().difference(telemetryTime).inMinutes.abs() < 5;

    _sites[index] = site.copyWith(
      aqi: telemetry.aqi ?? site.aqi,
      parameters: updatedParams,
      isDeviceOnline: isOnline,
      is4gConnected: isOnline,
      isGpsConnected: isOnline,
      lastSyncTime: lastSync,
      isSprinklerRunning: isSprinklerRunning,
    );
  }

  /// Merges telemetry values into the parameter map.
  ///
  /// If a telemetry field is `null` (not sent by the API), the previous
  /// value is retained. This ensures UI always shows the most recent
  /// known value rather than jumping to "-".
  Map<String, SensorReading> _buildParameters(
    AqiTelemetryModel telemetry,
    Map<String, SensorReading> current,
  ) {
    final updated = Map<String, SensorReading>.from(current);

    // Helper: only overwrite if the new value is non-null.
    void set(String key, double? value, String unit) {
      if (value != null) {
        updated[key] = SensorReading(value, unit);
      } else if (!updated.containsKey(key)) {
        // Ensure key exists even if value is null (shows "-" in UI).
        updated[key] = SensorReading(null, unit);
      }
    }

    set('PM1', telemetry.pm1, 'µg/m³');
    set('PM2.5', telemetry.pm25, 'µg/m³');
    set('PM10', telemetry.pm10, 'µg/m³');
    set('TSP', telemetry.tsp, 'µg/m³');
    set('Temp', telemetry.temperature, '°C');
    set('Humidity', telemetry.humidity, '%');
    set('CO', telemetry.co, 'ppm');
    set('CO₂', telemetry.co2, 'ppm');
    set('Noise', telemetry.noise, 'dB');

    // These parameters are not provided by the current API.
    // Keep existing values or ensure the key exists for UI display.
    if (!updated.containsKey('NO₂')) {
      updated['NO₂'] = const SensorReading(null, 'ppb');
    }
    if (!updated.containsKey('SO₂')) {
      updated['SO₂'] = const SensorReading(null, 'ppb');
    }
    if (!updated.containsKey('O₃')) {
      updated['O₃'] = const SensorReading(null, 'ppb');
    }
    if (!updated.containsKey('VOC')) {
      updated['VOC'] = const SensorReading(null, 'ppm');
    }

    return updated;
  }

  // ─── Initial Site Data ────────────────────────────────────────────────────

  void _initSiteData() {
    // No mock/dummy sites populated to show real data only
  }

  Future<void> _loadSprinklerDataFromAsset() async {
    try {
      final jsonString = await rootBundle.loadString('lib/data.json');
      final Map<String, dynamic> jsonMap = json.decode(jsonString);
      final response = SprinklerHistoryResponse.fromJson(jsonMap);

      final targetDeviceId = response.deviceId;
      final index = _sites.indexWhere((s) => s.id == targetDeviceId || s.deviceSerial == targetDeviceId);
      if (index != -1) {
        final site = _sites[index];

        if (response.detail.isNotEmpty) {
          final sortedDetails = List<SprinklerDailyDetail>.from(response.detail);
          sortedDetails.sort((a, b) {
            try {
              final partsA = a.date.split('-');
              final partsB = b.date.split('-');
              final dateA = DateTime(int.parse(partsA[2]), int.parse(partsA[1]), int.parse(partsA[0]));
              final dateB = DateTime(int.parse(partsB[2]), int.parse(partsB[1]), int.parse(partsB[0]));
              return dateB.compareTo(dateA);
            } catch (_) {
              return 0;
            }
          });

          DateTime? lastTriggerTime;
          int runDurationMinutes = 0;
          final List<SprinklerLog> historyLogs = [];

          for (final detail in response.detail) {
            for (final item in detail.history) {
              final onDateTime = DateTime.tryParse(item.ontime);
              final offDateTime = DateTime.tryParse(item.offTime);
              final durStr = item.time.replaceAll('min', '');
              final dur = int.tryParse(durStr) ?? 0;

              if (onDateTime != null) {
                historyLogs.add(SprinklerLog(
                  timestamp: onDateTime,
                  status: 'Started',
                  triggeredBy: 'Auto',
                  durationSeconds: dur * 60,
                ));
                if (offDateTime != null) {
                  historyLogs.add(SprinklerLog(
                    timestamp: offDateTime,
                    status: 'Stopped',
                    triggeredBy: 'Auto',
                    durationSeconds: dur * 60,
                  ));
                }

                if (lastTriggerTime == null || onDateTime.isAfter(lastTriggerTime)) {
                  lastTriggerTime = onDateTime;
                  runDurationMinutes = dur;
                }
              }
            }
          }

          historyLogs.sort((a, b) => b.timestamp.compareTo(a.timestamp));

          _sites[index] = site.copyWith(
            sprinklerLastTriggerTime: lastTriggerTime,
            sprinklerRunDurationMinutes: runDurationMinutes,
            sprinklerHistory: historyLogs,
          );
        }
      }
    } catch (e) {
      debugPrint('[SitesRepositoryImpl] Error loading sprinkler asset: $e');
    }
  }

  DateTime? _parseTelemetryDateTime(String? dateStr, String? timeStr) {
    if (dateStr == null || dateStr.isEmpty) return null;
    try {
      if (dateStr.contains('T')) {
        return DateTime.tryParse(dateStr);
      }

      int year = 0;
      int month = 0;
      int day = 0;

      final String separator;
      if (dateStr.contains('/')) {
        separator = '/';
      } else if (dateStr.contains('-')) {
        separator = '-';
      } else {
        return DateTime.tryParse(dateStr);
      }

      final parts = dateStr.split(separator);
      if (parts.length != 3) return null;

      if (parts[0].length == 4) {
        year = int.parse(parts[0]);
        month = int.parse(parts[1]);
        day = int.parse(parts[2]);
      } else {
        day = int.parse(parts[0]);
        month = int.parse(parts[1]);
        year = int.parse(parts[2]);
      }

      int hour = 0;
      int minute = 0;
      int second = 0;

      if (timeStr != null && timeStr.isNotEmpty) {
        final timeParts = timeStr.split(':');
        if (timeParts.isNotEmpty) {
          hour = int.tryParse(timeParts[0]) ?? 0;
        }
        if (timeParts.length > 1) {
          minute = int.tryParse(timeParts[1]) ?? 0;
        }
        if (timeParts.length > 2) {
          final secStr = timeParts[2].split('.')[0].split('+')[0];
          second = int.tryParse(secStr) ?? 0;
        }
      }

      return DateTime(year, month, day, hour, minute, second);
    } catch (_) {
      return null;
    }
  }

  @override
  void clearCache() {
    debugPrint('[Repository] Clearing cache and resetting customer tracking.');
    _sites.clear();
    _lastCustomerId = null;
  }

  @override
  Future<void> updateCalibrationSchedule(
      String siteId, CalibrationScheduleEntity schedule) async {
    final url = ApiConfig.updateClilbaratoinSchedule();
    final body = {
      "calibration_schedule_id": schedule.calibrationScheduleId,
      "device_id": siteId,
      "scheduled_date": DateFormat('yyyy-MM-dd')
          .format(schedule.scheduledDate!), //"2026-09-14",
      "status": schedule.status,
      "actual_scheduled_date": schedule.actualScheduledDate != null
          ? DateFormat('yyyy-MM-dd').format(schedule.actualScheduledDate!)
          : null //"2026-07-28"
    };

    try {
      final response = await _apiClient.dio.put(url, data: body);

      final responseData = response.data;
      if (response.statusCode != null &&
          response.statusCode! >= 200 &&
          response.statusCode! < 300 &&
          responseData != null) {}
    } catch (e) {
      debugPrint("error while update the calibration $e");
    }
  }

  @override
  Future<void> connectWebSocket() async {
    await _subscribeWebSocket();
  }

  @override
  Future<void> disconnectWebSocket() async {
    _isWebSocketSubscribed = false;
    await _websocketService.disconnectWebSocket();
    _webSocketSubscription?.cancel();
    _webSocketSubscription = null;
  }

  @override
  Stream<List<SiteEntity>> get liveDataStream => _sitesStreamController.stream;

  @override
  Future<void> initializeWebSocket() async {
    log("initialize websocket called");
    await _subscribeWebSocket();
  }
}
