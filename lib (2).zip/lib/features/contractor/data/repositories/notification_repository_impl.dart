import 'dart:developer';

import 'package:vasundhara_maha_aqim/core/exceptions/app_exception.dart';
import 'package:vasundhara_maha_aqim/core/network/api_client.dart';
import 'package:vasundhara_maha_aqim/core/network/api_config.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/notification_history_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/notification_respository.dart';

class NotificationRepositoryImpl implements NotificationRespository {
  final ApiClient _apiClient;
  NotificationRepositoryImpl(this._apiClient);

  @override
  Future<List<NotificationHistoryModel>>
      fetchNotificationRangeWithStartAndEndRepo(
          {String? page,
          String? size,
          required String fromDate,
          required String toDate}) async {
    final url = ApiConfig.notificationHistoryWithRange(
        page: page!, size: size!, startDate: fromDate, endDate: toDate);
    try {
      final response = await _apiClient.dio.get(url);

      log("this is the api response for notificatin ${response.data}");

      if (response.statusCode == 200) {
        List<NotificationHistoryModel> notificationHistory =
            (response.data['notification_history'] as List<dynamic>)
                .map<NotificationHistoryModel>(
                    (d) => NotificationHistoryModel.fromJson(d))
                .toList();
        if (notificationHistory.isNotEmpty) {
          log("if not empty");
          return notificationHistory;
        } else {
          log("if empty");
          return [
            // NotificationHistoryModel(
            //   aliasDept: "AA",
            //   createdAt: DateTime.now().toString(),
            //   description: "Pm2.5 Exeeded threwjed",
            //   eventType: "ALERT",
            //   layerName: "Notificaiton",
            //   lineNo: "lsma",
            //   notificationId: 2,
            //   priority: 2,
            //   sendAlert: true,
            //   sendNotification: true,
            //   solution: "smakmskl",
            //   source: "from iot device ",
            //   srNo: 3,
            //   title: 'noticaiton test',
            //   topic: "aa",
            //   username: "rangit",
            // ),
          ];
        }
      } else {
        log("if response is not 200");
        return [];
      }
    } catch (e) {
      throw AppException('Data not found');
    }
  }
}
