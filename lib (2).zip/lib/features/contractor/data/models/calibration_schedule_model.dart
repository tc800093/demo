import 'dart:convert';

import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_schedule_entity.dart';

CalibrationScheduleModel calibrationScheduleModelFromMap(String str) =>
    CalibrationScheduleModel.fromMap(json.decode(str));

String calibrationScheduleModelToMap(CalibrationScheduleModel data) =>
    json.encode(data.toMap());

class CalibrationScheduleModel extends CalibrationScheduleEntity {
  const CalibrationScheduleModel({
    super.srNo,
    super.calibrationScheduleId,
    super.deviceId,
    super.scheduledDate,
    super.status,
    super.createdAt,
    super.actualScheduledDate,
  });

  factory CalibrationScheduleModel.fromMap(Map<String, dynamic> json) {
    return CalibrationScheduleModel(
      srNo: json["sr_no"],
      calibrationScheduleId: json["calibration_schedule_id"],
      deviceId: json["device_id"],
      scheduledDate: json["scheduled_date"] == null
          ? null
          : DateTime.parse(json["scheduled_date"]),
      status: json["status"],
      createdAt: json["created_at"],
      actualScheduledDate: json["actual_scheduled_date"] == null
          ? null
          : DateTime.parse(
              json["actual_scheduled_date"],
            ),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "sr_no": srNo,
      "calibration_schedule_id": calibrationScheduleId,
      "device_id": deviceId,
      "scheduled_date": scheduledDate?.toIso8601String(),
      "status": status,
      "created_at": createdAt,
      "actual_scheduled_date": actualScheduledDate?.toIso8601String(),
    };
  }

  factory CalibrationScheduleModel.fromEntity(
      CalibrationScheduleEntity entity) {
    return CalibrationScheduleModel(
      srNo: entity.srNo,
      calibrationScheduleId: entity.calibrationScheduleId,
      deviceId: entity.deviceId,
      scheduledDate: entity.scheduledDate,
      status: entity.status,
      createdAt: entity.createdAt,
      actualScheduledDate: entity.actualScheduledDate,
    );
  }
}
