/// Model representing the live AQI telemetry data from SSE streams or REST endpoints.
///
/// All numeric fields are nullable to gracefully handle missing or
/// unexpected values from the backend. The [fromJson] factory uses
/// a defensive [_parseDouble] helper that accepts `num`, `String`,
/// and `null` inputs.
class AqiTelemetryModel {
  final String? date;
  final String? time;
  final double? pm1;
  final double? pm25;
  final double? pm10;
  final double? tsp;
  final double? co2;
  final double? temperature;
  final double? humidity;
  final double? co;
  final int? aqi;
  final double? noise;
  final dynamic sprinkler;
  final String deviceId;
  final String? simNo;
  final String? messageType;
  final String? aqiCategory;

  AqiTelemetryModel({
    this.date,
    this.time,
    this.pm1,
    this.pm25,
    this.pm10,
    this.tsp,
    this.co2,
    this.temperature,
    this.humidity,
    this.co,
    this.aqi,
    this.noise,
    this.sprinkler,
    required this.deviceId,
    this.simNo,
    this.messageType,
    this.aqiCategory,
  });

  /// Safely parse any value to a [double], returning null on failure.
  static double? _parseDouble(dynamic v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }

  /// Safely parse any value to an [int], returning null on failure.
  static int? _parseInt(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString());
  }

  /// Safely decodes a JSON map into the telemetry model.
  ///
  /// Missing keys default to `null`. The `device_id` key is required
  /// but falls back to an empty string if absent.
  factory AqiTelemetryModel.fromJson(Map<String, dynamic> json) {
    return AqiTelemetryModel(
      date: json['date']?.toString() ?? json['recordedAt']?.toString(),
      time: json['time']?.toString(),
      pm1: _parseDouble(json['pm1']),
      pm25: _parseDouble(json['pm25'] ?? json['pm2.5'] ?? 0),
      pm10: _parseDouble(json['pm10']),
      tsp: _parseDouble(json['tsp']),
      co2: _parseDouble(json['co2']),
      temperature: _parseDouble(json['temperature']),
      humidity: _parseDouble(json['humidity']),
      co: _parseDouble(json['co']),
      aqi: _parseInt(json['aqi']),
      noise: _parseDouble(json['noise']),
      sprinkler: json['sprinkler'] ?? json['sprinkler status'] ?? '',
      deviceId:
          json['deviceId']?.toString() ?? json['device_id']?.toString() ?? '',
      simNo: json['simNo']?.toString() ?? json['sim_no']?.toString() ?? '',
      messageType: json['messageType']?.toString() ??
          json['message_type']?.toString() ??
          json['msgType']?.toString() ??
          '',
      aqiCategory: json['aqiCategory']?.toString() ??
          json['aqi_categorye']?.toString() ??
          json['aqi category']?.toString() ??
          '',
    );
  }
}
