import '../../domain/entities/analytics_day_wise_entity.dart';

class AnalyticsDayWiseModel extends AnalyticsDayWiseEntity {
  const AnalyticsDayWiseModel({
    super.aqiDate,
    super.minAqi,
    super.maxAqi,
    super.avgAqi,
  });

  factory AnalyticsDayWiseModel.fromJson(Map<String, dynamic> json) {
    return AnalyticsDayWiseModel(
      aqiDate: json["aqi_date"],
      minAqi: json["min_aqi"],
      maxAqi: json["max_aqi"],
      avgAqi: json["avg_aqi"]?.toDouble(),
    );
  }

  AnalyticsDayWiseModel copyWith({
    String? aqiDate,
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) {
    return AnalyticsDayWiseModel(
      aqiDate: aqiDate ?? this.aqiDate,
      minAqi: minAqi ?? this.minAqi,
      maxAqi: maxAqi ?? this.maxAqi,
      avgAqi: avgAqi ?? this.avgAqi,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "aqi_date": aqiDate,
      "min_aqi": minAqi,
      "max_aqi": maxAqi,
      "avg_aqi": avgAqi,
    };
  }
}
