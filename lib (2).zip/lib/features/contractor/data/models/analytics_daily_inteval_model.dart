import '../../domain/entities/analytics_daily_interval_entity.dart';

class AnalyticsDailyIntervalModel extends AnalyticsDailyIntervalEntity {
  const AnalyticsDailyIntervalModel({
    DailySummaryModel? dailySummary,
    List<IntervalModel>? intervals,
  }) : super(
          dailySummary: dailySummary,
          intervals: intervals,
        );

  factory AnalyticsDailyIntervalModel.fromJson(Map<String, dynamic> json) {
    return AnalyticsDailyIntervalModel(
      dailySummary: json["daily_summary"] == null
          ? null
          : DailySummaryModel.fromJson(
              json["daily_summary"],
            ),
      intervals: json["intervals"] == null
          ? []
          : List<IntervalModel>.from(
              json["intervals"].map(
                (x) => IntervalModel.fromJson(x),
              ),
            ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "daily_summary": (dailySummary as DailySummaryModel?)?.toJson(),
      "intervals": intervals
              ?.map(
                (e) => (e as IntervalModel).toJson(),
              )
              .toList() ??
          [],
    };
  }
}

class DailySummaryModel extends DailySummaryEntity {
  const DailySummaryModel({
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) : super(
          minAqi: minAqi,
          maxAqi: maxAqi,
          avgAqi: avgAqi,
        );

  factory DailySummaryModel.fromJson(Map<String, dynamic> json) {
    return DailySummaryModel(
      minAqi: json["min_aqi"],
      maxAqi: json["max_aqi"],
      avgAqi: json["avg_aqi"]?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "min_aqi": minAqi,
      "max_aqi": maxAqi,
      "avg_aqi": avgAqi,
    };
  }

  DailySummaryModel copyWith({
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) {
    return DailySummaryModel(
      minAqi: minAqi ?? this.minAqi,
      maxAqi: maxAqi ?? this.maxAqi,
      avgAqi: avgAqi ?? this.avgAqi,
    );
  }
}

class IntervalModel extends IntervalEntity {
  const IntervalModel({
    String? intervalStart,
    String? intervalEnd,
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) : super(
          intervalStart: intervalStart,
          intervalEnd: intervalEnd,
          minAqi: minAqi,
          maxAqi: maxAqi,
          avgAqi: avgAqi,
        );

  factory IntervalModel.fromJson(Map<String, dynamic> json) {
    return IntervalModel(
      intervalStart: json["interval_start"],
      intervalEnd: json["interval_end"],
      minAqi: json["min_aqi"],
      maxAqi: json["max_aqi"],
      avgAqi: json["avg_aqi"]?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "interval_start": intervalStart,
      "interval_end": intervalEnd,
      "min_aqi": minAqi,
      "max_aqi": maxAqi,
      "avg_aqi": avgAqi,
    };
  }

  IntervalModel copyWith({
    String? intervalStart,
    String? intervalEnd,
    int? minAqi,
    int? maxAqi,
    double? avgAqi,
  }) {
    return IntervalModel(
      intervalStart: intervalStart ?? this.intervalStart,
      intervalEnd: intervalEnd ?? this.intervalEnd,
      minAqi: minAqi ?? this.minAqi,
      maxAqi: maxAqi ?? this.maxAqi,
      avgAqi: avgAqi ?? this.avgAqi,
    );
  }
}
