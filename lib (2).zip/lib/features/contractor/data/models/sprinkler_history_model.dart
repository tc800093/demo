class SprinklerHistoryResponse {
  final String deviceId;
  final String fromDate;
  final String toDate;
  final List<SprinklerDailyDetail> detail;

  SprinklerHistoryResponse({
    required this.deviceId,
    required this.fromDate,
    required this.toDate,
    required this.detail,
  });

  factory SprinklerHistoryResponse.fromJson(Map<String, dynamic> json) {
    return SprinklerHistoryResponse(
      deviceId: json['deviceid']?.toString() ?? '',
      fromDate: json['fromdate']?.toString() ?? '',
      toDate: json['todate']?.toString() ?? '',
      detail: (json['detail'] as List?)
              ?.map((e) => SprinklerDailyDetail.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }
}

class SprinklerDailyDetail {
  final String date;
  final String totalDuration;
  final String totalCount;
  final List<SprinklerHistoryItem> history;

  SprinklerDailyDetail({
    required this.date,
    required this.totalDuration,
    required this.totalCount,
    required this.history,
  });

  factory SprinklerDailyDetail.fromJson(Map<String, dynamic> json) {
    return SprinklerDailyDetail(
      date: json['date']?.toString() ?? '',
      totalDuration: json['totalDuration']?.toString() ?? '',
      totalCount: json['totalcount']?.toString() ?? '',
      history: (json['history'] as List?)
              ?.map((e) => SprinklerHistoryItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }
}

class SprinklerHistoryItem {
  final String ontime;
  final String offTime;
  final String time;

  SprinklerHistoryItem({
    required this.ontime,
    required this.offTime,
    required this.time,
  });

  factory SprinklerHistoryItem.fromJson(Map<String, dynamic> json) {
    return SprinklerHistoryItem(
      ontime: json['ontime']?.toString() ?? '',
      offTime: json['offTime']?.toString() ?? '',
      time: json['time']?.toString() ?? '',
    );
  }
}
