import 'dart:convert';

import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_entity.dart';

CalibrationHistoryModel calibrationHistoryModelFromMap(String str) =>
    CalibrationHistoryModel.fromMap(json.decode(str));

String calibrationHistoryModelToMap(CalibrationHistoryModel data) =>
    json.encode(data.toMap());

class CalibrationHistoryModel extends CalibrationHistoryEntity {
  const CalibrationHistoryModel({
    super.srNo,
    super.calibrationInfoId,
    super.deviceId,
    super.calibrationDate,
    super.calibratedBy,
    super.certificateNo,
    super.nextDueDate,
    super.remarks,
    super.createdAt,
  });

  factory CalibrationHistoryModel.fromMap(Map<String, dynamic> json) {
    return CalibrationHistoryModel(
      srNo: json["sr_no"],
      calibrationInfoId: json["calibration_info_id"],
      deviceId: json["device_id"],
      calibrationDate: json["calibration_date"] == null
          ? null
          : DateTime.parse(json["calibration_date"]),
      calibratedBy: json["calibrated_by"],
      certificateNo: json["certificate_no"],
      nextDueDate: json["next_due_date"] == null
          ? null
          : DateTime.parse(json["next_due_date"]),
      remarks: json["remarks"],
      createdAt: json["created_at"],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "sr_no": srNo,
      "calibration_info_id": calibrationInfoId,
      "device_id": deviceId,
      "calibration_date": calibrationDate?.toIso8601String(),
      "calibrated_by": calibratedBy,
      "certificate_no": certificateNo,
      "next_due_date": nextDueDate?.toIso8601String(),
      "remarks": remarks,
      "created_at": createdAt,
    };
  }

  factory CalibrationHistoryModel.fromEntity(CalibrationHistoryEntity entity) {
    return CalibrationHistoryModel(
      srNo: entity.srNo,
      calibrationInfoId: entity.calibrationInfoId,
      deviceId: entity.deviceId,
      calibrationDate: entity.calibrationDate,
      calibratedBy: entity.calibratedBy,
      certificateNo: entity.certificateNo,
      nextDueDate: entity.nextDueDate,
      remarks: entity.remarks,
      createdAt: entity.createdAt,
    );
  }
}
