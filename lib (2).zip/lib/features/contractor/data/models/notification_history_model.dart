import 'dart:convert';

import '../../domain/entities/notification_history_entity.dart';

List<NotificationHistoryModel> notificationHistoryModelFromJson(
  String str,
) =>
    List<NotificationHistoryModel>.from(
      json.decode(str).map(
            (x) => NotificationHistoryModel.fromJson(x),
          ),
    );

String notificationHistoryModelToJson(
  List<NotificationHistoryModel> data,
) =>
    json.encode(
      List<dynamic>.from(
        data.map((x) => x.toJson()),
      ),
    );

class NotificationHistoryModel extends NotificationHistoryEntity {
  const NotificationHistoryModel({
    super.srNo,
    super.notificationId,
    super.source,
    super.title,
    super.description,
    super.priority,
    super.lineNo,
    super.layerName,
    super.username,
    super.eventType,
    super.sendNotification,
    super.sendAlert,
    super.topic,
    super.aliasDept,
    super.solution,
    super.createdAt,
  });

  factory NotificationHistoryModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return NotificationHistoryModel(
      srNo: json['sr_no'],
      notificationId: json['notification_id'],
      source: json['source'],
      title: json['title'],
      description: json['description'],
      priority: json['priority'],
      lineNo: json['line_no'],
      layerName: json['layer_name'],
      username: json['username'],
      eventType: json['event_type'],
      sendNotification: json['send_notification'],
      sendAlert: json['send_alert'],
      topic: json['topic'],
      aliasDept: json['alias_dept'],
      solution: json['solution'],
      createdAt: json['created_at'],
    );
  }

  factory NotificationHistoryModel.fromEntity(
    NotificationHistoryEntity entity,
  ) {
    return NotificationHistoryModel(
      srNo: entity.srNo,
      notificationId: entity.notificationId,
      source: entity.source,
      title: entity.title,
      description: entity.description,
      priority: entity.priority,
      lineNo: entity.lineNo,
      layerName: entity.layerName,
      username: entity.username,
      eventType: entity.eventType,
      sendNotification: entity.sendNotification,
      sendAlert: entity.sendAlert,
      topic: entity.topic,
      aliasDept: entity.aliasDept,
      solution: entity.solution,
      createdAt: entity.createdAt,
    );
  }

  NotificationHistoryModel copyWith({
    int? srNo,
    int? notificationId,
    String? source,
    String? title,
    String? description,
    int? priority,
    String? lineNo,
    String? layerName,
    String? username,
    String? eventType,
    bool? sendNotification,
    bool? sendAlert,
    String? topic,
    String? aliasDept,
    String? solution,
    String? createdAt,
  }) {
    return NotificationHistoryModel(
      srNo: srNo ?? this.srNo,
      notificationId: notificationId ?? this.notificationId,
      source: source ?? this.source,
      title: title ?? this.title,
      description: description ?? this.description,
      priority: priority ?? this.priority,
      lineNo: lineNo ?? this.lineNo,
      layerName: layerName ?? this.layerName,
      username: username ?? this.username,
      eventType: eventType ?? this.eventType,
      sendNotification: sendNotification ?? this.sendNotification,
      sendAlert: sendAlert ?? this.sendAlert,
      topic: topic ?? this.topic,
      aliasDept: aliasDept ?? this.aliasDept,
      solution: solution ?? this.solution,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sr_no': srNo,
      'notification_id': notificationId,
      'source': source,
      'title': title,
      'description': description,
      'priority': priority,
      'line_no': lineNo,
      'layer_name': layerName,
      'username': username,
      'event_type': eventType,
      'send_notification': sendNotification,
      'send_alert': sendAlert,
      'topic': topic,
      'alias_dept': aliasDept,
      'solution': solution,
      'created_at': createdAt,
    };
  }
}
