import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/config/theme/colors.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_day_wise_entity.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/sprinkler_history_cubit.dart';
import '../../data/models/sprinkler_history_model.dart';

class SprinklerUsagePage extends StatefulWidget {
  const SprinklerUsagePage({super.key});

  @override
  State<SprinklerUsagePage> createState() => _SprinklerUsagePageState();
}

class _SprinklerUsagePageState extends State<SprinklerUsagePage> {
  late DateTime _startDate;
  late DateTime _endDate;
  DateTime? _activeDay;
  // int? _selectedTimelineIndex;
  late ScrollController _calendarScrollController;
  late String _currentHeaderMonthYear;
  bool _showLeftIndicator = true;
  bool _showRightIndicator = false;

  @override
  void initState() {
    super.initState();
    final today = DateTime.now();
    _endDate = today;
    _startDate = DateTime(today.year, today.month, today.day)
        .subtract(const Duration(days: 7));
    _activeDay = DateTime(today.year, today.month, today.day);
    // _selectedTimelineIndex = null;

    _currentHeaderMonthYear = _getHeaderString(_startDate, _endDate);

    _calendarScrollController = ScrollController();

    _calendarScrollController.addListener(() {
      if (_calendarScrollController.hasClients) {
        final maxScroll = _calendarScrollController.position.maxScrollExtent;
        final currentScroll = _calendarScrollController.offset;

        final showLeft = currentScroll < maxScroll - 5;
        final showRight = currentScroll > 5;

        // Calculate month/year of the centered item dynamically
        final today = DateTime.now();
        final double viewportWidth = MediaQuery.of(context).size.width;
        final double centerOffset = currentScroll + (viewportWidth / 2);
        final double padding = 16.w;
        final int centerIndex =
            ((centerOffset - padding - 31.w) / 62.w).round();

        final centerDate =
            today.subtract(Duration(days: centerIndex.clamp(0, 100000)));
        final months = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December'
        ];
        final String newHeader =
            "${months[centerDate.month - 1]} ${centerDate.year}";

        if (showLeft != _showLeftIndicator ||
            showRight != _showRightIndicator ||
            (_startDate.day == _endDate.day &&
                newHeader != _currentHeaderMonthYear)) {
          setState(() {
            _showLeftIndicator = showLeft;
            _showRightIndicator = showRight;
            if (_startDate.day == _endDate.day) {
              _currentHeaderMonthYear = newHeader;
            }
          });
        }
      }
    });
  }

  String _getHeaderString(DateTime start, DateTime end) {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    final startDay = DateTime(start.year, start.month, start.day);
    final endDay = DateTime(end.year, end.month, end.day);
    if (startDay == endDay) {
      return "${months[startDay.month - 1]} ${startDay.year}";
    }
    final startAbbr = months[startDay.month - 1].substring(0, 3);
    final endAbbr = months[endDay.month - 1].substring(0, 3);
    if (startDay.year == endDay.year) {
      return "${startDay.day} $startAbbr - ${endDay.day} $endAbbr, ${startDay.year}";
    }
    return "${startDay.day} $startAbbr ${startDay.year} - ${endDay.day} $endAbbr ${endDay.year}";
  }

  SprinklerDailyData _getDailyDataForDate(DateTime date, List<SprinklerDailyDetail> details) {
    final dateStr = DateFormat('dd-MM-yyyy').format(date);
    
    final match = details.firstWhere(
      (d) => d.date == dateStr,
      orElse: () => SprinklerDailyDetail(
        date: dateStr,
        totalDuration: "0m",
        totalCount: "0",
        history: [],
      ),
    );

    String lastTime = "No activity";
    String lastType = "None";
    if (match.history.isNotEmpty) {
      final latest = match.history.first;
      try {
        final dt = DateTime.parse(latest.ontime);
        lastTime = DateFormat('hh:mm a').format(dt);
        lastType = "Started";
        if (latest.offTime.isNotEmpty) {
          final stopDt = DateTime.parse(latest.offTime);
          lastTime = DateFormat('hh:mm a').format(stopDt);
          lastType = "Stopped";
        }
      } catch (_) {
        lastTime = "No activity";
        lastType = "None";
      }
    }

    String dur = match.totalDuration;
    if (!dur.contains('h') && !dur.contains('m') && dur.isNotEmpty) {
      dur = "$dur min";
    }
    dur = dur.replaceAll('min', 'm');

    return SprinklerDailyData(
      totalStarts: int.tryParse(match.totalCount) ?? match.history.length,
      totalDuration: dur.isEmpty ? "0m" : dur,
      lastActionTime: lastTime,
      lastActionType: lastType,
    );
  }

  List<SprinklerEventModel> _getEventsForDate(DateTime date, List<SprinklerDailyDetail> details) {
    final dateStr = DateFormat('dd-MM-yyyy').format(date);
    
    final match = details.firstWhere(
      (d) => d.date == dateStr,
      orElse: () => SprinklerDailyDetail(
        date: dateStr,
        totalDuration: "0m",
        totalCount: "0",
        history: [],
      ),
    );

    final List<SprinklerEventModel> events = [];
    for (final item in match.history) {
      if (item.offTime.isNotEmpty) {
        try {
          final offDt = DateTime.parse(item.offTime);
          final timeFormatted = DateFormat('dd MMM yyyy hh:mm a').format(offDt);
          events.add(SprinklerEventModel(
            isOn: false,
            time: timeFormatted,
            duration: item.time,
          ));
        } catch (_) {}
      }
      try {
        final onDt = DateTime.parse(item.ontime);
        final timeFormatted = DateFormat('dd MMM yyyy hh:mm a').format(onDt);
        events.add(SprinklerEventModel(
          isOn: true,
          time: timeFormatted,
          duration: "--",
        ));
      } catch (_) {}
    }
    return events;
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);

    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text("Sprinkler Usage"),
      ),
      body: BlocBuilder<SprinklerHistoryCubit, SprinklerHistoryState>(
        builder: (context, state) {
          if (state is SprinklerHistoryLoading) {
            return const Center(
              child: CircularProgressIndicator(color: AppColors.primary),
            );
          }
          if (state is SprinklerHistoryError) {
            return Center(
              child: Text(
                'Error: ${state.message}',
                style: TextStyle(color: colors.textPrimary),
              ),
            );
          }
          if (state is SprinklerHistoryLoaded) {
            final details = state.historyResponse.detail;

            final todayData = _getDailyDataForDate(DateTime.now(), details);
            final selectedDay = _activeDay ?? DateTime.now();
            final selectedData = _getDailyDataForDate(selectedDay, details);
            final selectedEvents = _getEventsForDate(selectedDay, details);
            
            final formattedSelectedDate = DateFormat('EEEE, dd MMMM yyyy').format(selectedDay);
            final isSelectedToday = DateFormat('dd-MM-yyyy').format(selectedDay) == DateFormat('dd-MM-yyyy').format(DateTime.now());

            return SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHorizontalCalendar('', []),
                  SizedBox(height: 24.h),
                  Row(
                    children: [
                      Container(
                        width: 8.w,
                        height: 8.h,
                        decoration: const BoxDecoration(
                          color: AppColors.online,
                          shape: BoxShape.circle,
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Text(
                        "TODAY'S USAGE MONITOR",
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: colors.textSecondary,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12.h),
                  Row(
                    children: [
                      Expanded(
                        child: _buildMetricCard(
                          title: "Runtime",
                          value: todayData.totalDuration,
                          subtitle: "Today",
                          icon: Icons.timer_outlined,
                          color: AppColors.primary,
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Expanded(
                        child: _buildMetricCard(
                          title: "Starts",
                          value: "${todayData.totalStarts}",
                          subtitle: "Times today",
                          icon: Icons.play_arrow_outlined,
                          color: Colors.amber[700]!,
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Expanded(
                        child: _buildMetricCard(
                          title: "Last Action",
                          value: todayData.lastActionTime,
                          subtitle: todayData.lastActionType,
                          icon: Icons.history_toggle_off_outlined,
                          color: Colors.teal[600]!,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 24.h),
                  Text(
                    "SELECTED DAY DETAILS",
                    style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                      color: colors.textSecondary,
                      letterSpacing: 1.2,
                    ),
                  ),
                  SizedBox(height: 12.h),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(16.r),
                    decoration: BoxDecoration(
                      color: colors.surface,
                      borderRadius: BorderRadius.circular(16.r),
                      border: Border.all(color: colors.border),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.02),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                isSelectedToday ? "Today" : formattedSelectedDate,
                                style: TextStyle(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                  color: colors.textPrimary,
                                ),
                              ),
                              SizedBox(height: 4.h),
                              Text(
                                "Selected Date",
                                style: TextStyle(
                                  fontSize: 10.sp,
                                  color: colors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.shower_outlined,
                                size: 16.r,
                                color: AppColors.primary,
                              ),
                              SizedBox(width: 6.w),
                              Text(
                                selectedData.totalDuration,
                                style: TextStyle(
                                  fontSize: 13.sp,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.primary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 24.h),
                  Text(
                    "SPRINKLER EVENTS",
                    style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                      color: colors.textSecondary,
                      letterSpacing: 1.2,
                    ),
                  ),
                  SizedBox(height: 12.h),
                  if (selectedEvents.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 40.h),
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          Icon(
                            Icons.history_outlined,
                            size: 40.r,
                            color: colors.textMuted,
                          ),
                          SizedBox(height: 12.h),
                          Text(
                            "No events recorded on this day",
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: colors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: selectedEvents.length,
                      itemBuilder: (context, index) {
                        final event = selectedEvents[index];
                        return _buildActivityEventTile(context, event);
                      },
                    ),
                ],
              ),
            );
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }

  Widget _buildMetricCard({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    final colors = AppColors.of(context);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.h),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: colors.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(
                icon,
                size: 18.r,
                color: color,
              ),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 9.sp,
                  fontWeight: FontWeight.bold,
                  color: colors.textMuted,
                ),
              ),
            ],
          ),
          SizedBox(height: 10.h),
          Text(
            value,
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: colors.textPrimary,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            title,
            style: TextStyle(
              fontSize: 9.sp,
              color: colors.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityEventTile(BuildContext context, SprinklerEventModel event) {
    final colors = AppColors.of(context);
    return Container(
      margin: EdgeInsets.only(bottom: 10.h),
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: colors.border),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8.r),
            decoration: BoxDecoration(
              color: event.isOn 
                  ? AppColors.online.withValues(alpha: 0.1) 
                  : AppColors.batteryLow.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              event.isOn ? Icons.shower : Icons.shower_outlined,
              size: 16.r,
              color: event.isOn ? AppColors.online : AppColors.batteryLow,
            ),
          ),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.isOn ? "Sprinkler ON" : "Sprinkler OFF",
                  style: TextStyle(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.bold,
                    color: colors.textPrimary,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  event.time,
                  style: TextStyle(
                    fontSize: 11.sp,
                    color: colors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          if (!event.isOn && event.duration != "--")
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
              decoration: BoxDecoration(
                color: colors.background,
                borderRadius: BorderRadius.circular(6.r),
                border: Border.all(color: colors.border),
              ),
              child: Text(
                event.duration,
                style: TextStyle(
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w600,
                  color: colors.textPrimary,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHorizontalCalendar(
      String site, List<AnalyticsDayWiseEntity> dailySummary) {
    final int totalDays = _endDate.difference(_startDate).inDays + 1;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _currentHeaderMonthYear,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Icon(
                      Icons.arrow_back_rounded,
                      size: 11.r,
                      color: AppColors.textSecondary,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      'Swipe left for history',
                      style: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            IconButton(
              icon: Icon(
                Icons.calendar_month_rounded,
                color: AppColors.primary,
                size: 22.r,
              ),
              onPressed: () async {
                final DateTimeRange? picked = await showDateRangePicker(
                  context: context,
                  initialDateRange: DateTimeRange(
                    start: _startDate,
                    end: _endDate.isBefore(_startDate) ? _startDate : _endDate,
                  ),
                  firstDate: DateTime(2000, 1, 1),
                  lastDate: DateTime.now(),
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: ColorScheme.light(
                          primary: AppColors.primary,
                          onPrimary: Colors.white,
                          onSurface: AppColors.textPrimary,
                        ),
                      ),
                      child: child!,
                    );
                  },
                );
                if (picked != null) {
                  _onRangeSelected(picked.start, picked.end);
                }
              },
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Stack(
          children: [
            SizedBox(
              height: 95.h,
              child: ListView.builder(
                controller: _calendarScrollController,
                scrollDirection: Axis.horizontal,
                reverse: true,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.w,
                ),
                itemCount: totalDays,
                itemBuilder: (context, index) {
                  final date = _endDate.subtract(Duration(days: index));

                  final startDay = DateTime(
                      _startDate.year, _startDate.month, _startDate.day);
                  final endDay =
                      DateTime(_endDate.year, _endDate.month, _endDate.day);
                  final currentDay = DateTime(date.year, date.month, date.day);

                  final bool isSelected;
                  final bool isInBetween;

                  if (_activeDay != null) {
                    final activeClean = DateTime(
                        _activeDay!.year, _activeDay!.month, _activeDay!.day);
                    isSelected = currentDay == activeClean;
                    isInBetween = !isSelected;
                  } else {
                    final bool isInRange = !currentDay.isBefore(startDay) &&
                        !currentDay.isAfter(endDay);
                    isSelected = currentDay == startDay || currentDay == endDay;
                    isInBetween = isInRange && !isSelected;
                  }

                  final bool isToday = date.year == DateTime.now().year &&
                      date.month == DateTime.now().month &&
                      date.day == DateTime.now().day;

                  return _buildDayCard(
                    dailySummary,
                    site,
                    date,
                    isSelected,
                    isInBetween,
                    isToday,
                  );
                },
              ),
            ),
            // Left Fade Indicator to signal more scrollable content on the left
            if (_showLeftIndicator)
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 30.w,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          AppColors.of(context).background,
                          AppColors.of(context)
                              .background
                              .withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            // Right Fade Indicator (shows up when scrolled to reveal hidden right items)
            if (_showRightIndicator)
              Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                width: 30.w,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                        colors: [
                          AppColors.of(context).background,
                          AppColors.of(context)
                              .background
                              .withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildDayCard(
    List<AnalyticsDayWiseEntity> entity,
    String site,
    DateTime date,
    bool isSelected,
    bool isInBetween,
    bool isToday,
  ) {
    final List<String> weekdays = [
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      'Fri',
      'Sat',
      'Sun'
    ];
    final weekdayStr = weekdays[date.weekday - 1];

    final bool isRealToday = date.year == DateTime.now().year &&
        date.month == DateTime.now().month &&
        date.day == DateTime.now().day;

    int? aqi;
    // if (isRealToday && site.aqi != null) {
    //   // Today: use the live SSE/latest value first, fall back to history
    //   aqi = site.aqi;
    // }

    if (entity.isNotEmpty) {
      // Average all readings for this date

      for (final e in entity) {
        DateTime dailyDate = DateFormat('dd-MM-yyyy').parseUtc(e.aqiDate!);
        if (dailyDate.day == date.day &&
            dailyDate.month == date.month &&
            dailyDate.year == date.year) {
          aqi = e.avgAqi!.toInt();
        }
      }
    }
    // aqi remains null if no data at all → badge shows "-" with grey color

    final aqiColor = AppColors.getAqiColor(aqi);
    final badgeTextColor = _getContrastColor(aqiColor);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _onDateSelected(date),
      child: Container(
        width: 50.w,
        margin: EdgeInsets.symmetric(horizontal: 6.w),
        padding: EdgeInsets.symmetric(vertical: 6.h),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary
              : isInBetween
                  ? AppColors.primary.withValues(alpha: 0.12)
                  : AppColors.surface,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isSelected
                ? AppColors.primary
                : isInBetween
                    ? AppColors.primary.withValues(alpha: 0.3)
                    : isRealToday
                        ? AppColors.primary.withValues(alpha: 0.5)
                        : AppColors.border,
            width: isRealToday || isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.primary.withValues(alpha: 0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  )
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              weekdayStr,
              style: TextStyle(
                fontSize: 9.sp,
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? Colors.white70
                    : isInBetween
                        ? AppColors.primary
                        : AppColors.textSecondary,
              ),
            ),
            SizedBox(height: 4.h),
            Text(
              '${date.day}',
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
                color: isSelected
                    ? Colors.white
                    : isInBetween
                        ? AppColors.primary
                        : AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 6.h),
            // AQI Badge
            Container(
              padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: aqiColor,
                borderRadius: BorderRadius.circular(6.r),
              ),
              child: Text(
                '${aqi ?? "-"}',
                style: TextStyle(
                  fontSize: 8.sp,
                  fontWeight: FontWeight.bold,
                  color: badgeTextColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onRangeSelected(DateTime start, DateTime end) {
    setState(() {
      _startDate = DateTime(start.year, start.month, start.day);
      _endDate = DateTime(end.year, end.month, end.day, 23, 59, 59);
      _activeDay = DateTime(end.year, end.month, end.day);
      // _selectedTimelineIndex = null;
      _currentHeaderMonthYear = _getHeaderString(_startDate, _endDate);
    });

    // if (widget.site.imeiNo.isNotEmpty) {
    //   fetchAnalytics();
    // }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToSelectedDate();
    });
  }

  void _scrollToSelectedDate({bool animate = true}) {
    if (!_calendarScrollController.hasClients) return;

    final today = DateTime.now();
    final startOfToday = DateTime(today.year, today.month, today.day);
    final selectedStart = DateTime(_endDate.year, _endDate.month, _endDate.day);
    final index = startOfToday.difference(selectedStart).inDays;

    if (index >= 0) {
      final double itemWidth = 62.w; // 50.w + 12.w spacing
      final double viewportWidth = MediaQuery.of(context).size.width;
      final double targetOffset =
          (index * itemWidth) - (viewportWidth / 2 - 47.w);

      if (animate) {
        _calendarScrollController.animateTo(
          targetOffset.clamp(
              0.0, _calendarScrollController.position.maxScrollExtent),
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOut,
        );
      } else {
        _calendarScrollController.jumpTo(
          targetOffset.clamp(
              0.0, _calendarScrollController.position.maxScrollExtent),
        );
      }
    }
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _activeDay = DateTime(date.year, date.month, date.day);
      // _selectedTimelineIndex = null;
    });
  }

  Color _getContrastColor(Color color) {
    final double yiq = (((color.r * 255.0) * 299) +
            ((color.g * 255.0) * 587) +
            ((color.b * 255.0) * 114)) /
        1000;
    return yiq >= 128 ? const Color(0xFF0F172A) : Colors.white;
  }
}


class SprinklerDailyData {
  final int totalStarts;
  final String totalDuration;
  final String lastActionTime;
  final String lastActionType;

  const SprinklerDailyData({
    required this.totalStarts,
    required this.totalDuration,
    required this.lastActionTime,
    required this.lastActionType,
  });
}

class SprinklerEventModel {
  final bool isOn;
  final String time;
  final String duration;

  const SprinklerEventModel({
    required this.isOn,
    required this.time,
    required this.duration,
  });
}
