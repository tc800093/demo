import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vasundhara_maha_aqim/core/network/websocket_service_v2.dart';
import '../../domain/repositories/sites_repository.dart';
import '../widgets/contractor_device_detail_sheet.dart';
import '../widgets/sprinkler_info_card_widget.dart';
import '../../../../config/theme/colors.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../../shared/widgets/aqi_gauge.dart';
import '../../../../shared/widgets/sprinkler_effect.dart';
import '../bloc/sites_bloc.dart';
import '../bloc/sprinkler_bloc.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

/// The Contractor Dashboard Home Screen.
class ContractorDashboard extends StatefulWidget {
  const ContractorDashboard({super.key});

  @override
  State<ContractorDashboard> createState() => _ContractorDashboardState();
}

class _ContractorDashboardState extends State<ContractorDashboard>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  final CarouselSliderController _carouselController =
      CarouselSliderController();
  late AnimationController _bounceController;
  late Animation<double> _bounceAnimation;
  final Set<String> _expandedSiteAddresses = {};

  @override
  void initState() {
    super.initState();

    // WebsocketServiceV2().connectWebSocket();
    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _bounceAnimation = Tween<double>(begin: 0.0, end: -6.0).animate(
      CurvedAnimation(parent: _bounceController, curve: Curves.easeInOut),
    );
    // WebSocketServiceV2.instance.connect();
    context.read<SitesBloc>().add(const FetchLiveData());
  }

  @override
  void dispose() {
    _bounceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthBloc>().state;
    String name = 'Contractor A';
    String company = 'BuildWell Pvt. Ltd.';
    if (authState is AuthAuthenticated) {
      name = authState.user.name;
      company = authState.user.companyName ?? '';
    }

    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      body: SafeArea(
        child: MultiBlocListener(
          listeners: [
            BlocListener<AuthBloc, AuthState>(
              listener: (context, state) {
                if (state is AuthUnauthenticated) {
                  context.go(AppRoutes.login);
                }
              },
            ),
            BlocListener<SprinklerBloc, SprinklerState>(
              listener: (context, state) {
                if (state is SprinklerActionSuccess) {
                  // Refresh site state in SitesBloc
                  context.read<SitesBloc>().add(LoadSites());

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Row(
                        children: [
                          Icon(
                            state.site.isSprinklerRunning
                                ? Icons.water_drop_rounded
                                : Icons.stop_circle_rounded,
                            color: Colors.white,
                            size: 20.r,
                          ),
                          SizedBox(width: 8.w),
                          Text(state.site.isSprinklerRunning
                              ? 'Sprinkler triggered successfully'
                              : 'Sprinkler stopped successfully'),
                        ],
                      ),
                      backgroundColor: state.site.isSprinklerRunning
                          ? const Color(0xFF0284C7)
                          : const Color(0xFF64748B),
                      behavior: SnackBarBehavior.floating,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                } else if (state is SprinklerError) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${state.message}'),
                      backgroundColor: AppColors.aqiRed,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
            ),
          ],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header greeting (ALWAYS visible)
              Container(
                color: AppColors.primary,
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                child: _buildHeader(context, name, company),
              ),

              // Dynamic Body based on Sites Bloc state
              Expanded(
                child: BlocBuilder<SitesBloc, SitesState>(
                  builder: (context, state) {
                    if (state is SitesLoading) {
                      return const Center(
                        child:
                            CircularProgressIndicator(color: AppColors.primary),
                      );
                    }
                    if (state is SitesError) {
                      return ErrorDisplayWidget(
                        message: state.message,
                        onRetry: () {
                          context.read<SitesBloc>().add(LoadSites());
                        },
                      );
                    }
                    if (state is SitesLoaded && state.sites.isNotEmpty) {
                      // Ensure index is within range in case list shrinks
                      if (_currentIndex >= state.sites.length) {
                        _currentIndex = 0;
                      }
                      final site = state.sites[_currentIndex];
                      return Stack(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Count indicator row
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 16.w,
                                    right: 16.w,
                                    top: 8.h,
                                    bottom: 2.h),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Active Devices',
                                      style: TextStyle(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.bold,
                                        color: colors.textPrimary,
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 12.w, vertical: 4.h),
                                      decoration: BoxDecoration(
                                        color: AppColors.primary
                                            .withValues(alpha: 0.08),
                                        borderRadius:
                                            BorderRadius.circular(16.r),
                                        border: Border.all(
                                            color: AppColors.primary
                                                .withValues(alpha: 0.2),
                                            width: 1.r),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            '${_currentIndex + 1} / ${state.sites.length}',
                                            style: TextStyle(
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.primary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // Sliding Sites Carousel
                              Expanded(
                                child: CarouselSlider.builder(
                                  carouselController: _carouselController,
                                  itemCount: state.sites.length,
                                  options: CarouselOptions(
                                    height: double.infinity,
                                    viewportFraction: 1.0,
                                    enableInfiniteScroll: false,
                                    initialPage: _currentIndex,
                                    onPageChanged: (index, reason) {
                                      setState(() {
                                        _currentIndex = index;
                                      });
                                    },
                                  ),
                                  itemBuilder: (context, index, realIndex) {
                                    final currentSite = state.sites[index];
                                    return RefreshIndicator(
                                      onRefresh: () async {
                                        context
                                            .read<SitesBloc>()
                                            .add(LoadSites());
                                      },
                                      child: SingleChildScrollView(
                                        physics:
                                            const AlwaysScrollableScrollPhysics(),
                                        padding: EdgeInsets.only(
                                            left: 16.w,
                                            right: 16.w,
                                            top: 4.h,
                                            bottom: 12.h),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            // Active Site Title Card
                                            _buildActiveSiteIndicator(
                                                context, currentSite),

                                            SizedBox(height: 10.h),

                                            // Hero Gauge with merged Device Status & Sprinkler Controls
                                            AqiGauge(
                                              site: currentSite,
                                              trendText: '+16 since last hour',
                                              updateTimeText:
                                                  'Updated 2 min ago',
                                              showDeviceAndSprinkler: true,
                                            ),

                                            SizedBox(height: 10.h),

                                            // Sprinkler Info Card Widget displaying latest recording
                                            SprinklerInfoCardWidget(
                                              site: currentSite,
                                              isSprinklerRunning: currentSite.isSprinklerRunning,
                                            ),

                                            SizedBox(height: 24.h),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),

                          // Sprinkler Water Spray Overlay (dynamic based on visible site)
                          SprinklerEffect(isRunning: site.isSprinklerRunning),
                        ],
                      );
                    }
                    return Center(
                      child: RefreshIndicator(
                        onRefresh: () async {
                          context.read<SitesBloc>().add(LoadSites());
                        },
                        child: SingleChildScrollView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 90.r,
                                height: 90.r,
                                decoration: BoxDecoration(
                                  color:
                                      AppColors.primary.withValues(alpha: 0.08),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: AppColors.primary
                                        .withValues(alpha: 0.15),
                                    width: 2.r,
                                  ),
                                ),
                                child: Center(
                                  child: Icon(
                                    Icons.sensors_off_rounded,
                                    size: 42.r,
                                    color: AppColors.primary,
                                  ),
                                ),
                              ),
                              SizedBox(height: 20.h),
                              Text(
                                'No Device Allocated',
                                style: TextStyle(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.bold,
                                  color: colors.textPrimary,
                                ),
                              ),
                              SizedBox(height: 8.h),
                              Text(
                                'There are no active monitoring devices allocated to your account at this time.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 12.sp,
                                  color: colors.textSecondary,
                                  height: 1.5,
                                ),
                              ),
                              SizedBox(height: 16.h),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 14.w, vertical: 10.h),
                                decoration: BoxDecoration(
                                  color: Colors.amber.withValues(alpha: 0.08),
                                  borderRadius: BorderRadius.circular(10.r),
                                  border: Border.all(
                                    color: Colors.amber.withValues(alpha: 0.2),
                                    width: 1.r,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.info_outline_rounded,
                                      color: Colors.amber[800],
                                      size: 16.r,
                                    ),
                                    SizedBox(width: 8.w),
                                    Expanded(
                                      child: Text(
                                        'Please contact the Administrator to map a device to your account.',
                                        style: TextStyle(
                                          fontSize: 11.sp,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.amber[900],
                                          height: 1.4,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 24.h),
                              ElevatedButton.icon(
                                onPressed: () {
                                  context.read<SitesBloc>().add(LoadSites());
                                },
                                icon: Icon(
                                  Icons.refresh_rounded,
                                  size: 16.r,
                                  color: Colors.white,
                                ),
                                label: Text(
                                  'Refresh Status',
                                  style: TextStyle(
                                    fontSize: 13.sp,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.primary,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 24.w, vertical: 12.h),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.r),
                                  ),
                                  elevation: 0,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, String name, String company) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Hello, $name',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                company,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11.sp,
                  color: Colors.white.withValues(alpha: 0.75),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 8.w),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
              ),
              child: IconButton(
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(
                  minWidth: 36.r,
                  minHeight: 36.r,
                ),
                icon: Icon(Icons.notifications_outlined,
                    size: 18.r, color: Colors.white),
                onPressed: () => context.push(AppRoutes.contractorAlerts),
              ),
            ),
            SizedBox(width: 6.w),
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
              ),
              child: IconButton(
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(
                  minWidth: 36.r,
                  minHeight: 36.r,
                ),
                icon: Icon(Icons.person_outline_rounded,
                    size: 18.r, color: Colors.white),
                onPressed: () {
                  context.push(AppRoutes.contractorProfile);
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActiveSiteIndicator(BuildContext context, SiteEntity site) {
    final colors = AppColors.of(context);
    return GestureDetector(
      onTap: () {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (sheetContext) =>
              ContractorDeviceDetailSheet(deviceId: site.id),
        );
      },
      child: ScadaCard(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      context
                          .go('${AppRoutes.contractorMap}?siteId=${site.id}');
                    },
                    child: AnimatedBuilder(
                      animation: _bounceAnimation,
                      builder: (context, child) {
                        return Transform.translate(
                          offset: Offset(0, _bounceAnimation.value),
                          child: child,
                        );
                      },
                      child: Icon(Icons.pin_drop_rounded,
                          color: AppColors.primary, size: 28.r),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          site.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.bold,
                            color: colors.textPrimary,
                          ),
                        ),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final span = TextSpan(
                              text: site.address,
                              style: TextStyle(
                                fontSize: 11.sp,
                                color: colors.textSecondary,
                                fontWeight: FontWeight.w500,
                              ),
                            );
                            final tp = TextPainter(
                              text: span,
                              maxLines: 1,
                              textDirection: TextDirection.ltr,
                            );
                            tp.layout(maxWidth: constraints.maxWidth);
                            final isOverflowing = tp.didExceedMaxLines;
                            final isExpanded =
                                _expandedSiteAddresses.contains(site.id);

                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  site.address,
                                  maxLines: isExpanded ? null : 1,
                                  overflow: isExpanded
                                      ? TextOverflow.visible
                                      : TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 11.sp,
                                    color: colors.textSecondary,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                if (isOverflowing)
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        if (isExpanded) {
                                          _expandedSiteAddresses
                                              .remove(site.id);
                                        } else {
                                          _expandedSiteAddresses.add(site.id);
                                        }
                                      });
                                    },
                                    child: Padding(
                                      padding: EdgeInsets.only(top: 2.h),
                                      child: Text(
                                        isExpanded ? 'See Less' : 'See More',
                                        style: TextStyle(
                                          fontSize: 10.sp,
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 12.w),
            IconButton(
              onPressed: () {
                context.push('/contractor/sites/${site.id}');
              },
              icon: AnimatedEyeIcon(
                color: AppColors.primary,
                size: 20.r,
              ),
              constraints: const BoxConstraints(),
              padding: EdgeInsets.all(8.r),
              style: IconButton.styleFrom(
                backgroundColor: AppColors.primary.withValues(alpha: 0.08),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.r),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
