import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../bloc/sites_bloc.dart';
import '../../domain/repositories/sites_repository.dart';
import '../widgets/contractor_device_detail_sheet.dart';

class SitesListPage extends StatefulWidget {
  const SitesListPage({super.key});

  @override
  State<SitesListPage> createState() => _SitesListPageState();
}

class _SitesListPageState extends State<SitesListPage> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('My Devices'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search Input Row
            Container(
              color: colors.surface,
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              child: TextFormField(
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.toLowerCase();
                  });
                },
                decoration: InputDecoration(
                  hintText: 'Search devices...',
                  prefixIcon: Icon(Icons.search_rounded,
                      color: colors.textSecondary),
                  fillColor: colors.background,
                  contentPadding: const EdgeInsets.symmetric(vertical: 8),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),

            // Sites List
            Expanded(
              child: BlocBuilder<SitesBloc, SitesState>(
                builder: (context, state) {
                  if (state is SitesLoading) {
                    return const Center(
                        child: CircularProgressIndicator(
                            color: AppColors.primary));
                  }
                  if (state is SitesLoaded) {
                    // Filter logic
                    final filteredSites = state.sites.where((site) {
                      final matchesSearch = site.name
                              .toLowerCase()
                              .contains(_searchQuery) ||
                          site.projectName.toLowerCase().contains(_searchQuery);

                      return matchesSearch;
                    }).toList();

                    if (filteredSites.isEmpty) {
                      return Center(
                        child: RefreshIndicator(
                          onRefresh: () async {
                            context.read<SitesBloc>().add(LoadSites());
                          },
                          child: SingleChildScrollView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: EdgeInsets.symmetric(horizontal: 24.w),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 90.r,
                                  height: 90.r,
                                  decoration: BoxDecoration(
                                    color: AppColors.primary.withValues(alpha: 0.08),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: AppColors.primary.withValues(alpha: 0.15),
                                      width: 2.r,
                                    ),
                                  ),
                                  child: Center(
                                    child: Icon(
                                      Icons.sensors_off_rounded,
                                      size: 42.r,
                                      color: AppColors.primary,
                                    ),
                                  ),
                                ),
                                SizedBox(height: 20.h),
                                Text(
                                  'No Device Allocated',
                                  style: TextStyle(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  'There are no active monitoring devices allocated to your account at this time.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 12.sp,
                                    color: AppColors.textSecondary,
                                    height: 1.5,
                                  ),
                                ),
                                SizedBox(height: 16.h),
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
                                  decoration: BoxDecoration(
                                    color: Colors.amber.withValues(alpha: 0.08),
                                    borderRadius: BorderRadius.circular(10.r),
                                    border: Border.all(
                                      color: Colors.amber.withValues(alpha: 0.2),
                                      width: 1.r,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.info_outline_rounded,
                                        color: Colors.amber[800],
                                        size: 16.r,
                                      ),
                                      SizedBox(width: 8.w),
                                      Expanded(
                                        child: Text(
                                          'Please contact the Administrator to map a device to your account.',
                                          style: TextStyle(
                                            fontSize: 11.sp,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.amber[900],
                                            height: 1.4,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 24.h),
                                ElevatedButton.icon(
                                  onPressed: () {
                                    context.read<SitesBloc>().add(LoadSites());
                                  },
                                  icon: Icon(
                                    Icons.refresh_rounded,
                                    size: 16.r,
                                    color: Colors.white,
                                  ),
                                  label: Text(
                                    'Refresh Status',
                                    style: TextStyle(
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.primary,
                                    padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.r),
                                    ),
                                    elevation: 0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }

                    return ListView.builder(
                      padding: const EdgeInsets.all(16.0),
                      itemCount: filteredSites.length,
                      itemBuilder: (context, index) {
                        return _buildSiteCard(context, filteredSites[index]);
                      },
                    );
                  }
                  return const Center(child: Text('Failed to load devices'));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSiteCard(BuildContext context, SiteEntity site) {
    final statusColor = AppColors.getAqiColor(site.aqi);
    final statusText = AppColors.getAqiStatus(site.aqi);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: GestureDetector(
        onTap: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (sheetContext) =>
                ContractorDeviceDetailSheet(deviceId: site.id),
          );
        },
        child: ScadaCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          site.name,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Project: ${site.projectName}',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  AqiStatusChip(
                    label: site.isDeviceOnline ? 'Online' : 'Offline',
                    color: site.isDeviceOnline
                        ? AppColors.online
                        : AppColors.offline,
                  ),
                ],
              ),
              Divider(color: AppColors.border, height: 24),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${site.aqi ?? "N/A"}',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: statusColor == AppColors.aqiYellow
                            ? const Color(0xFFD4AF37)
                            : statusColor,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'AQI Status: $statusText',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: statusColor == AppColors.aqiYellow
                                ? const Color(0xFFD4AF37)
                                : statusColor,
                          ),
                        ),
                        Text(
                          site.address,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  IconButton(
                    icon: const AnimatedEyeIcon(
                      size: 20,
                      color: AppColors.primary,
                    ),
                    onPressed: () {
                      context.push('/contractor/sites/${site.id}');
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
