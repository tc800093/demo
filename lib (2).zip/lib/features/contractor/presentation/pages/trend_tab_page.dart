import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/config/theme/colors.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_daily_interval_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_day_wise_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/sites_repository.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/bloc/analytics_bloc/analytics_bloc.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/pages/site_details_page.dart';

class TrendTabPage extends StatefulWidget {
  final SiteEntity site;
  const TrendTabPage({super.key, required this.site});

  @override
  State<TrendTabPage> createState() => _TrendTabPageState();
}

class _TrendTabPageState extends State<TrendTabPage> {
  late DateTime _startDate;
  late DateTime _endDate;
  DateTime? _activeDay;
  // int? _selectedTimelineIndex;
  late ScrollController _calendarScrollController;
  late String _currentHeaderMonthYear;
  bool _showLeftIndicator = true;
  bool _showRightIndicator = false;
  String selectedInterval = '1';
  final List<String> intervalList = ['1', '3', '6'];

  @override
  void initState() {
    super.initState();
    final today = DateTime.now();
    _endDate = today;
    _startDate = DateTime(today.year, today.month, today.day)
        .subtract(const Duration(days: 7));
    _activeDay = DateTime(today.year, today.month, today.day);
    // _selectedTimelineIndex = null;

    _currentHeaderMonthYear = _getHeaderString(_startDate, _endDate);
    fetchAnalytics();

    _calendarScrollController = ScrollController();

    _calendarScrollController.addListener(() {
      if (_calendarScrollController.hasClients) {
        final maxScroll = _calendarScrollController.position.maxScrollExtent;
        final currentScroll = _calendarScrollController.offset;

        final showLeft = currentScroll < maxScroll - 5;
        final showRight = currentScroll > 5;

        // Calculate month/year of the centered item dynamically
        final today = DateTime.now();
        final double viewportWidth = MediaQuery.of(context).size.width;
        final double centerOffset = currentScroll + (viewportWidth / 2);
        final double padding = 16.w;
        final int centerIndex =
            ((centerOffset - padding - 31.w) / 62.w).round();

        final centerDate =
            today.subtract(Duration(days: centerIndex.clamp(0, 100000)));
        final months = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December'
        ];
        final String newHeader =
            "${months[centerDate.month - 1]} ${centerDate.year}";

        if (showLeft != _showLeftIndicator ||
            showRight != _showRightIndicator ||
            (_startDate.day == _endDate.day &&
                newHeader != _currentHeaderMonthYear)) {
          setState(() {
            _showLeftIndicator = showLeft;
            _showRightIndicator = showRight;
            if (_startDate.day == _endDate.day) {
              _currentHeaderMonthYear = newHeader;
            }
          });
        }
      }
    });
  }

  void fetchAnalytics() async {
    context.read<AnalyticsBloc>().add(FetchAnalytics(
        imeiNo: widget.site.imeiNo,
        interval: selectedInterval,
        fromdate: DateFormat('dd-MM-yyyy').format(_startDate),
        toDate: DateFormat('dd-MM-yyyy').format(_endDate)));
  }

  void fetchCurreteDate() async {
    context.read<AnalyticsBloc>().add(FetchDailySummaryEvent(
          imeiNo: widget.site.imeiNo,
          interval: selectedInterval,
          date: DateFormat('dd-MM-yyyy').format(_activeDay!),
        ));

    context.read<AnalyticsBloc>().add(FetchDayWiseEvent(
        imeiNo: widget.site.imeiNo,
        fromdate: DateFormat('dd-MM-yyyy').format(_startDate),
        toDate: DateFormat('dd-MM-yyyy').format(_endDate)));
  }

  String _getHeaderString(DateTime start, DateTime end) {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    final startDay = DateTime(start.year, start.month, start.day);
    final endDay = DateTime(end.year, end.month, end.day);
    if (startDay == endDay) {
      return "${months[startDay.month - 1]} ${startDay.year}";
    }
    final startAbbr = months[startDay.month - 1].substring(0, 3);
    final endAbbr = months[endDay.month - 1].substring(0, 3);
    if (startDay.year == endDay.year) {
      return "${startDay.day} $startAbbr - ${endDay.day} $endAbbr, ${startDay.year}";
    }
    return "${startDay.day} $startAbbr ${startDay.year} - ${endDay.day} $endAbbr ${endDay.year}";
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AnalyticsBloc, AnalyticsState>(
      listener: (context, state) {},
      builder: (context, state) {
        return SingleChildScrollView(
          padding: EdgeInsets.all(16.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Same calendar section as Live tab
              _buildHorizontalCalendar(
                  widget.site,
                  state.status == AnalyticsStatus.success
                      ? state.analyticsDayWise!
                      : []),
              SizedBox(height: 24.h),

              if (state.status == AnalyticsStatus.loading) ...[
                const Center(
                    child: CircularProgressIndicator(color: AppColors.primary))
              ],

              if (state.status == AnalyticsStatus.failure) ...[
                Center(
                    child: Text(state.message.isNotEmpty
                        ? state.message
                        : "Unable to fetch trends"))
              ],
              if (state.status == AnalyticsStatus.success) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'SELECTED DAY: $selectedInterval Hr INTERVAL DETAIL',
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xFF64748B),
                        letterSpacing: 1.2,
                      ),
                    ),
                    Container(
                      height: 35.h,
                      padding: EdgeInsets.symmetric(horizontal: 8.w),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8.r),
                        border: Border.all(
                          color: const Color(0xFFCBD5E1),
                        ),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedInterval,
                          icon: const Icon(
                            Icons.keyboard_arrow_down,
                            size: 18,
                          ),
                          style: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF334155),
                          ),
                          items: intervalList.map((interval) {
                            return DropdownMenuItem<String>(
                              value: interval,
                              child: Text('$interval hr'),
                            );
                          }).toList(),
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                selectedInterval = value;
                              });

                              context.read<AnalyticsBloc>().add(
                                  FetchDailySummaryEvent(
                                      imeiNo: widget.site.imeiNo,
                                      date: DateFormat('dd-MM-yyyy')
                                          .format(_activeDay!),
                                      interval: selectedInterval));
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10.h),
                if (state.dailySummaryStatus ==
                    AnalyticsDailySummaryStatus.loading) ...[
                  Container(
                    height: 269.h,
                    width: 600.w,
                    padding: EdgeInsets.all(16.r),
                    decoration: BoxDecoration(
                      color: AppColors.of(context).surface, // Light background
                      borderRadius: BorderRadius.circular(16.r),
                      border: Border.all(color: AppColors.of(context).border),
                      boxShadow: [
                        BoxShadow(
                          color:
                              AppColors.textSecondary.withValues(alpha: 0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          color: AppColors.primary,
                        )
                      ],
                    ),
                  )
                ],
                if (state.dailySummaryStatus ==
                    AnalyticsDailySummaryStatus.failure) ...[
                  Container(
                    height: 269.h,
                    width: 600.w,
                    padding: EdgeInsets.all(16.r),
                    decoration: BoxDecoration(
                      color: AppColors.of(context).surface, // Light background
                      borderRadius: BorderRadius.circular(16.r),
                      border: Border.all(color: AppColors.of(context).border),
                      boxShadow: [
                        BoxShadow(
                          color:
                              AppColors.textSecondary.withValues(alpha: 0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('No details found for selected date'),
                      ],
                    ),
                  )
                ],
                if (state.dailySummaryStatus ==
                    AnalyticsDailySummaryStatus.success) ...[
                  _build3HourDetailCard(state.analyticsDailyIntervalEntity!),
                ],
                if (state.dayWiseStatus == AnalyticsDayWiseStatus.loading) ...[
                  Container(
                    height: 269.h,
                    width: 600.w,
                    padding: EdgeInsets.all(16.r),
                    decoration: BoxDecoration(
                      color: AppColors.of(context).surface, // Light background
                      borderRadius: BorderRadius.circular(16.r),
                      border: Border.all(color: AppColors.of(context).border),
                      boxShadow: [
                        BoxShadow(
                          color:
                              AppColors.textSecondary.withValues(alpha: 0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          color: AppColors.primary,
                        )
                      ],
                    ),
                  )
                ],
                if (state.dayWiseStatus == AnalyticsDayWiseStatus.failure)
                  ...[],
                if (state.dayWiseStatus == AnalyticsDayWiseStatus.success) ...[
                  SizedBox(height: 24.h),
                  Text(
                    '${_endDate.difference(_startDate).inDays + 1}-DAY CALCULATED CONTINUOUS TREND',
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF64748B),
                      letterSpacing: 1.2,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  // Continuous trend card
                  // state.analyticsDayWise!.isEmpty
                  _build8DayTrendCard(state.analyticsDayWise!),
                  // : const SizedBox.shrink(),
                  SizedBox(height: 24.h),
                ],
              ],
            ],
          ),
        );
      },
    );
  }

  int getLabelInterval(DateTime start, DateTime end) {
    final days = end.difference(start).inDays + 1;

    if (days <= 7) return 1;
    if (days <= 15) return 2;
    if (days <= 30) return 5;
    if (days <= 90) return 10;
    return 30;
  }

  Widget _build3HourDetailCard(
      AnalyticsDailyIntervalEntity selectedDayAnalytics) {
    final selectedDate = selectedDayAnalytics.intervals!.isNotEmpty
        ? _getRealHistoryDayForDate(
            _activeDay!, selectedDayAnalytics.intervals!)
        : _getHistoryDayForDate(_activeDay!);
    final colors = AppColors.of(context);
    final minColor =
        AppColors.getAqiColor(selectedDayAnalytics.dailySummary!.minAqi ?? 0);
    final maxColor =
        AppColors.getAqiColor(selectedDayAnalytics.dailySummary!.maxAqi ?? 0);
    final minTime = "${selectedDate.minAqiHour.toString().padLeft(2, '0')}:00";
    final maxTime = "${selectedDate.maxAqiHour.toString().padLeft(2, '0')}:00";

    // final minTime = "12:00";
    // final maxTime = "13:00";

    double? maxVal = selectedDayAnalytics.intervals!
        .map((e) => e.avgAqi ?? 0)
        .reduce((a, b) => a > b ? a : b);

    //  selectedDay.intervals
    //     .map((v) => v.toDouble())
    //     .reduce((a, b) => a > b ? a : b);
    double chartMaxY = (maxVal * 1.2).clamp(120.0, 500.0);
    // double chartMaxY = 12;

    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: colors.surface, // Light background
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: colors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.textSecondary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Min / Max indicators row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Min AQI Box
              Row(
                children: [
                  Container(
                    width: 38.r,
                    height: 38.r,
                    decoration: BoxDecoration(
                      color: minColor,
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Center(
                      child: Text(
                        '${selectedDate.minAqi}',
                        // '${selectedDayAnalytics.dailySummary!.minAqi ?? 0}',
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: _getContrastColor(minColor),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '↓ Min AQI',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: minColor,
                        ),
                      ),
                      Text(
                        '@$minTime',
                        style: TextStyle(
                          fontSize: 10.sp,
                          color: AppColors
                              .textSecondary, // Dark/grey text for light theme
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              // Max AQI Box
              Row(
                children: [
                  Container(
                    width: 38.r,
                    height: 38.r,
                    decoration: BoxDecoration(
                      color: maxColor,
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Center(
                      child: Text(
                        '${selectedDate.maxAqi}',

                        // '${selectedDayAnalytics.dailySummary!.maxAqi ?? 0}',
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: _getContrastColor(maxColor),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '↑ Max AQI',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: maxColor,
                        ),
                      ),
                      Text(
                        '@$maxTime',
                        style: TextStyle(
                          fontSize: 10.sp,
                          color: AppColors
                              .textSecondary, // Dark/grey text for light theme
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: 24.h),

          // 3-Hour Interval Bar Chart
          SizedBox(
            height: 180.h,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: chartMaxY,
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  show: true,
                  topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.w,
                      interval: (chartMaxY / 4).roundToDouble().clamp(10, 100),
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 9.sp), // Dark text
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.h,
                      getTitlesWidget: (value, meta) {
                        // const times = [
                        //   '00:00',
                        //   '03:00',
                        //   '06:00',
                        //   '09:00',
                        //   '12:00',
                        //   '15:00',
                        //   '18:00',
                        //   '21:00'
                        // ];
                        final times = selectedDayAnalytics.intervals;

                        if (value >= 0 && value < times!.length) {
                          final index = value.toInt();

                          int labelInterval = 3; // default

                          switch (selectedInterval) {
                            case '1 hr':
                              labelInterval = 1;
                              break;
                            case '3 hr':
                              labelInterval = 3;
                              break;
                            case '6 hr':
                              labelInterval = 6;
                              break;
                          }

                          if (index % labelInterval != 0) {
                            return const SizedBox();
                          }
                          return SideTitleWidget(
                            meta: meta,
                            space: 6.h,
                            child: Text(
                              DateFormat("HH").format(DateTime.parse(
                                  times[value.toInt()].intervalStart!)),
                              style: TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 9.sp), // Dark text
                            ),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                ),
                barGroups: _build3HourBarGroups(selectedDayAnalytics),
              ),
            ),
          ),
        ],
      ),
    );
  }

  AqiHistoryDay _getHistoryDayForDate(DateTime date) {
    return AqiHistoryDay(
      date: date,
      averageAqi: 0,
      intervals: List.filled(24, 0),
      minAqi: 0,
      minAqiHour: 0,
      maxAqi: 0,
      maxAqiHour: 0,
    );
  }

  AqiHistoryDay _getRealHistoryDayForDate(
    DateTime date,
    List<IntervalEntity> intervalData,
  ) {
    if (intervalData.isEmpty) {
      return _getHistoryDayForDate(date);
    }

    int sum = 0;
    int count = 0;

    int? minVal;
    int minHour = 0;

    int? maxVal;
    int maxHour = 0;

    // 8 intervals for 24 hours (3 hour each)
    final List<int> intervals = List.filled(intervalData.length, 0);

    for (int i = 0; i < intervalData.length; i++) {
      final interval = intervalData[i];

      final avgAqi = interval.avgAqi != null ? interval.avgAqi!.round() : 0;

      // Average calculation
      sum += avgAqi;
      count++;

      // Store interval average
      intervals[i] = avgAqi;

      final intervalHour = interval.intervalStart != null
          ? DateTime.parse(interval.intervalStart!).hour
          : 0;

      if (avgAqi > 0) {
        // Find minimum AQI (ignore 1)
        if (minVal == null || avgAqi < minVal) {
          minVal = avgAqi;
          minHour = intervalHour;
        }

        // Find maximum AQI
        if (maxVal == null || avgAqi > maxVal) {
          maxVal = avgAqi;
          maxHour = intervalHour;
        }
      }
    }

    final average = count > 0 ? (sum ~/ count) : 0;

    return AqiHistoryDay(
      date: date,
      averageAqi: average,
      intervals: intervals,
      minAqi: minVal ?? 0,
      minAqiHour: minHour,
      maxAqi: maxVal ?? 0,
      maxAqiHour: maxHour,
    );
  }

  int _getLabelInterval(List<AnalyticsDayWiseEntity> history) {
    if (history.length <= 1) return 1;

    final start = DateFormat('dd-MM-yyyy').parseUtc(history.first.aqiDate!);
    final end = DateFormat('dd-MM-yyyy').parseUtc(history.last.aqiDate!);

    final days = end.difference(start).inDays + 1;

    if (days <= 7) return 1;
    if (days <= 15) return 2;
    if (days <= 30) return 5;
    if (days <= 90) return 10;

    return 30;
  }

  Widget _build8DayTrendCard(List<AnalyticsDayWiseEntity> history) {
    final colors = AppColors.of(context);
    double maxAvg = history.isNotEmpty
        ? history.map((h) => h.avgAqi ?? 0.0).reduce((a, b) => a > b ? a : b)
        : 0;
    double chartMaxY = (maxAvg * 1.2).clamp(100.0, 500.0);

    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: colors.surface, // Light background
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: colors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.textSecondary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          SizedBox(
            height: 180.h,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: chartMaxY,
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  show: true,
                  topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.w,
                      interval: (chartMaxY / 4).roundToDouble().clamp(10, 100),
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 9.sp), // Dark text
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.h,
                      getTitlesWidget: (value, meta) {
                        if (value >= 0 &&
                            value < (history.isNotEmpty ? history.length : 8)) {
                          final index = value.toInt();
                          final interval = _getLabelInterval(history);

                          // Show only interval labels and always show the last one
                          if (index % interval != 0 &&
                              index != history.length - 1) {
                            return const SizedBox.shrink();
                          }

                          final day = history[index];
                          final dayStr = DateFormat('dd MMM').format(
                            DateFormat('dd-MM-yyyy').parseUtc(day.aqiDate!),
                          );
                          // final dayStr = DateFormat('dd MMM').format(
                          //     DateFormat('dd-MM-yyyy').parseUtc(day.aqiDate!));
                          // "${day.aqiDate} ${_getMonthAbbr(DateTime.parse(day.aqiDate.toString()).month)}";
                          return SideTitleWidget(
                            meta: meta,
                            space: 6.h,
                            child: Text(
                              dayStr,
                              style: TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 9.sp), // Dark text
                            ),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                ),
                barGroups: _build8DayBarGroups(history),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<BarChartGroupData> _build3HourBarGroups(
      AnalyticsDailyIntervalEntity selectedDay) {
    // final selectedDay = _getRealHistoryDayForDate(_activeDay ?? _endDate);
    return List.generate(selectedDay.intervals!.length, (index) {
      final val = selectedDay.intervals![index].avgAqi ?? 0;

      final color = AppColors.getAqiColor(val.toInt());

      return BarChartGroupData(
        x: index,
        barsSpace: 2,
        barRods: [
          BarChartRodData(
            toY: val.toDouble(),
            color: color,
            width: selectedInterval == '1'
                ? 6.w
                : selectedInterval == '3'
                    ? 14.w
                    : 16.w, // reduce width for 24 bars
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(3.r),
              topRight: Radius.circular(3.r),
            ),
          ),
        ],
      );
    });
  }

  List<BarChartGroupData> _build8DayBarGroups(
      List<AnalyticsDayWiseEntity> history) {
    return List.generate(history.length, (index) {
      final val = history[index].avgAqi;
      final color = val == 0
          ? AppColors.border.withValues(alpha: 0.5)
          : AppColors.getAqiColor(val!.toInt());
      return BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
            toY: val!.toDouble(),
            color: color,
            width: 14.w,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(4.r),
              topRight: Radius.circular(4.r),
            ),
          ),
        ],
      );
    });
  }

  Widget _buildHorizontalCalendar(
      SiteEntity site, List<AnalyticsDayWiseEntity> dailySummary) {
    final int totalDays = _endDate.difference(_startDate).inDays + 1;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _currentHeaderMonthYear,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Icon(
                      Icons.arrow_back_rounded,
                      size: 11.r,
                      color: AppColors.textSecondary,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      'Swipe left for history',
                      style: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            IconButton(
              icon: Icon(
                Icons.calendar_month_rounded,
                color: AppColors.primary,
                size: 22.r,
              ),
              onPressed: () async {
                final DateTimeRange? picked = await showDateRangePicker(
                  context: context,
                  initialDateRange: DateTimeRange(
                    start: _startDate,
                    end: _endDate.isBefore(_startDate) ? _startDate : _endDate,
                  ),
                  firstDate: DateTime(2000, 1, 1),
                  lastDate: DateTime.now(),
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: ColorScheme.light(
                          primary: AppColors.primary,
                          onPrimary: Colors.white,
                          onSurface: AppColors.textPrimary,
                        ),
                      ),
                      child: child!,
                    );
                  },
                );
                if (picked != null) {
                  _onRangeSelected(picked.start, picked.end);
                }
              },
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Stack(
          children: [
            SizedBox(
              height: 95.h,
              child: ListView.builder(
                controller: _calendarScrollController,
                scrollDirection: Axis.horizontal,
                reverse: true,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.w,
                ),
                itemCount: totalDays,
                itemBuilder: (context, index) {
                  final date = _endDate.subtract(Duration(days: index));

                  final startDay = DateTime(
                      _startDate.year, _startDate.month, _startDate.day);
                  final endDay =
                      DateTime(_endDate.year, _endDate.month, _endDate.day);
                  final currentDay = DateTime(date.year, date.month, date.day);

                  final bool isSelected;
                  final bool isInBetween;

                  if (_activeDay != null) {
                    final activeClean = DateTime(
                        _activeDay!.year, _activeDay!.month, _activeDay!.day);
                    isSelected = currentDay == activeClean;
                    isInBetween = !isSelected;
                  } else {
                    final bool isInRange = !currentDay.isBefore(startDay) &&
                        !currentDay.isAfter(endDay);
                    isSelected = currentDay == startDay || currentDay == endDay;
                    isInBetween = isInRange && !isSelected;
                  }

                  final bool isToday = date.year == DateTime.now().year &&
                      date.month == DateTime.now().month &&
                      date.day == DateTime.now().day;

                  return _buildDayCard(
                    dailySummary,
                    site,
                    date,
                    isSelected,
                    isInBetween,
                    isToday,
                  );
                },
              ),
            ),
            // Left Fade Indicator to signal more scrollable content on the left
            if (_showLeftIndicator)
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 30.w,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          AppColors.of(context).background,
                          AppColors.of(context)
                              .background
                              .withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            // Right Fade Indicator (shows up when scrolled to reveal hidden right items)
            if (_showRightIndicator)
              Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                width: 30.w,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                        colors: [
                          AppColors.of(context).background,
                          AppColors.of(context)
                              .background
                              .withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildDayCard(
    List<AnalyticsDayWiseEntity> entity,
    SiteEntity site,
    DateTime date,
    bool isSelected,
    bool isInBetween,
    bool isToday,
  ) {
    final List<String> weekdays = [
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      'Fri',
      'Sat',
      'Sun'
    ];
    final weekdayStr = weekdays[date.weekday - 1];

    final bool isRealToday = date.year == DateTime.now().year &&
        date.month == DateTime.now().month &&
        date.day == DateTime.now().day;

    int? aqi;
    if (isRealToday && site.aqi != null) {
      // Today: use the live SSE/latest value first, fall back to history
      aqi = site.aqi;
    }

    if (aqi == null && entity.isNotEmpty) {
      // Average all readings for this date

      for (final e in entity) {
        DateTime dailyDate = DateFormat('dd-MM-yyyy').parseUtc(e.aqiDate!);
        if (dailyDate.day == date.day &&
            dailyDate.month == date.month &&
            dailyDate.year == date.year) {
          aqi = e.avgAqi!.toInt();
        }
      }
    }
    // aqi remains null if no data at all → badge shows "-" with grey color

    final aqiColor = AppColors.getAqiColor(aqi);
    final badgeTextColor = _getContrastColor(aqiColor);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _onDateSelected(date),
      child: Container(
        width: 50.w,
        margin: EdgeInsets.symmetric(horizontal: 6.w),
        padding: EdgeInsets.symmetric(vertical: 6.h),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary
              : isInBetween
                  ? AppColors.primary.withValues(alpha: 0.12)
                  : AppColors.surface,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isSelected
                ? AppColors.primary
                : isInBetween
                    ? AppColors.primary.withValues(alpha: 0.3)
                    : isRealToday
                        ? AppColors.primary.withValues(alpha: 0.5)
                        : AppColors.border,
            width: isRealToday || isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.primary.withValues(alpha: 0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  )
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              weekdayStr,
              style: TextStyle(
                fontSize: 9.sp,
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? Colors.white70
                    : isInBetween
                        ? AppColors.primary
                        : AppColors.textSecondary,
              ),
            ),
            SizedBox(height: 4.h),
            Text(
              '${date.day}',
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
                color: isSelected
                    ? Colors.white
                    : isInBetween
                        ? AppColors.primary
                        : AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 6.h),
            // AQI Badge
            Container(
              padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: aqiColor,
                borderRadius: BorderRadius.circular(6.r),
              ),
              child: Text(
                '${aqi ?? "-"}',
                style: TextStyle(
                  fontSize: 8.sp,
                  fontWeight: FontWeight.bold,
                  color: badgeTextColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onRangeSelected(DateTime start, DateTime end) {
    setState(() {
      _startDate = DateTime(start.year, start.month, start.day);
      _endDate = DateTime(end.year, end.month, end.day, 23, 59, 59);
      _activeDay = DateTime(end.year, end.month, end.day);
      // _selectedTimelineIndex = null;
      _currentHeaderMonthYear = _getHeaderString(_startDate, _endDate);
    });

    if (widget.site.imeiNo.isNotEmpty) {
      fetchAnalytics();
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToSelectedDate();
    });
  }

  void _scrollToSelectedDate({bool animate = true}) {
    if (!_calendarScrollController.hasClients) return;

    final today = DateTime.now();
    final startOfToday = DateTime(today.year, today.month, today.day);
    final selectedStart = DateTime(_endDate.year, _endDate.month, _endDate.day);
    final index = startOfToday.difference(selectedStart).inDays;

    if (index >= 0) {
      final double itemWidth = 62.w; // 50.w + 12.w spacing
      final double viewportWidth = MediaQuery.of(context).size.width;
      final double targetOffset =
          (index * itemWidth) - (viewportWidth / 2 - 47.w);

      if (animate) {
        _calendarScrollController.animateTo(
          targetOffset.clamp(
              0.0, _calendarScrollController.position.maxScrollExtent),
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOut,
        );
      } else {
        _calendarScrollController.jumpTo(
          targetOffset.clamp(
              0.0, _calendarScrollController.position.maxScrollExtent),
        );
      }
    }
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _activeDay = DateTime(date.year, date.month, date.day);
      // _selectedTimelineIndex = null;
    });

    context.read<AnalyticsBloc>().add(FetchDailySummaryEvent(
        date: DateFormat('dd-MM-yyyy').format(_activeDay!),
        interval: selectedInterval,
        imeiNo: widget.site.imeiNo));
  }

  Color _getContrastColor(Color color) {
    final double yiq = (((color.r * 255.0) * 299) +
            ((color.g * 255.0) * 587) +
            ((color.b * 255.0) * 114)) /
        1000;
    return yiq >= 128 ? const Color(0xFF0F172A) : Colors.white;
  }
}
