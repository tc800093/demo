import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../config/theme/colors.dart';
import '../../../../core/network/api_config.dart';
import '../../../../config/theme/map_styles.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../../shared/widgets/map_marker_helper.dart';
import '../bloc/sites_bloc.dart';
import '../../domain/repositories/sites_repository.dart';

class SitesMapPage extends StatefulWidget {
  final String? selectedSiteId;
  const SitesMapPage({super.key, this.selectedSiteId});

  @override
  State<SitesMapPage> createState() => _SitesMapPageState();
}

class _SitesMapPageState extends State<SitesMapPage>
    with SingleTickerProviderStateMixin {
  GoogleMapController? _mapController;
  String _currentMapStyleName = 'Silver';
  bool _isMapStyleManuallySet = false;
  SiteEntity? _selectedMapSite;
  Map<String, BitmapDescriptor> _customMarkers = {};

  AnimationController? _pulseController;
  bool _hasCenteredOnTarget = false;

  String get _activeMapStyleName {
    if (_isMapStyleManuallySet) {
      return _currentMapStyleName;
    }
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return isDarkMode ? 'Dark' : 'Silver';
  }

  String? _getMapStyleJson() {
    final styleName = _activeMapStyleName;
    if (styleName == 'Silver') {
      return MapStyles.silver;
    } else if (styleName == 'Dark') {
      return MapStyles.dark;
    }
    return null;
  }

  void _loadCustomMarkers(List<SiteEntity> sites) async {
    final Map<String, BitmapDescriptor> loadedMarkers = {};
    for (final site in sites) {
      final String aqiText = site.aqi?.toString() ?? 'Offline';
      final Color color = AppColors.getAqiColor(site.aqi);
      try {
        final marker = await MapMarkerHelper.createAqiMarker(aqiText, color);
        loadedMarkers[site.id] = marker;
      } catch (e) {
        debugPrint('Error generating custom marker: $e');
      }
    }
    if (mounted) {
      setState(() {
        _customMarkers = loadedMarkers;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    // Load initial markers if Bloc already has data loaded
    final sitesState = context.read<SitesBloc>().state;
    if (sitesState is SitesLoaded) {
      _loadCustomMarkers(sitesState.sites);
      _checkAndSetSelectedSite(sitesState.sites);
      if (widget.selectedSiteId == null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _fitAllMarkers(sitesState.sites);
        });
      }
    }

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )
      ..repeat()
      ..addListener(() {
        // setState(() {});
      });
  }

  @override
  void didUpdateWidget(covariant SitesMapPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.selectedSiteId != oldWidget.selectedSiteId) {
      _hasCenteredOnTarget = false;
      final sitesState = context.read<SitesBloc>().state;
      if (sitesState is SitesLoaded) {
        _checkAndSetSelectedSite(sitesState.sites);
      }
    }
  }

  void _checkAndSetSelectedSite(List<SiteEntity> sites) {
    if (widget.selectedSiteId != null && !_hasCenteredOnTarget) {
      final site = sites.firstWhere(
        (s) => s.id == widget.selectedSiteId,
        orElse: () => sites.first,
      );
      if (site.id == widget.selectedSiteId) {
        setState(() {
          _selectedMapSite = site;
        });
        _hasCenteredOnTarget = true;
        _animateCameraToSite(site);
      }
    }
  }

  void _animateCameraToSite(SiteEntity site) {
    _mapController?.animateCamera(
      CameraUpdate.newLatLngZoom(
        LatLng(site.latitude, site.longitude),
        14.5,
      ),
    );
  }

  void _fitAllMarkers(List<SiteEntity> sites) {
    if (sites.isEmpty || _mapController == null) return;

    double? minLat, maxLat, minLng, maxLng;
    for (final site in sites) {
      if (site.latitude == 0.0 && site.longitude == 0.0) continue;

      if (minLat == null || site.latitude < minLat) minLat = site.latitude;
      if (maxLat == null || site.latitude > maxLat) maxLat = site.latitude;
      if (minLng == null || site.longitude < minLng) minLng = site.longitude;
      if (maxLng == null || site.longitude > maxLng) maxLng = site.longitude;
    }

    if (minLat == null || maxLat == null || minLng == null || maxLng == null) {
      return;
    }

    if ((maxLat - minLat).abs() < 0.001 && (maxLng - minLng).abs() < 0.001) {
      _mapController!.animateCamera(
        CameraUpdate.newLatLngZoom(LatLng(minLat, minLng), 13.0),
      );
    } else {
      final bounds = LatLngBounds(
        southwest: LatLng(minLat, minLng),
        northeast: LatLng(maxLat, maxLng),
      );
      _mapController!.animateCamera(
        CameraUpdate.newLatLngBounds(bounds, 50),
      );
    }
  }

  Future<void> _openDirections(BuildContext context, SiteEntity site) async {
    final String destination = site.address.isNotEmpty
        ? Uri.encodeComponent(site.address)
        : '${site.latitude},${site.longitude}';
    final Uri googleMapsUrl =
        Uri.parse(ApiConfig.googleMapsDirections(destination));
    try {
      if (await canLaunchUrl(googleMapsUrl)) {
        await launchUrl(googleMapsUrl, mode: LaunchMode.externalApplication);
      } else {
        throw Exception('Could not launch maps application');
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Row(
              children: [
                Icon(Icons.error_outline_rounded, color: Colors.white),
                SizedBox(width: 8),
                Expanded(
                  child: Text('Could not open Google Maps navigation.'),
                ),
              ],
            ),
            backgroundColor: AppColors.aqiRed,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _pulseController?.dispose();
    // Do not call _mapController?.dispose() as it is disposed by GoogleMap widget automatically
    super.dispose();
  }

  Widget _buildStylePill(String name, IconData icon) {
    final isSelected = _activeMapStyleName == name;
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentMapStyleName = name;
          _isMapStyleManuallySet = true;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 14,
              color: isSelected
                  ? Colors.white
                  : AppColors.of(context).textSecondary,
            ),
            const SizedBox(width: 4),
            Text(
              name,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected
                    ? Colors.white
                    : AppColors.of(context).textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('Monitoring Map'),
      ),
      body: SafeArea(
        child: BlocConsumer<SitesBloc, SitesState>(
          listener: (context, state) {
            if (state is SitesLoaded) {
              _loadCustomMarkers(state.sites);
              _checkAndSetSelectedSite(state.sites);
              if (widget.selectedSiteId == null) {
                _fitAllMarkers(state.sites);
              }
            }
          },
          builder: (context, state) {
            if (state is SitesLoading && _customMarkers.isEmpty) {
              return const Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              );
            }
            if (state is SitesLoaded) {
              return _buildRealMapView(state.sites);
            }
            if (state is SitesError) {
              return ErrorDisplayWidget(
                message: state.message,
                onRetry: () {
                  context.read<SitesBloc>().add(LoadSites());
                },
              );
            }
            return const Center(child: Text('Failed to load map data'));
          },
        ),
      ),
    );
  }

  Widget _buildRealMapView(List<SiteEntity> sites) {
    final Map<String, LatLng> sitePositions = {};
    final List<LatLng> placedCoordinates = [];
    const double threshold = 0.00015; // Threshold to consider overlapping
    const double offsetDist = 0.00018; // Spiral radius offset

    final Set<Marker> googleMarkers = sites.map((site) {
      double lat = site.latitude;
      double lng = site.longitude;

      int overlapCount = 0;
      for (final coord in placedCoordinates) {
        final double latDiff = (coord.latitude - lat).abs();
        final double lngDiff = (coord.longitude - lng).abs();
        if (latDiff < threshold && lngDiff < threshold) {
          overlapCount++;
        }
      }

      if (overlapCount > 0) {
        final double angle = overlapCount * 2.39996; // Golden angle in radians
        final double currentOffset = offsetDist * (1 + 0.1 * overlapCount);
        lat += currentOffset * math.sin(angle);
        lng += currentOffset * math.cos(angle);
      }

      final LatLng finalPosition = LatLng(lat, lng);
      placedCoordinates.add(finalPosition);
      sitePositions[site.id] = finalPosition;

      double hue = BitmapDescriptor.hueGreen;
      if (site.aqi != null) {
        final aqi = site.aqi!;
        if (aqi <= 50) {
          hue = BitmapDescriptor.hueGreen;
        } else if (aqi <= 100) {
          hue = BitmapDescriptor.hueYellow;
        } else if (aqi <= 200) {
          hue = BitmapDescriptor.hueOrange;
        } else {
          hue = BitmapDescriptor.hueRed;
        }
      }

      final customIcon = _customMarkers[site.id];

      return Marker(
        markerId: MarkerId(site.id),
        position: finalPosition,
        icon: customIcon ?? BitmapDescriptor.defaultMarkerWithHue(hue),
        onTap: () {
          setState(() {
            _selectedMapSite = site;
          });
          _mapController?.animateCamera(
            CameraUpdate.newLatLng(finalPosition),
          );
        },
        infoWindow: InfoWindow(
          title: site.name,
          snippet: 'AQI: ${site.aqi ?? "Offline"}',
        ),
      );
    }).toSet();

    final LatLng? selectedCenter = _selectedMapSite != null
        ? (sitePositions[_selectedMapSite!.id] ??
            LatLng(_selectedMapSite!.latitude, _selectedMapSite!.longitude))
        : null;

    final Set<Circle> circles = selectedCenter != null &&
            _pulseController != null
        ? {
            Circle(
              circleId: CircleId('pulse_core_${_selectedMapSite!.id}'),
              center: selectedCenter,
              radius: 16.0,
              fillColor: AppColors.primary.withValues(
                alpha: 0.6 + 0.4 * _pulseController!.value,
              ),
              strokeColor: Colors.white.withValues(
                alpha: 0.9,
              ),
              strokeWidth: 3,
            ),
            Circle(
              circleId: CircleId('pulse_ripple1_${_selectedMapSite!.id}'),
              center: selectedCenter,
              radius: 16.0 + 350.0 * _pulseController!.value,
              fillColor: AppColors.primary.withValues(
                alpha: 0.55 * (1.0 - _pulseController!.value),
              ),
              strokeColor: AppColors.primary.withValues(
                alpha: 0.95 * (1.0 - _pulseController!.value),
              ),
              strokeWidth: 6,
            ),
            Circle(
              circleId: CircleId('pulse_ripple2_${_selectedMapSite!.id}'),
              center: selectedCenter,
              radius: 16.0 + 350.0 * ((_pulseController!.value + 0.33) % 1.0),
              fillColor: AppColors.primary.withValues(
                alpha: 0.55 * (1.0 - ((_pulseController!.value + 0.33) % 1.0)),
              ),
              strokeColor: AppColors.primary.withValues(
                alpha: 0.95 * (1.0 - ((_pulseController!.value + 0.33) % 1.0)),
              ),
              strokeWidth: 6,
            ),
            Circle(
              circleId: CircleId('pulse_ripple3_${_selectedMapSite!.id}'),
              center: selectedCenter,
              radius: 16.0 + 350.0 * ((_pulseController!.value + 0.67) % 1.0),
              fillColor: AppColors.primary.withValues(
                alpha: 0.55 * (1.0 - ((_pulseController!.value + 0.67) % 1.0)),
              ),
              strokeColor: AppColors.primary.withValues(
                alpha: 0.95 * (1.0 - ((_pulseController!.value + 0.67) % 1.0)),
              ),
              strokeWidth: 6,
            ),
          }
        : {};

    return Stack(
      children: [
        Positioned.fill(
          child: GoogleMap(
            style: _getMapStyleJson(),
            onMapCreated: (GoogleMapController controller) {
              _mapController = controller;
              // If we already have a site selected but haven't animated yet, do it now
              if (_selectedMapSite != null) {
                _animateCameraToSite(_selectedMapSite!);
              } else {
                _fitAllMarkers(sites);
              }
            },
            initialCameraPosition: const CameraPosition(
              target: LatLng(18.5204, 73.8567),
              zoom: 12.0,
            ),
            markers: googleMarkers,
            circles: circles,
            rotateGesturesEnabled: false,
            tiltGesturesEnabled: false,
            mapToolbarEnabled: false,
            zoomControlsEnabled: false,
          ),
        ),
        // Floating Map Style Selector
        Positioned(
          top: 20,
          left: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildStylePill('Standard', Icons.map_outlined),
                _buildStylePill('Silver', Icons.palette_outlined),
                _buildStylePill('Dark', Icons.dark_mode_outlined),
              ],
            ),
          ),
        ),
        // Floating Zoom Controls
        Positioned(
          top: 20,
          right: 20,
          child: Column(
            children: [
              FloatingActionButton.small(
                heroTag: 'zoom_in_contractor_map_tab',
                backgroundColor: Colors.white,
                foregroundColor: AppColors.textPrimary,
                onPressed: () {
                  _mapController?.animateCamera(CameraUpdate.zoomIn());
                },
                child: const Icon(Icons.add_rounded),
              ),
              const SizedBox(height: 8),
              FloatingActionButton.small(
                heroTag: 'zoom_out_contractor_map_tab',
                backgroundColor: Colors.white,
                foregroundColor: AppColors.textPrimary,
                onPressed: () {
                  _mapController?.animateCamera(CameraUpdate.zoomOut());
                },
                child: const Icon(Icons.remove_rounded),
              ),
            ],
          ),
        ),
        if (_selectedMapSite != null)
          Positioned(
            bottom: 24,
            left: 20,
            right: 20,
            child: _buildSiteDetailOverlay(context, _selectedMapSite!),
          ),
      ],
    );
  }

  Widget _buildSiteDetailOverlay(BuildContext context, SiteEntity site) {
    final statusColor = AppColors.getAqiColor(site.aqi);
    final statusText = AppColors.getAqiStatus(site.aqi);

    return Dismissible(
      key: Key(site.id),
      direction: DismissDirection.down,
      onDismissed: (_) {
        setState(() {
          _selectedMapSite = null;
        });
      },
      child: ScadaCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row: Site Name, Status indicator dot and Close button
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              site.name,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textPrimary,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Online/Offline status dot badge
                          //
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: site.isDeviceOnline
                                  ? AppColors.online
                                  : AppColors.offline,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            site.isDeviceOnline ? 'Online' : 'Offline',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              color: site.isDeviceOnline
                                  ? AppColors.online
                                  : AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${site.projectName} • ${site.projectType}',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.close_rounded,
                    size: 20,
                    color: AppColors.textMuted,
                  ),
                  onPressed: () {
                    setState(() {
                      _selectedMapSite = null;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Site Address
            Row(
              children: [
                Icon(
                  Icons.location_on_outlined,
                  size: 13,
                  color: AppColors.textSecondary,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    site.address,
                    style: TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // AQI Display Section (card-in-card design)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: statusColor.withValues(alpha: 0.15),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  // Circular AQI bubble
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: statusColor,
                      boxShadow: [
                        BoxShadow(
                          color: statusColor.withValues(alpha: 0.25),
                          blurRadius: 6,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        '${site.aqi ?? "-"}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // AQI text & description
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'AQI is $statusText',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: statusColor == AppColors.aqiYellow
                                ? const Color(0xFFD4AF37)
                                : statusColor,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Serial: ${site.deviceSerial}',
                          style: TextStyle(
                            fontSize: 10,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Buttons Bar (using Expanded to take exactly 50% width and fit perfectly without overflow)
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: BorderSide(
                          color: AppColors.primary.withValues(alpha: 0.4),
                          width: 1.2),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    icon: const Icon(Icons.directions_outlined, size: 16),
                    label: const Text(
                      'Directions',
                      style:
                          TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                    onPressed: () => _openDirections(context, site),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    icon: const Icon(Icons.analytics_outlined, size: 16),
                    label: const Text(
                      'Details',
                      style:
                          TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                    onPressed: () =>
                        context.push('/contractor/sites/${site.id}'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
