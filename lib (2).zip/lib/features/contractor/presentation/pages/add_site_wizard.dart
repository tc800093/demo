import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../config/theme/colors.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../bloc/sites_bloc.dart';
import '../../domain/repositories/sites_repository.dart';

class AddSiteWizard extends StatefulWidget {
  const AddSiteWizard({super.key});

  @override
  State<AddSiteWizard> createState() => _AddSiteWizardState();
}

class _AddSiteWizardState extends State<AddSiteWizard> {
  int _currentStep = 0;
  final int _totalSteps = 5;

  // Form keys
  final _step1Key = GlobalKey<FormState>();
  final _step2Key = GlobalKey<FormState>();
  final _step4Key = GlobalKey<FormState>();

  // Data fields
  final _nameController = TextEditingController();
  final _projectNameController = TextEditingController();
  String _projectType = 'Construction';
  final _addressController = TextEditingController();
  final _latController = TextEditingController(text: '18.5793');
  final _lngController = TextEditingController(text: '73.7383');
  
  // Step 4 fields
  final _deviceSerialController = TextEditingController();
  bool _isDeviceValidated = false;
  bool _isValidatingDevice = false;

  @override
  void dispose() {
    _nameController.dispose();
    _projectNameController.dispose();
    _addressController.dispose();
    _latController.dispose();
    _lngController.dispose();
    _deviceSerialController.dispose();
    super.dispose();
  }

  void _onNext() {
    if (_currentStep == 0) {
      if (_step1Key.currentState?.validate() ?? false) {
        setState(() => _currentStep++);
      }
    } else if (_currentStep == 1) {
      if (_step2Key.currentState?.validate() ?? false) {
        setState(() => _currentStep++);
      }
    } else if (_currentStep == 2) {
      // Step 3 is map pin dropping (mocked)
      setState(() => _currentStep++);
    } else if (_currentStep == 3) {
      // Step 4 validation check
      if (!_isDeviceValidated) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please validate your device serial number first.')),
        );
        return;
      }
      setState(() => _currentStep++);
    } else if (_currentStep == 4) {
      _createSite();
    }
  }

  void _onBack() {
    if (_currentStep > 0) {
      setState(() => _currentStep--);
    } else {
      context.pop();
    }
  }

  void _validateDevice() async {
    if (_deviceSerialController.text.trim().isEmpty) return;
    setState(() {
      _isValidatingDevice = true;
    });
    
    await Future.delayed(const Duration(seconds: 1)); // Simulate network check
    
    setState(() {
      _isValidatingDevice = false;
      _isDeviceValidated = true;
    });
  }

  void _createSite() {
    final newSite = SiteEntity(
      id: 'site_${DateTime.now().millisecondsSinceEpoch}',
      name: _nameController.text.trim(),
      projectName: _projectNameController.text.trim(),
      projectType: _projectType,
      address: _addressController.text.trim(),
      latitude: double.tryParse(_latController.text) ?? 18.5793,
      longitude: double.tryParse(_lngController.text) ?? 73.7383,
      aqi: 55, // Newly initialized status
      parameters: const {
        'PM1': SensorReading(12, 'µg/m³'),
        'PM2.5': SensorReading(35, 'µg/m³'),
        'PM10': SensorReading(45, 'µg/m³'),
        'TSP': SensorReading(60, 'µg/m³'),
        'Temp': SensorReading(26.0, '°C'),
        'Humidity': SensorReading(60, '%'),
        'CO': SensorReading(0.1, 'ppm'),
        'CO₂': SensorReading(360, 'ppm'),
        'NO₂': SensorReading(8, 'ppb'),
        'SO₂': SensorReading(4, 'ppb'),
        'O₃': SensorReading(20, 'ppb'),
        'VOC': SensorReading(0.1, 'ppm'),
      },
      deviceSerial: _deviceSerialController.text.trim(),
      imeiNo: '',
      isDeviceOnline: true,
      signalStrength: 85,
      batteryLevel: 100,
      isGpsConnected: true,
      is4gConnected: true,
      firmwareVersion: 'v2.4.1',
      lastSyncTime: DateTime.now(),
      sprinklerMode: 'Auto',
      isSprinklerRunning: false,
      sprinklerRunDurationMinutes: 0,
      sprinklerHistory: const [],
      maintenanceHistory: const [],
      calibrationHistory: const [],
    );

    context.read<SitesBloc>().add(AddSite(newSite));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Site registered successfully!'), backgroundColor: AppColors.online),
    );
    context.go(AppRoutes.contractorSites);
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('Add New Site'),
        leading: IconButton(
          icon: const Icon(Icons.close_rounded),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Progress Bar / Step text
            _buildProgressBar(),
            
            // Step content container
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: _buildStepContent(),
              ),
            ),
            
            // Bottom Action buttons
            _buildBottomActionBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressBar() {
    final colors = AppColors.of(context);
    final percent = (_currentStep + 1) / _totalSteps;
    return Container(
      color: colors.surface,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Step ${_currentStep + 1} of $_totalSteps',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: colors.textSecondary),
              ),
              Text(
                '${(percent * 100).toInt()}% Complete',
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.primary),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: percent,
              backgroundColor: colors.border,
              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildStep1BasicDetails();
      case 1:
        return _buildStep2Address();
      case 2:
        return _buildStep3MapSelection();
      case 3:
        return _buildStep4DeviceAssignment();
      case 4:
        return _buildStep5Confirmation();
      default:
        return Container();
    }
  }

  Widget _buildBottomActionBar() {
    final colors = AppColors.of(context);
    return Container(
      color: colors.surface,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Row(
        children: [
          if (_currentStep > 0) ...[
            Expanded(
              child: SecondaryButton(
                text: 'Back',
                onPressed: _onBack,
              ),
            ),
            const SizedBox(width: 16),
          ],
          Expanded(
            child: PrimaryButton(
              text: _currentStep == _totalSteps - 1 ? 'Create Site' : 'Next',
              onPressed: _onNext,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep1BasicDetails() {
    final colors = AppColors.of(context);
    return Form(
      key: _step1Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Basic Site Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: colors.textPrimary)),
          const SizedBox(height: 16),
          
          Text('Site Name', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
          const SizedBox(height: 8),
          TextFormField(
            controller: _nameController,
            validator: (value) => (value == null || value.isEmpty) ? 'Enter site name' : null,
            decoration: InputDecoration(hintText: 'Construction Site F', fillColor: colors.surface),
          ),
          
          const SizedBox(height: 20),
          
          Text('Project Name', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
          const SizedBox(height: 8),
          TextFormField(
            controller: _projectNameController,
            validator: (value) => (value == null || value.isEmpty) ? 'Enter project name' : null,
            decoration: InputDecoration(hintText: 'Metro Construction', fillColor: colors.surface),
          ),
          
          const SizedBox(height: 20),
          
          Text('Project Type', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: _projectType,
            onChanged: (val) => setState(() => _projectType = val!),
            decoration: InputDecoration(fillColor: colors.surface),
            items: ['Construction', 'Industrial', 'Infrastructure', 'Mining', 'Commercial']
                .map((type) => DropdownMenuItem(value: type, child: Text(type)))
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildStep2Address() {
    final colors = AppColors.of(context);
    return Form(
      key: _step2Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Location & Address', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: colors.textPrimary)),
          const SizedBox(height: 16),
          
          Text('Site Address', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
          const SizedBox(height: 8),
          TextFormField(
            controller: _addressController,
            maxLines: 3,
            validator: (value) => (value == null || value.isEmpty) ? 'Enter site address' : null,
            decoration: InputDecoration(hintText: 'Sector 63, Noida, UP', fillColor: colors.surface),
          ),
          
          const SizedBox(height: 20),
          
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Latitude', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _latController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) => (value == null || value.isEmpty) ? 'Required' : null,
                      decoration: InputDecoration(fillColor: colors.surface),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Longitude', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _lngController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) => (value == null || value.isEmpty) ? 'Required' : null,
                      decoration: InputDecoration(fillColor: colors.surface),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStep3MapSelection() {
    final colors = AppColors.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Confirm Coordinates on Map', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: colors.textPrimary)),
        const SizedBox(height: 12),
        
        // Mock interactive map representation
        Container(
          height: 250,
          width: double.infinity,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: colors.border),
          ),
          child: Stack(
            children: [
              // Grid pattern representing map
              Positioned.fill(
                child: GridPaper(
                  color: Colors.blue.withValues(alpha: 0.05),
                  interval: 50,
                  child: Container(),
                ),
              ),
              
              // Marker in center
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.location_on_rounded, size: 40, color: AppColors.aqiRed),
                    Text(
                      'Drop pin on map',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: colors.textPrimary),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        Text(
          'Pinned Location: Lat ${_latController.text}, Lng ${_lngController.text}',
          style: TextStyle(fontSize: 12, color: colors.textSecondary, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  Widget _buildStep4DeviceAssignment() {
    final colors = AppColors.of(context);
    return Form(
      key: _step4Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Assign IoT Device', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: colors.textPrimary)),
          const SizedBox(height: 16),
          
          Text('Device Serial Number', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: colors.textPrimary)),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: _deviceSerialController,
                  validator: (value) => (value == null || value.isEmpty) ? 'Enter device serial' : null,
                  decoration: InputDecoration(hintText: 'AQI-UDB-9188497373', fillColor: colors.surface),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: _validateDevice,
                  child: _isValidatingDevice
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Text('Validate', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 24),
          
          if (_isDeviceValidated) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.online.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.online.withValues(alpha: 0.2)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.check_circle_outline_rounded, color: AppColors.online, size: 28),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Device Validated Successfully', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.online, fontSize: 13)),
                        const SizedBox(height: 4),
                        Text('Model: VASUNDHARA AQI System', style: TextStyle(fontSize: 12, color: colors.textPrimary)),
                        Text('Status: Active | Last Calibration: 10 Mar 2025', style: TextStyle(fontSize: 11, color: colors.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStep5Confirmation() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Confirm Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.of(context).textPrimary)),
        const SizedBox(height: 16),
        
        ScadaCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildConfirmRow('Site Name', _nameController.text),
              _buildConfirmRow('Project Name', _projectNameController.text),
              _buildConfirmRow('Project Type', _projectType),
              _buildConfirmRow('Address', _addressController.text),
              _buildConfirmRow('Coordinates', 'Lat ${_latController.text}, Lng ${_lngController.text}'),
              _buildConfirmRow('Device Serial', _deviceSerialController.text),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildConfirmRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontSize: 11, color: AppColors.of(context).textSecondary, fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(value, style: TextStyle(fontSize: 14, color: AppColors.of(context).textPrimary, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
