import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/core/utils/helper.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/bloc/notification_history/notification_history_bloc.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';

class AlertsPage extends StatefulWidget {
  const AlertsPage({super.key});

  @override
  State<AlertsPage> createState() => _AlertsPageState();
}

class _AlertsPageState extends State<AlertsPage> {
  String _activeTab = 'All'; // 'All', 'Critical', 'Warning', 'Info'

  final ScrollController controller = ScrollController();

  late DateTime _startDate;
  late DateTime _endDate;
  DateTime? _activeDay;

  @override
  void initState() {
    controller.addListener(() {
      if (controller.position.pixels >=
          controller.position.maxScrollExtent - 200) {
        context
            .read<NotificationHistoryBloc>()
            .add(FetchNotificationHistoryFromRange(
                endDate: getCurrentDateTime(DateTime.now()),
                // startDate: getCurrentDateTime(DateTime(DateTime.now().year,
                //     DateTime.now().month, DateTime.now().day, 00, 00, 00)
                startDate: '2026-07-01 00:00:00',
                isLoadMore: true));
      }
    });
    fetchNotificationHistory();
    super.initState();
  }

  String getCurrentDateTime(DateTime date) {
    return DateFormat('yyyy-MM-dd HH:mm:ss').format(date);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void fetchNotificationHistory() async {
    context
        .read<NotificationHistoryBloc>()
        .add(FetchNotificationHistoryFromRange(
            endDate: getCurrentDateTime(DateTime.now()),
            // startDate: getCurrentDateTime(DateTime(DateTime.now().year,
            //     DateTime.now().month, DateTime.now().day, 00, 00, 00)
            startDate: '2026-07-01 00:00:00'));
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('Compliance & Device Alerts'),
      ),
      body: SafeArea(
        child: BlocConsumer<NotificationHistoryBloc, NotificationHistoryState>(
          listener: (context, state) {},
          builder: (context, state) {
            return Column(
              children: [
                // Tabs Row
                Container(
                  color: colors.surface,
                  padding: const EdgeInsets.symmetric(
                      vertical: 12.0, horizontal: 16.0),
                  child: Row(
                    children:
                        ['All', 'Critical', 'Warning', 'Info'].map((tabName) {
                      final isActive = _activeTab == tabName;
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: ChoiceChip(
                            label: Text(
                              tabName,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: isActive
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                color: isActive
                                    ? Colors.white
                                    : colors.textSecondary,
                              ),
                            ),
                            selected: isActive,
                            selectedColor: AppColors.primary,
                            backgroundColor: colors.background,
                            onSelected: (bool selected) {
                              if (selected) {
                                setState(() {
                                  _activeTab = tabName;
                                });
                                context.read<NotificationHistoryBloc>().add(
                                    FilterNotificationByType(
                                        alertType: _activeTab
                                            .toString()
                                            .toLowerCase()));
                              }
                            },
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                // Alerts List
                if (state.notificationHistoryStatus ==
                    NotificationHistoryStatus.success) ...[
                  Expanded(
                    child: state.filteredNotificationList.isEmpty
                        ? Center(
                            child: Text('No alerts found for this filter.',
                                style:
                                    TextStyle(color: AppColors.textSecondary)),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(16),
                            controller: controller,
                            itemCount: state.filteredNotificationList.length,
//                           state.notifications.length +
// (state.hasMore ? 1 : 0),
                            itemBuilder: (context, index) {
                              final alert =
                                  state.filteredNotificationList[index];
                              final type =
                                  alert.eventType.toString().toLowerCase();

                              Color color = AppColors.online;
                              if (type == 'critical') color = AppColors.aqiRed;
                              if (type == 'warning')
                                color = AppColors.aqiOrange;

                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                child: ScadaCard(
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.only(top: 4),
                                        width: 10,
                                        height: 10,
                                        decoration: BoxDecoration(
                                          color: color,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 16),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  alert.title.toString(),
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 13,
                                                      color: AppColors
                                                          .textPrimary),
                                                ),
                                                Text(
                                                  // '${alert.createdAt}',
                                                  getTimeAgo(alert.createdAt
                                                      .toString()),
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      color:
                                                          AppColors.textMuted),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 6),
                                            Text(
                                              alert.description.toString(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  color:
                                                      AppColors.textSecondary,
                                                  height: 1.4),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}
