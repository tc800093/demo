import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../config/theme/colors.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

class ContractorShell extends StatelessWidget {
  final Widget child;

  const ContractorShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthBloc>().state;
    UserRole role = UserRole.user;
    if (authState is AuthAuthenticated) {
      role = authState.user.role;
    }
    final bool isCustomer = role == UserRole.user;

    return Scaffold(
      body: child,
      bottomNavigationBar: Builder(
        builder: (context) {
          final colors = AppColors.of(context);
          return Container(
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: colors.border, width: 1)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.02),
                  blurRadius: 10,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: BottomNavigationBar(
              currentIndex: _getSelectedIndex(context, isCustomer),
              onTap: (index) => _onItemTapped(index, context, isCustomer),
              type: BottomNavigationBarType.fixed,
              backgroundColor: AppColors.primary,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.white.withValues(alpha: 0.6),
              selectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  fontFamily: 'Poppins'),
              unselectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 12,
                  fontFamily: 'Poppins'),
              items: [
                const BottomNavigationBarItem(
                  icon: Icon(Icons.dashboard_outlined),
                  activeIcon: Icon(Icons.dashboard_rounded),
                  label: 'Dashboard',
                ),
                if (isCustomer)
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.people_outline_rounded),
                    activeIcon: Icon(Icons.people_rounded),
                    label: 'Sub-Customers',
                  ),
                const BottomNavigationBarItem(
                  icon: Icon(Icons.view_list_outlined),
                  activeIcon: Icon(Icons.view_list_rounded),
                  label: 'My Devices',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(Icons.place_outlined),
                  activeIcon: Icon(Icons.place_rounded),
                  label: 'Map view',
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  int _getSelectedIndex(BuildContext context, bool isCustomer) {
    final location = GoRouterState.of(context).matchedLocation;
    if (location.startsWith('/contractor/dashboard')) return 0;

    if (isCustomer) {
      if (location.startsWith('/contractor/sub-customers')) return 1;
      if (location.startsWith('/contractor/sites')) return 2;
      if (location.startsWith('/contractor/map')) return 3;
    } else {
      if (location.startsWith('/contractor/sites')) return 1;
      if (location.startsWith('/contractor/map')) return 2;
    }

    return 0;
  }

  void _onItemTapped(int index, BuildContext context, bool isCustomer) {
    if (isCustomer) {
      switch (index) {
        case 0:
          context.go('/contractor/dashboard');
          break;
        case 1:
          context.go('/contractor/sub-customers');
          break;
        case 2:
          context.go('/contractor/sites');
          break;
        case 3:
          context.go('/contractor/map');
          break;
      }
    } else {
      switch (index) {
        case 0:
          context.go('/contractor/dashboard');
          break;
        case 1:
          context.go('/contractor/sites');
          break;
        case 2:
          context.go('/contractor/map');
          break;
      }
    }
  }
}
