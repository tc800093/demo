import 'package:flutter/material.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  String _reportType = 'AQI Summary'; // 'AQI Summary', 'Performance', 'Compliance'
  String _timeRange = '7 Days'; // '24 Hours', '7 Days', '30 Days'

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: const Text('Reports & Audits'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Generate Compliance Report',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 6),
              Text(
                'Select configuration to generate standard compliance reports.',
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
              ),
              
              const SizedBox(height: 24),
              
              // Select Report Type
              Text('Report Category', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                initialValue: _reportType,
                onChanged: (val) => setState(() => _reportType = val!),
                decoration: InputDecoration(fillColor: AppColors.surface),
                items: ['AQI Summary', 'Performance Audit', 'Compliance & Exceedances', 'Device Log Diagnostics']
                    .map((item) => DropdownMenuItem(value: item, child: Text(item)))
                    .toList(),
              ),
              
              const SizedBox(height: 20),
              
              // Select Time Range
              Text('Date Range', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              Row(
                children: ['24 Hours', '7 Days', '30 Days'].map((range) {
                  final isSelected = _timeRange == range;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4.0),
                      child: GestureDetector(
                        onTap: () => setState(() => _timeRange = range),
                        child: Container(
                          height: 48,
                          decoration: BoxDecoration(
                            color: isSelected ? AppColors.primaryLight : Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isSelected ? AppColors.primary : AppColors.border,
                            ),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            range,
                            style: TextStyle(
                              fontSize: 12,
                              color: isSelected ? AppColors.primary : AppColors.textSecondary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              
              const SizedBox(height: 30),
              
              // Compliance Indicator Box
              ScadaCard(
                child: Row(
                  children: [
                    const Icon(Icons.verified_user_rounded, color: AppColors.online, size: 36),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('92% Compliance Score', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: AppColors.textPrimary)),
                          const SizedBox(height: 2),
                          Text('Site metrics stayed within government compliance thresholds for $_timeRange.', style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.4)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              const Spacer(),
              
              PrimaryButton(
                text: 'Download PDF Report',
                icon: Icons.picture_as_pdf_rounded,
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Downloading PDF report...', style: TextStyle(color: Colors.white)), backgroundColor: AppColors.online),
                  );
                },
              ),
              const SizedBox(height: 16),
              SecondaryButton(
                text: 'Export Excel Spreadsheet',
                icon: Icons.table_view_rounded,
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Exporting Excel logs...')),
                  );
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
