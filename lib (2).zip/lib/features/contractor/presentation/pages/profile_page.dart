import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../../../config/theme/colors.dart';
import '../../../../app/router/router.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../core/theme/theme_cubit.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String _selectedLanguage = 'English';
  String _appVersion = '1.0.0';

  @override
  void initState() {
    super.initState();
    _loadAppVersion();
  }

  Future<void> _loadAppVersion() async {
    try {
      final packageInfo = await PackageInfo.fromPlatform();
      if (mounted) {
        setState(() {
          _appVersion = packageInfo.version;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthBloc>().state;
    final colors = AppColors.of(context);
    String name = 'User';
    String email = '';
    String phone = '';
    String roleLabel = 'User';
    String? company;
    Color roleBadgeColor = AppColors.primary;

    if (authState is AuthAuthenticated) {
      name = authState.user.name;
      email = authState.user.email;
      phone = authState.user.phone;
      company = authState.user.companyName;
      switch (authState.user.role) {
        case UserRole.admin:
          roleLabel = 'Platform Administrator';
          roleBadgeColor = const Color(0xFF7C3AED);
          break;
        case UserRole.subAdmin:
          roleLabel = 'Sub Administrator';
          roleBadgeColor = const Color(0xFF0D9488);
          break;
        case UserRole.user:
          roleLabel = 'Customer';
          roleBadgeColor = AppColors.primary;
          break;
        case UserRole.subUser:
          roleLabel = 'Sub Customer';
          roleBadgeColor = const Color(0xFFEA580C);
          break;
      }
    }

    String initials = '?';
    final trimmedName = name.trim();
    if (trimmedName.isNotEmpty) {
      final parts = trimmedName.split(' ').where((w) => w.isNotEmpty).toList();
      if (parts.isNotEmpty) {
        initials = parts.map((w) => w[0].toUpperCase()).take(2).join();
      }
    }

    return Scaffold(
      backgroundColor: colors.background,
      body: BlocListener<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is AuthUnauthenticated) {
            context.go(AppRoutes.login);
          }
        },
        child: CustomScrollView(
          slivers: [
            // Premium gradient AppBar
            SliverAppBar(
              expandedHeight: 200,
              pinned: true,
              backgroundColor: AppColors.primary,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: Colors.white, size: 20),
                onPressed: () => context.pop(),
              ),
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF1E65CD),
                        Color(0xFF1A56B0),
                        Color(0xFF0D3B7A),
                      ],
                    ),
                  ),
                  child: SafeArea(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 16),
                        // Avatar with gradient border
                        Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withValues(alpha: 0.8),
                                Colors.white.withValues(alpha: 0.3),
                              ],
                            ),
                          ),
                          child: CircleAvatar(
                            radius: 38,
                            backgroundColor:
                                Colors.white.withValues(alpha: 0.15),
                            child: Text(
                              initials,
                              style: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          name,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(height: 4),
                        // Role badge
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: roleBadgeColor.withValues(alpha: 0.25),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.3),
                            ),
                          ),
                          child: Text(
                            roleLabel,
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // Body Content
            SliverToBoxAdapter(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ── Personal Information Section ──
                    _buildSectionHeader('Personal Information', colors),
                    const SizedBox(height: 12),
                    ScadaCard(
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildInfoTile(
                            icon: Icons.person_outline_rounded,
                            iconColor: AppColors.primary,
                            label: 'Full Name',
                            value: name,
                            colors: colors,
                          ),
                          Divider(color: colors.border, height: 1, indent: 56),
                          _buildInfoTile(
                            icon: Icons.email_outlined,
                            iconColor: const Color(0xFF0D9488),
                            label: 'Email Address',
                            value: email.isNotEmpty ? email : '—',
                            colors: colors,
                          ),
                          Divider(color: colors.border, height: 1, indent: 56),
                          _buildInfoTile(
                            icon: Icons.phone_android_rounded,
                            iconColor: const Color(0xFF7C3AED),
                            label: 'Phone Number',
                            value: phone.isNotEmpty ? phone : '—',
                            colors: colors,
                          ),
                          Divider(color: colors.border, height: 1, indent: 56),
                          _buildInfoTile(
                            icon: Icons.business_rounded,
                            iconColor: const Color(0xFFEA580C),
                            label: 'Company',
                            value: company ?? '—',
                            colors: colors,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 28),

                    // ── Appearance Section ──
                    _buildSectionHeader('Appearance', colors),
                    const SizedBox(height: 12),
                    BlocBuilder<ThemeCubit, ThemeMode>(
                      builder: (context, currentMode) {
                        return ScadaCard(
                          padding: EdgeInsets.zero,
                          child: Column(
                            children: [
                              _buildThemeOption(
                                icon: Icons.light_mode_rounded,
                                iconColor: const Color(0xFFF59E0B),
                                title: 'Light',
                                subtitle: 'Classic light appearance',
                                isSelected: currentMode == ThemeMode.light,
                                onTap: () =>
                                    context.read<ThemeCubit>().setLight(),
                                colors: colors,
                              ),
                              Divider(
                                  color: colors.border, height: 1, indent: 56),
                              _buildThemeOption(
                                icon: Icons.dark_mode_rounded,
                                iconColor: const Color(0xFF6366F1),
                                title: 'Dark',
                                subtitle: 'Reduced light for comfort',
                                isSelected: currentMode == ThemeMode.dark,
                                onTap: () =>
                                    context.read<ThemeCubit>().setDark(),
                                colors: colors,
                              ),
                              Divider(
                                  color: colors.border, height: 1, indent: 56),
                              _buildThemeOption(
                                icon: Icons.settings_brightness_rounded,
                                iconColor: const Color(0xFF0EA5E9),
                                title: 'System',
                                subtitle: 'Follow device settings',
                                isSelected: currentMode == ThemeMode.system,
                                onTap: () =>
                                    context.read<ThemeCubit>().setSystem(),
                                colors: colors,
                              ),
                            ],
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 28),

                    // ── Settings Section ──
                    _buildSectionHeader('Settings', colors),
                    const SizedBox(height: 12),
                    ScadaCard(
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          // Language Selector
                          _buildSettingTileWithTrailing(
                            icon: Icons.translate_rounded,
                            iconColor: const Color(0xFF0EA5E9),
                            title: 'Language',
                            subtitle: _selectedLanguage,
                            colors: colors,
                            trailing: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: colors.background,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: colors.border),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _selectedLanguage,
                                  isDense: true,
                                  dropdownColor: colors.surface,
                                  icon: Icon(Icons.keyboard_arrow_down_rounded,
                                      size: 18, color: colors.textSecondary),
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: colors.textPrimary,
                                  ),
                                  items: const [
                                    DropdownMenuItem(
                                        value: 'English',
                                        child: Text('English')),
                                    DropdownMenuItem(
                                        value: 'हिन्दी', child: Text('हिन्दी')),
                                    DropdownMenuItem(
                                        value: 'मराठी', child: Text('मराठी')),
                                  ],
                                  onChanged: (val) {
                                    if (val != null) {
                                      setState(() {
                                        _selectedLanguage = val;
                                      });
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                          Divider(color: colors.border, height: 1, indent: 56),
                          _buildSettingTile(
                            icon: Icons.notifications_none_rounded,
                            iconColor: const Color(0xFFF59E0B),
                            title: 'Notification Settings',
                            subtitle: 'Push alert triggers',
                            colors: colors,
                            onTap: () {},
                          ),
                          Divider(color: colors.border, height: 1, indent: 56),
                          //real app version here using package_info_plus

                          _buildSettingTile(
                            icon: Icons.info_outline_rounded,
                            iconColor: colors.textSecondary,
                            title: 'App Version',
                            subtitle: 'v$_appVersion',
                            colors: colors,
                            onTap: () {},
                          ),
                        ],
                      ),
                    ),

                    // Sub-Customer Management (only for user role)
                    if (authState is AuthAuthenticated &&
                        authState.user.role == UserRole.user) ...[
                      const SizedBox(height: 28),
                      _buildSectionHeader('Management', colors),
                      const SizedBox(height: 12),
                      ScadaCard(
                        padding: EdgeInsets.zero,
                        child: _buildSettingTile(
                          icon: Icons.people_outline_rounded,
                          iconColor: AppColors.primary,
                          title: 'Manage Sub-Customers',
                          subtitle: 'View and add sub-customer accounts',
                          colors: colors,
                          onTap: () {
                            context.push('/contractor/sub-customers');
                          },
                        ),
                      ),
                    ],

                    const SizedBox(height: 36),

                    // ── Logout Button ──
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFEF2F2),
                          foregroundColor: const Color(0xFFDC2626),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: const BorderSide(
                                color: Color(0xFFFECACA), width: 1.5),
                          ),
                        ),
                        onPressed: () {
                          _showLogoutConfirmation(context, colors);
                        },
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.logout_rounded, size: 20),
                            SizedBox(width: 10),
                            Text(
                              'Log Out',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Section Header ──
  Widget _buildSectionHeader(String title, dynamic colors) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: colors.textMuted,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  // ── Info Tile (read-only) ──
  Widget _buildInfoTile({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    required dynamic colors,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: iconColor),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: colors.textMuted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: colors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Theme Option Tile ──
  Widget _buildThemeOption({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required bool isSelected,
    required VoidCallback onTap,
    required dynamic colors,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 18, color: iconColor),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: colors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: colors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? AppColors.primary : colors.textMuted,
                  width: isSelected ? 6 : 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Setting Tile with onTap ──
  Widget _buildSettingTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    required dynamic colors,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 18, color: iconColor),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: colors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: colors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded,
                size: 20, color: colors.textMuted),
          ],
        ),
      ),
    );
  }

  // ── Setting Tile with Custom Trailing Widget ──
  Widget _buildSettingTileWithTrailing({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required Widget trailing,
    required dynamic colors,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: iconColor),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: colors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 11,
                    color: colors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }

  // ── Logout Confirmation Dialog ──
  void _showLogoutConfirmation(BuildContext context, dynamic colors) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: colors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            const Icon(Icons.logout_rounded,
                color: Color(0xFFDC2626), size: 22),
            const SizedBox(width: 10),
            Text(
              'Log Out',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: colors.textPrimary,
              ),
            ),
          ],
        ),
        content: Text(
          'Are you sure you want to log out of your account?',
          style: TextStyle(
            fontSize: 14,
            color: colors.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: colors.textSecondary,
              ),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 0,
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              context.read<AuthBloc>().add(AuthLogoutRequested());
            },
            child: const Text(
              'Log Out',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
