import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/core/utils/validator.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/models/calibration_schedule_model.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_day_wise_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_schedule_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/bloc/analytics_bloc/analytics_bloc.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/pages/trend_tab_page.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/widgets/calibration_history_card_widget.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/widgets/calibration_schedule_card_widget.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../../shared/widgets/aqi_gauge.dart';
import '../../../../shared/widgets/sprinkler_effect.dart';
import '../bloc/sites_bloc.dart';
import '../bloc/sprinkler_bloc.dart';
import '../../domain/repositories/sites_repository.dart';
import '../../data/models/aqi_telemetry_model.dart';
import '../../../../core/di/injection.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../../../admin/domain/repositories/admin_repository.dart';
import '../../../admin/domain/entities/device_entity.dart';

class SiteDetailsPage extends StatefulWidget {
  final String siteId;

  const SiteDetailsPage({super.key, required this.siteId});

  @override
  State<SiteDetailsPage> createState() => _SiteDetailsPageState();
}

class _SiteDetailsPageState extends State<SiteDetailsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  late DateTime _startDate;
  late DateTime _endDate;
  DateTime? _activeDay;
  int? _selectedTimelineIndex;
  late ScrollController _calendarScrollController;
  late String _currentHeaderMonthYear;
  bool _showLeftIndicator = true;
  bool _showRightIndicator = false;

  // Real AQI history state
  List<AqiTelemetryModel> _apiHistory = [];
  // List<AnalyticsDailyIntervalEntity?> _analyticsDailyIntervalModel = [];
  // ignore: unused_field
  bool _isLoadingHistory = false;
  String? _loadedDeviceSerial;

  @override
  void initState() {
    super.initState();
    final today = DateTime.now();
    _endDate = today;
    _startDate = DateTime(today.year, today.month, today.day)
        .subtract(const Duration(days: 7));
    _activeDay = DateTime(today.year, today.month, today.day);
    _selectedTimelineIndex = null;
    _calendarScrollController = ScrollController();
    _tabController = TabController(length: 7, vsync: this);
    _tabController.addListener(() {
      if (mounted) {
        // setState(() {});
      }
    });
    context.read<SitesBloc>().add(LoadSiteDetails(widget.siteId));

    _currentHeaderMonthYear = _getHeaderString(_startDate, _endDate);

    _calendarScrollController.addListener(() {
      if (_calendarScrollController.hasClients) {
        final maxScroll = _calendarScrollController.position.maxScrollExtent;
        final currentScroll = _calendarScrollController.offset;

        final showLeft = currentScroll < maxScroll - 5;
        final showRight = currentScroll > 5;

        // Calculate month/year of the centered item dynamically
        final today = DateTime.now();
        final double viewportWidth = MediaQuery.of(context).size.width;
        final double centerOffset = currentScroll + (viewportWidth / 2);
        final double padding = 16.w;
        final int centerIndex =
            ((centerOffset - padding - 31.w) / 62.w).round();

        final centerDate =
            today.subtract(Duration(days: centerIndex.clamp(0, 100000)));
        final months = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December'
        ];
        final String newHeader =
            "${months[centerDate.month - 1]} ${centerDate.year}";

        if (showLeft != _showLeftIndicator ||
            showRight != _showRightIndicator ||
            (_startDate.day == _endDate.day &&
                newHeader != _currentHeaderMonthYear)) {
          setState(() {
            _showLeftIndicator = showLeft;
            _showRightIndicator = showRight;
            if (_startDate.day == _endDate.day) {
              _currentHeaderMonthYear = newHeader;
            }
          });
        }
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) {
          _scrollToSelectedDate(animate: false);
        }
      });
    });
  }

  Future<void> _loadHistory(String deviceSerial) async {
    if (deviceSerial.isEmpty) return;

    context.read<AnalyticsBloc>().add(FetchDayWiseEvent(
        imeiNo: deviceSerial,
        fromdate: DateFormat('dd-MM-yyyy').format(_startDate),
        toDate: DateFormat('dd-MM-yyyy').format(_endDate)));
    final mockDeviceIds = {
      '123456',
      'AQI-LOG-8827361524',
      'AQI-HWY-0987654321',
      'AQI-STO-1928374650',
    };
    if (mockDeviceIds.contains(deviceSerial)) {
      return;
    }

    setState(() {
      _isLoadingHistory = true;
    });

    try {
      final repository = getIt<SitesRepository>();
      // final analyticsRepository = getIt<AnalyticsRepository>();

      // final startDay =
      //     DateTime(_startDate.year, _startDate.month, _startDate.day);
      final endDay = DateTime(_endDate.year, _endDate.month, _endDate.day);

      // final int totalDays = endDay.difference(startDay).inDays + 1;
      // Query days in parallel to ensure every day's telemetry is populated
      // context.read<AnalyticsBloc>().add(FetchDayWiseEvent(
      //     imeiNo: widget.siteId,
      //     fromdate: DateFormat('dd-MM-yyyy').format(_startDate),
      //     toDate: DateFormat('dd-MM-yyyy').format(_endDate)));
      final futures = <Future<List<AqiTelemetryModel>>>[];
      // final analyticsfutures = <Future<AnalyticsDailyIntervalEntity?>>[];
      // for (int i = 0; i < totalDays; i++) {
      //   final day = startDay.add(Duration(days: i));
      final dayFrom =
          '${endDay.year}-${endDay.month.toString().padLeft(2, '0')}-${endDay.day.toString().padLeft(2, '0')}T00:00:00';
      final dayTo =
          '${endDay.year}-${endDay.month.toString().padLeft(2, '0')}-${endDay.day.toString().padLeft(2, '0')}T23:59:59';
      //   analyticsfutures.add(analyticsRepository.fetchAQIAnalyticsRepo(
      //       deviceSerial,
      //       DateFormat('dd-MM-yyyy')
      //           .format(DateFormat('yyyy-MM-dd').parseUTC(dayFrom)),
      //       '3'));
      futures.add(repository.getAqiHistoryRange(
        deviceSerial,
        dayFrom,
        dayTo,
        page: 0,
        size:
            500, // Query with size 500 which is guaranteed to succeed (< 1000)
      ));
      // }

      final results = await Future.wait(futures);
      // final analyticsResult = await Future.wait(analyticsfutures);

      // final List<AnalyticsDailyIntervalEntity?> intervalEntity =
      //     analyticsResult;
      final List<AqiTelemetryModel> combinedHistory = [];

      // final List<AnalyticsDailyIntervalEntity?> combinedHistory = [];
      for (final list in results) {
        combinedHistory.addAll(list);
      }

      if (mounted) {
        setState(() {
          _apiHistory = combinedHistory;
          // _analyticsDailyIntervalModel = combinedHistory;
          _isLoadingHistory = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingHistory = false;
        });
      }
      debugPrint('Error loading AQI history range: $e');
    }
  }

  List<AqiTelemetryModel> _getHistoryReadingsForDate(DateTime date) {
    return _apiHistory.where((h) {
      final parsed = _parseTelemetryDateTime(h.date, null);
      if (parsed == null) return false;
      return parsed.year == date.year &&
          parsed.month == date.month &&
          parsed.day == date.day;
    }).toList();
  }

  List<AqiTelemetryModel> _getHistoryReadingsForRange(
      DateTime start, DateTime end) {
    final startDay = DateTime(start.year, start.month, start.day);
    final endDay = DateTime(end.year, end.month, end.day, 23, 59, 59);

    return _apiHistory.where((h) {
      final parsed = _parseTelemetryDateTime(h.date, null);
      if (parsed == null) return false;
      final readingDate = DateTime(parsed.year, parsed.month, parsed.day);
      return !readingDate.isBefore(startDay) && !readingDate.isAfter(endDay);
    }).toList();
  }

  SiteEntity _getHistoricalSiteDataForRange(
      SiteEntity site, DateTime start, DateTime end) {
    final readings = _getHistoryReadingsForRange(start, end);
    if (readings.isEmpty) {
      return site.copyWith(
        aqi: null,
        parameters: {
          'PM2.5': const SensorReading(null, 'µg/m³'),
          'PM10': const SensorReading(null, 'µg/m³'),
          'TSP': const SensorReading(null, 'µg/m³'),
          'Temp': const SensorReading(null, '°C'),
          'Humidity': const SensorReading(null, '%'),
        },
        isDeviceOnline: false,
      );
    }

    DateTime latestTime = start;
    for (final r in readings) {
      final readingDt = _parseTelemetryDateTime(r.date, r.time);
      if (readingDt != null && readingDt.isAfter(latestTime)) {
        latestTime = readingDt;
      }
    }

    int sumAqi = 0;
    double sumPm1 = 0;
    double sumPm25 = 0;
    double sumPm10 = 0;
    double sumTemp = 0;
    double sumHum = 0;
    double sumNoise = 0;
    double sumCo2 = 0;
    double sumCo = 0;

    int countPm1 = 0;
    int countPm25 = 0;
    int countPm10 = 0;
    int countTemp = 0;
    int countHum = 0;
    int countNoise = 0;
    int countCo2 = 0;
    int countCo = 0;
    bool sprinklerActive = false;
    String? aqiCategory;

    int countAqi = 0;
    for (final r in readings) {
      if (r.aqi != null) {
        sumAqi += r.aqi!;
        countAqi++;
      }
      if (r.pm1 != null) {
        sumPm1 += r.pm1!;
        countPm1++;
      }
      if (r.pm25 != null) {
        sumPm25 += r.pm25!;
        countPm25++;
      }
      if (r.pm10 != null) {
        sumPm10 += r.pm10!;
        countPm10++;
      }
      if (r.temperature != null) {
        sumTemp += r.temperature!;
        countTemp++;
      }
      if (r.humidity != null) {
        sumHum += r.humidity!;
        countHum++;
      }
      if (r.noise != null) {
        sumNoise += r.noise!;
        countNoise++;
      }
      if (r.co2 != null) {
        sumCo2 += r.co2!;
        countCo2++;
      }
      if (r.co != null) {
        sumCo += r.co!;
        countCo++;
      }
      if (r.sprinkler != null && r.sprinkler != 0) {
        sprinklerActive = true;
      }
      aqiCategory ??= r.aqiCategory;
    }

    final int? avgAqi = countAqi > 0 ? (sumAqi ~/ countAqi) : null;
    final Map<String, SensorReading> historicalParams = {
      'PM2.5': SensorReading(
          countPm25 > 0
              ? double.parse((sumPm25 / countPm25).toStringAsFixed(1))
              : null,
          'µg/m³'),
      'PM10': SensorReading(
          countPm10 > 0
              ? double.parse((sumPm10 / countPm10).toStringAsFixed(1))
              : null,
          'µg/m³'),
      'TSP': SensorReading(
          countPm10 > 0
              ? double.parse(((sumPm10 / countPm10) * 1.3).toStringAsFixed(1))
              : null,
          'µg/m³'),
      'Temp': SensorReading(
          countTemp > 0
              ? double.parse((sumTemp / countTemp).toStringAsFixed(1))
              : null,
          '°C'),
      'Humidity': SensorReading(
          countHum > 0
              ? double.parse((sumHum / countHum).toStringAsFixed(1))
              : null,
          '%'),
      'PM1': SensorReading(
          countPm1 > 0
              ? double.parse((sumPm1 / countPm1).toStringAsFixed(1))
              : null,
          'µg/m³'),
      'Noise': SensorReading(
          countNoise > 0
              ? double.parse((sumNoise / countNoise).toStringAsFixed(1))
              : null,
          'dB'),
      'CO₂': SensorReading(
          countCo2 > 0
              ? double.parse((sumCo2 / countCo2).toStringAsFixed(1))
              : null,
          'ppm'),
      'CO': SensorReading(
          countCo > 0
              ? double.parse((sumCo / countCo).toStringAsFixed(2))
              : null,
          'mg/m³'),
    };

    return site.copyWith(
      aqi: avgAqi,
      parameters: historicalParams,
      isDeviceOnline: true,
      isSprinklerRunning: sprinklerActive,
      lastSyncTime: latestTime,
    );
  }

  String _getHeaderString(DateTime start, DateTime end) {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    final startDay = DateTime(start.year, start.month, start.day);
    final endDay = DateTime(end.year, end.month, end.day);
    if (startDay == endDay) {
      return "${months[startDay.month - 1]} ${startDay.year}";
    }
    final startAbbr = months[startDay.month - 1].substring(0, 3);
    final endAbbr = months[endDay.month - 1].substring(0, 3);
    if (startDay.year == endDay.year) {
      return "${startDay.day} $startAbbr - ${endDay.day} $endAbbr, ${startDay.year}";
    }
    return "${startDay.day} $startAbbr ${startDay.year} - ${endDay.day} $endAbbr ${endDay.year}";
  }

  void _onRangeSelected(DateTime start, DateTime end) {
    setState(() {
      _startDate = DateTime(start.year, start.month, start.day);
      _endDate = DateTime(end.year, end.month, end.day, 23, 59, 59);
      _activeDay = DateTime(end.year, end.month, end.day);
      _selectedTimelineIndex = null;
      _currentHeaderMonthYear = _getHeaderString(_startDate, _endDate);
    });

    if (_loadedDeviceSerial != null && _loadedDeviceSerial!.isNotEmpty) {
      _loadHistory(_loadedDeviceSerial!);
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToSelectedDate();
    });
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _activeDay = DateTime(date.year, date.month, date.day);
      _selectedTimelineIndex = null;
    });
  }

  AqiHistoryDay _getRealHistoryDayForDate(SiteEntity site, DateTime date) {
    final readings = _getHistoryReadingsForDate(date);
    if (readings.isEmpty) {
      return _getHistoryDayForDate(site, date);
    }

    int sum = 0;
    int minVal = 999;
    int minHour = 0;
    int maxVal = -1;
    int maxHour = 0;

    final List<int> intervals = List.filled(8, 0);
    final List<int> intervalCounts = List.filled(8, 0);

    for (final r in readings) {
      final aqi = r.aqi ?? 0;
      sum += aqi;
      if (aqi < minVal) {
        minVal = aqi;
        final hour = int.tryParse(r.time?.split(':')[0] ?? '') ?? 0;
        minHour = hour;
      }
      if (aqi > maxVal) {
        maxVal = aqi;
        final hour = int.tryParse(r.time?.split(':')[0] ?? '') ?? 0;
        maxHour = hour;
      }

      final hour = int.tryParse(r.time?.split(':')[0] ?? '') ?? 0;
      final intervalIndex = (hour ~/ 3).clamp(0, 7);
      intervals[intervalIndex] += aqi;
      intervalCounts[intervalIndex]++;
    }

    for (int i = 0; i < 8; i++) {
      if (intervalCounts[i] > 0) {
        intervals[i] = intervals[i] ~/ intervalCounts[i];
      } else {
        intervals[i] = 0;
      }
    }

    final average = readings.isNotEmpty ? (sum ~/ readings.length) : 0;
    if (minVal == 999) minVal = 0;
    if (maxVal == -1) maxVal = 0;

    return AqiHistoryDay(
      date: date,
      averageAqi: average,
      intervals: intervals,
      minAqi: minVal,
      minAqiHour: minHour,
      maxAqi: maxVal,
      maxAqiHour: maxHour,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    _calendarScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: BlocBuilder<SitesBloc, SitesState>(
          builder: (context, state) {
            if (state is SiteDetailsLoaded) {
              return Text(state.site.name);
            }
            return const Text('Device Details');
          },
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => context.pop(),
        ),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white.withValues(alpha: 0.6),
          indicatorColor: Colors.white,
          tabAlignment: TabAlignment.start,
          tabs: const [
            Tab(text: 'Live'),
            Tab(text: 'Calibration'),
            Tab(text: 'Trends'),
            Tab(text: 'Parameters'),
            Tab(text: 'Device'),
            Tab(text: 'Alerts'),
            //    Tab(text: 'Reports'),
            Tab(text: 'Maintenance'),
          ],
        ),
      ),
      body: SafeArea(
        child: BlocListener<SprinklerBloc, SprinklerState>(
          listener: (context, state) {
            if (state is SprinklerActionSuccess &&
                state.site.id == widget.siteId) {
              // Refresh site details
              context.read<SitesBloc>().add(LoadSiteDetails(widget.siteId));

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Row(
                    children: [
                      Icon(
                        state.site.isSprinklerRunning
                            ? Icons.water_drop_rounded
                            : Icons.stop_circle_rounded,
                        color: Colors.white,
                        size: 20.r,
                      ),
                      SizedBox(width: 8.w),
                      Text(state.site.isSprinklerRunning
                          ? 'Sprinkler triggered successfully'
                          : 'Sprinkler stopped successfully'),
                    ],
                  ),
                  backgroundColor: state.site.isSprinklerRunning
                      ? const Color(0xFF0284C7)
                      : const Color(0xFF64748B),
                  behavior: SnackBarBehavior.floating,
                  duration: const Duration(seconds: 2),
                ),
              );
            } else if (state is SprinklerError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.message),
                  backgroundColor: AppColors.aqiRed,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }
          },
          child: BlocBuilder<SitesBloc, SitesState>(
            builder: (context, state) {
              if (state is SitesLoading) {
                return const Center(
                    child: CircularProgressIndicator(color: AppColors.primary));
              }
              if (state is SitesError) {
                return ErrorDisplayWidget(
                  message: state.message,
                  onRetry: () {
                    context
                        .read<SitesBloc>()
                        .add(LoadSiteDetails(widget.siteId));
                  },
                );
              }
              if (state is SiteDetailsLoaded) {
                final site = state.site;
                log("sprinkler status ${site.isSprinklerRunning}");
                final serialToLoad =
                    site.imeiNo.isNotEmpty ? site.imeiNo : site.deviceSerial;
                if (_loadedDeviceSerial != serialToLoad) {
                  _loadedDeviceSerial = serialToLoad;
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _loadHistory(serialToLoad);
                  });
                }

                final today = DateTime.now();
                final SiteEntity displaySite;
                if (_activeDay != null) {
                  final bool isActiveDayToday =
                      _activeDay!.year == today.year &&
                          _activeDay!.month == today.month &&
                          _activeDay!.day == today.day;
                  if (isActiveDayToday) {
                    final hist = _getHistoricalSiteData(site, _activeDay!);
                    displaySite = site.copyWith(
                      aqi: site.aqi ?? hist.aqi,
                      parameters: site.parameters.isNotEmpty
                          ? site.parameters
                          : hist.parameters,
                    );
                  } else {
                    displaySite = _getHistoricalSiteData(site, _activeDay!);
                  }
                } else {
                  final bool isSelectedToday = _startDate.year == today.year &&
                      _startDate.month == today.month &&
                      _startDate.day == today.day &&
                      _endDate.year == today.year &&
                      _endDate.month == today.month &&
                      _endDate.day == today.day;
                  if (isSelectedToday) {
                    final hist = _getHistoricalSiteData(site, today);
                    displaySite = site.copyWith(
                      aqi: site.aqi ?? hist.aqi,
                      parameters: site.parameters.isNotEmpty
                          ? site.parameters
                          : hist.parameters,
                    );
                  } else {
                    displaySite = _getHistoricalSiteDataForRange(
                        site, _startDate, _endDate);
                  }
                }
                final sprinklerState = context.watch<SprinklerBloc>().state;
                final isSprinklerRunning =
                    (sprinklerState is SprinklerActionSuccess &&
                            sprinklerState.site.id == site.id)
                        ? sprinklerState.site.isSprinklerRunning
                        : site.isSprinklerRunning;

                return Stack(
                  children: [
                    TabBarView(
                      controller: _tabController,
                      children: [
                        BlocBuilder<AnalyticsBloc, AnalyticsState>(
                          builder: (context, analyticsState) {
                            return _buildLiveTab(
                                context,
                                site,
                                analyticsState.dayWiseStatus ==
                                        AnalyticsDayWiseStatus.success
                                    ? analyticsState.analyticsDayWise!
                                    : []);
                          },
                        ),
                        _buildCalibrationTab(site),
                        // _buildTrendsTab(site),
                        TrendTabPage(site: site),
                        _buildParametersTab(displaySite),
                        _buildDeviceTab(site),
                        _buildAlertsTab(site),
                        //hide this for now
                        //    _buildReportsTab(site),

                        _buildMaintenanceTab(site),
                      ],
                    ),
                    if (_tabController.index == 0)
                      SprinklerEffect(isRunning: isSprinklerRunning),
                  ],
                );
              }
              return const Center(child: Text('Could not load site details.'));
            },
          ),
        ),
      ),
    );
  }

  Widget _buildLiveTab(BuildContext context, SiteEntity site,
      List<AnalyticsDayWiseEntity> dailySummary) {
    final colors = AppColors.of(context);
    final today = DateTime.now();
    final bool isSelectedToday = _activeDay == null &&
        _startDate.year == today.year &&
        _startDate.month == today.month &&
        _startDate.day == today.day &&
        _endDate.year == today.year &&
        _endDate.month == today.month &&
        _endDate.day == today.day;

    final SiteEntity displaySite;
    if (_activeDay != null) {
      final bool isActiveDayToday = _activeDay!.year == today.year &&
          _activeDay!.month == today.month &&
          _activeDay!.day == today.day;
      if (isActiveDayToday) {
        final hist = _getHistoricalSiteData(site, _activeDay!);
        displaySite = site.copyWith(
          aqi: site.aqi ?? hist.aqi,
          parameters:
              site.parameters.isNotEmpty ? site.parameters : hist.parameters,
        );
      } else {
        displaySite = _getHistoricalSiteData(site, _activeDay!);
      }
    } else {
      if (isSelectedToday) {
        final hist = _getHistoricalSiteData(site, today);
        displaySite = site.copyWith(
          aqi: site.aqi ?? hist.aqi,
          parameters:
              site.parameters.isNotEmpty ? site.parameters : hist.parameters,
        );
      } else {
        displaySite =
            _getHistoricalSiteDataForRange(site, _startDate, _endDate);
      }
    }

    final realReadings = _activeDay != null
        ? _getHistoryReadingsForDate(_activeDay!)
        : _getHistoryReadingsForRange(_startDate, _endDate);

    return SingleChildScrollView(
      padding: EdgeInsets.all(16.r),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Commented the date selector
          // _buildHorizontalCalendar(site, dailySummary),
          /*
            if (_isLoadingHistory)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: LinearProgressIndicator(
                color: AppColors.primary,
                minHeight: 2,
              ),
            ),
             */
          SizedBox(height: 10.h),
          AqiGauge(
            site: displaySite,
            showDeviceAndSprinkler: isSelectedToday,
          ),
          SizedBox(height: 24.h),
          // Sorted Readings chronologically for linear chart visualization
          () {
            final sortedReadings = List<AqiTelemetryModel>.from(realReadings);
            sortedReadings.sort((a, b) {
              final aDt =
                  _parseTelemetryDateTime(a.date, a.time) ?? DateTime(2000);
              final bDt =
                  _parseTelemetryDateTime(b.date, b.time) ?? DateTime(2000);
              return aDt.compareTo(bDt);
            });

            if (sortedReadings.isEmpty) {
              return Container(
                width: double.infinity,
                padding: EdgeInsets.all(20.r),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(16.r),
                  border: Border.all(color: colors.border),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.analytics_outlined,
                      size: 40.r,
                      color: colors.textSecondary.withValues(alpha: 0.5),
                    ),
                    SizedBox(height: 12.h),
                    Text(
                      'No Timeline Data Available',
                      style: TextStyle(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.bold,
                        color: colors.textPrimary,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      'Select another date range or check back later.',
                      style: TextStyle(
                        fontSize: 10.sp,
                        color: colors.textSecondary,
                      ),
                    ),
                  ],
                ),
              );
            }

            final List<FlSpot> spots = [];
            for (int i = 0; i < sortedReadings.length; i++) {
              spots.add(FlSpot(
                  i.toDouble(), (sortedReadings[i].aqi ?? 0).toDouble()));
            }

            final int selectedIndex = _selectedTimelineIndex != null &&
                    _selectedTimelineIndex! < sortedReadings.length
                ? _selectedTimelineIndex!
                : sortedReadings.length - 1;

            final activeReading = sortedReadings[selectedIndex];

            // Determine dynamic title interval safely
            final double bottomInterval = sortedReadings.length > 1
                ? (sortedReadings.length / 4).clamp(1.0, double.infinity)
                : 1.0;

            final double maxValX = sortedReadings.length > 1
                ? (sortedReadings.length - 1).toDouble()
                : 1.0;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16.r),
                  decoration: BoxDecoration(
                    color: colors.surface,
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: colors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'AIR QUALITY TIMELINE',
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w800,
                              color: colors.textPrimary,
                              letterSpacing: 0.5,
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.w, vertical: 3.h),
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(20.r),
                              border: Border.all(
                                  color:
                                      AppColors.primary.withValues(alpha: 0.3)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 6.r,
                                  height: 6.r,
                                  decoration: const BoxDecoration(
                                    color: AppColors.primary,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                SizedBox(width: 4.w),
                                Text(
                                  'Continuous Stream',
                                  style: TextStyle(
                                    fontSize: 8.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 16.h),
                      SizedBox(
                        height: 160.h,
                        child: LineChart(
                          LineChartData(
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: true,
                              horizontalInterval: 100,
                              verticalInterval: bottomInterval,
                              getDrawingHorizontalLine: (value) => FlLine(
                                color: colors.border.withValues(alpha: 0.4),
                                strokeWidth: 1,
                                dashArray: [4, 4],
                              ),
                              getDrawingVerticalLine: (value) => FlLine(
                                color: colors.border.withValues(alpha: 0.4),
                                strokeWidth: 1,
                                dashArray: [4, 4],
                              ),
                            ),
                            titlesData: FlTitlesData(
                              show: true,
                              rightTitles: const AxisTitles(
                                  sideTitles: SideTitles(showTitles: false)),
                              topTitles: const AxisTitles(
                                  sideTitles: SideTitles(showTitles: false)),
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 22,
                                  interval: bottomInterval,
                                  getTitlesWidget: (value, meta) {
                                    final int idx = value.toInt();
                                    if (idx >= 0 &&
                                        idx < sortedReadings.length) {
                                      final r = sortedReadings[idx];
                                      final timeStr =
                                          r.time?.substring(0, 5) ?? '';
                                      return SideTitleWidget(
                                        meta: meta,
                                        space: 4.h,
                                        child: Text(
                                          timeStr,
                                          style: TextStyle(
                                            fontSize: 8.sp,
                                            color: colors.textSecondary,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      );
                                    }
                                    return const SizedBox.shrink();
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 30,
                                  interval: 100,
                                  getTitlesWidget: (value, meta) {
                                    if (value % 100 == 0) {
                                      return SideTitleWidget(
                                        meta: meta,
                                        space: 4.w,
                                        child: Text(
                                          value.toInt().toString(),
                                          style: TextStyle(
                                            fontSize: 8.sp,
                                            color: colors.textSecondary,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      );
                                    }
                                    return const SizedBox.shrink();
                                  },
                                ),
                              ),
                            ),
                            borderData: FlBorderData(show: false),
                            minX: 0,
                            maxX: maxValX,
                            minY: 0,
                            maxY: 400.0,
                            lineTouchData: LineTouchData(
                              touchCallback: (FlTouchEvent event,
                                  LineTouchResponse? touchResponse) {
                                if (touchResponse != null &&
                                    touchResponse.lineBarSpots != null &&
                                    touchResponse.lineBarSpots!.isNotEmpty) {
                                  final int touchedIndex = touchResponse
                                      .lineBarSpots!.first.spotIndex;
                                  if (touchedIndex >= 0 &&
                                      touchedIndex < sortedReadings.length) {
                                    setState(() {
                                      _selectedTimelineIndex = touchedIndex;
                                    });
                                  }
                                }
                              },
                              handleBuiltInTouches: true,
                              touchTooltipData: LineTouchTooltipData(
                                getTooltipColor: (touchedSpot) => const Color(0xFF0F172A),
                                tooltipRoundedRadius: 8.r,
                                getTooltipItems: (touchedSpots) {
                                  return touchedSpots.map((touchedSpot) {
                                    return LineTooltipItem(
                                      'AQI: ${touchedSpot.y.toInt()}',
                                      TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 9.sp,
                                      ),
                                    );
                                  }).toList();
                                },
                              ),
                            ),
                            lineBarsData: [
                              LineChartBarData(
                                spots: spots,
                                isCurved: true,
                                barWidth: 2,
                                color: AppColors.primary,
                                belowBarData: BarAreaData(
                                  show: true,
                                  gradient: LinearGradient(
                                    colors: [
                                      AppColors.primary.withValues(alpha: 0.2),
                                      AppColors.primary.withValues(alpha: 0.0),
                                    ],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ),
                                ),
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    final bool isSpotSelected =
                                        index == selectedIndex;
                                    return FlDotCirclePainter(
                                      radius: isSpotSelected ? 5.r : 1.5.r,
                                      color: isSpotSelected
                                          ? Colors.white
                                          : AppColors.primary,
                                      strokeWidth: isSpotSelected ? 2.5.r : 0,
                                      strokeColor: AppColors.primary,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 8.h),
                      Center(
                        child: Text(
                          'Tap on the timeline points to inspect detailed telemetry',
                          style: TextStyle(
                            fontSize: 8.5.sp,
                            color: colors.textSecondary.withValues(alpha: 0.8),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 16.h),
                // Premium Tooltip Box matching light styling
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: colors.surface,
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: colors.border),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.04),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  padding: EdgeInsets.all(16.r),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Row with Time Dropdown and Stepper Arrows
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Row(
                              children: [
                                Icon(
                                  Icons.access_time_filled_rounded,
                                  size: 14.r,
                                  color: colors.textSecondary,
                                ),
                                SizedBox(width: 4.w),
                                // Dropdown selection of timeline points
                                DropdownButtonHideUnderline(
                                  child: DropdownButton<int>(
                                    value: selectedIndex,
                                    icon: Icon(
                                      Icons.arrow_drop_down_rounded,
                                      color: colors.textSecondary,
                                    ),
                                    dropdownColor: colors.surface,
                                    isDense: true,
                                    items: List.generate(sortedReadings.length,
                                        (idx) {
                                      final r = sortedReadings[idx];
                                      final displayTime =
                                          r.time ?? 'Point ${idx + 1}';
                                      return DropdownMenuItem<int>(
                                        value: idx,
                                        child: Text(
                                          displayTime,
                                          style: TextStyle(
                                            fontSize: 12.5.sp,
                                            fontWeight: FontWeight.bold,
                                            color: colors.textPrimary,
                                          ),
                                        ),
                                      );
                                    }),
                                    onChanged: (newVal) {
                                      if (newVal != null) {
                                        setState(() {
                                          _selectedTimelineIndex = newVal;
                                        });
                                      }
                                    },
                                  ),
                                ),
                                SizedBox(width: 4.w),
                                // Prev/Next stepper buttons
                                IconButton(
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(),
                                  icon: Icon(
                                    Icons.chevron_left_rounded,
                                    size: 20.r,
                                    color: selectedIndex > 0
                                        ? AppColors.primary
                                        : AppColors.textSecondary
                                            .withValues(alpha: 0.3),
                                  ),
                                  onPressed: selectedIndex > 0
                                      ? () => setState(() {
                                            _selectedTimelineIndex =
                                                selectedIndex - 1;
                                          })
                                      : null,
                                ),
                                IconButton(
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(),
                                  icon: Icon(
                                    Icons.chevron_right_rounded,
                                    size: 20.r,
                                    color: selectedIndex <
                                            sortedReadings.length - 1
                                        ? AppColors.primary
                                        : AppColors.textSecondary
                                            .withValues(alpha: 0.3),
                                  ),
                                  onPressed:
                                      selectedIndex < sortedReadings.length - 1
                                          ? () => setState(() {
                                                _selectedTimelineIndex =
                                                    selectedIndex + 1;
                                              })
                                          : null,
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.w, vertical: 4.h),
                            decoration: BoxDecoration(
                              color: AppColors.getAqiColor(activeReading.aqi),
                              borderRadius: BorderRadius.circular(6.r),
                            ),
                            child: Text(
                              'AQI: ${activeReading.aqi ?? "-"}',
                              style: TextStyle(
                                fontSize: 10.sp,
                                fontWeight: FontWeight.w800,
                                color: _getContrastColor(
                                    AppColors.getAqiColor(activeReading.aqi)),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12.h),

                      // PM Values grid
                      Row(
                        children: [
                          Expanded(
                            child: _buildLightParamBox(
                                'PM 1.0', activeReading.pm1, 'µg/m³'),
                          ),
                          SizedBox(width: 8.w),
                          Expanded(
                            child: _buildLightParamBox(
                                'PM 2.5', activeReading.pm25, 'µg/m³'),
                          ),
                          SizedBox(width: 8.w),
                          Expanded(
                            child: _buildLightParamBox(
                                'PM 10', activeReading.pm10, 'µg/m³'),
                          ),
                        ],
                      ),
                      SizedBox(height: 14.h),

                      // Temperature & Humidity Row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.thermostat_rounded,
                                size: 13.r,
                                color: colors.textSecondary,
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                'Temperature:',
                                style: TextStyle(
                                  fontSize: 10.5.sp,
                                  color: colors.textSecondary,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                activeReading.temperature != null
                                    ? '${activeReading.temperature}°C'
                                    : 'N/A',
                                style: TextStyle(
                                  fontSize: 10.5.sp,
                                  fontWeight: FontWeight.bold,
                                  color: colors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.water_drop_rounded,
                                size: 13.r,
                                color: colors.textSecondary,
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                'Humidity:',
                                style: TextStyle(
                                  fontSize: 10.5.sp,
                                  color: colors.textSecondary,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                activeReading.humidity != null
                                    ? '${activeReading.humidity}%'
                                    : 'N/A',
                                style: TextStyle(
                                  fontSize: 10.5.sp,
                                  fontWeight: FontWeight.bold,
                                  color: colors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 8.h),

                      // Sprinkler Relay Row
                      Row(
                        children: [
                          Icon(
                            Icons.shower_rounded,
                            size: 13.r,
                            color: colors.textSecondary,
                          ),
                          SizedBox(width: 4.w),
                          Text(
                            'SPRINKLER RELAY:',
                            style: TextStyle(
                              fontSize: 10.5.sp,
                              color: colors.textSecondary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 6.w),
                          Text(
                            activeReading.sprinkler != null &&
                                    activeReading.sprinkler != 0
                                ? 'ACTIVE'
                                : 'N/A',
                            style: TextStyle(
                              fontSize: 10.5.sp,
                              fontWeight: FontWeight.w900,
                              color: activeReading.sprinkler != null &&
                                      activeReading.sprinkler != 0
                                  ? AppColors.online
                                  : colors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            );
          }(),
        ],
      ),
    );
  }

  // --- Tab 2: Detailed Parameters Grid ---
  Widget _buildParametersTab(SiteEntity site) {
    final colors = AppColors.of(context);
    return ListView.builder(
      padding: EdgeInsets.all(16.r),
      itemCount: site.parameters.length,
      itemBuilder: (context, index) {
        final key = site.parameters.keys.elementAt(index);
        final reading = site.parameters[key]!;

        // Dynamic color indication
        Color color = AppColors.online;
        if (key == 'PM2.5' || key == 'PM10' || key == 'TSP') {
          color = AppColors.getAqiColor(reading.value?.toInt() ?? 0);
        }

        return Container(
          margin: EdgeInsets.only(bottom: 12.h),
          child: ScadaCard(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      width: 4.w,
                      height: 32.h,
                      decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(2.r)),
                    ),
                    SizedBox(width: 16.w),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(key,
                            style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.bold,
                                color: colors.textPrimary)),
                        Text('Sensor Node Reading',
                            style: TextStyle(
                                fontSize: 11.sp, color: colors.textMuted)),
                      ],
                    ),
                  ],
                ),
                Text(
                  '${reading.value != null ? reading.value!.toStringAsFixed(2) : "-"} ${reading.unit}',
                  style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: colors.textPrimary),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- Tab 3: Trends Charts ---
  Widget _buildTrendsTab(SiteEntity site) {
    final selectedDay = _getRealHistoryDayForDate(site, _activeDay ?? _endDate);
    final int daysInRange = _endDate.difference(_startDate).inDays + 1;
    final int chartDays = daysInRange.clamp(1, 30);
    final history = List.generate(chartDays, (index) {
      final date = _endDate.subtract(Duration(days: index));
      return _getRealHistoryDayForDate(site, date);
    });

    return SingleChildScrollView(
      padding: EdgeInsets.all(16.r),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Same calendar section as Live tab
          _buildHorizontalCalendar(site, []),
          SizedBox(height: 24.h),

          // SELECTED DAY: 3-HOUR INTERVAL DETAIL
          Text(
            'SELECTED DAY: 3-HOUR INTERVAL DETAIL',
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF64748B),
              letterSpacing: 1.2,
            ),
          ),
          SizedBox(height: 10.h),

          // Detail card
          _build3HourDetailCard(selectedDay),
          SizedBox(height: 24.h),

          // 8-DAY CALCULATED CONTINUOUS TREND
          Text(
            '8-DAY CALCULATED CONTINUOUS TREND',
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF64748B),
              letterSpacing: 1.2,
            ),
          ),
          SizedBox(height: 10.h),

          // Continuous trend card
          _build8DayTrendCard(history),
          SizedBox(height: 24.h),
        ],
      ),
    );
  }

  Widget _build3HourDetailCard(AqiHistoryDay selectedDay) {
    final colors = AppColors.of(context);
    final minColor = AppColors.getAqiColor(selectedDay.minAqi);
    final maxColor = AppColors.getAqiColor(selectedDay.maxAqi);
    final minTime = "${selectedDay.minAqiHour.toString().padLeft(2, '0')}:00";
    final maxTime = "${selectedDay.maxAqiHour.toString().padLeft(2, '0')}:00";

    double maxVal = selectedDay.intervals
        .map((v) => v.toDouble())
        .reduce((a, b) => a > b ? a : b);
    double chartMaxY = (maxVal * 1.2).clamp(120.0, 500.0);

    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: colors.surface, // Light background
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: colors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.textSecondary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Min / Max indicators row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Min AQI Box
              Row(
                children: [
                  Container(
                    width: 38.r,
                    height: 38.r,
                    decoration: BoxDecoration(
                      color: minColor,
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Center(
                      child: Text(
                        '${selectedDay.minAqi}',
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: _getContrastColor(minColor),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '↓ Min AQI',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: minColor,
                        ),
                      ),
                      Text(
                        '@$minTime',
                        style: TextStyle(
                          fontSize: 10.sp,
                          color: AppColors
                              .textSecondary, // Dark/grey text for light theme
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              // Max AQI Box
              Row(
                children: [
                  Container(
                    width: 38.r,
                    height: 38.r,
                    decoration: BoxDecoration(
                      color: maxColor,
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Center(
                      child: Text(
                        '${selectedDay.maxAqi}',
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: _getContrastColor(maxColor),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '↑ Max AQI',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: maxColor,
                        ),
                      ),
                      Text(
                        '@$maxTime',
                        style: TextStyle(
                          fontSize: 10.sp,
                          color: AppColors
                              .textSecondary, // Dark/grey text for light theme
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: 24.h),

          // 3-Hour Interval Bar Chart
          SizedBox(
            height: 180.h,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: chartMaxY,
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  show: true,
                  topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.w,
                      interval: (chartMaxY / 4).roundToDouble().clamp(10, 100),
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 9.sp), // Dark text
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.h,
                      getTitlesWidget: (value, meta) {
                        const times = [
                          '00:00',
                          '03:00',
                          '06:00',
                          '09:00',
                          '12:00',
                          '15:00',
                          '18:00',
                          '21:00'
                        ];
                        if (value >= 0 && value < times.length) {
                          return SideTitleWidget(
                            meta: meta,
                            space: 6.h,
                            child: Text(
                              times[value.toInt()],
                              style: TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 9.sp), // Dark text
                            ),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                ),
                barGroups: _build3HourBarGroups(selectedDay),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _build8DayTrendCard(List<AqiHistoryDay> history) {
    final colors = AppColors.of(context);
    double maxAvg = history
        .map((h) => h.averageAqi.toDouble())
        .reduce((a, b) => a > b ? a : b);
    double chartMaxY = (maxAvg * 1.2).clamp(100.0, 500.0);

    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: colors.surface, // Light background
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: colors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.textSecondary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          SizedBox(
            height: 180.h,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: chartMaxY,
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  show: true,
                  topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.w,
                      interval: (chartMaxY / 4).roundToDouble().clamp(10, 100),
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 9.sp), // Dark text
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28.h,
                      getTitlesWidget: (value, meta) {
                        if (value >= 0 && value < history.length) {
                          final day = history[value.toInt()];
                          final dayStr =
                              "${day.date.day} ${_getMonthAbbr(day.date.month)}";
                          return SideTitleWidget(
                            meta: meta,
                            space: 6.h,
                            child: Text(
                              dayStr,
                              style: TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 9.sp), // Dark text
                            ),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                ),
                barGroups: _build8DayBarGroups(history),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<BarChartGroupData> _build3HourBarGroups(AqiHistoryDay selectedDay) {
    return List.generate(selectedDay.intervals.length, (index) {
      final val = selectedDay.intervals[index];
      final color = AppColors.getAqiColor(val);
      return BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
            toY: val.toDouble(),
            color: color,
            width: 14.w,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(4.r),
              topRight: Radius.circular(4.r),
            ),
          ),
        ],
      );
    });
  }

  List<BarChartGroupData> _build8DayBarGroups(List<AqiHistoryDay> history) {
    return List.generate(history.length, (index) {
      final val = history[index].averageAqi;
      final color = val == 0
          ? AppColors.border.withValues(alpha: 0.5)
          : AppColors.getAqiColor(val);
      return BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
            toY: val.toDouble(),
            color: color,
            width: 14.w,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(4.r),
              topRight: Radius.circular(4.r),
            ),
          ),
        ],
      );
    });
  }

  AqiHistoryDay _getHistoryDayForDate(SiteEntity site, DateTime date) {
    return AqiHistoryDay(
      date: date,
      averageAqi: 0,
      intervals: List.filled(8, 0),
      minAqi: 0,
      minAqiHour: 0,
      maxAqi: 0,
      maxAqiHour: 0,
    );
  }

  String _getMonthAbbr(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }

  Color _getContrastColor(Color color) {
    final double yiq = (((color.r * 255.0) * 299) +
            ((color.g * 255.0) * 587) +
            ((color.b * 255.0) * 114)) /
        1000;
    return yiq >= 128 ? const Color(0xFF0F172A) : Colors.white;
  }

  // --- Tab 4: Alerts Timeline ---
  Widget _buildAlertsTab(SiteEntity site) {
    final alerts = [
      {
        'title': 'PM2.5 Limit Exceeded',
        'desc': 'PM2.5 reading reached 219 ug/m3, triggering compliance alert.',
        'time': '10:30 AM',
        'type': 'Critical'
      },
      {
        'title': 'Sprinkler Activated',
        'desc': 'Automated dust suppression system triggered for PM10 control.',
        'time': '09:00 AM',
        'type': 'Info'
      },
      {
        'title': 'Sync Interval Warning',
        'desc': 'Sensor calibration delay exceeded nominal window.',
        'time': 'Yesterday',
        'type': 'Warning'
      },
    ];

    return ListView.builder(
      padding: EdgeInsets.all(16.r),
      itemCount: alerts.length,
      itemBuilder: (context, index) {
        final alert = alerts[index];
        final type = alert['type']!;

        Color indicatorColor = AppColors.online;
        if (type == 'Critical') indicatorColor = AppColors.aqiRed;
        if (type == 'Warning') indicatorColor = AppColors.aqiOrange;

        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              children: [
                Container(
                  width: 12.r,
                  height: 12.r,
                  decoration: BoxDecoration(
                      color: indicatorColor, shape: BoxShape.circle),
                ),
                if (index < alerts.length - 1)
                  Container(
                    width: 2.w,
                    height: 80.h,
                    color: AppColors.border,
                  ),
              ],
            ),
            SizedBox(width: 16.w),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(bottom: 20.h),
                child: ScadaCard(
                  padding: EdgeInsets.all(16.r),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(alert['title']!,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13.sp,
                                  color: AppColors.textPrimary)),
                          Text(alert['time']!,
                              style: TextStyle(
                                  fontSize: 10.sp, color: AppColors.textMuted)),
                        ],
                      ),
                      SizedBox(height: 6.h),
                      Text(alert['desc']!,
                          style: TextStyle(
                              fontSize: 12.sp,
                              color: AppColors.textSecondary,
                              height: 1.4)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatDate(DateTime dateTime) {
    return "${dateTime.day.toString().padLeft(2, '0')}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.year}";
  }

  // --- Tab 6: Device Diagnostic Settings ---
  Widget _buildDeviceTab(SiteEntity site) {
    final authState = context.read<AuthBloc>().state;
    final bool isAdmin =
        authState is AuthAuthenticated && authState.user.role == UserRole.admin;

    return ListView(
      padding: EdgeInsets.all(16.r),
      children: [
        ScadaCard(
          padding: EdgeInsets.all(16.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Device Configuration',
                      style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary)),
                  if (isAdmin)
                    IconButton(
                      icon: const Icon(Icons.edit_rounded,
                          color: AppColors.primary),
                      onPressed: () => _showEditDeviceDialog(context, site),
                    ),
                ],
              ),
              SizedBox(height: 16.h),
              _buildDetailRow('Device Model', 'VASUNDHARA Maha AQI System'),
              _buildDetailRow('Serial Number', site.deviceSerial),
              _buildDetailRow('Firmware Version', site.firmwareVersion),
              _buildDetailRow('Installation Date',
                  _formatDate(site.displayInstallationDate)),
              _buildDetailRow('Previous Calibration',
                  _formatDate(site.displayLastCalibrationDate)),
              _buildDetailRow('Next Calibration Due',
                  _formatDate(site.displayNextCalibrationDate)),
              _buildDetailRow('Last Synchronized',
                  site.lastSyncTime.toLocal().toString().split('.')[0]),
            ],
          ),
        ),
        SizedBox(height: 16.h),
        ScadaCard(
          padding: EdgeInsets.all(16.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Hardware Connectivity Diagnostics',
                  style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary)),
              SizedBox(height: 16.h),
              _buildDiagnosticRow(
                  '4G Telemetry Connection', site.is4gConnected),
              _buildDiagnosticRow('GPS Tracking Signal', site.isGpsConnected),
              _buildDiagnosticRow(
                  'Sensor Grid Calibration status', site.isDeviceOnline),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            child: Text(label,
                style:
                    TextStyle(fontSize: 12.sp, color: AppColors.textSecondary)),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(value,
                textAlign: TextAlign.right,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary)),
          ),
        ],
      ),
    );
  }

  Widget _buildDiagnosticRow(String label, bool isOk) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Text(label,
                style:
                    TextStyle(fontSize: 12.sp, color: AppColors.textSecondary)),
          ),
          SizedBox(width: 8.w),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(isOk ? 'OK' : 'FAIL',
                  style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: isOk ? AppColors.online : AppColors.aqiRed)),
              SizedBox(width: 8.w),
              Icon(
                isOk ? Icons.check_circle_rounded : Icons.cancel_rounded,
                size: 16.r,
                color: isOk ? AppColors.online : AppColors.aqiRed,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Tab 7: Maintenance Logs ---
  Widget _buildMaintenanceTab(SiteEntity site) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: ListView.builder(
        padding: EdgeInsets.all(16.r),
        itemCount: site.maintenanceHistory.length + 1,
        itemBuilder: (context, index) {
          if (index == site.maintenanceHistory.length) {
            return Container(
              margin: EdgeInsets.only(top: 24.h, bottom: 40.h),
              child: PrimaryButton(
                text: 'Record New Service Remark',
                icon: Icons.build_rounded,
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Opening service form...')),
                  );
                },
              ),
            );
          }
          final log = site.maintenanceHistory[index];
          return Container(
            margin: EdgeInsets.only(bottom: 12.h),
            child: ScadaCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(log.serviceType,
                          style: TextStyle(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textPrimary)),
                      Text(
                        '${log.date.day}/${log.date.month}/${log.date.year}',
                        style: TextStyle(
                            fontSize: 11.sp, color: AppColors.textMuted),
                      ),
                    ],
                  ),
                  Divider(color: AppColors.border, height: 20.h),
                  Text('Technician: ${log.technician}',
                      style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary)),
                  SizedBox(height: 6.h),
                  Text('Remarks: ${log.remarks}',
                      style: TextStyle(
                          fontSize: 12.sp,
                          color: AppColors.textSecondary,
                          height: 1.4)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHorizontalCalendar(
      SiteEntity site, List<AnalyticsDayWiseEntity> dailySummary) {
    final int totalDays = _endDate.difference(_startDate).inDays + 1;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _currentHeaderMonthYear,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Icon(
                      Icons.arrow_back_rounded,
                      size: 11.r,
                      color: AppColors.textSecondary,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      'Swipe left for history',
                      style: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            IconButton(
              icon: Icon(
                Icons.calendar_month_rounded,
                color: AppColors.primary,
                size: 22.r,
              ),
              onPressed: () async {
                final DateTimeRange? picked = await showDateRangePicker(
                  context: context,
                  initialDateRange: DateTimeRange(
                    start: _startDate,
                    end: _endDate.isBefore(_startDate) ? _startDate : _endDate,
                  ),
                  firstDate: DateTime(2000, 1, 1),
                  lastDate: DateTime.now(),
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: ColorScheme.light(
                          primary: AppColors.primary,
                          onPrimary: Colors.white,
                          onSurface: AppColors.textPrimary,
                        ),
                      ),
                      child: child!,
                    );
                  },
                );
                if (picked != null) {
                  _onRangeSelected(picked.start, picked.end);
                }
              },
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Stack(
          children: [
            SizedBox(
              height: 95.h,
              child: ListView.builder(
                controller: _calendarScrollController,
                scrollDirection: Axis.horizontal,
                reverse: true,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.w,
                ),
                itemCount: totalDays,
                itemBuilder: (context, index) {
                  final date = _endDate.subtract(Duration(days: index));

                  final startDay = DateTime(
                      _startDate.year, _startDate.month, _startDate.day);
                  final endDay =
                      DateTime(_endDate.year, _endDate.month, _endDate.day);
                  final currentDay = DateTime(date.year, date.month, date.day);

                  final bool isSelected;
                  final bool isInBetween;

                  if (_activeDay != null) {
                    final activeClean = DateTime(
                        _activeDay!.year, _activeDay!.month, _activeDay!.day);
                    isSelected = currentDay == activeClean;
                    isInBetween = !isSelected;
                  } else {
                    final bool isInRange = !currentDay.isBefore(startDay) &&
                        !currentDay.isAfter(endDay);
                    isSelected = currentDay == startDay || currentDay == endDay;
                    isInBetween = isInRange && !isSelected;
                  }

                  final bool isToday = date.year == DateTime.now().year &&
                      date.month == DateTime.now().month &&
                      date.day == DateTime.now().day;

                  return _buildDayCard(
                    dailySummary,
                    site,
                    date,
                    isSelected,
                    isInBetween,
                    isToday,
                  );
                },
              ),
            ),
            // Left Fade Indicator to signal more scrollable content on the left
            if (_showLeftIndicator)
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 30.w,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          AppColors.of(context).background,
                          AppColors.of(context)
                              .background
                              .withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            // Right Fade Indicator (shows up when scrolled to reveal hidden right items)
            if (_showRightIndicator)
              Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                width: 30.w,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                        colors: [
                          AppColors.of(context).background,
                          AppColors.of(context)
                              .background
                              .withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildDayCard(
    List<AnalyticsDayWiseEntity> entity,
    SiteEntity site,
    DateTime date,
    bool isSelected,
    bool isInBetween,
    bool isToday,
  ) {
    final List<String> weekdays = [
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      'Fri',
      'Sat',
      'Sun'
    ];
    final weekdayStr = weekdays[date.weekday - 1];

    final bool isRealToday = date.year == DateTime.now().year &&
        date.month == DateTime.now().month &&
        date.day == DateTime.now().day;

    // Get real AQI from API data for this date
    // final readings = _getHistoryReadingsForDate(date);
    // final readings = entity.where((h){
    //   DateTime intervalDate = DateFormat('dd-MM-yyyy').parseUtc(h.aqiDate!);
    //   return
    // }).toList();
    int? aqi;
    if (isRealToday && site.aqi != null) {
      // Today: use the live SSE/latest value first, fall back to history
      aqi = site.aqi;
    }
    // if (aqi == null && readings.isNotEmpty) {
    //   // Average all readings for this date
    //   final validAqis =
    //       readings.where((r) => r.aqi != null).map((r) => r.aqi!).toList();
    //   if (validAqis.isNotEmpty) {
    //     aqi = validAqis.reduce((a, b) => a + b) ~/ validAqis.length;
    //   }
    // }

    if (aqi == null && entity.isNotEmpty) {
      // Average all readings for this date

      for (final e in entity) {
        DateTime dailyDate = DateFormat('dd-MM-yyyy').parseUtc(e.aqiDate!);
        if (dailyDate.day == date.day &&
            dailyDate.month == date.month &&
            dailyDate.year == date.year) {
          aqi = e.avgAqi!.toInt();
        }
      }
    }
    // aqi remains null if no data at all → badge shows "-" with grey color

    final aqiColor = AppColors.getAqiColor(aqi);
    final badgeTextColor = _getContrastColor(aqiColor);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _onDateSelected(date),
      child: Container(
        width: 50.w,
        margin: EdgeInsets.symmetric(horizontal: 6.w),
        padding: EdgeInsets.symmetric(vertical: 6.h),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary
              : isInBetween
                  ? AppColors.primary.withValues(alpha: 0.12)
                  : AppColors.surface,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isSelected
                ? AppColors.primary
                : isInBetween
                    ? AppColors.primary.withValues(alpha: 0.3)
                    : isRealToday
                        ? AppColors.primary.withValues(alpha: 0.5)
                        : AppColors.border,
            width: isRealToday || isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.primary.withValues(alpha: 0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  )
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.03),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              weekdayStr,
              style: TextStyle(
                fontSize: 9.sp,
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? Colors.white70
                    : isInBetween
                        ? AppColors.primary
                        : AppColors.textSecondary,
              ),
            ),
            SizedBox(height: 4.h),
            Text(
              '${date.day}',
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
                color: isSelected
                    ? Colors.white
                    : isInBetween
                        ? AppColors.primary
                        : AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 6.h),
            // AQI Badge
            Container(
              padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: aqiColor,
                borderRadius: BorderRadius.circular(6.r),
              ),
              child: Text(
                '${aqi ?? "-"}',
                style: TextStyle(
                  fontSize: 8.sp,
                  fontWeight: FontWeight.bold,
                  color: badgeTextColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLightParamBox(String title, double? value, String unit) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 4.w),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 9.sp,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            value != null ? value.toString() : '-',
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            unit,
            style: TextStyle(
              fontSize: 8.sp,
              color: AppColors.textSecondary.withValues(alpha: 0.6),
            ),
          ),
        ],
      ),
    );
  }

  void _scrollToSelectedDate({bool animate = true}) {
    if (!_calendarScrollController.hasClients) return;

    final today = DateTime.now();
    final startOfToday = DateTime(today.year, today.month, today.day);
    final selectedStart = DateTime(_endDate.year, _endDate.month, _endDate.day);
    final index = startOfToday.difference(selectedStart).inDays;

    if (index >= 0) {
      final double itemWidth = 62.w; // 50.w + 12.w spacing
      final double viewportWidth = MediaQuery.of(context).size.width;
      final double targetOffset =
          (index * itemWidth) - (viewportWidth / 2 - 47.w);

      if (animate) {
        _calendarScrollController.animateTo(
          targetOffset.clamp(
              0.0, _calendarScrollController.position.maxScrollExtent),
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOut,
        );
      } else {
        _calendarScrollController.jumpTo(
          targetOffset.clamp(
              0.0, _calendarScrollController.position.maxScrollExtent),
        );
      }
    }
  }

  SiteEntity _getHistoricalSiteData(SiteEntity site, DateTime date) {
    final readings = _getHistoryReadingsForDate(date);
    if (readings.isNotEmpty) {
      // Find the latest reading's timestamp (time of last sync) for this date
      DateTime latestTime = date;
      for (final r in readings) {
        final readingDt = _parseTelemetryDateTime(r.date, r.time);
        if (readingDt != null && readingDt.isAfter(latestTime)) {
          latestTime = readingDt;
        }
      }

      // Average all readings for the date
      int sumAqi = 0;
      int countAqi = 0;
      double sumPm1 = 0, sumPm25 = 0, sumPm10 = 0;
      double sumTemp = 0, sumHum = 0, sumNoise = 0;
      double sumCo2 = 0, sumCo = 0;
      int countPm1 = 0, countPm25 = 0, countPm10 = 0;
      int countTemp = 0, countHum = 0, countNoise = 0;
      int countCo2 = 0, countCo = 0;
      bool sprinklerActive = false;

      for (final r in readings) {
        if (r.aqi != null) {
          sumAqi += r.aqi!;
          countAqi++;
        }
        if (r.pm1 != null) {
          sumPm1 += r.pm1!;
          countPm1++;
        }
        if (r.pm25 != null) {
          sumPm25 += r.pm25!;
          countPm25++;
        }
        if (r.pm10 != null) {
          sumPm10 += r.pm10!;
          countPm10++;
        }
        if (r.temperature != null) {
          sumTemp += r.temperature!;
          countTemp++;
        }
        if (r.humidity != null) {
          sumHum += r.humidity!;
          countHum++;
        }
        if (r.noise != null) {
          sumNoise += r.noise!;
          countNoise++;
        }
        if (r.co2 != null) {
          sumCo2 += r.co2!;
          countCo2++;
        }
        if (r.co != null) {
          sumCo += r.co!;
          countCo++;
        }
        if (r.sprinkler != null && r.sprinkler != 0) sprinklerActive = true;
      }

      final int? avgAqi = countAqi > 0 ? (sumAqi ~/ countAqi) : null;
      final Map<String, SensorReading> historicalParams = {
        'PM2.5': SensorReading(
            countPm25 > 0
                ? double.parse((sumPm25 / countPm25).toStringAsFixed(1))
                : null,
            'µg/m³'),
        'PM10': SensorReading(
            countPm10 > 0
                ? double.parse((sumPm10 / countPm10).toStringAsFixed(1))
                : null,
            'µg/m³'),
        'TSP': SensorReading(
            countPm10 > 0
                ? double.parse(((sumPm10 / countPm10) * 1.3).toStringAsFixed(1))
                : null,
            'µg/m³'),
        'Temp': SensorReading(
            countTemp > 0
                ? double.parse((sumTemp / countTemp).toStringAsFixed(1))
                : null,
            '°C'),
        'Humidity': SensorReading(
            countHum > 0
                ? double.parse((sumHum / countHum).toStringAsFixed(1))
                : null,
            '%'),
        'PM1': SensorReading(
            countPm1 > 0
                ? double.parse((sumPm1 / countPm1).toStringAsFixed(1))
                : null,
            'µg/m³'),
        'Noise': SensorReading(
            countNoise > 0
                ? double.parse((sumNoise / countNoise).toStringAsFixed(1))
                : null,
            'dB'),
        'CO₂': SensorReading(
            countCo2 > 0
                ? double.parse((sumCo2 / countCo2).toStringAsFixed(1))
                : null,
            'ppm'),
        'CO': SensorReading(
            countCo > 0
                ? double.parse((sumCo / countCo).toStringAsFixed(2))
                : null,
            'mg/m³'),
      };

      return site.copyWith(
        aqi: avgAqi,
        parameters: historicalParams,
        isDeviceOnline: true,
        isSprinklerRunning: sprinklerActive,
        lastSyncTime: latestTime,
      );
    }

    // No data for this date — return null params
    return site.copyWith(
      aqi: null,
      parameters: {
        'PM2.5': const SensorReading(null, 'µg/m³'),
        'PM10': const SensorReading(null, 'µg/m³'),
        'TSP': const SensorReading(null, 'µg/m³'),
        'Temp': const SensorReading(null, '°C'),
        'Humidity': const SensorReading(null, '%'),
      },
      isDeviceOnline: false,
    );
  }

  Widget _buildCalibrationTab(SiteEntity site) {
    final authState = context.read<AuthBloc>().state;
    final bool isAdmin =
        authState is AuthAuthenticated && authState.user.role == UserRole.admin;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: ListView(
        padding: EdgeInsets.all(16.r),
        children: [
          site.calibrationScheduleList.isNotEmpty
              ? CalibrationScheduleCard(
                  isShowViewAll: isAdmin,
                  schedule: site.calibrationScheduleList.first,
                  onEdit: () {
                    showUpdateCalibrationScheduleBottomSheet(
                        context: context,
                        schedule: site.calibrationScheduleList.first,
                        onUpdate: ((
                            {actualScheduledDate,
                            required scheduledDate,
                            required status}) {
                          CalibrationScheduleEntity newSchedule =
                              site.calibrationScheduleList.first.copyWith(
                            actualScheduledDate: actualScheduledDate,
                            status: status,
                            calibrationScheduleId: site.calibrationScheduleList
                                .first.calibrationScheduleId,
                            scheduledDate: scheduledDate,
                            deviceId:
                                site.calibrationScheduleList.first.deviceId ??
                                    site.id,
                          );

                          context.read<SitesBloc>().add(
                              UpdateCalibrationScheduleEvent(
                                  siteId: site.calibrationScheduleList.first
                                          .deviceId ??
                                      site.id,
                                  calibration: newSchedule));
                        }));
                  },
                  onViewAll: () {
                    showAllCalibrationScheduleBottomSheet(
                        context: context,
                        scheduleList: site.calibrationScheduleList);
                  })
              : Padding(
                  padding: EdgeInsets.symmetric(vertical: 30.h),
                  child: Center(
                    child: Text(
                      'No calibration schedule found.',
                      style: TextStyle(
                          color: AppColors.textMuted, fontSize: 13.sp),
                    ),
                  ),
                ),
          // ScadaCard(
          //   padding: EdgeInsets.all(16.r),
          //   child: Column(
          //     crossAxisAlignment: CrossAxisAlignment.start,
          //     children: [
          //       Row(
          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //         children: [
          //           Text(
          //             'Calibration Schedule',
          //             style: TextStyle(
          //               fontSize: 15.sp,
          //               fontWeight: FontWeight.bold,
          //               color: AppColors.textPrimary,
          //             ),
          //           ),
          //           AqiStatusChip(label: statusText, color: statusColor),
          //         ],
          //       ),
          //       Divider(color: AppColors.border, height: 24.h),
          //       // site.calibrationScheduleList.isNotEmpty
          //       //     ? CalibrationScheduleCard(
          //       //         schedule: site.calibrationScheduleList.first,
          //       //         onEdit: () {},
          //       //         onViewAll: () {})
          //       //     : const SizedBox.shrink(),
          //       // _buildDetailRow('Device Model', 'VASUNDHARA Maha AQI System'),
          //       // _buildDetailRow('Serial Number', site.deviceSerial),
          //       // _buildDetailRow('Last Calibration',
          //       //     _formatDate(site.displayLastCalibrationDate)),
          //       // _buildDetailRow('Next Calibration Due',
          //       //     _formatDate(site.displayNextCalibrationDate)),
          //       // _buildDetailRow('Calibration Cycle', '180 Days (Standard)'),
          //     ],
          //   ),
          // ),
          SizedBox(height: 20.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Calibration History',
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                '${site.calibrationHistory.length} logs',
                style: TextStyle(
                  fontSize: 12.sp,
                  color: AppColors.textMuted,
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),

          if (isAdmin)
            PrimaryButton(
              // text: 'Perform New Calibration',
              text: 'Add Calibration Info',
              icon: Icons.biotech_rounded,
              onPressed: () => showCalibrationFormBottomSheet(
                  context: context,
                  schedule: site.calibrationScheduleList.first,
                  onSave: (data) {
                    context.read<SitesBloc>().add(RecordCalibration(
                        siteId: site.id.toString(), calibration: data));
                  }),
            )
          else
            SecondaryButton(
              text: 'Request Device Calibration Check',
              icon: Icons.notifications_active_rounded,
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Calibration check request sent to Admin.'),
                    backgroundColor: AppColors.primary,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
          SizedBox(height: 10.h),
          if (site.calibrationHistory.isEmpty)
            Padding(
              padding: EdgeInsets.symmetric(vertical: 30.h),
              child: Center(
                child: Text(
                  'No calibration records found.',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 13.sp),
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: site.calibrationHistory.length,
              itemBuilder: (context, index) {
                final log = site.calibrationHistory[index];
                return InkWell(
                    onTap: () {
                      if (isAdmin) {
                        showCalibrationFormBottomSheet(
                            context: context,
                            schedule: site.calibrationScheduleList.first,
                            onSave: (data) {
                              context.read<SitesBloc>().add(
                                  UpdateCalibrationEvent(
                                      siteId: site.id.toString(),
                                      calibration: data));
                            },
                            calibration: log);
                      }
                    },
                    child: CalibrationHistoryCardWidget(calibration: log));
              },
            ),
          SizedBox(height: 16.h),

          // SizedBox(height: 24.h),
        ],
      ),
    );
  }

  DateTime addMonths(DateTime date, int months) {
    final year = date.year + ((date.month - 1 + months) ~/ 12);
    final month = ((date.month - 1 + months) % 12) + 1;

    final lastDay = DateTime(year, month + 1, 0).day;
    final day = date.day > lastDay ? lastDay : date.day;

    return DateTime(
      year,
      month,
      day,
      date.hour,
      date.minute,
      date.second,
      date.millisecond,
      date.microsecond,
    );
  }

  Future<void> showCalibrationFormBottomSheet({
    required BuildContext context,
    CalibrationHistoryEntity? calibration,
    CalibrationScheduleModel? schedule,
    required Function(CalibrationHistoryEntity data) onSave,
  }) async {
    final formKey = GlobalKey<FormState>();

    final calibratedByController = TextEditingController(
      text: calibration?.calibratedBy ?? "",
    );

    final certificateController = TextEditingController(
      text: calibration?.certificateNo ?? "",
    );

    final remarksController = TextEditingController(
      text: calibration?.remarks ?? "",
    );

    DateTime? calibrationDate = calibration?.calibrationDate ??
        schedule?.actualScheduledDate ??
        schedule?.scheduledDate ??
        DateTime.now();

    DateTime? nextDueDate = calibration?.nextDueDate ??
        (schedule?.actualScheduledDate != null
            ? addMonths(schedule!.actualScheduledDate!, 3)
            : schedule!.scheduledDate != null
                ? addMonths(schedule.scheduledDate!, 3)
                : addMonths(DateTime.now(), 3));
    String? deviceId = calibration?.deviceId;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(24),
        ),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            Future<void> selectDate(bool isNextDue) async {
              final picked = await showDatePicker(
                context: context,
                initialDate: isNextDue
                    ? (nextDueDate ?? DateTime.now())
                    : calibrationDate!,
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
              );

              if (picked != null) {
                setState(() {
                  if (isNextDue) {
                    nextDueDate = picked;
                  } else {
                    calibrationDate = picked;
                  }
                });
              }
            }

            return Padding(
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Center(
                        child: Container(
                          height: 5,
                          width: 50,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      Text(
                        calibration == null
                            ? "Add Calibration"
                            : "Update Calibration",
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 20),

                      /// Calibration Date

                      _dateField(
                        title: "Calibration Date",
                        value: calibrationDate,
                        onTap: () {
                          selectDate(false);
                        },
                      ),

                      const SizedBox(height: 16),

                      TextFormField(
                        controller: calibratedByController,
                        decoration: const InputDecoration(
                          labelText: "Calibrated By",
                          border: OutlineInputBorder(),
                        ),
                      ),

                      const SizedBox(height: 16),

                      TextFormField(
                        controller: certificateController,
                        decoration: const InputDecoration(
                          labelText: "Certificate No",
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Certificate required";
                          }

                          return null;
                        },
                      ),

                      const SizedBox(height: 16),

                      _dateField(
                        title: "Next Due Date",
                        value: nextDueDate,
                        onTap: () {
                          selectDate(true);
                        },
                      ),

                      const SizedBox(height: 16),

                      TextFormField(
                        controller: remarksController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: "Remarks",
                          border: OutlineInputBorder(),
                        ),
                      ),

                      const SizedBox(height: 24),

                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () {
                            if (!formKey.currentState!.validate()) {
                              return;
                            }

                            final data = CalibrationHistoryEntity(
                              srNo: calibration?.srNo,
                              calibrationInfoId: calibration?.calibrationInfoId,
                              deviceId: deviceId,
                              calibrationDate: calibrationDate,
                              calibratedBy: calibratedByController.text.trim(),
                              certificateNo: certificateController.text.trim(),
                              nextDueDate: nextDueDate,
                              remarks: remarksController.text.trim(),
                              createdAt: calibration?.createdAt ??
                                  DateTime.now().toIso8601String(),
                            );

                            Navigator.pop(context);

                            onSave(data);
                          },
                          child: Text(
                            calibration == null
                                ? "Save Calibration"
                                : "Update Calibration",
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _dateField({
    required String title,
    required DateTime? value,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: title,
          border: const OutlineInputBorder(),
        ),
        child: Text(
          value == null
              ? "Select Date"
              : "${value.day.toString().padLeft(2, '0')}-"
                  "${value.month.toString().padLeft(2, '0')}-"
                  "${value.year}",
        ),
      ),
    );
  }

  // void _showRecordCalibrationDialog(BuildContext context, SiteEntity site) {
  //   final colors = AppColors.of(context);
  //   final formKey = GlobalKey<FormState>();
  //   final technicianController = TextEditingController(text: 'Rajesh Kumar');
  //   final remarksController = TextEditingController();
  //   String calibrationType = 'Span Calibration';
  //   String parameters = 'All Sensors';
  //   String status = 'Passed';

  //   showDialog(
  //     context: context,
  //     builder: (dialogContext) {
  //       return StatefulBuilder(
  //         builder: (context, setState) {
  //           return AlertDialog(
  //             backgroundColor: AppColors.of(context).background,
  //             surfaceTintColor: Colors.transparent,
  //             shape: RoundedRectangleBorder(
  //               borderRadius: BorderRadius.circular(16.r),
  //             ),
  //             title: Text(
  //               'Record Device Calibration',
  //               style: TextStyle(
  //                 fontSize: 16.sp,
  //                 fontWeight: FontWeight.bold,
  //                 color: colors.textPrimary,
  //               ),
  //             ),
  //             content: SingleChildScrollView(
  //               child: Form(
  //                 key: formKey,
  //                 child: Column(
  //                   mainAxisSize: MainAxisSize.min,
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: [
  //                     Text('Calibration Type',
  //                         style: TextStyle(
  //                             fontSize: 11.sp, color: colors.textSecondary)),
  //                     SizedBox(height: 6.h),
  //                     Container(
  //                       padding: EdgeInsets.symmetric(horizontal: 12.w),
  //                       decoration: BoxDecoration(
  //                         color: colors.surface,
  //                         borderRadius: BorderRadius.circular(8.r),
  //                         border: Border.all(color: colors.border),
  //                       ),
  //                       child: DropdownButtonHideUnderline(
  //                         child: DropdownButton<String>(
  //                           value: calibrationType,
  //                           isExpanded: true,
  //                           dropdownColor: colors.surface,
  //                           items: [
  //                             'Zero Calibration',
  //                             'Span Calibration',
  //                             'Field Calibration'
  //                           ]
  //                               .map((type) => DropdownMenuItem(
  //                                     value: type,
  //                                     child: Text(type,
  //                                         style: TextStyle(
  //                                             fontSize: 13.sp,
  //                                             color: colors.textPrimary)),
  //                                   ))
  //                               .toList(),
  //                           onChanged: (val) {
  //                             if (val != null) {
  //                               setState(() => calibrationType = val);
  //                             }
  //                           },
  //                         ),
  //                       ),
  //                     ),
  //                     SizedBox(height: 14.h),
  //                     Text('Calibrated Parameters',
  //                         style: TextStyle(
  //                             fontSize: 11.sp, color: colors.textSecondary)),
  //                     SizedBox(height: 6.h),
  //                     Container(
  //                       padding: EdgeInsets.symmetric(horizontal: 12.w),
  //                       decoration: BoxDecoration(
  //                         color: colors.surface,
  //                         borderRadius: BorderRadius.circular(8.r),
  //                         border: Border.all(color: colors.border),
  //                       ),
  //                       child: DropdownButtonHideUnderline(
  //                         child: DropdownButton<String>(
  //                           value: parameters,
  //                           isExpanded: true,
  //                           dropdownColor: colors.surface,
  //                           items: [
  //                             'All Sensors',
  //                             'Particulate (PM2.5, PM10)',
  //                             'Gas Sensors (CO, CO2, VOC)',
  //                             'Temp & Humidity Only'
  //                           ]
  //                               .map((param) => DropdownMenuItem(
  //                                     value: param,
  //                                     child: Text(param,
  //                                         style: TextStyle(
  //                                             fontSize: 13.sp,
  //                                             color: colors.textPrimary)),
  //                                   ))
  //                               .toList(),
  //                           onChanged: (val) {
  //                             if (val != null) setState(() => parameters = val);
  //                           },
  //                         ),
  //                       ),
  //                     ),
  //                     SizedBox(height: 14.h),
  //                     Text('Calibration Status',
  //                         style: TextStyle(
  //                             fontSize: 11.sp, color: colors.textSecondary)),
  //                     SizedBox(height: 6.h),
  //                     Container(
  //                       padding: EdgeInsets.symmetric(horizontal: 12.w),
  //                       decoration: BoxDecoration(
  //                         color: colors.surface,
  //                         borderRadius: BorderRadius.circular(8.r),
  //                         border: Border.all(color: colors.border),
  //                       ),
  //                       child: DropdownButtonHideUnderline(
  //                         child: DropdownButton<String>(
  //                           value: status,
  //                           isExpanded: true,
  //                           dropdownColor: colors.surface,
  //                           items: ['Passed', 'Failed', 'Pending']
  //                               .map((st) => DropdownMenuItem(
  //                                     value: st,
  //                                     child: Text(st,
  //                                         style: TextStyle(
  //                                             fontSize: 13.sp,
  //                                             color: colors.textPrimary)),
  //                                   ))
  //                               .toList(),
  //                           onChanged: (val) {
  //                             if (val != null) setState(() => status = val);
  //                           },
  //                         ),
  //                       ),
  //                     ),
  //                     SizedBox(height: 14.h),
  //                     Text('Technician',
  //                         style: TextStyle(
  //                             fontSize: 11.sp, color: colors.textSecondary)),
  //                     SizedBox(height: 6.h),
  //                     TextFormField(
  //                       controller: technicianController,
  //                       style: TextStyle(
  //                           fontSize: 13.sp, color: colors.textPrimary),
  //                       decoration: InputDecoration(
  //                         hintText: 'Enter technician name',
  //                         fillColor: colors.surface,
  //                         filled: true,
  //                         contentPadding: EdgeInsets.symmetric(
  //                             horizontal: 12.w, vertical: 8.h),
  //                         border: OutlineInputBorder(
  //                           borderRadius: BorderRadius.circular(8.r),
  //                           borderSide: BorderSide(color: colors.border),
  //                         ),
  //                       ),
  //                       validator: (value) =>
  //                           value == null || value.trim().isEmpty
  //                               ? 'Technician name required'
  //                               : null,
  //                     ),
  //                     SizedBox(height: 14.h),
  //                     Text('Remarks',
  //                         style: TextStyle(
  //                             fontSize: 11.sp, color: colors.textSecondary)),
  //                     SizedBox(height: 6.h),
  //                     TextFormField(
  //                       controller: remarksController,
  //                       maxLines: 3,
  //                       style: TextStyle(
  //                           fontSize: 13.sp, color: colors.textPrimary),
  //                       decoration: InputDecoration(
  //                         hintText: 'Enter calibration remarks',
  //                         fillColor: colors.surface,
  //                         filled: true,
  //                         contentPadding: EdgeInsets.symmetric(
  //                             horizontal: 12.w, vertical: 8.h),
  //                         border: OutlineInputBorder(
  //                           borderRadius: BorderRadius.circular(8.r),
  //                           borderSide: BorderSide(color: colors.border),
  //                         ),
  //                       ),
  //                       validator: (value) =>
  //                           value == null || value.trim().isEmpty
  //                               ? 'Remarks required'
  //                               : null,
  //                     ),
  //                   ],
  //                 ),
  //               ),
  //             ),
  //             actions: [
  //               TextButton(
  //                 onPressed: () => Navigator.pop(dialogContext),
  //                 child: Text('Cancel',
  //                     style: TextStyle(color: AppColors.textSecondary)),
  //               ),
  //               ElevatedButton(
  //                 style: ElevatedButton.styleFrom(
  //                   backgroundColor: AppColors.primary,
  //                   shape: RoundedRectangleBorder(
  //                       borderRadius: BorderRadius.circular(8.r)),
  //                 ),
  //                 onPressed: () {
  //                   if (formKey.currentState?.validate() ?? false) {
  //                     // final newLog = CalibrationLog(
  //                     //   date: DateTime.now(),
  //                     //   technician: technicianController.text.trim(),
  //                     //   calibrationType: calibrationType,
  //                     //   parameters: parameters,
  //                     //   status: status,
  //                     //   remarks: remarksController.text.trim(),
  //                     // );
  //                     // this.context.read<SitesBloc>().add(
  //                     //       RecordCalibration(
  //                     //         siteId: site.id,
  //                     //         calibration: newLog,
  //                     //       ),
  //                     //     );
  //                     Navigator.pop(dialogContext);
  //                   }
  //                 },
  //                 child: const Text('Save Log',
  //                     style: TextStyle(color: Colors.white)),
  //               ),
  //             ],
  //           );
  //         },
  //       );
  //     },
  //   );
  // }

  Future<void> _showEditDeviceDialog(
      BuildContext context, SiteEntity site) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => const Center(
        child: CircularProgressIndicator(color: AppColors.primary),
      ),
    );

    try {
      final device = await getIt<AdminRepository>().getDeviceDetail(site.id);
      Navigator.pop(context); // Dismiss loading dialog

      if (!context.mounted) return;
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) {
          return _DeviceEditDialog(
            device: device,
            onSaved: () {
              // Refresh details
              this.context.read<SitesBloc>().add(LoadSiteDetails(site.id));
              // Also show a success message
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Device specification updated successfully.'),
                  backgroundColor: AppColors.online,
                ),
              );
            },
          );
        },
      );
    } catch (e) {
      Navigator.pop(context); // Dismiss loading dialog
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to load device details: $e'),
          backgroundColor: AppColors.aqiRed,
        ),
      );
    }
  }
}

class _DeviceEditDialog extends StatefulWidget {
  final DeviceEntity device;
  final VoidCallback onSaved;

  const _DeviceEditDialog({required this.device, required this.onSaved});

  @override
  State<_DeviceEditDialog> createState() => _DeviceEditDialogState();
}

class _DeviceEditDialogState extends State<_DeviceEditDialog> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameController;
  late TextEditingController _codeController;
  late TextEditingController _imeiController;
  late TextEditingController _simController;
  late TextEditingController _firmwareController;
  late TextEditingController _latitudeController;
  late TextEditingController _longitudeController;
  late TextEditingController _radiusController;
  late TextEditingController _addressController;
  late TextEditingController _cityController;
  late TextEditingController _districtController;
  late TextEditingController _stateController;
  late TextEditingController _remarksController;

  DateTime? _installationDate;
  DateTime? _expiryDate;
  bool _active = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final d = widget.device;
    _nameController = TextEditingController(text: d.deviceName);
    _codeController = TextEditingController(text: d.deviceCode);
    _imeiController = TextEditingController(text: d.imeiNo);
    _simController = TextEditingController(text: d.simNo);
    _firmwareController = TextEditingController(text: d.firmwareVersion);
    _latitudeController =
        TextEditingController(text: d.latitude?.toString() ?? '');
    _longitudeController =
        TextEditingController(text: d.longitude?.toString() ?? '');
    _radiusController =
        TextEditingController(text: d.geofenceRadius?.toString() ?? '');
    _addressController = TextEditingController(text: d.address ?? '');
    _cityController = TextEditingController(text: d.city ?? '');
    _districtController = TextEditingController(text: d.district ?? '');
    _stateController = TextEditingController(text: d.state ?? '');
    _remarksController = TextEditingController(text: d.remarks ?? '');
    _installationDate = d.installationDate;
    _expiryDate = d.expiryDate;
    _active = d.active;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _codeController.dispose();
    _imeiController.dispose();
    _simController.dispose();
    _firmwareController.dispose();
    _latitudeController.dispose();
    _longitudeController.dispose();
    _radiusController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _districtController.dispose();
    _stateController.dispose();
    _remarksController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context, DateTime initial,
      Function(DateTime) onPicked) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() {
        onPicked(picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
      ),
      padding: EdgeInsets.only(
        left: 16.w,
        right: 16.w,
        top: 12.h,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20.h,
      ),
      child: Material(
        color: Colors.transparent,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Edit Device Registry',
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primary,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded,
                          color: AppColors.primary),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                Divider(color: AppColors.border, height: 16.h),
                // _buildTextField('Device Code / Serial *', _codeController,
                //     validator: (v) => v!.isEmpty ? 'Required' : null),
                SizedBox(height: 12.h),
                _buildTextField(
                  'Device Custom Name *',
                  _nameController,
                ),
                // validator: (v) => v!.isEmpty ? 'Required' : null),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildTextField('IMEI Number *', _imeiController,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(15),
                          ],
                          keyboardType: TextInputType.number,
                          validator: (v) =>
                              Validator.validateImei(v, msg: 'Required')),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: _buildTextField('SIM Number', _simController,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            // LengthLimitingTextInputFormatter(16),
                          ],
                          keyboardType: TextInputType.number,
                          validator: (v) => Validator.simNumber(v, 'Required')),
                    ),
                  ],
                ),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildTextField(
                          'Firmware Version', _firmwareController,
                          validator: (e) =>
                              Validator.validateFirmwareVersion(e)),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: SwitchListTile.adaptive(
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          'Active State',
                          style: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        value: _active,
                        onChanged: (val) => setState(() => _active = val),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildTextField('Latitude', _latitudeController,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true), validator: (v) {
                        if (v != null && v.isNotEmpty) {
                          if (double.tryParse(v) == null) {
                            return 'Invalid decimal';
                          }
                        }
                        return null;
                      }),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: _buildTextField('Longitude', _longitudeController,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true), validator: (v) {
                        if (v != null && v.isNotEmpty) {
                          if (double.tryParse(v) == null) {
                            return 'Invalid decimal';
                          }
                        }
                        return null;
                      }),
                    ),
                  ],
                ),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildTextField(
                          'Geofence Radius (m)', _radiusController,
                          keyboardType: TextInputType.number, validator: (v) {
                        if (v != null && v.isNotEmpty) {
                          if (int.tryParse(v) == null) return 'Invalid integer';
                        }
                        return null;
                      }),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Container(),
                    ),
                  ],
                ),
                SizedBox(height: 12.h),
                _buildTextField('Installation Address', _addressController),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(child: _buildTextField('City', _cityController)),
                    SizedBox(width: 12.w),
                    Expanded(
                        child:
                            _buildTextField('District', _districtController)),
                  ],
                ),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(child: _buildTextField('State', _stateController)),
                    SizedBox(width: 12.w),
                    Expanded(
                        child: _buildTextField('Remarks', _remarksController)),
                  ],
                ),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon:
                            const Icon(Icons.calendar_today_rounded, size: 14),
                        label: Text(
                          _installationDate == null
                              ? 'Install Date'
                              : '${_installationDate!.day}/${_installationDate!.month}/${_installationDate!.year}',
                          style: TextStyle(fontSize: 11.sp),
                        ),
                        onPressed: () => _selectDate(
                            context,
                            _installationDate ?? DateTime.now(),
                            (d) => _installationDate = d),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.date_range_rounded, size: 14),
                        label: Text(
                          _expiryDate == null
                              ? 'Expiry Date'
                              : '${_expiryDate!.day}/${_expiryDate!.month}/${_expiryDate!.year}',
                          style: TextStyle(fontSize: 11.sp),
                        ),
                        onPressed: () => _selectDate(
                            context,
                            _expiryDate ??
                                DateTime.now().add(const Duration(days: 730)),
                            (d) => _expiryDate = d),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 24.h),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    minimumSize: Size(double.infinity, 44.h),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r)),
                  ),
                  onPressed: _isSaving
                      ? null
                      : () async {
                          if (_formKey.currentState!.validate()) {
                            setState(() {
                              _isSaving = true;
                            });
                            try {
                              final updatedDevice = DeviceEntity(
                                srNo: widget.device.srNo,
                                deviceId: widget.device.deviceId,
                                deviceCode: widget.device.deviceCode,
                                deviceName: _nameController.text.trim(),
                                imeiNo: _imeiController.text.trim(),
                                simNo: _simController.text.trim(),
                                firmwareVersion:
                                    _firmwareController.text.trim(),
                                installationDate: _installationDate,
                                expiryDate: _expiryDate,
                                active: _active,
                                createdAt: widget.device.createdAt,
                                updatedAt: DateTime.now(),
                                customerId: widget.device.customerId,
                                siteName: _nameController.text.trim(),
                                projectName: widget.device.projectName,
                                latitude: double.tryParse(
                                    _latitudeController.text.trim()),
                                longitude: double.tryParse(
                                    _longitudeController.text.trim()),
                                geofenceRadius:
                                    int.tryParse(_radiusController.text.trim()),
                                address: _addressController.text.trim(),
                                city: _cityController.text.trim(),
                                district: _districtController.text.trim(),
                                state: _stateController.text.trim(),
                                remarks: _remarksController.text.trim(),
                              );

                              await getIt<AdminRepository>()
                                  .updateDevice(updatedDevice);
                              widget.onSaved();
                              Navigator.pop(context);
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content:
                                        Text('Failed to update device: $e')),
                              );
                            } finally {
                              if (mounted) {
                                setState(() {
                                  _isSaving = false;
                                });
                              }
                            }
                          }
                        },
                  child: _isSaving
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2),
                        )
                      : const Text('Save Update'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller,
      {TextInputType? keyboardType,
      String? Function(String?)? validator,
      List<TextInputFormatter>? inputFormatters}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                fontSize: 11.sp,
                fontWeight: FontWeight.w600,
                color: AppColors.of(context).textSecondary)),
        SizedBox(height: 4.h),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          validator: validator,
          inputFormatters: inputFormatters,
          decoration: InputDecoration(
            isDense: true,
            contentPadding:
                EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
            fillColor: AppColors.of(context).background,
            filled: true,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.r),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }
}

DateTime? _parseTelemetryDateTime(String? dateStr, String? timeStr) {
  if (dateStr == null || dateStr.isEmpty) return null;
  try {
    if (dateStr.contains('T')) {
      return DateTime.tryParse(dateStr);
    }

    int year = 0;
    int month = 0;
    int day = 0;

    final String separator;
    if (dateStr.contains('/')) {
      separator = '/';
    } else if (dateStr.contains('-')) {
      separator = '-';
    } else {
      return DateTime.tryParse(dateStr);
    }

    final parts = dateStr.split(separator);
    if (parts.length != 3) return null;

    if (parts[0].length == 4) {
      year = int.parse(parts[0]);
      month = int.parse(parts[1]);
      day = int.parse(parts[2]);
    } else {
      day = int.parse(parts[0]);
      month = int.parse(parts[1]);
      year = int.parse(parts[2]);
    }

    int hour = 0;
    int minute = 0;
    int second = 0;

    if (timeStr != null && timeStr.isNotEmpty) {
      final timeParts = timeStr.split(':');
      if (timeParts.isNotEmpty) {
        hour = int.tryParse(timeParts[0]) ?? 0;
      }
      if (timeParts.length > 1) {
        minute = int.tryParse(timeParts[1]) ?? 0;
      }
      if (timeParts.length > 2) {
        final secStr = timeParts[2].split('.')[0].split('+')[0];
        second = int.tryParse(secStr) ?? 0;
      }
    }

    return DateTime(year, month, day, hour, minute, second);
  } catch (_) {
    return null;
  }
}

class AqiHistoryDay {
  final DateTime date;
  final int averageAqi;
  final List<int> intervals;
  final int minAqi;
  final int minAqiHour;
  final int maxAqi;
  final int maxAqiHour;

  AqiHistoryDay({
    required this.date,
    required this.averageAqi,
    required this.intervals,
    required this.minAqi,
    required this.minAqiHour,
    required this.maxAqi,
    required this.maxAqiHour,
  });
}
