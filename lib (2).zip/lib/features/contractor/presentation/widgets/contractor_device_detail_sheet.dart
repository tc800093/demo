// features/contractor/presentation/widgets/contractor_device_detail_sheet.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../admin/domain/entities/device_entity.dart';
import '../../../admin/domain/repositories/admin_repository.dart';
import '../../../../config/theme/colors.dart';
import '../../../../core/di/injection.dart';

class ContractorDeviceDetailSheet extends StatefulWidget {
  final String deviceId;

  const ContractorDeviceDetailSheet({super.key, required this.deviceId});

  @override
  State<ContractorDeviceDetailSheet> createState() =>
      _ContractorDeviceDetailSheetState();
}

class _ContractorDeviceDetailSheetState
    extends State<ContractorDeviceDetailSheet> {
  late Future<DeviceEntity> _deviceFuture;
  bool _isAddressExpanded = false;

  @override
  void initState() {
    super.initState();
    _deviceFuture = getIt<AdminRepository>().getDeviceDetail(widget.deviceId);
  }

  @override
  Widget build(BuildContext context) {
    final maxSheetHeight = MediaQuery.of(context).size.height * 0.8;
    final colors = AppColors.of(context);

    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxSheetHeight),
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        ),
        padding: EdgeInsets.only(
          left: 16.w,
          right: 16.w,
          top: 6.h,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16.h,
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle indicator
              Container(
                width: 40.w,
                height: 4.h,
                margin: EdgeInsets.only(bottom: 16.h),
                decoration: BoxDecoration(
                  color: colors.border,
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),

              // Title Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Device Specification',
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primary,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.close_rounded,
                      color: colors.textSecondary,
                    ),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              Divider(color: colors.border, height: 16.h),

              // Future Content Builder
              Flexible(
                child: FutureBuilder<DeviceEntity>(
                  future: _deviceFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Padding(
                        padding: EdgeInsets.symmetric(vertical: 40.h),
                        child: const Center(
                          child: CircularProgressIndicator(
                            color: AppColors.primary,
                          ),
                        ),
                      );
                    }

                    if (snapshot.hasError) {
                      return Padding(
                        padding: EdgeInsets.symmetric(vertical: 24.h),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.error_outline_rounded,
                              color: AppColors.aqiRed,
                              size: 40.r,
                            ),
                            SizedBox(height: 12.h),
                            Text(
                              'Failed to load device details',
                              style: TextStyle(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              snapshot.error.toString(),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 11.sp,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            SizedBox(height: 16.h),
                            ElevatedButton.icon(
                              onPressed: () {
                                setState(() {
                                  _deviceFuture = getIt<AdminRepository>()
                                      .getDeviceDetail(widget.deviceId);
                                });
                              },
                              icon: const Icon(Icons.refresh_rounded, size: 16),
                              label: const Text('Retry'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.r),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }

                    if (!snapshot.hasData) {
                      return Padding(
                        padding: EdgeInsets.symmetric(vertical: 40.h),
                        child: const Center(
                          child: Text('No details found for this device.'),
                        ),
                      );
                    }

                    final device = snapshot.data!;

                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // _buildDetailRow(
                          //   'Device Code',
                          //   device.deviceCode,
                          //   icon: Icons.qr_code_rounded,
                          // ),
                          _buildDetailRow(
                            'Device Name',
                            device.deviceName,
                            icon: Icons.router_rounded,
                          ),
                          _buildDetailRow(
                            'IMEI Number',
                            device.imeiNo,
                            icon: Icons.fingerprint_rounded,
                          ),
                          _buildDetailRow(
                            'SIM Details',
                            device.simNo.isEmpty
                                ? 'Not Provided'
                                : device.simNo,
                            icon: Icons.sim_card_rounded,
                          ),
                          _buildDetailRow(
                            'Firmware Version',
                            device.firmwareVersion,
                            icon: Icons.terminal_rounded,
                          ),
                          if (device.userName != null &&
                              device.userName!.isNotEmpty)
                            _buildDetailRow(
                              // 'Allocated Customer',

                              'Allocated To',
                              device.firmName != null &&
                                      device.firmName!.isNotEmpty
                                  ? '${device.firmName})'
                                  : '-',
                              // ? '${device.userName} (${device.firmName})'
                              // : device.userName!,
                              icon: Icons.person_outline_rounded,
                            ),
                          if (device.siteName != null &&
                              device.siteName!.isNotEmpty)
                            _buildDetailRow(
                              'Site / Station',
                              device.siteName!,
                              icon: Icons.domain_rounded,
                            ),
                          if (device.projectName != null &&
                              device.projectName!.isNotEmpty)
                            _buildDetailRow(
                              'Project Name',
                              device.projectName!,
                              icon: Icons.business_rounded,
                            ),
                          if (device.latitude != null &&
                              device.longitude != null)
                            _buildDetailRow(
                              'Geofence Coordinate Area',
                              'Lat: ${device.latitude}, Lng: ${device.longitude} (Radius: ${device.geofenceRadius ?? 100}m)',
                              icon: Icons.explore_outlined,
                            ),
                          if (device.address != null &&
                              device.address!.isNotEmpty)
                            _buildDetailRow(
                              'Installation Location',
                              '',
                              icon: Icons.location_on_outlined,
                              customValueWidget: StatefulBuilder(
                                builder: (context, detailSetState) {
                                  final addressText = [
                                    device.address,
                                    if (device.city != null &&
                                        device.city!.isNotEmpty)
                                      device.city,
                                    if (device.district != null &&
                                        device.district!.isNotEmpty)
                                      device.district,
                                    if (device.state != null &&
                                        device.state!.isNotEmpty)
                                      device.state
                                  ].join(', ');

                                  return Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        addressText,
                                        maxLines: _isAddressExpanded ? null : 2,
                                        overflow: _isAddressExpanded
                                            ? null
                                            : TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 13.sp,
                                          color:
                                              AppColors.of(context).textPrimary,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            _isAddressExpanded =
                                                !_isAddressExpanded;
                                          });
                                          detailSetState(() {});
                                        },
                                        child: Padding(
                                          padding: EdgeInsets.only(top: 4.h),
                                          child: Text(
                                            _isAddressExpanded
                                                ? 'See Less'
                                                : 'See More',
                                            style: TextStyle(
                                              fontSize: 11.sp,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.primary,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ),
                          if (device.remarks != null &&
                              device.remarks!.isNotEmpty)
                            _buildDetailRow(
                              'Remarks / Comments',
                              device.remarks!,
                              icon: Icons.comment_outlined,
                            ),
                          _buildDetailRow(
                            'Status Badge',
                            device.active ? 'ACTIVE' : 'INACTIVE',
                            icon: Icons.check_circle_outline_rounded,
                            customValueWidget: Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 8.w,
                                vertical: 2.h,
                              ),
                              decoration: BoxDecoration(
                                color: (device.active
                                        ? AppColors.online
                                        : AppColors.offline)
                                    .withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                              child: Text(
                                device.active ? 'ACTIVE' : 'INACTIVE',
                                style: TextStyle(
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.bold,
                                  color: device.active
                                      ? AppColors.online
                                      : AppColors.offline,
                                ),
                              ),
                            ),
                          ),
                          _buildDetailRow(
                            'Installation Details',
                            device.installationDate == null
                                ? 'Not Configured'
                                : '${device.installationDate!.day.toString().padLeft(2, '0')}/${device.installationDate!.month.toString().padLeft(2, '0')}/${device.installationDate!.year}',
                            icon: Icons.calendar_month_rounded,
                          ),
                          _buildDetailRow(
                            'Expiry Details',
                            device.expiryDate == null
                                ? 'Not Configured'
                                : '${device.expiryDate!.day.toString().padLeft(2, '0')}/${device.expiryDate!.month.toString().padLeft(2, '0')}/${device.expiryDate!.year}',
                            icon: Icons.date_range_rounded,
                          ),
                          if (device.createdAt != null)
                            _buildDetailRow(
                              'Registry Timestamp',
                              device.createdAt.toString().split('.')[0],
                              icon: Icons.history_toggle_off_rounded,
                            ),
                          SizedBox(height: 8.h),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value,
      {required IconData icon, Widget? customValueWidget}) {
    final colors = AppColors.of(context);
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16.r, color: AppColors.primary),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 10.sp,
                    color: colors.textSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2.h),
                customValueWidget ??
                    Text(
                      value,
                      style: TextStyle(
                        fontSize: 13.sp,
                        color: colors.textPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
