import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/app/router/router.dart';
import 'package:vasundhara_maha_aqim/config/theme/colors.dart';
import 'package:vasundhara_maha_aqim/core/utils/helper.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/sites_repository.dart';

class SprinklerInfoCardWidget extends StatelessWidget {
  final SiteEntity site;
  final bool? isSprinklerRunning;
  const SprinklerInfoCardWidget(
      {super.key, required this.site, this.isSprinklerRunning = false});

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Container(
      margin: EdgeInsets.only(top: 8.h),
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: colors.border,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8.r),
                    decoration: BoxDecoration(
                      color: isSprinklerRunning!
                          ? AppColors.online.withValues(alpha: 0.12)
                          : Colors.grey.withValues(alpha: 0.12),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.water_drop_rounded,
                      size: 20.r,
                      color: isSprinklerRunning!
                          ? AppColors.online
                          : colors.textMuted,
                    ),
                  ),
                  SizedBox(width: 10.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Sprinkler",
                        style: TextStyle(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w600,
                          color: colors.textSecondary,
                        ),
                      ),
                      SizedBox(height: 3.h),
                      Text(
                        isSprinklerRunning! ? "Running" : "Stopped",
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: isSprinklerRunning!
                              ? AppColors.online
                              : colors.textPrimary,
                        ),
                      ),
                    ],
                  )
                ],
              ),
              IconButton(
                onPressed: () {
                  context.push(
                    AppRoutes.contractorSprinklerPage,
                    extra: site.id,
                  );
                },
                icon: Icon(
                  Icons.arrow_forward_ios_rounded,
                  size: 18.r,
                  color: colors.textSecondary,
                ),
              )
            ],
          ),
          SizedBox(height: 12.h),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 10.w,
              vertical: 8.h,
            ),
            decoration: BoxDecoration(
              color: colors.background,
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                sprinklerDetailItem(
                  icon: Icons.schedule_rounded,
                  title: "Last ON",
                  value: site.sprinklerLastTriggerTime != null
                      ? DateFormat('dd MMM\nHH:ss a')
                          .format(site.sprinklerLastTriggerTime!)
                      : "03 Aug\n05:42 PM",
                ),
                sprinklerDetailItem(
                  icon: Icons.timer_outlined,
                  title: "Duration",
                  value: site.sprinklerRunDurationMinutes != 0
                      ? '${site.sprinklerRunDurationMinutes.toString()} min'
                      : "20 min",
                ),
                sprinklerDetailItem(
                  icon: Icons.history_rounded,
                  title: "Runs",
                  value: site.sprinklerHistory.isNotEmpty
                      ? site.sprinklerHistory
                          .where((e) => e.status == "Started")
                          .length
                          .toString()
                      : "124",
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
