import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_schedule_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/bloc/sites_bloc.dart';

class CalibrationScheduleCard extends StatelessWidget {
  final CalibrationScheduleEntity schedule;
  final VoidCallback onEdit;
  final VoidCallback onViewAll;
  final bool isShowViewAll;

  const CalibrationScheduleCard(
      {super.key,
      required this.schedule,
      required this.onEdit,
      required this.onViewAll,
      this.isShowViewAll = false});

  @override
  Widget build(BuildContext context) {
    final status = schedule.status ?? "PENDING";
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 0,
        vertical: 8,
      ),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: 8,
            offset: const Offset(0, 3),
            color: Colors.black.withValues(alpha: 0.08),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Header Row
          Row(
            children: [
              // Calendar Icon Badge
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.calendar_month_rounded,
                  color: Colors.orange,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),

              // Title
              Expanded(
                child: Text(
                  "Calibration Schedule",
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              // Top Right Action Icons
              isShowViewAll
                  ? IconButton(
                      onPressed: onViewAll,
                      icon: const Icon(Icons.visibility_outlined),
                      tooltip: "View Details",
                      visualDensity: VisualDensity.compact,
                      iconSize: 20,
                      color: theme.colorScheme.onSurfaceVariant,
                    )
                  : const SizedBox.shrink(),
              isShowViewAll
                  ? IconButton(
                      onPressed: onEdit,
                      icon: const Icon(Icons.edit_outlined),
                      tooltip: "Edit",
                      visualDensity: VisualDensity.compact,
                      iconSize: 20,
                      color: theme.colorScheme.primary,
                    )
                  : const SizedBox.shrink(),
            ],
          ),

          const SizedBox(height: 16),

          /// Dates Block & Status Chip
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _info(
                    "Scheduled Date",
                    _formatDate(schedule.scheduledDate),
                  ),
                ),
                Container(
                  height: 28,
                  width: 1,
                  color:
                      theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _info(
                    "Actual Date",
                    _formatDate(schedule.actualScheduledDate),
                  ),
                ),
                _statusChip(status),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _info(String title, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 11,
            color: Colors.grey,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _statusChip(String status) {
    Color color;

    switch (status.toUpperCase()) {
      case "COMPLETED":
        color = Colors.green;
        break;
      case "PENDING":
        color = Colors.orange;
        break;
      case "CANCELLED":
        color = Colors.red;
        break;
      default:
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.3,
        ),
      ),
    );
  }

  String _formatDate(DateTime? date) {
    if (date == null) return "-";
    return "${date.day.toString().padLeft(2, '0')}-"
        "${date.month.toString().padLeft(2, '0')}-"
        "${date.year}";
  }
}

Future<void> showAllCalibrationScheduleBottomSheet(
    {required BuildContext context,
    required List<CalibrationScheduleEntity> scheduleList}) async {
  await await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return StatefulBuilder(builder: (context, setState) {
        return Container(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(24),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 50,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Calibration Schedule Record",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 400.h,
                child: ListView.builder(
                  shrinkWrap: true,
                  // physics: const NeverScrollableScrollPhysics(),
                  itemCount: scheduleList.length,
                  itemBuilder: (context, index) {
                    final log = scheduleList[index];
                    return CalibrationScheduleCard(
                      schedule: log,
                      onEdit: () {
                        Navigator.pop(context);
                        showUpdateCalibrationScheduleBottomSheet(
                            context: context,
                            schedule: log,
                            onUpdate: ((
                                {actualScheduledDate,
                                required scheduledDate,
                                required status}) {
                              CalibrationScheduleEntity newSchedule =
                                  log.copyWith(
                                actualScheduledDate: actualScheduledDate,
                                calibrationScheduleId:
                                    log.calibrationScheduleId,
                                scheduledDate: scheduledDate,
                                deviceId: log.deviceId,
                              );

                              context.read<SitesBloc>().add(
                                  UpdateCalibrationScheduleEvent(
                                      siteId: log.deviceId.toString(),
                                      calibration: newSchedule));
                            }));
                      },
                      onViewAll: () {},
                    );
                  },
                ),
              )
            ],
          ),
        );
      });
    },
  );
}

Future<void> showUpdateCalibrationScheduleBottomSheet({
  required BuildContext context,
  required CalibrationScheduleEntity schedule,
  required Function({
    required DateTime scheduledDate,
    required String status,
    DateTime? actualScheduledDate,
  }) onUpdate,
}) async {
  DateTime scheduledDate = schedule.scheduledDate ?? DateTime.now();
  DateTime? actualScheduledDate = schedule.actualScheduledDate;
  String status = schedule.status ?? "PENDING";

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) {
      return StatefulBuilder(
        builder: (context, setState) {
          Future<void> pickDate({
            required bool isActual,
          }) async {
            final picked = await showDatePicker(
              context: context,
              initialDate: isActual
                  ? (actualScheduledDate ?? DateTime.now())
                  : scheduledDate,
              firstDate: DateTime(2020),
              lastDate: DateTime(2100),
            );

            if (picked != null) {
              setState(() {
                if (isActual) {
                  actualScheduledDate = picked;
                } else {
                  scheduledDate = picked;
                }
              });
            }
          }

          return Container(
            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 20,
              bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            ),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(24),
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 50,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Update Calibration Schedule",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 24),

                  /// Scheduled Date
                  const Text(
                    "Actual Scheduled Date",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  InkWell(
                    onTap: () => pickDate(isActual: true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 14,
                      ),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey.shade300,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.calendar_today),
                          const SizedBox(width: 12),
                          Text(
                            DateFormat(
                              "dd MMM yyyy",
                            ).format(scheduledDate),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  /// Status
                  // DropdownButtonFormField<String>(
                  //   initialValue: status,
                  //   decoration: const InputDecoration(
                  //     labelText: "Status",
                  //     border: OutlineInputBorder(),
                  //   ),
                  //   items: const [
                  //     DropdownMenuItem(
                  //       value: "PENDING",
                  //       child: Text("Pending"),
                  //     ),
                  //     DropdownMenuItem(
                  //       value: "COMPLETED",
                  //       child: Text("Completed"),
                  //     ),
                  //     DropdownMenuItem(
                  //       value: "CANCELLED",
                  //       child: Text("Cancelled"),
                  //     ),
                  //   ],
                  //   onChanged: (value) {
                  //     if (value != null) {
                  //       setState(() {
                  //         status = value;

                  //         if (status != "COMPLETED") {
                  //           actualScheduledDate = null;
                  //         }
                  //       });
                  //     }
                  //   },
                  // ),

                  // if (status == "COMPLETED") ...[
                  //   const SizedBox(height: 20),
                  //   const Text(
                  //     "Actual Calibration Date",
                  //     style: TextStyle(
                  //       fontWeight: FontWeight.w600,
                  //     ),
                  //   ),
                  //   const SizedBox(height: 8),
                  //   InkWell(
                  //     onTap: () => pickDate(isActual: true),
                  //     child: Container(
                  //       padding: const EdgeInsets.symmetric(
                  //         horizontal: 16,
                  //         vertical: 14,
                  //       ),
                  //       decoration: BoxDecoration(
                  //         border: Border.all(
                  //           color: Colors.grey.shade300,
                  //         ),
                  //         borderRadius: BorderRadius.circular(12),
                  //       ),
                  //       child: Row(
                  //         children: [
                  //           const Icon(Icons.event),
                  //           const SizedBox(width: 12),
                  //           Text(
                  //             actualScheduledDate == null
                  //                 ? "Select Date"
                  //                 : DateFormat(
                  //                     "dd MMM yyyy",
                  //                   ).format(
                  //                     actualScheduledDate!,
                  //                   ),
                  //           ),
                  //         ],
                  //       ),
                  //     ),
                  //   ),
                  // ],

                  const SizedBox(height: 30),

                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Cancel"),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            onUpdate(
                              scheduledDate: scheduledDate,
                              status: status,
                              actualScheduledDate: actualScheduledDate,
                            );
                          },
                          child: const Text("Update"),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
