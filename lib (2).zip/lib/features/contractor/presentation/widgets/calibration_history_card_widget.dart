import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:vasundhara_maha_aqim/config/theme/colors.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_entity.dart';

class CalibrationHistoryCardWidget extends StatelessWidget {
  final CalibrationHistoryEntity calibration;

  const CalibrationHistoryCardWidget({
    super.key,
    required this.calibration,
  });

  @override
  Widget build(BuildContext context) {
    final isExpired = calibration.nextDueDate != null &&
        calibration.nextDueDate!.isBefore(DateTime.now());
    final formattedCalibrationDate = calibration.calibrationDate != null
        ? DateFormat('dd MMM yyyy').format(calibration.calibrationDate!)
        : '-';
    final formattedDueDate = calibration.nextDueDate != null
        ? DateFormat('dd MMM yyyy').format(calibration.nextDueDate!)
        : '-';
    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 0,
        vertical: 8,
      ),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: 8,
            offset: const Offset(0, 3),
            color: Colors.black.withValues(alpha: 0.08),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.blue.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.precision_manufacturing,
                  color: Colors.blue,
                ),
              ),

              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Calibration",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      "Certificate: ${calibration.certificateNo}",
                      style: TextStyle(
                          fontSize: 12.sp, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),

              /// Status
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: isExpired
                      ? Colors.red.withValues(alpha: 0.12)
                      : Colors.green.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  isExpired ? "Expired" : "Valid",
                  style: TextStyle(
                    color: isExpired ? Colors.red : Colors.green,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              )
            ],
          ),

          const SizedBox(height: 18),

          /// Dates
          Row(
            children: [
              Expanded(
                child: _infoItem(
                  icon: Icons.event,
                  title: "Calibrated On",
                  value: formattedCalibrationDate,
                ),
              ),
              Expanded(
                child: _infoItem(
                  icon: Icons.event_available,
                  title: "Next Due",
                  value: formattedDueDate,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          /// Calibrated By
          _infoRow(
            Icons.business,
            "Calibrated By",
            calibration.calibratedBy ?? "-",
          ),

          const SizedBox(height: 8),

          /// Remarks
          _infoRow(
            Icons.notes,
            "Remarks",
            calibration.remarks ?? "-",
          ),
        ],
      ),
    );
  }

  Widget _infoItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: Colors.grey,
            ),
            const SizedBox(width: 5),
            Text(
              title,
              style: const TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _infoRow(
    IconData icon,
    String title,
    String value,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 18,
          color: Colors.grey,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: RichText(
            text: TextSpan(
              style: const TextStyle(
                color: Colors.black87,
                fontSize: 14,
              ),
              children: [
                TextSpan(
                  text: "$title: ",
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextSpan(
                  text: value,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
