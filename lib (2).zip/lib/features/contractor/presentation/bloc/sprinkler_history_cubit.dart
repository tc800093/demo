import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import '../../data/models/sprinkler_history_model.dart';

abstract class SprinklerHistoryState extends Equatable {
  const SprinklerHistoryState();

  @override
  List<Object?> get props => [];
}

class SprinklerHistoryInitial extends SprinklerHistoryState {}

class SprinklerHistoryLoading extends SprinklerHistoryState {}

class SprinklerHistoryLoaded extends SprinklerHistoryState {
  final SprinklerHistoryResponse historyResponse;

  const SprinklerHistoryLoaded(this.historyResponse);

  @override
  List<Object?> get props => [historyResponse];
}

class SprinklerHistoryError extends SprinklerHistoryState {
  final String message;

  const SprinklerHistoryError(this.message);

  @override
  List<Object?> get props => [message];
}

class SprinklerHistoryCubit extends Cubit<SprinklerHistoryState> {
  SprinklerHistoryCubit() : super(SprinklerHistoryInitial());

  Future<void> loadSprinklerHistory() async {
    emit(SprinklerHistoryLoading());
    try {
      final jsonString = await rootBundle.loadString('lib/data.json');
      final Map<String, dynamic> jsonMap = json.decode(jsonString);
      final response = SprinklerHistoryResponse.fromJson(jsonMap);
      emit(SprinklerHistoryLoaded(response));
    } catch (e) {
      emit(SprinklerHistoryError(e.toString()));
    }
  }
}
