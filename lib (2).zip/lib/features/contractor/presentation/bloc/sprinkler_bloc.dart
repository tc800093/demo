import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../domain/repositories/sites_repository.dart';
import '../../../../core/di/injection.dart';

// --- Events ---
abstract class SprinklerEvent extends Equatable {
  const SprinklerEvent();

  @override
  List<Object?> get props => [];
}

class SprinklerToggleRequested extends SprinklerEvent {
  final String siteId;
  final bool isRunning;

  const SprinklerToggleRequested({required this.siteId, required this.isRunning});

  @override
  List<Object?> get props => [siteId, isRunning];
}

class SprinklerModeChangeRequested extends SprinklerEvent {
  final String siteId;
  final String mode;

  const SprinklerModeChangeRequested({required this.siteId, required this.mode});

  @override
  List<Object?> get props => [siteId, mode];
}

// --- States ---
abstract class SprinklerState extends Equatable {
  const SprinklerState();

  @override
  List<Object?> get props => [];
}

class SprinklerInitial extends SprinklerState {}

class SprinklerLoading extends SprinklerState {}

class SprinklerActionSuccess extends SprinklerState {
  final SiteEntity site;

  const SprinklerActionSuccess(this.site);

  @override
  List<Object?> get props => [site];
}

class SprinklerError extends SprinklerState {
  final String message;

  const SprinklerError(this.message);

  @override
  List<Object?> get props => [message];
}

// --- Bloc ---
class SprinklerBloc extends Bloc<SprinklerEvent, SprinklerState> {
  final SitesRepository _sitesRepository;

  SprinklerBloc() 
      : _sitesRepository = getIt<SitesRepository>(),
        super(SprinklerInitial()) {
    on<SprinklerToggleRequested>(_onSprinklerToggleRequested);
    on<SprinklerModeChangeRequested>(_onSprinklerModeChangeRequested);
  }

  Future<void> _onSprinklerToggleRequested(
    SprinklerToggleRequested event,
    Emitter<SprinklerState> emit,
  ) async {
    emit(SprinklerLoading());
    try {
      final updatedSite = await _sitesRepository.toggleSprinkler(event.siteId, event.isRunning);
      emit(SprinklerActionSuccess(updatedSite));
    } catch (e) {
      emit(SprinklerError(AppException.from(e).toString()));
    }
  }

  Future<void> _onSprinklerModeChangeRequested(
    SprinklerModeChangeRequested event,
    Emitter<SprinklerState> emit,
  ) async {
    emit(SprinklerLoading());
    try {
      final updatedSite = await _sitesRepository.setSprinklerMode(event.siteId, event.mode);
      emit(SprinklerActionSuccess(updatedSite));
    } catch (e) {
      emit(SprinklerError(AppException.from(e).toString()));
    }
  }
}
