import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/notification_history_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/notification_respository.dart';
part 'notification_history_event.dart';
part 'notification_history_state.dart';

class NotificationHistoryBloc
    extends Bloc<NotificationHistoryEvent, NotificationHistoryState> {
  final NotificationRespository notificationRespository;
  NotificationHistoryBloc({required this.notificationRespository})
      : super(const NotificationHistoryState()) {
    on<FetchNotificationHistoryFromRange>(_onFetchNotificationHistoryFromRange);
    on<FilterNotificationByType>(_onFilterNotificationByType);
  }

  FutureOr<void> _onFetchNotificationHistoryFromRange(
      FetchNotificationHistoryFromRange event,
      Emitter<NotificationHistoryState> emit) async {
    try {
      if (!event.isLoadMore) {
        emit(state.copyWith(
            notificationHistoryStatus: NotificationHistoryStatus.loading));
      }

      final nextPage = event.isLoadMore ? state.page + 1 : 0;

      final response = await notificationRespository
          .fetchNotificationRangeWithStartAndEndRepo(
              page: event.page.toString(),
              size: event.size.toString(),
              fromDate: event.startDate,
              toDate: event.endDate);

      final updatedList = event.isLoadMore
          ? [...state.nofificationList, ...response]
          : response;

      emit(state.copyWith(
        notificationHistoryStatus: NotificationHistoryStatus.success,
        nofificationList: updatedList,
        filteredNotificationList: updatedList,
        page: nextPage,
        hasMore: response.length == 20,
      ));
    } catch (e) {
      emit(state.copyWith(
          notificationHistoryStatus: NotificationHistoryStatus.failed,
          message: "something went wrong"));
    }
  }

  FutureOr<void> _onFilterNotificationByType(FilterNotificationByType event,
      Emitter<NotificationHistoryState> emit) async {
    if (event.alertType == null || event.alertType!.isEmpty) {
      emit(state.copyWith(
        filteredNotificationList: state.nofificationList,
      ));

      return;
    }

    final filteredList;
    if (event.alertType.toString().toLowerCase() == "all") {
      filteredList = state.nofificationList;
    } else {
      filteredList = state.nofificationList
          .where((notification) => notification.eventType == event.alertType)
          .toList();
    }

    emit(state.copyWith(
      filteredNotificationList: filteredList,
    ));
  }
}
