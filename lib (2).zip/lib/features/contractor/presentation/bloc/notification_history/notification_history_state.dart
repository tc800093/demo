part of 'notification_history_bloc.dart';

enum NotificationHistoryStatus { init, loading, success, failed }

class NotificationHistoryState extends Equatable {
  final NotificationHistoryStatus notificationHistoryStatus;
  final List<NotificationHistoryEntity> nofificationList;
  final List<NotificationHistoryEntity> filteredNotificationList;
  final String? message;
  final bool hasMore;
  final int page;
  const NotificationHistoryState(
      {this.message = '',
      this.filteredNotificationList = const [],
      this.nofificationList = const [],
      this.hasMore = true,
      this.page = 0,
      this.notificationHistoryStatus = NotificationHistoryStatus.init});

  NotificationHistoryState copyWith(
      {NotificationHistoryStatus? notificationHistoryStatus,
      String? message,
      bool? hasMore,
      int? page,
      List<NotificationHistoryEntity>? nofificationList,
      List<NotificationHistoryEntity>? filteredNotificationList}) {
    return NotificationHistoryState(
        message: message ?? this.message,
        notificationHistoryStatus:
            notificationHistoryStatus ?? this.notificationHistoryStatus,
        nofificationList: nofificationList ?? this.nofificationList,
        hasMore: hasMore ?? this.hasMore,
        filteredNotificationList:
            filteredNotificationList ?? this.filteredNotificationList,
        page: page ?? this.page);
  }

  @override
  List<Object?> get props => [
        message,
        notificationHistoryStatus,
        nofificationList,
        page,
        hasMore,
        filteredNotificationList
      ];
}
