part of 'notification_history_bloc.dart';

abstract class NotificationHistoryEvent extends Equatable {}

class FetchNotificationHistoryFromRange extends NotificationHistoryEvent {
  final String startDate;
  final String endDate;
  final int page;
  final int size;
  final bool isLoadMore;
  FetchNotificationHistoryFromRange(
      {this.page = 1,
      this.size = 10,
      this.isLoadMore = false,
      required this.endDate,
      required this.startDate});

  @override
  List<Object?> get props => [startDate, endDate];
}

class FilterNotificationByType extends NotificationHistoryEvent {
  final String? alertType;

  FilterNotificationByType({
    this.alertType,
  });

  @override
  List<Object?> get props => [alertType];
}
