import 'dart:async';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/calibration_schedule_entity.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../domain/repositories/sites_repository.dart';

// --- Events ---
abstract class SitesEvent extends Equatable {
  const SitesEvent();

  @override
  List<Object?> get props => [];
}

class LoadSites extends SitesEvent {}

class ClearSitesCache extends SitesEvent {}

class LoadSiteDetails extends SitesEvent {
  final String siteId;

  const LoadSiteDetails(this.siteId);

  @override
  List<Object?> get props => [siteId];
}

class AddSite extends SitesEvent {
  final SiteEntity site;

  const AddSite(this.site);

  @override
  List<Object?> get props => [site];
}

class UpdateSites extends SitesEvent {
  final List<SiteEntity> sites;

  const UpdateSites(this.sites);

  @override
  List<Object?> get props => [sites];
}

class FetchLiveData extends SitesEvent {
  const FetchLiveData();

  @override
  List<Object?> get props => [];
}

class RecordCalibration extends SitesEvent {
  final String siteId;
  final CalibrationHistoryEntity calibration;

  const RecordCalibration({required this.siteId, required this.calibration});

  @override
  List<Object?> get props => [siteId, calibration];
}

class UpdateCalibrationEvent extends SitesEvent {
  final String siteId;
  final CalibrationHistoryEntity calibration;

  const UpdateCalibrationEvent(
      {required this.siteId, required this.calibration});

  @override
  List<Object?> get props => [siteId, calibration];
}

class UpdateCalibrationScheduleEvent extends SitesEvent {
  final String siteId;
  final CalibrationScheduleEntity calibration;

  const UpdateCalibrationScheduleEvent(
      {required this.siteId, required this.calibration});

  @override
  List<Object?> get props => [siteId, calibration];
}

// --- States ---
abstract class SitesState extends Equatable {
  const SitesState();

  @override
  List<Object?> get props => [];
}

class SitesInitial extends SitesState {}

class SitesLoading extends SitesState {}

class SitesLoaded extends SitesState {
  final List<SiteEntity> sites;

  const SitesLoaded(this.sites);

  @override
  List<Object?> get props => [sites];
}

class SiteDetailsLoaded extends SitesLoaded {
  final SiteEntity site;

  const SiteDetailsLoaded({required this.site, required List<SiteEntity> sites})
      : super(sites);

  @override
  List<Object?> get props => [site, ...super.props];
}

class SiteAddSuccess extends SitesState {}

class SitesError extends SitesState {
  final String message;

  const SitesError(this.message);

  @override
  List<Object?> get props => [message];
}

// --- Bloc ---
class SitesBloc extends Bloc<SitesEvent, SitesState> {
  final SitesRepository _sitesRepository;
  StreamSubscription? _sitesSubscription;

  SitesBloc(this._sitesRepository) : super(SitesInitial()) {
    on<LoadSites>(_onLoadSites);
    on<LoadSiteDetails>(_onLoadSiteDetails);
    on<AddSite>(_onAddSite);
    on<UpdateSites>(_onUpdateSites);
    on<RecordCalibration>(_onRecordCalibration);
    on<UpdateCalibrationEvent>(_onUpdateCalibrationEvent);
    on<ClearSitesCache>(_onClearSitesCache);
    on<UpdateCalibrationScheduleEvent>(_onUpdateCalibrationScheduleEvent);
    on<FetchLiveData>(_onFetchLiveData);

    _sitesRepository.liveDataStream.listen((data) {
      add(UpdateSites(data));
    });

    // Single listener for site updates from the repository stream
    // _sitesSubscription = _sitesRepository.sitesStream.listen((sites) {
    //   log("listen the data from stream ");
    //   add(UpdateSites(sites));
    // });

    _sitesRepository.initializeWebSocket();
  }

  @override
  Future<void> close() async {
    _sitesSubscription?.cancel();
    _sitesRepository.disconnectWebSocket();
    return super.close();
  }

  void _onClearSitesCache(ClearSitesCache event, Emitter<SitesState> emit) {
    emit(SitesInitial());
  }

  Future<void> _onLoadSites(LoadSites event, Emitter<SitesState> emit) async {
    emit(SitesLoading());
    try {
      final sites = await _sitesRepository.getSites();
      emit(SitesLoaded(sites));
    } catch (e) {
      emit(SitesError(AppException.from(e).toString()));
    }
  }

  Future<void> _onLoadSiteDetails(
      LoadSiteDetails event, Emitter<SitesState> emit) async {
    emit(SitesLoading());
    try {
      final site = await _sitesRepository.getSiteDetails(event.siteId);
      final sites = await _sitesRepository.getSites();
      emit(SiteDetailsLoaded(site: site, sites: sites));
    } catch (e) {
      emit(SitesError(AppException.from(e).toString()));
    }
  }

  Future<void> _onAddSite(AddSite event, Emitter<SitesState> emit) async {
    emit(SitesLoading());
    try {
      await _sitesRepository.addSite(event.site);
      emit(SiteAddSuccess());
      // Reload sites
      final sites = await _sitesRepository.getSites();
      emit(SitesLoaded(sites));
    } catch (e) {
      emit(SitesError(AppException.from(e).toString()));
    }
  }

  void _onUpdateSites(UpdateSites event, Emitter<SitesState> emit) {
    final currentState = state;
    if (currentState is SiteDetailsLoaded) {
      final updatedSite = event.sites.firstWhere(
        (s) => s.id == currentState.site.id,
        orElse: () => currentState.site,
      );
      emit(SiteDetailsLoaded(site: updatedSite, sites: event.sites));
    } else if (currentState is SitesLoaded) {
      emit(SitesLoaded(event.sites));
    }
  }

  Future<void> _onRecordCalibration(
      RecordCalibration event, Emitter<SitesState> emit) async {
    try {
      await _sitesRepository.recordCalibration(event.siteId, event.calibration);
      final site = await _sitesRepository.getSiteDetails(event.siteId);
      final sites = await _sitesRepository.getSites();
      emit(SiteDetailsLoaded(site: site, sites: sites));
    } catch (e) {
      emit(SitesError(AppException.from(e).toString()));
    }
  }

  Future<void> _onUpdateCalibrationEvent(
      UpdateCalibrationEvent event, Emitter<SitesState> emit) async {
    try {
      await _sitesRepository.updateCalibrationRecord(
          event.siteId, event.calibration);
      final site = await _sitesRepository.getSiteDetails(event.siteId);
      final sites = await _sitesRepository.getSites();
      emit(SiteDetailsLoaded(site: site, sites: sites));
    } catch (e) {
      emit(SitesError(AppException.from(e).toString()));
    }
  }

  FutureOr<void> _onUpdateCalibrationScheduleEvent(
      UpdateCalibrationScheduleEvent event, Emitter<SitesState> emit) async {
    try {
      await _sitesRepository.updateCalibrationSchedule(
          event.siteId, event.calibration);
      final site = await _sitesRepository.getSiteDetails(event.siteId);
      final sites = await _sitesRepository.getSites();
      emit(SiteDetailsLoaded(site: site, sites: sites));
    } catch (e, trace) {
      debugPrint("error for teh update schedule  $e \n $trace");
      emit(SitesError(AppException.from(e).toString()));
    }
  }

  FutureOr<void> _onFetchLiveData(
      FetchLiveData event, Emitter<SitesState> emit) async {
    // The repository already subscribes to WebSocket internally.
    // Just ensure the connection is active — no additional listener needed.
    await _sitesRepository.connectWebSocket();
  }
}
