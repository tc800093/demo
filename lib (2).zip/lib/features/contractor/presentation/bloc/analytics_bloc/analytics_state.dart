part of 'analytics_bloc.dart';

enum AnalyticsStatus {
  initial,
  loading,
  success,
  failure,
}

enum AnalyticsDailySummaryStatus {
  initial,
  loading,
  success,
  failure,
}

enum AnalyticsDayWiseStatus {
  initial,
  loading,
  success,
  failure,
}

class AnalyticsState extends Equatable {
  final AnalyticsStatus status;
  final String message;
  final AnalyticsDailyIntervalEntity? analyticsDailyIntervalEntity;
  final List<AnalyticsDayWiseEntity>? analyticsDayWise;
  final AnalyticsDailySummaryStatus? dailySummaryStatus;
  final AnalyticsDayWiseStatus? dayWiseStatus;

  AnalyticsState(
      {this.status = AnalyticsStatus.initial,
      this.message = '',
      this.analyticsDailyIntervalEntity,
      this.analyticsDayWise = const [],
      this.dailySummaryStatus = AnalyticsDailySummaryStatus.initial,
      this.dayWiseStatus = AnalyticsDayWiseStatus.initial});

  AnalyticsState copyWith(
      {AnalyticsStatus? status,
      String? message,
      AnalyticsDailyIntervalEntity? analyticsDailyIntervalEntity,
      List<AnalyticsDayWiseEntity>? analyticsDayWise,
      AnalyticsDailySummaryStatus? dailySummaryStatus,
      AnalyticsDayWiseStatus? dayWiseStatus}) {
    return AnalyticsState(
        status: status ?? this.status,
        message: message ?? this.message,
        analyticsDailyIntervalEntity:
            analyticsDailyIntervalEntity ?? this.analyticsDailyIntervalEntity,
        analyticsDayWise: analyticsDayWise ?? this.analyticsDayWise,
        dailySummaryStatus: dailySummaryStatus ?? this.dailySummaryStatus,
        dayWiseStatus: dayWiseStatus ?? this.dayWiseStatus);
  }

  @override
  List<Object?> get props => [
        status,
        message,
        analyticsDailyIntervalEntity,
        analyticsDayWise,
        dayWiseStatus,
        dailySummaryStatus
      ];
}
