import 'dart:async';
import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/rendering.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_daily_interval_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/entities/analytics_day_wise_entity.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/analytics_repository.dart';

part 'analytics_event.dart';
part 'analytics_state.dart';

class AnalyticsBloc extends Bloc<AnalyticsEvent, AnalyticsState> {
  final AnalyticsRepository repository;
  AnalyticsBloc({required this.repository}) : super(AnalyticsState()) {
    on<FetchAnalytics>(_onFetchAnalytics);
    on<FetchDailySummaryEvent>(_onFetchDailySummaryEvent);
    on<FetchDayWiseEvent>(_onFetchDayWiseEvent);
  }

  FutureOr<void> _onFetchDailySummaryEvent(
      FetchDailySummaryEvent event, Emitter<AnalyticsState> emit) async {
    try {
      emit(state.copyWith(
          dailySummaryStatus: AnalyticsDailySummaryStatus.loading));
      final result = await repository.fetchAQIAnalyticsRepo(
          event.imeiNo, event.date, event.interval.toString());

      if (result != null) {
        emit(state.copyWith(
            dailySummaryStatus: AnalyticsDailySummaryStatus.success,
            analyticsDailyIntervalEntity: result));
      } else {
        emit(state.copyWith(
            dailySummaryStatus: AnalyticsDailySummaryStatus.failure,
            message: 'no data found'));
      }
    } catch (e) {
      debugPrint("analytics daily summary bloc error $e");

      emit(state.copyWith(
          dailySummaryStatus: AnalyticsDailySummaryStatus.failure,
          message: "something went wrong"));
    }
  }

  FutureOr<void> _onFetchDayWiseEvent(
      FetchDayWiseEvent event, Emitter<AnalyticsState> emit) async {
    try {
      emit(state.copyWith(
          dayWiseStatus: AnalyticsDayWiseStatus.loading, message: ''));
      final result = await repository.fetchAQIDayWiseAnalyticsRepo(
          event.imeiNo, event.fromdate, event.toDate);

      if (result.isNotEmpty) {
        emit(state.copyWith(
            dayWiseStatus: AnalyticsDayWiseStatus.success,
            analyticsDayWise: result));
      } else {
        emit(state.copyWith(
            dayWiseStatus: AnalyticsDayWiseStatus.failure,
            message: 'Data not  found'));
      }
    } catch (e) {
      emit(state.copyWith(
          dayWiseStatus: AnalyticsDayWiseStatus.failure,
          message: 'something went wrong'));
      log("analytics day wise  bloc error $e");
    }
  }

  FutureOr<void> _onFetchAnalytics(
      FetchAnalytics event, Emitter<AnalyticsState> emit) async {
    try {
      emit(state.copyWith(status: AnalyticsStatus.loading, message: ""));
      final results = await Future.wait([
        repository.fetchAQIAnalyticsRepo(
            event.imeiNo, event.toDate, event.interval.toString()),
        repository.fetchAQIDayWiseAnalyticsRepo(
            event.imeiNo, event.fromdate, event.toDate)
      ]);

      final intervalWise = results[0] as AnalyticsDailyIntervalEntity?;
      final dayWiseData = results[1] as List<AnalyticsDayWiseEntity>?;
      emit(state.copyWith(
          status: AnalyticsStatus.success,
          dailySummaryStatus: intervalWise != null
              ? AnalyticsDailySummaryStatus.success
              : AnalyticsDailySummaryStatus.failure,
          dayWiseStatus: dayWiseData != null
              ? AnalyticsDayWiseStatus.success
              : AnalyticsDayWiseStatus.failure,
          message: "",
          analyticsDailyIntervalEntity: intervalWise,
          analyticsDayWise: dayWiseData));
    } catch (e) {
      emit(state.copyWith(
          status: AnalyticsStatus.failure, message: "something went wrong"));
    }
  }
}
