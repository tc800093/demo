part of 'analytics_bloc.dart';

abstract class AnalyticsEvent extends Equatable {}

class FetchAnalytics extends AnalyticsEvent {
  final String imeiNo;
  final String fromdate;
  final String toDate;
  final String? interval;
  FetchAnalytics(
      {required this.fromdate,
      required this.imeiNo,
      required this.toDate,
      this.interval = '1'});
  @override
  List<Object?> get props => [imeiNo, fromdate, toDate, interval];
}

class FetchDailySummaryEvent extends AnalyticsEvent {
  final String imeiNo;
  final String date;
  final String? interval;
  FetchDailySummaryEvent(
      {required this.date, required this.imeiNo, this.interval = '1'});

  @override
  List<Object?> get props => [imeiNo, date, interval];
}

class FetchDayWiseEvent extends AnalyticsEvent {
  final String imeiNo;
  final String fromdate;
  final String toDate;
  FetchDayWiseEvent({
    required this.fromdate,
    required this.imeiNo,
    required this.toDate,
  });

  @override
  List<Object?> get props => [imeiNo, fromdate, toDate];
}
