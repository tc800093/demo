import 'package:equatable/equatable.dart';
import '../../../auth/domain/repositories/auth_repository.dart';

class CustomerEntity extends Equatable {
  final int? srNo;
  final String customerId;
  final String fullName;
  final String? firmName;
  final String mobileNo;
  final String email;
  final UserRole role;
  final bool active;
  final String? createdAt;
  final String? createdBy;
  final bool isSubUser;
  final String? parentCustomerId;
  final String? parentUserName;

  const CustomerEntity({
    this.srNo,
    required this.customerId,
    required this.fullName,
    this.firmName,
    required this.mobileNo,
    required this.email,
    required this.role,
    required this.active,
    this.createdAt,
    this.createdBy,
    required this.isSubUser,
    this.parentCustomerId,
    this.parentUserName,
  });

  @override
  List<Object?> get props => [
        srNo,
        customerId,
        fullName,
        firmName,
        mobileNo,
        email,
        role,
        active,
        createdAt,
        createdBy,
        isSubUser,
        parentCustomerId,
        parentUserName,
      ];

  CustomerEntity copyWith({
    int? srNo,
    String? customerId,
    String? fullName,
    String? firmName,
    String? mobileNo,
    String? email,
    UserRole? role,
    bool? active,
    String? createdAt,
    String? createdBy,
    bool? isSubUser,
    String? parentCustomerId,
    String? parentUserName,
  }) {
    return CustomerEntity(
      srNo: srNo ?? this.srNo,
      customerId: customerId ?? this.customerId,
      fullName: fullName ?? this.fullName,
      firmName: firmName ?? this.firmName,
      mobileNo: mobileNo ?? this.mobileNo,
      email: email ?? this.email,
      role: role ?? this.role,
      active: active ?? this.active,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
      isSubUser: isSubUser ?? this.isSubUser,
      parentCustomerId: parentCustomerId ?? this.parentCustomerId,
      parentUserName: parentUserName ?? this.parentUserName,
    );
  }
}
