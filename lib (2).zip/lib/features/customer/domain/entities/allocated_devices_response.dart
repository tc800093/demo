import '../../../admin/domain/entities/device_entity.dart';

/// Response wrapper for the allocated devices API.
class AllocatedDevicesResponse {
  final List<DeviceEntity> devices;
  final int currentPage;
  final int pageSize;
  final int totalItems;
  final int totalPages;

  const AllocatedDevicesResponse({
    required this.devices,
    required this.currentPage,
    required this.pageSize,
    required this.totalItems,
    required this.totalPages,
  });
}
