// features/customer/domain/repositories/customer_repository.dart
import '../entities/customer_entity.dart';
import '../entities/allocated_devices_response.dart';
import '../../../auth/domain/repositories/auth_repository.dart';

abstract class CustomerRepository {
  Future<List<CustomerEntity>> getCustomers(
      {int page = 0, int size = 10, String? search, String? parentCustomerId});
  Future<CustomerEntity> getCustomerDetails(String customerId);
  Future<CustomerEntity> saveCustomer({
    required String fullName,
    String? firmName,
    required String mobileNo,
    required String email,
    required String password,
    required UserRole role,
    required bool active,
  });
  Future<CustomerEntity> updateCustomer(CustomerEntity customer,
      {String? password});
  Future<AllocatedDevicesResponse> getAllocatedDevices(String customerId,
      {int page = 0, int size = 10, String? search, String? role});
  Future<void> removeDevice(String deviceId);
  Future<void> assignDevicesToSubUser({
    required String subUserId,
    required List<String> deviceIds,
    required String remark,
  });
  Future<void> deallocateDeviceFromSubUser({
    required String subUserId,
    required List<String> deviceIds,
    required String remark,
  });
  Future<void> deleteCustomer({
    required String customerId,
    bool removeDevices = false,
  });
}
