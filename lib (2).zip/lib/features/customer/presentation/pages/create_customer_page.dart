// features/customer/presentation/pages/create_customer_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../bloc/customer_bloc.dart';
import '../../domain/entities/customer_entity.dart';
import '../../data/models/customer_model.dart';

class CreateCustomerPage extends StatefulWidget {
  final CustomerEntity? customerToEdit;

  const CreateCustomerPage({super.key, this.customerToEdit});

  @override
  State<CreateCustomerPage> createState() => _CreateCustomerPageState();
}

class _CreateCustomerPageState extends State<CreateCustomerPage> {
  final _formKey = GlobalKey<FormState>();

  final _fullNameController = TextEditingController();
  final _firmNameController = TextEditingController();
  final _mobileController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  UserRole _selectedRole = UserRole.user;
  bool _isActive = true;
  bool _obscurePassword = true;

  List<UserRole> _availableRoles = [UserRole.user];

  @override
  void initState() {
    super.initState();
    _determineAvailableRoles();
    if (widget.customerToEdit != null) {
      _fullNameController.text = widget.customerToEdit!.fullName;
      _firmNameController.text = widget.customerToEdit!.firmName ?? '';
      _mobileController.text = widget.customerToEdit!.mobileNo;
      _emailController.text = widget.customerToEdit!.email;
      _selectedRole = widget.customerToEdit!.role;
      _isActive = widget.customerToEdit!.active;
    }
  }

  void _determineAvailableRoles() {
    final authState = context.read<AuthBloc>().state;
    if (authState is AuthAuthenticated) {
      final parentRole = authState.user.role;
      switch (parentRole) {
        case UserRole.admin:
          _availableRoles = [UserRole.user];
          if (widget.customerToEdit != null &&
              widget.customerToEdit!.role == UserRole.subAdmin) {
            _availableRoles.insert(0, UserRole.subAdmin);
          }
          _selectedRole = widget.customerToEdit?.role ?? UserRole.user;
          break;
        case UserRole.subAdmin:
          _availableRoles = [UserRole.user];
          _selectedRole = widget.customerToEdit?.role ?? UserRole.user;
          break;
        case UserRole.user:
          _availableRoles = [UserRole.subUser];
          _selectedRole = widget.customerToEdit?.role ?? UserRole.subUser;
          break;
        default:
          _availableRoles = [UserRole.subUser];
          _selectedRole = widget.customerToEdit?.role ?? UserRole.subUser;
      }
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _firmNameController.dispose();
    _mobileController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    final authState = context.read<AuthBloc>().state;
    UserRole? parentRole;
    if (authState is AuthAuthenticated) {
      parentRole = authState.user.role;
    }

    String screenTitle =
        widget.customerToEdit != null ? 'Edit User' : 'Create User';
    if (parentRole == UserRole.user) {
      screenTitle = widget.customerToEdit != null
          ? 'Edit Sub-Customer'
          : 'Add Sub-Customer';
    }

    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: Text(
          screenTitle,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18.sp,
            fontFamily: 'Poppins',
          ),
        ),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: BlocListener<CustomerBloc, CustomerState>(
        listener: (context, state) {
          if (state is CustomerActionSuccess) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.online,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
            );
            context.pop();
          } else if (state is CustomerError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.aqiRed,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
            );
          }
        },
        child: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(20.r),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header note
                  Text(
                    widget.customerToEdit != null
                        ? 'Update User Details'
                        : 'Setup User Details',
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    widget.customerToEdit != null
                        ? 'Update details below to modify user permissions and attributes.'
                        : 'Provide details below to provision a new user on the Maha AQI platform.',
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Fields Container
                  ScadaCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Full Name
                        _buildLabel('Full Name'),
                        TextFormField(
                          controller: _fullNameController,
                          textCapitalization: TextCapitalization.words,
                          decoration: _buildInputDecoration(
                              'Enter full name', Icons.person_outline_rounded),
                          // validator: (value) {
                          //   if (value == null || value.trim().isEmpty) {
                          //     return 'Please enter a full name';
                          //   }
                          //   return null;
                          // },
                        ),
                        SizedBox(height: 16.h),

                        // Firm Name
                        _buildLabel('Firm / Company Name'),
                        TextFormField(
                          controller: _firmNameController,
                          textCapitalization: TextCapitalization.words,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Please enter company/firm name';
                            }
                            return null;
                          },
                          decoration: _buildInputDecoration(
                              'Enter company/firm name',
                              Icons.business_outlined),
                        ),
                        SizedBox(height: 16.h),

                        // Mobile No
                        _buildLabel('Mobile Number'),
                        TextFormField(
                          controller: _mobileController,
                          keyboardType: TextInputType.phone,
                          maxLength: 10,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          decoration: _buildInputDecoration(
                              'Enter 10-digit mobile number',
                              Icons.phone_android_rounded),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Please enter a mobile number';
                            }
                            final trimmed = value.trim();
                            if (trimmed.length != 10) {
                              return 'Please enter a valid 10-digit mobile number';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 16.h),

                        // Email
                        _buildLabel('Email Address'),
                        TextFormField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: _buildInputDecoration(
                              'Enter email address', Icons.email_outlined),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Please enter an email address';
                            }
                            if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                .hasMatch(value.trim())) {
                              return 'Please enter a valid email address';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 16.h),

                        // Password
                        _buildLabel('Password'),
                        TextFormField(
                          controller: _passwordController,
                          obscureText: _obscurePassword,
                          decoration: _buildInputDecoration(
                            'Enter login password',
                            Icons.lock_outline_rounded,
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword
                                    ? Icons.visibility_off_rounded
                                    : Icons.visibility_rounded,
                                color: AppColors.textSecondary,
                                size: 20.r,
                              ),
                              onPressed: () {
                                setState(() {
                                  _obscurePassword = !_obscurePassword;
                                });
                              },
                            ),
                          ),
                          validator: (value) {
                            if (widget.customerToEdit == null &&
                                (value == null || value.trim().isEmpty)) {
                              return 'Please enter a password';
                            }
                            if (value != null &&
                                value.trim().isNotEmpty &&
                                value.trim().length < 4) {
                              return 'Password must be at least 4 characters';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 16.h),

                        // Role Selection
                        if (_availableRoles.length > 1) ...[
                          _buildLabel('User Role'),
                          DropdownButtonFormField<UserRole>(
                            initialValue: _selectedRole,
                            decoration:
                                _buildInputDecoration('', Icons.badge_outlined),
                            items: _availableRoles.map((role) {
                              String label = 'Customer';
                              if (role == UserRole.subAdmin) {
                                label = 'Sub Admin';
                              }
                              if (role == UserRole.subUser) {
                                label = 'Sub Customer';
                              }
                              return DropdownMenuItem<UserRole>(
                                value: role,
                                child: Text(label),
                              );
                            }).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                setState(() {
                                  _selectedRole = val;
                                });
                              }
                            },
                          ),
                          SizedBox(height: 16.h),
                        ] else ...[
                          // Fixed single role display
                          _buildLabel('User Role'),
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                                horizontal: 12.w, vertical: 12.h),
                            decoration: BoxDecoration(
                              color: AppColors.background,
                              borderRadius: BorderRadius.circular(10.r),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.badge_outlined,
                                    color: AppColors.textSecondary, size: 20.r),
                                SizedBox(width: 10.w),
                                Text(
                                  _selectedRole == UserRole.subUser
                                      ? 'Sub Customer'
                                      : 'Customer',
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 16.h),
                        ],

                        // Status Switch
                        Row(
                          children: [
                            Icon(Icons.power_settings_new_rounded,
                                color: AppColors.textSecondary, size: 20.r),
                            SizedBox(width: 10.w),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Account Status',
                                    style: TextStyle(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                  Text(
                                    _isActive ? 'Active' : 'Inactive',
                                    style: TextStyle(
                                      fontSize: 11.sp,
                                      color: _isActive
                                          ? AppColors.online
                                          : AppColors.aqiRed,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Switch.adaptive(
                              value: _isActive,
                              activeThumbColor: AppColors.primary,
                              onChanged: (val) {
                                setState(() {
                                  _isActive = val;
                                });
                              },
                            ),
                          ],
                        ),
                        SizedBox(height: 16.h),
                      ],
                    ),
                  ),

                  SizedBox(height: 30.h),

                  // Submit Button
                  BlocBuilder<CustomerBloc, CustomerState>(
                    builder: (context, state) {
                      final isLoading = state is CustomerLoading;
                      return PrimaryButton(
                        text: widget.customerToEdit != null
                            ? 'Save Changes'
                            : 'Save User',
                        icon: Icons.save_rounded,
                        isLoading: isLoading,
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            if (widget.customerToEdit != null) {
                              final updated = CustomerModel(
                                customerId: widget.customerToEdit!.customerId,
                                fullName: _fullNameController.text.trim(),
                                firmName: _firmNameController.text.trim(),
                                mobileNo: _mobileController.text.trim(),
                                email: _emailController.text.trim(),
                                role: _selectedRole,
                                active: _isActive,
                                isSubUser: _selectedRole == UserRole.subUser,
                                parentCustomerId:
                                    widget.customerToEdit!.parentCustomerId,
                                parentUserName:
                                    widget.customerToEdit!.parentUserName,
                              );
                              context.read<CustomerBloc>().add(
                                    UpdateCustomerDetails(
                                      customer: updated,
                                      password:
                                          _passwordController.text.isNotEmpty
                                              ? _passwordController.text
                                              : null,
                                    ),
                                  );
                            } else {
                              context.read<CustomerBloc>().add(
                                    CreateCustomer(
                                      fullName: _fullNameController.text.trim(),
                                      firmName: _firmNameController.text.trim(),
                                      mobileNo: _mobileController.text.trim(),
                                      email: _emailController.text.trim(),
                                      password: _passwordController.text,
                                      role: _selectedRole,
                                      active: _isActive,
                                    ),
                                  );
                            }
                          }
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 6.h),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12.sp,
          fontWeight: FontWeight.bold,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String hint, IconData prefixIcon,
      {Widget? suffixIcon}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(
        color: AppColors.textMuted,
        fontSize: 13.sp,
      ),
      prefixIcon: Icon(
        prefixIcon,
        color: AppColors.textSecondary,
        size: 20.r,
      ),
      suffixIcon: suffixIcon,
      fillColor: AppColors.surface,
      filled: true,
      contentPadding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 12.w),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(color: AppColors.border, width: 1.r),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(color: AppColors.border, width: 1.r),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(color: AppColors.primary, width: 1.5.r),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(color: AppColors.aqiRed, width: 1.r),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(color: AppColors.aqiRed, width: 1.5.r),
      ),
    );
  }
}
