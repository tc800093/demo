// features/customer/presentation/pages/customer_details_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/custom_widgets.dart';
import '../../../../core/di/injection.dart';
import '../../../../app/router/router.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../../../admin/domain/entities/device_entity.dart';
import '../../../contractor/presentation/widgets/contractor_device_detail_sheet.dart';
import '../../domain/entities/customer_entity.dart';
import '../../domain/repositories/customer_repository.dart';
import '../bloc/customer_bloc.dart';

class CustomerDetailsPage extends StatefulWidget {
  final CustomerEntity customer;

  const CustomerDetailsPage({super.key, required this.customer});

  @override
  State<CustomerDetailsPage> createState() => _CustomerDetailsPageState();
}

class _CustomerDetailsPageState extends State<CustomerDetailsPage> {
  late bool _isActive;
  late CustomerEntity _currentCustomer;
  bool _isToggling = false;

  // Allocated devices state
  List<DeviceEntity> _allocatedDevices = [];
  bool _isLoadingDevices = true;
  String? _devicesError;
  int _totalDevices = 0;
  bool _isDeassignMode = false;
  final Set<String> _selectedDeassignDeviceIds = {};

  // Subcontractor list state
  List<CustomerEntity> _subcontractors = [];
  bool _isLoadingSubcontractors = false;
  String? _subcontractorsError;

  UserRole? get _currentUserRole {
    final authState = context.read<AuthBloc>().state;
    if (authState is AuthAuthenticated) {
      return authState.user.role;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _currentCustomer = widget.customer;
    _isActive = widget.customer.active;
    _fetchAllocatedDevices();
    if (_currentCustomer.role == UserRole.user) {
      _fetchSubcontractors();
    }
  }

  Future<void> _fetchAllocatedDevices() async {
    setState(() {
      _isLoadingDevices = true;
      _devicesError = null;
    });
    try {
      final response = await getIt<CustomerRepository>().getAllocatedDevices(
        _currentCustomer.customerId,
        page: 0,
        size: 20,
        role: _currentCustomer.role == UserRole.subUser ? 'Sub_User' : null,
      );

      if (mounted) {
        setState(() {
          _allocatedDevices = response.devices;
          _totalDevices = response.totalItems;
          _isLoadingDevices = false;
          _selectedDeassignDeviceIds.clear();
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _devicesError = e.toString();
          _isLoadingDevices = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    final currentUserRole = _currentUserRole;

    String initials = 'U';
    final trimmedName = _currentCustomer.firmName!.trim();
    if (trimmedName.isNotEmpty) {
      final parts = trimmedName.split(' ').where((e) => e.isNotEmpty).toList();
      if (parts.isNotEmpty) {
        initials = parts.map((e) => e[0]).take(2).join().toUpperCase();
      }
    }

    final Color roleColor = _currentCustomer.role == UserRole.admin
        ? Colors.blue
        : _currentCustomer.role == UserRole.subAdmin
            ? Colors.teal
            : _currentCustomer.role == UserRole.user
                ? Colors.orange
                : Colors.purple;

    final String roleName = _currentCustomer.role == UserRole.admin
        ? 'Platform Administrator'
        : _currentCustomer.role == UserRole.subAdmin
            ? 'Sub Administrator'
            : _currentCustomer.role == UserRole.user
                ? 'Customer'
                : 'Sub Customer';

    return Scaffold(
      backgroundColor: colors.background,
      bottomNavigationBar: _isDeassignMode ? _buildDeassignBottomBar() : null,
      appBar: AppBar(
        title: Text(
          'User Management',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18.sp,
            fontFamily: 'Poppins',
          ),
        ),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: BlocListener<CustomerBloc, CustomerState>(
        listener: (context, state) {
          if (state is CustomerActionSuccess) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.online,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
            );
            // Keep the optimistic toggle value — update _currentCustomer to match
            setState(() {
              _isToggling = false;
              _currentCustomer = _currentCustomer.copyWith(active: _isActive);
            });
          } else if (state is CustomerError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.aqiRed,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
            );
            // Revert toggle on error — restore original value from _currentCustomer
            setState(() {
              _isToggling = false;
              _isActive = _currentCustomer.active;
            });
          } else if (state is CustomersLoaded) {
            // Find updated user in reloaded list and sync local state
            final updatedUser = state.customers.firstWhere(
              (u) => u.customerId == _currentCustomer.customerId,
              orElse: () => _currentCustomer,
            );
            if (mounted) {
              setState(() {
                _isToggling = false;
                _currentCustomer = updatedUser;
                _isActive = updatedUser.active;
              });
            }
          }
        },
        child: Stack(
          children: [
            SafeArea(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(20.r),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Profile Header Card
                    ScadaCard(
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 36.r,
                            backgroundColor: roleColor.withValues(alpha: 0.15),
                            child: Text(
                              initials,
                              style: TextStyle(
                                fontSize: 24.sp,
                                fontWeight: FontWeight.bold,
                                color: roleColor,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                          SizedBox(height: 12.h),
                          Text(
                            _currentCustomer.firmName != null
                                ? _currentCustomer.firmName.toString()
                                : '',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.bold,
                              color: colors.textPrimary,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            _currentCustomer.fullName.isNotEmpty == true
                                ? _currentCustomer.fullName
                                : 'No Name',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 13.sp,
                              color: colors.textSecondary,
                            ),
                          ),
                          SizedBox(height: 16.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12.w, vertical: 4.h),
                                decoration: BoxDecoration(
                                  color: roleColor.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(20.r),
                                  border: Border.all(
                                      color: roleColor.withValues(alpha: 0.3)),
                                ),
                                child: Text(
                                  roleName,
                                  style: TextStyle(
                                    fontSize: 10.sp,
                                    fontWeight: FontWeight.bold,
                                    color: roleColor,
                                  ),
                                ),
                              ),
                              SizedBox(width: 8.w),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12.w, vertical: 4.h),
                                decoration: BoxDecoration(
                                  color: (_isActive
                                          ? AppColors.online
                                          : AppColors.aqiRed)
                                      .withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(20.r),
                                  border: Border.all(
                                    color: (_isActive
                                            ? AppColors.online
                                            : AppColors.aqiRed)
                                        .withValues(alpha: 0.3),
                                  ),
                                ),
                                child: Text(
                                  _isActive ? 'ACTIVE' : 'SUSPENDED',
                                  style: TextStyle(
                                    fontSize: 10.sp,
                                    fontWeight: FontWeight.bold,
                                    color: _isActive
                                        ? AppColors.online
                                        : AppColors.aqiRed,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20.h),

                    // Information details Card
                    Text(
                      'Account Details',
                      style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold,
                        color: colors.textPrimary,
                        fontFamily: 'Poppins',
                      ),
                    ),
                    SizedBox(height: 8.h),
                    ScadaCard(
                      padding: EdgeInsets.zero,
                      child: Column(
                        children: [
                          _buildDetailRow(Icons.phone_rounded, 'Mobile Number',
                              _currentCustomer.mobileNo),
                          Divider(color: colors.border, height: 1),
                          _buildDetailRow(Icons.email_rounded, 'Email Address',
                              _currentCustomer.email),
                          Divider(color: colors.border, height: 1),
                          if (_currentCustomer.createdAt != null) ...[
                            _buildDetailRow(
                                Icons.calendar_today_rounded,
                                'Registration Date',
                                _currentCustomer.createdAt!.split('T')[0]),
                            Divider(color: colors.border, height: 1),
                          ],
                          _buildDetailRow(Icons.badge_rounded,
                              'Access Permission', roleName),
                          if (_currentCustomer.isSubUser &&
                              (_currentCustomer.parentUserName != null ||
                                  _currentCustomer.parentCustomerId !=
                                      null)) ...[
                            Divider(color: colors.border, height: 1),
                            _buildDetailRow(
                              Icons.link_rounded,
                              'Assigned By',
                              _currentCustomer.parentUserName != null &&
                                      _currentCustomer
                                          .parentUserName!.isNotEmpty
                                  ? _currentCustomer.parentUserName!
                                  : (_currentCustomer.parentCustomerId!.length >
                                          22
                                      ? '${_currentCustomer.parentCustomerId!.substring(0, 22)}...'
                                      : _currentCustomer.parentCustomerId!),
                            ),
                          ],
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),

                    // Allocated Devices Section
                    Row(
                      children: [
                        Text(
                          'Allocated Devices',
                          style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.bold,
                            color: colors.textPrimary,
                            fontFamily: 'Poppins',
                          ),
                        ),
                        SizedBox(width: 8.w),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 8.w, vertical: 2.h),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Text(
                            '$_totalDevices',
                            style: TextStyle(
                              fontSize: 11.sp,
                              fontWeight: FontWeight.bold,
                              color: AppColors.primary,
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ),
                        const Spacer(),
                        if (currentUserRole == UserRole.user &&
                            !_isDeassignMode)
                          PopupMenuButton<String>(
                            icon: Icon(
                              Icons.more_vert_rounded,
                              color: colors.textSecondary,
                              size: 22.r,
                            ),
                            tooltip: 'Manage Devices',
                            onSelected: (value) {
                              if (value == 'assign') {
                                context
                                    .push(AppRoutes.contractorAssignDevices,
                                        extra: _currentCustomer)
                                    .then((val) {
                                  if (val == true) {
                                    _fetchAllocatedDevices();
                                  }
                                });
                              } else if (value == 'deassign') {
                                setState(() {
                                  _isDeassignMode = true;
                                  _selectedDeassignDeviceIds.clear();
                                });
                              }
                            },
                            itemBuilder: (context) => [
                              PopupMenuItem(
                                value: 'assign',
                                child: Row(
                                  children: [
                                    Icon(Icons.add_link_rounded,
                                        size: 18.r, color: AppColors.primary),
                                    SizedBox(width: 8.w),
                                    Text(
                                      'Assign New Devices',
                                      style: TextStyle(
                                        fontSize: 12.sp,
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (_allocatedDevices.isNotEmpty)
                                PopupMenuItem(
                                  value: 'deassign',
                                  child: Row(
                                    children: [
                                      Icon(Icons.link_off_rounded,
                                          size: 18.r, color: AppColors.aqiRed),
                                      SizedBox(width: 8.w),
                                      Text(
                                        'Deassign Devices',
                                        style: TextStyle(
                                          fontSize: 12.sp,
                                          color: AppColors.aqiRed,
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                      ],
                    ),
                    if (currentUserRole == UserRole.user &&
                        _isDeassignMode &&
                        _allocatedDevices.isNotEmpty) ...[
                      SizedBox(height: 8.h),
                      Row(
                        children: [
                          SizedBox(
                            width: 24.w,
                            height: 24.h,
                            child: Checkbox(
                              value: _selectedDeassignDeviceIds.length ==
                                      _allocatedDevices.length &&
                                  _allocatedDevices.isNotEmpty,
                              onChanged: (val) {
                                setState(() {
                                  if (val == true) {
                                    _selectedDeassignDeviceIds.addAll(
                                      _allocatedDevices.map((e) => e.deviceId),
                                    );
                                  } else {
                                    _selectedDeassignDeviceIds.clear();
                                  }
                                });
                              },
                              activeColor: AppColors.aqiRed,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                            ),
                          ),
                          SizedBox(width: 8.w),
                          Text(
                            'Select All Devices',
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w600,
                              color: colors.textPrimary,
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ],
                      ),
                    ],
                    SizedBox(height: 8.h),
                    _buildAllocatedDevicesSection(),
                    if (_currentCustomer.role == UserRole.user) ...[
                      SizedBox(height: 24.h),
                      Row(
                        children: [
                          Text(
                            'Sub-Customers',
                            style: TextStyle(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.bold,
                              color: colors.textPrimary,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          SizedBox(width: 8.w),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.w, vertical: 2.h),
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                            child: Text(
                              '${_subcontractors.length}',
                              style: TextStyle(
                                fontSize: 11.sp,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primary,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      _buildSubcontractorsSection(),
                    ],
                    SizedBox(height: 24.h),

                    // Main Action Buttons
                    Row(
                      children: [
                        Expanded(
                          child: PrimaryButton(
                            text: 'Edit User',
                            icon: Icons.edit_rounded,
                            onPressed: () {
                              final authState = context.read<AuthBloc>().state;
                              UserRole? currentUserRole;
                              if (authState is AuthAuthenticated) {
                                currentUserRole = authState.user.role;
                              }
                              final editRoute =
                                  currentUserRole == UserRole.admin ||
                                          currentUserRole == UserRole.subAdmin
                                      ? '/admin/contractors/create'
                                      : '/contractor/sub-customers/create';
                              final bloc = context.read<CustomerBloc>();
                              context
                                  .push(editRoute, extra: _currentCustomer)
                                  .then((_) async {
                                bloc.add(const LoadCustomers());
                                try {
                                  final freshCustomer =
                                      await getIt<CustomerRepository>()
                                          .getCustomerDetails(
                                              _currentCustomer.customerId);
                                  if (mounted) {
                                    setState(() {
                                      _currentCustomer = freshCustomer;
                                      _isActive = freshCustomer.active;
                                    });
                                    if (_currentCustomer.role ==
                                        UserRole.user) {
                                      _fetchSubcontractors();
                                    }
                                  }
                                } catch (e) {
                                  debugPrint(
                                      'Error reloading fresh customer details: $e');
                                }
                              });
                            },
                          ),
                        ),
                        //only show delete button if customer is active
                        if (_isActive) ...[
                          SizedBox(width: 12.w),
                          Expanded(
                            child: SecondaryButton(
                              text: 'Delete User',
                              icon: Icons.delete_outline_rounded,
                              onPressed: () =>
                                  _showDeleteConfirmationDialog(context),
                            ),
                          ),
                        ]
                      ],
                    ),
                  ],
                ),
              ),
            ),
            BlocBuilder<CustomerBloc, CustomerState>(
              builder: (context, state) {
                if (state is CustomerLoading && !_isToggling) {
                  return Container(
                    color: Colors.black.withValues(alpha: 0.5),
                    child: const Center(
                      child:
                          CircularProgressIndicator(color: AppColors.primary),
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    final colors = AppColors.of(context);
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Row(
        children: [
          Icon(icon, size: 18.r, color: colors.textSecondary),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 10.sp,
                    color: colors.textSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 13.sp,
                    color: colors.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAllocatedDevicesSection() {
    final colors = AppColors.of(context);
    if (_isLoadingDevices) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );
    }

    if (_devicesError != null) {
      return Center(
        child: Column(
          children: [
            Text(
              'Failed to load devices',
              style: TextStyle(color: AppColors.aqiRed, fontSize: 13.sp),
            ),
            TextButton(
              onPressed: _fetchAllocatedDevices,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_allocatedDevices.isEmpty) {
      return ScadaCard(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 20.h),
          child: Center(
            child: Column(
              children: [
                Icon(
                  Icons.router_outlined,
                  size: 32.r,
                  color: colors.textMuted,
                ),
                SizedBox(height: 8.h),
                Text(
                  'No devices allocated to this user.',
                  style: TextStyle(
                    color: colors.textSecondary,
                    fontSize: 12.sp,
                    fontFamily: 'Poppins',
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final authState = context.read<AuthBloc>().state;
    UserRole? currentUserRole;
    if (authState is AuthAuthenticated) {
      currentUserRole = authState.user.role;
    }

    return Column(
      children: _allocatedDevices.map((device) {
        final statusColor = device.active ? AppColors.online : AppColors.aqiRed;
        return Container(
          margin: EdgeInsets.only(bottom: 8.h),
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: colors.border, width: 1.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(12.r),
              onTap: _isDeassignMode
                  ? () {
                      setState(() {
                        if (_selectedDeassignDeviceIds
                            .contains(device.deviceId)) {
                          _selectedDeassignDeviceIds.remove(device.deviceId);
                        } else {
                          _selectedDeassignDeviceIds.add(device.deviceId);
                        }
                      });
                    }
                  : () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        builder: (sheetContext) => ContractorDeviceDetailSheet(
                            deviceId: device.deviceId),
                      );
                    },
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // --- Top Row: Checkbox + Icon + Name (left) | Status Pill (top-right) ---
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        if (currentUserRole == UserRole.user &&
                            _isDeassignMode) ...[
                          SizedBox(
                            width: 24.w,
                            height: 24.h,
                            child: Checkbox(
                              value: _selectedDeassignDeviceIds
                                  .contains(device.deviceId),
                              onChanged: (val) {
                                setState(() {
                                  if (val == true) {
                                    _selectedDeassignDeviceIds
                                        .add(device.deviceId);
                                  } else {
                                    _selectedDeassignDeviceIds
                                        .remove(device.deviceId);
                                  }
                                });
                              },
                              activeColor: AppColors.aqiRed,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                            ),
                          ),
                          SizedBox(width: 8.w),
                        ],
                        CircleAvatar(
                          radius: 20.r,
                          backgroundColor:
                              AppColors.primary.withValues(alpha: 0.1),
                          child: Icon(
                            Icons.router_rounded,
                            color: AppColors.primary,
                            size: 20.r,
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 2.h),
                              Text(
                                device.deviceName.isNotEmpty
                                    ? device.deviceName
                                    : 'Unnamed Device',
                                style: TextStyle(
                                  fontSize: 13.sp,
                                  fontWeight: FontWeight.bold,
                                  color: colors.textPrimary,
                                  fontFamily: 'Poppins',
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: 8.w),
                        // Status Pill (top-right corner)
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 8.w, vertical: 3.h),
                          decoration: BoxDecoration(
                            color: statusColor.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10.r),
                            border: Border.all(
                              color: statusColor.withValues(alpha: 0.25),
                              width: 0.5.r,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 5.r,
                                height: 5.r,
                                decoration: BoxDecoration(
                                  color: statusColor,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                device.active ? 'Active' : 'Inactive',
                                style: TextStyle(
                                  fontSize: 9.sp,
                                  fontWeight: FontWeight.bold,
                                  color: statusColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10.h),
                    // --- Bottom Row: Details (left) | Action Buttons & Chevron (right) ---
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Code: ${device.deviceCode}',
                                style: TextStyle(
                                  fontSize: 11.sp,
                                  color: colors.textSecondary,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              if (device.siteName != null &&
                                  device.siteName!.isNotEmpty) ...[
                                SizedBox(height: 2.h),
                                Text(
                                  'Site: ${device.siteName}',
                                  style: TextStyle(
                                    fontSize: 11.sp,
                                    color: colors.textSecondary,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ],
                          ),
                        ),
                        SizedBox(width: 8.w),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (!_isDeassignMode) ...[
                              IconButton(
                                tooltip: 'View Device Details',
                                icon: AnimatedEyeIcon(
                                  color: AppColors.primary,
                                  size: 20.r,
                                ),
                                constraints: const BoxConstraints(),
                                padding: EdgeInsets.all(8.r),
                                style: IconButton.styleFrom(
                                  backgroundColor:
                                      AppColors.primary.withValues(alpha: 0.08),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.r),
                                  ),
                                ),
                                onPressed: () {
                                  final detailPath = currentUserRole ==
                                              UserRole.admin ||
                                          currentUserRole == UserRole.subAdmin
                                      ? AppRoutes.adminSiteDetails
                                          .replaceAll(':id', device.deviceId)
                                      : AppRoutes.contractorSiteDetails
                                          .replaceAll(':id', device.deviceId);
                                  context.push(detailPath);
                                },
                              ),
                              SizedBox(width: 8.w),
                              if (currentUserRole == UserRole.admin ||
                                  currentUserRole == UserRole.subAdmin ||
                                  (currentUserRole == UserRole.user &&
                                      _currentCustomer.role ==
                                          UserRole.subUser)) ...[
                                //// dont show this option for contractor and admin both -keep commented
                                // IconButton(
                                //   tooltip: currentUserRole == UserRole.user
                                //       ? 'Deassign Device'
                                //       : 'Remove Device',
                                //   icon: Icon(
                                //     Icons.link_off_rounded,
                                //     color: AppColors.aqiRed,
                                //     size: 22.r,
                                //   ),
                                //   padding: EdgeInsets.all(4.r),
                                //   constraints: const BoxConstraints(),
                                //   onPressed: () => _confirmRemoveDevice(device),
                                // ),

                                SizedBox(width: 12.w),
                              ],
                              Icon(
                                Icons.chevron_right_rounded,
                                color: colors.textMuted,
                                size: 20.r,
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Future<void> _fetchSubcontractors() async {
    if (!mounted) return;
    setState(() {
      _isLoadingSubcontractors = true;
      _subcontractorsError = null;
    });
    try {
      final list = await getIt<CustomerRepository>().getCustomers(
        parentCustomerId: _currentCustomer.customerId,
      );
      debugPrint("Subcontractors fetched from API: ${list.length} items");
      for (var c in list) {
        debugPrint(
            "Subcontractor: id=${c.customerId}, name=${c.fullName}, role=${c.role}, parent=${c.parentCustomerId}");
      }
      final filtered = list.where((c) {
        return c.role == UserRole.subUser;
      }).toList();
      debugPrint("Filtered subcontractors: ${filtered.length} items");
      if (mounted) {
        setState(() {
          _subcontractors = filtered;
          _isLoadingSubcontractors = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _subcontractorsError = e.toString();
          _isLoadingSubcontractors = false;
        });
      }
    }
  }

  Widget _buildSubcontractorsSection() {
    final colors = AppColors.of(context);
    if (_isLoadingSubcontractors) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );
    }

    if (_subcontractorsError != null) {
      return Center(
        child: Column(
          children: [
            Text(
              'Failed to load sub-customers',
              style: TextStyle(color: AppColors.aqiRed, fontSize: 13.sp),
            ),
            TextButton(
              onPressed: _fetchSubcontractors,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_subcontractors.isEmpty) {
      return ScadaCard(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 20.h),
          child: Center(
            child: Column(
              children: [
                Icon(
                  Icons.people_outline_rounded,
                  size: 32.r,
                  color: colors.textMuted,
                ),
                SizedBox(height: 8.h),
                Text(
                  'No sub-customers allocated to this contractor.',
                  style: TextStyle(
                    color: colors.textSecondary,
                    fontSize: 12.sp,
                    fontFamily: 'Poppins',
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Column(
      children: _subcontractors.map((subcontractor) {
        final statusColor =
            subcontractor.active ? AppColors.online : AppColors.aqiRed;
        return Container(
          margin: EdgeInsets.only(bottom: 8.h),
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: colors.border, width: 1.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(12.r),
              onTap: () {
                final authState = context.read<AuthBloc>().state;
                UserRole? currentUserRole;
                if (authState is AuthAuthenticated) {
                  currentUserRole = authState.user.role;
                }
                final route = (currentUserRole == UserRole.admin ||
                        currentUserRole == UserRole.subAdmin)
                    ? AppRoutes.adminCustomerDetails
                    : AppRoutes.contractorCustomerDetails;
                context.push(route, extra: subcontractor).then((_) {
                  _fetchSubcontractors();
                });
              },
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 20.r,
                      backgroundColor:
                          const Color(0xFF607D8B).withValues(alpha: 0.1),
                      child: Icon(
                        Icons.person_outline_rounded,
                        color: const Color(0xFF607D8B),
                        size: 20.r,
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            subcontractor.fullName,
                            style: TextStyle(
                              fontSize: 13.sp,
                              fontWeight: FontWeight.bold,
                              color: colors.textPrimary,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          if (subcontractor.firmName?.isNotEmpty == true) ...[
                            SizedBox(height: 2.h),
                            Text(
                              subcontractor.firmName!,
                              style: TextStyle(
                                fontSize: 11.sp,
                                color: colors.textSecondary,
                              ),
                            ),
                          ],
                          SizedBox(height: 2.h),
                          Text(
                            'Mobile: ${subcontractor.mobileNo}',
                            style: TextStyle(
                              fontSize: 11.sp,
                              color: colors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 8.r,
                      height: 8.r,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: colors.textMuted,
                      size: 14.r,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  void _confirmDeassignMultipleDevices() {
    final count = _selectedDeassignDeviceIds.length;
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Deassign Devices?'),
          content: Text(
            'Are you sure you want to deassign $count selected device(s) from this subcontractor\'s assignment?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
                _deassignMultipleDevices();
              },
              style: TextButton.styleFrom(
                foregroundColor: AppColors.aqiRed,
              ),
              child: const Text('Deassign'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deassignMultipleDevices() async {
    setState(() {
      _isLoadingDevices = true;
    });

    try {
      final deviceIdsList = _selectedDeassignDeviceIds.toList();
      await getIt<CustomerRepository>().deallocateDeviceFromSubUser(
        subUserId: _currentCustomer.customerId,
        deviceIds: deviceIdsList,
        remark: 'Bulk deassigned from subcontractor by contractor',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
                '${deviceIdsList.length} device(s) deassigned successfully!'),
            backgroundColor: AppColors.online,
          ),
        );
        setState(() {
          _isDeassignMode = false;
          _selectedDeassignDeviceIds.clear();
        });
        _fetchAllocatedDevices();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingDevices = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to deassign devices: ${e.toString()}'),
            backgroundColor: AppColors.aqiRed,
          ),
        );
      }
    }
  }

  // void _confirmRemoveDevice(DeviceEntity device) {
  //   final isContractor = _currentUserRole == UserRole.user;
  //   final titleText = isContractor ? 'Deassign Device?' : 'Deallocate Device?';
  //   final contentText = isContractor
  //       ? 'Are you sure you want to deassign ${device.deviceName} (${device.deviceCode}) from this subcontractor\'s assignment?'
  //       : 'Are you sure you want to remove ${device.deviceName} (${device.deviceCode}) from this customer\'s allocation?';
  //   final actionText = isContractor ? 'Deassign' : 'Deallocate';

  //   showDialog(
  //     context: context,
  //     builder: (dialogContext) {
  //       return AlertDialog(
  //         title: Text(titleText),
  //         content: Text(contentText),
  //         actions: [
  //           TextButton(
  //             onPressed: () => Navigator.pop(dialogContext),
  //             child: const Text('Cancel'),
  //           ),
  //           TextButton(
  //             onPressed: () {
  //               Navigator.pop(dialogContext);
  //               _removeDeviceAllocation(device.deviceId);
  //             },
  //             style: TextButton.styleFrom(
  //               foregroundColor: AppColors.aqiRed,
  //             ),
  //             child: Text(actionText),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  // Future<void> _removeDeviceAllocation(String deviceId) async {
  //   setState(() {
  //     _isLoadingDevices = true;
  //   });

  //   try {
  //     if (_currentUserRole == UserRole.user) {
  //       // Contractor login: deassign devices from subcontractor using deallocateDeviceFromSubUser API
  //       await getIt<CustomerRepository>().deallocateDeviceFromSubUser(
  //         subUserId: _currentCustomer.customerId,
  //         deviceIds: [deviceId],
  //         remark: 'Deassigned from subcontractor by contractor',
  //       );
  //     } else {
  //       // Admin login: remove/deallocate device using removeDevice API
  //       await getIt<CustomerRepository>().removeDevice(deviceId);
  //     }
  //     if (mounted) {
  //       final successMsg = _currentUserRole == UserRole.user
  //           ? 'Device deassigned successfully!'
  //           : 'Device deallocated successfully!';
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text(successMsg),
  //           backgroundColor: AppColors.online,
  //         ),
  //       );
  //       _fetchAllocatedDevices();
  //     }
  //   } catch (e) {
  //     if (mounted) {
  //       setState(() {
  //         _isLoadingDevices = false;
  //       });
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text('Failed to deallocate device: ${e.toString()}'),
  //           backgroundColor: AppColors.aqiRed,
  //         ),
  //       );
  //     }
  //   }
  // }

  Widget _buildDeassignBottomBar() {
    final colors = AppColors.of(context);
    final count = _selectedDeassignDeviceIds.length;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: colors.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '$count Selected',
              style: TextStyle(
                fontSize: 13.sp,
                fontWeight: FontWeight.bold,
                color: colors.textPrimary,
                fontFamily: 'Poppins',
              ),
            ),
            Row(
              children: [
                OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _isDeassignMode = false;
                      _selectedDeassignDeviceIds.clear();
                    });
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: colors.textSecondary,
                    side: BorderSide(color: colors.border),
                    padding:
                        EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                  ),
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
                SizedBox(width: 12.w),
                ElevatedButton(
                  onPressed: _selectedDeassignDeviceIds.isEmpty
                      ? null
                      : _confirmDeassignMultipleDevices,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.aqiRed,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: Colors.grey.shade300,
                    disabledForegroundColor: Colors.grey.shade500,
                    padding:
                        EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                  ),
                  child: Text(
                    'Deassign Devices',
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmationDialog(BuildContext context) {
    final colors = AppColors.of(context);
    bool removeDevices = false;

    // Capture bloc reference before showing dialog to avoid ProviderNotFoundException
    final customerBloc = context.read<CustomerBloc>();
    final pageContext = context;

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (BuildContext stateContext, StateSetter setState) {
            return AlertDialog(
              backgroundColor: colors.surface,
              title: Row(
                children: [
                  Icon(Icons.warning_rounded,
                      color: AppColors.aqiRed, size: 24.r),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Text(
                      'Delete User',
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: colors.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Are you sure you want to delete this user? This action cannot be undone.',
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: colors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Container(
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      color: AppColors.aqiRed.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(8.r),
                      border: Border.all(
                        color: AppColors.aqiRed.withValues(alpha: 0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline_rounded,
                            size: 18.r, color: AppColors.aqiRed),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Text(
                            'User: ${_currentCustomer.fullName}',
                            style: TextStyle(
                              fontSize: 12.sp,
                              color: AppColors.aqiRed,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (_currentUserRole == UserRole.admin) ...[
                    SizedBox(height: 16.h),
                    Text(
                      'Delete Options:',
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                        color: colors.textSecondary,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Container(
                      padding: EdgeInsets.all(12.w),
                      decoration: BoxDecoration(
                        color: colors.background,
                        borderRadius: BorderRadius.circular(8.r),
                        border: Border.all(color: colors.border),
                      ),
                      child: Column(
                        children: [
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                removeDevices = false;
                              });
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8.h, horizontal: 8.w),
                              child: Row(
                                children: [
                                  Radio<bool>(
                                    value: false,
                                    groupValue: removeDevices,
                                    onChanged: (value) {
                                      setState(() {
                                        removeDevices = value ?? false;
                                      });
                                    },
                                    activeColor: AppColors.primary,
                                  ),
                                  SizedBox(width: 8.w),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Delete user only',
                                          style: TextStyle(
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w600,
                                            color: colors.textPrimary,
                                          ),
                                        ),
                                        Text(
                                          'Keep allocated devices',
                                          style: TextStyle(
                                            fontSize: 11.sp,
                                            color: colors.textSecondary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Divider(
                            height: 1,
                            color: colors.border,
                          ),
                          // for admin only delete user with devices
                          // Contractor cant see delete options -- fix it

                          GestureDetector(
                            onTap: () {
                              setState(() {
                                removeDevices = true;
                              });
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8.h, horizontal: 8.w),
                              child: Row(
                                children: [
                                  Radio<bool>(
                                    value: true,
                                    groupValue: removeDevices,
                                    onChanged: (value) {
                                      setState(() {
                                        removeDevices = value ?? false;
                                      });
                                    },
                                    activeColor: AppColors.primary,
                                  ),
                                  SizedBox(width: 8.w),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Delete user with devices',
                                          style: TextStyle(
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w600,
                                            color: colors.textPrimary,
                                          ),
                                        ),
                                        Text(
                                          'Remove all allocated devices',
                                          style: TextStyle(
                                            fontSize: 11.sp,
                                            color: colors.textSecondary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(),
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                      color: colors.textSecondary,
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.aqiRed,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                  ),
                  onPressed: () {
                    Navigator.of(dialogContext).pop();
                    // Use captured bloc reference instead of context.read
                    customerBloc.add(
                      DeleteCustomer(
                        customerId: _currentCustomer.customerId,
                        removeDevices: removeDevices,
                      ),
                    );
                    // Navigate back after a short delay to allow the bloc to process
                    Future.delayed(const Duration(milliseconds: 500), () {
                      if (pageContext.mounted) {
                        pageContext.pop();
                      }
                    });
                  },
                  child: Text(
                    'Delete',
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
