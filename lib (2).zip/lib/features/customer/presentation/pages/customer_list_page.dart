import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../config/theme/colors.dart';
import '../../../../shared/widgets/error_display_widget.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../bloc/customer_bloc.dart';
import '../../domain/entities/customer_entity.dart';

class CustomerListPage extends StatefulWidget {
  const CustomerListPage({super.key});

  @override
  State<CustomerListPage> createState() => _CustomerListPageState();
}

class _CustomerListPageState extends State<CustomerListPage> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController controller = ScrollController();
  String _searchQuery = '';
  String _filter = 'All'; // 'All', 'Active', 'Inactive'

  @override
  void initState() {
    super.initState();
    context.read<CustomerBloc>().add(const LoadCustomers());
    controller.addListener(() {
      if (controller.position.pixels == controller.position.maxScrollExtent) {
        final state = context.read<CustomerBloc>().state;

        if (state is CustomersLoaded && state.hasMore) {
          context.read<CustomerBloc>().add(
                const LoadCustomers(
                  isLoadMore: true,
                ),
              );
        }
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    final authState = context.read<AuthBloc>().state;
    UserRole? currentUserRole;
    if (authState is AuthAuthenticated) {
      currentUserRole = authState.user.role;
    }

    final bool canCreate = currentUserRole != UserRole.subUser;

    return Scaffold(
      backgroundColor: colors.background,
      appBar: AppBar(
        title: Text(
          currentUserRole == UserRole.user
              ? 'Sub-Customer Directory'
              : 'User Directory',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18.sp,
            fontFamily: 'Poppins',
          ),
        ),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => context.pop(),
              )
            : null,
        actions: [
          BlocBuilder<CustomerBloc, CustomerState>(
            builder: (context, state) {
              if (state is CustomersLoaded) {
                int count = state.customers.length;
                if (currentUserRole == UserRole.user &&
                    authState is AuthAuthenticated) {
                  count = state.customers.where((c) {
                    return c.role == UserRole.subUser &&
                        c.parentCustomerId == authState.user.id;
                  }).length;
                }
                return Padding(
                  padding: EdgeInsets.only(right: 16.w),
                  child: Center(
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12.r),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.3),
                          width: 1.r,
                        ),
                      ),
                      child: Text(
                        'Total: $count',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search Input Row
            Container(
              color: colors.surface,
              padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 8.h),
              child: TextFormField(
                controller: _searchController,
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.toLowerCase();
                  });
                },
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: colors.textPrimary,
                ),
                decoration: InputDecoration(
                  hintText: 'Search by name, mobile, email or company...',
                  hintStyle: TextStyle(
                    color: colors.textMuted,
                    fontSize: 13.sp,
                  ),
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    color: colors.textSecondary,
                    size: 20.r,
                  ),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                          icon: Icon(
                            Icons.cancel_rounded,
                            color: colors.textMuted,
                            size: 18.r,
                          ),
                          onPressed: () {
                            _searchController.clear();
                            setState(() {
                              _searchQuery = '';
                            });
                          },
                        )
                      : null,
                  fillColor: colors.background,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r),
                    borderSide: BorderSide(color: colors.border, width: 1.r),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r),
                    borderSide: BorderSide(color: colors.border, width: 1.r),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r),
                    borderSide:
                        BorderSide(color: AppColors.primary, width: 1.5.r),
                  ),
                ),
              ),
            ),

            // Premium Filters Section
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: colors.surface,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.02),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
                border: Border(
                  bottom: BorderSide(
                    color: colors.border.withValues(alpha: 0.5),
                    width: 1.h,
                  ),
                ),
              ),
              child: BlocBuilder<CustomerBloc, CustomerState>(
                builder: (context, state) {
                  List<CustomerEntity> listForCounts = [];
                  if (state is CustomersLoaded || state is CustomerLoadMore) {
                    listForCounts = state is CustomersLoaded
                        ? state.customers
                        : (state as CustomerLoadMore).customers;
                  }

                  // If Contractor, filter only their sub-users
                  if (currentUserRole == UserRole.user &&
                      authState is AuthAuthenticated) {
                    listForCounts = listForCounts.where((c) {
                      return c.role == UserRole.subUser &&
                          c.parentCustomerId == authState.user.id;
                    }).toList();
                  }

                  final totalCount = listForCounts.length;

                  final activeCount =
                      listForCounts.where((c) => c.active).length;
                  final inactiveCount =
                      listForCounts.where((c) => !c.active).length;

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Row for Status Filter
                      Row(
                        children: [
                          Icon(
                            Icons.toggle_on_outlined,
                            size: 16.r,
                            color: AppColors.accent,
                          ),
                          SizedBox(width: 6.w),
                          Text(
                            'Status',
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold,
                              color: colors.textPrimary,
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 4.h),
                      Row(
                        children: [
                          ...['All', 'Active', 'Inactive'].map((filterName) {
                            final isSelected = _filter == filterName;
                            Color chipBgColor = colors.background;
                            Color labelColor = colors.textSecondary;
                            Color activeIndicatorColor = colors.textMuted;
                            int count = 0;

                            if (filterName == 'Active') {
                              count = activeCount;
                            } else if (filterName == 'Inactive') {
                              count = inactiveCount;
                            } else {
                              count = totalCount;
                            }

                            if (isSelected) {
                              if (filterName == 'Active') {
                                chipBgColor =
                                    AppColors.online.withValues(alpha: 0.1);
                                labelColor = AppColors.online;
                                activeIndicatorColor = AppColors.online;
                              } else if (filterName == 'Inactive') {
                                chipBgColor =
                                    AppColors.aqiRed.withValues(alpha: 0.1);
                                labelColor = AppColors.aqiRed;
                                activeIndicatorColor = AppColors.aqiRed;
                              } else {
                                chipBgColor = AppColors.primaryLight;
                                labelColor = AppColors.primary;
                                activeIndicatorColor = AppColors.primary;
                              }
                            } else {
                              if (filterName == 'Active') {
                                activeIndicatorColor =
                                    AppColors.online.withValues(alpha: 0.5);
                              } else if (filterName == 'Inactive') {
                                activeIndicatorColor =
                                    AppColors.aqiRed.withValues(alpha: 0.5);
                              } else {
                                activeIndicatorColor = colors.textMuted;
                              }
                            }

                            return Padding(
                              padding: EdgeInsets.only(right: 8.w),
                              child: ChoiceChip(
                                showCheckmark: false,
                                label: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    if (filterName == 'Active' ||
                                        filterName == 'Inactive') ...[
                                      Container(
                                        width: 6.r,
                                        height: 6.r,
                                        decoration: BoxDecoration(
                                          color: activeIndicatorColor,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      SizedBox(width: 5.w),
                                    ],
                                    Text('$filterName ($count)'),
                                  ],
                                ),
                                selected: isSelected,
                                labelStyle: TextStyle(
                                  fontSize: 11.5.sp,
                                  color: labelColor,
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.w500,
                                  fontFamily: 'Poppins',
                                ),
                                selectedColor: chipBgColor,
                                backgroundColor: colors.background,
                                side: BorderSide(
                                  color: isSelected
                                      ? labelColor.withValues(alpha: 0.3)
                                      : Colors.transparent,
                                  width: 1.r,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.r),
                                ),
                                onSelected: (val) {
                                  if (val) setState(() => _filter = filterName);
                                },
                              ),
                            );
                          }),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),

            // Customers List
            Expanded(
              child: BlocBuilder<CustomerBloc, CustomerState>(
                builder: (context, state) {
                  if (state is CustomerLoading) {
                    return const Center(
                      child:
                          CircularProgressIndicator(color: AppColors.primary),
                    );
                  }
                  if (state is CustomerError) {
                    return ErrorDisplayWidget(
                      message: state.message,
                      onRetry: () {
                        context.read<CustomerBloc>().add(const LoadCustomers());
                      },
                    );
                  }
                  if (state is CustomersLoaded || state is CustomerLoadMore) {
                    final customers = state is CustomersLoaded
                        ? state.customers
                        : (state as CustomerLoadMore).customers;
                    final filteredList = customers.where((c) {
                      // If the logged in user is a Contractor, only show their subcontractors
                      if (currentUserRole == UserRole.user &&
                          authState is AuthAuthenticated) {
                        if (c.role != UserRole.subUser) {
                          return false;
                        }
                      }

                      // Filter by search query across full_name, firm_name, mobile_no, email
                      final query = _searchQuery;
                      final queryDigits =
                          query.replaceAll(RegExp(r'[^0-9]'), '');
                      final matchesName =
                          c.fullName.toLowerCase().contains(query);
                      final matchesFirm =
                          c.firmName?.toLowerCase().contains(query) ?? false;
                      final matchesEmail =
                          c.email.toLowerCase().contains(query);
                      final matchesMobile = queryDigits.isNotEmpty
                          ? c.mobileNo
                              .replaceAll(RegExp(r'[^0-9]'), '')
                              .contains(queryDigits)
                          : c.mobileNo.toLowerCase().contains(query);
                      final matchesSearch = matchesName ||
                          matchesFirm ||
                          matchesEmail ||
                          matchesMobile;

                      if (!matchesSearch) return false;

                      // Filter by active/inactive status
                      if (_filter == 'Active' && !c.active) return false;
                      if (_filter == 'Inactive' && c.active) return false;

                      return true;
                    }).toList();

                    if (filteredList.isEmpty) {
                      return Center(
                        child: Text(
                          'No records found.',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 14.sp,
                          ),
                        ),
                      );
                    }

                    return ListView.builder(
                      padding: EdgeInsets.all(16.r),
                      controller: controller,
                      itemCount: filteredList.length +
                          (state is CustomerLoadMore ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == filteredList.length) {
                          return const CircularProgressIndicator();
                        }
                        final customer = filteredList[index];
                        return _buildCustomerCard(context, customer);
                      },
                    );
                  }
                  return const Center(
                      child: Text('Initialize customer loading...'));
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: canCreate
          ? FloatingActionButton.extended(
              onPressed: () {
                final String addRoute = currentUserRole == UserRole.admin ||
                        currentUserRole == UserRole.subAdmin
                    ? '/admin/contractors/create'
                    : '/contractor/sub-customers/create';
                final bloc = context.read<CustomerBloc>();
                context.push(addRoute).then((_) {
                  bloc.add(const LoadCustomers());
                });
              },
              backgroundColor: AppColors.primary,
              icon: const Icon(Icons.add_rounded, color: Colors.white),
              label: Text(
                currentUserRole == UserRole.user
                    ? 'Add Sub-Customer'
                    : 'Add User',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold),
              ),
            )
          : null,
    );
  }

  Widget _buildCustomerCard(BuildContext context, CustomerEntity customer) {
    final colors = AppColors.of(context);
    final authState = context.read<AuthBloc>().state;
    UserRole? currentUserRole;
    if (authState is AuthAuthenticated) {
      currentUserRole = authState.user.role;
    }

    String roleLabel = 'Customer';
    Color roleColor = AppColors.primary;
    IconData roleIcon = Icons.person_rounded;
    if (customer.role == UserRole.admin) {
      roleLabel = 'Admin';
      roleColor = AppColors.aqiPurple;
      roleIcon = Icons.admin_panel_settings_rounded;
    } else if (customer.role == UserRole.subAdmin) {
      roleLabel = 'Sub Admin';
      roleColor = AppColors.accent;
      roleIcon = Icons.manage_accounts_rounded;
    } else if (customer.role == UserRole.user) {
      roleLabel = 'Customer';
      roleColor = AppColors.primary;
      roleIcon = Icons.person_rounded;
    } else if (customer.role == UserRole.subUser) {
      roleLabel = 'Sub Customer';
      roleColor = const Color(0xFF607D8B);
      roleIcon = Icons.person_outline_rounded;
    }

    final statusColor = customer.active ? AppColors.online : AppColors.aqiRed;
    final statusText = customer.active ? 'Active' : 'Inactive';

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: colors.border, width: 1.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16.r),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              final detailRoute = currentUserRole == UserRole.admin ||
                      currentUserRole == UserRole.subAdmin
                  ? '/admin/contractors/details'
                  : '/contractor/sub-customers/details';
              final bloc = context.read<CustomerBloc>();
              context.push(detailRoute, extra: customer).then((_) {
                bloc.add(const LoadCustomers());
              });
            },
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Left side accent indicator bar
                  Container(
                    width: 5.w,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          roleColor,
                          roleColor.withValues(alpha: 0.6),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 14.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // --- Top Row: Avatar + Name (left) | Status Pill (top-right) ---
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // User Avatar Initials with Sr No Badge
                              Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Container(
                                    width: 44.r,
                                    height: 44.r,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          roleColor.withValues(alpha: 0.15),
                                          roleColor.withValues(alpha: 0.05),
                                        ],
                                      ),
                                      border: Border.all(
                                        color:
                                            roleColor.withValues(alpha: 0.25),
                                        width: 1.5.r,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        customer.firmName != null &&
                                                customer.firmName!.isNotEmpty
                                            ? customer.firmName!
                                                .substring(0, 1)
                                                .toUpperCase()
                                            : 'U',
                                        style: TextStyle(
                                          color: roleColor,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 17.sp,
                                          fontFamily: 'Poppins',
                                        ),
                                      ),
                                    ),
                                  ),
                                  if (customer.srNo != null)
                                    Positioned(
                                      top: -5.r,
                                      left: -5.r,
                                      child: Container(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 5.w, vertical: 1.5.h),
                                        decoration: BoxDecoration(
                                          color: roleColor,
                                          borderRadius:
                                              BorderRadius.circular(6.r),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.black
                                                  .withValues(alpha: 0.1),
                                              blurRadius: 2,
                                              offset: const Offset(0, 1),
                                            ),
                                          ],
                                        ),
                                        child: Text(
                                          '#${customer.srNo}',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 8.sp,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Poppins',
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              SizedBox(width: 12.w),
                              // Name + Firm
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 2.h),
                                    Text(
                                      customer.firmName != null &&
                                              customer.firmName!.isNotEmpty
                                          ? customer.firmName.toString()
                                          : '-',
                                      style: TextStyle(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.bold,
                                        color: colors.textPrimary,
                                        fontFamily: 'Poppins',
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    // if (customer.firmName != null &&
                                    //     customer.firmName!.isNotEmpty) ...[
                                    SizedBox(height: 1.h),
                                    Text(
                                      customer.fullName,
                                      style: TextStyle(
                                        fontSize: 11.5.sp,
                                        color: colors.textSecondary,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    // ],
                                  ],
                                ),
                              ),
                              SizedBox(width: 8.w),
                              // Status Pill (top-right corner)
                              Padding(
                                padding: EdgeInsets.only(right: 10.w, top: 2.h),
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10.w, vertical: 4.h),
                                  decoration: BoxDecoration(
                                    color: statusColor.withValues(alpha: 0.08),
                                    borderRadius: BorderRadius.circular(20.r),
                                    border: Border.all(
                                      color:
                                          statusColor.withValues(alpha: 0.25),
                                      width: 1.r,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        width: 7.r,
                                        height: 7.r,
                                        decoration: BoxDecoration(
                                          color: statusColor,
                                          shape: BoxShape.circle,
                                          boxShadow: customer.active
                                              ? [
                                                  BoxShadow(
                                                    color: statusColor
                                                        .withValues(alpha: 0.4),
                                                    blurRadius: 4,
                                                    spreadRadius: 1,
                                                  ),
                                                ]
                                              : null,
                                        ),
                                      ),
                                      SizedBox(width: 5.w),
                                      Text(
                                        statusText,
                                        style: TextStyle(
                                          fontSize: 10.5.sp,
                                          fontWeight: FontWeight.w700,
                                          color: statusColor,
                                          fontFamily: 'Poppins',
                                          letterSpacing: 0.3,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 10.h),

                          // --- Contact Info Row ---
                          Row(
                            children: [
                              Icon(Icons.phone_iphone_rounded,
                                  size: 13.r, color: colors.textMuted),
                              SizedBox(width: 4.w),
                              Text(
                                customer.mobileNo,
                                style: TextStyle(
                                    fontSize: 11.sp,
                                    color: colors.textSecondary),
                              ),
                              SizedBox(width: 14.w),
                              Icon(Icons.mail_outline_rounded,
                                  size: 13.r, color: colors.textMuted),
                              SizedBox(width: 4.w),
                              Expanded(
                                child: Text(
                                  customer.email,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 11.sp,
                                      color: colors.textSecondary),
                                ),
                              ),
                            ],
                          ),

                          // --- Metadata Row (Created At & Parent User Info) ---
                          if (customer.createdAt != null ||
                              customer.isSubUser) ...[
                            SizedBox(height: 8.h),
                            Row(
                              children: [
                                if (customer.createdAt != null) ...[
                                  Icon(Icons.calendar_today_rounded,
                                      size: 12.r, color: colors.textMuted),
                                  SizedBox(width: 4.w),
                                  Text(
                                    'Joined: ${customer.createdAt!.split('T')[0]}',
                                    style: TextStyle(
                                      fontSize: 10.5.sp,
                                      color: colors.textSecondary,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ],
                                if (customer.createdAt != null &&
                                    customer.isSubUser &&
                                    customer.parentCustomerId != null)
                                  SizedBox(width: 10.w),
                                if (customer.isSubUser &&
                                    (customer.parentUserName != null ||
                                        customer.parentCustomerId != null)) ...[
                                  Icon(Icons.link_rounded,
                                      size: 13.r, color: colors.textMuted),
                                  SizedBox(width: 4.w),
                                  Expanded(
                                    child: Text(
                                      customer.parentUserName != null &&
                                              customer
                                                  .parentUserName!.isNotEmpty
                                          ? 'By: ${customer.parentUserName}'
                                          : 'By: ${customer.parentCustomerId!.length > 22 ? customer.parentCustomerId!.substring(0, 22) : customer.parentCustomerId}...',
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 10.5.sp,
                                        color: colors.textSecondary,
                                        fontFamily: 'Poppins',
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ],

                          SizedBox(height: 10.h),

                          // --- Bottom Row: Role Pill (left) | Arrow (bottom-right) ---
                          Row(
                            children: [
                              // Role Pill
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 10.w, vertical: 4.h),
                                decoration: BoxDecoration(
                                  color: roleColor.withValues(alpha: 0.08),
                                  borderRadius: BorderRadius.circular(20.r),
                                  border: Border.all(
                                    color: roleColor.withValues(alpha: 0.25),
                                    width: 1.r,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      roleIcon,
                                      size: 13.r,
                                      color: roleColor,
                                    ),
                                    SizedBox(width: 5.w),
                                    Text(
                                      roleLabel,
                                      style: TextStyle(
                                        fontSize: 10.5.sp,
                                        fontWeight: FontWeight.w700,
                                        color: roleColor,
                                        fontFamily: 'Poppins',
                                        letterSpacing: 0.3,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Spacer(),
                              // Forward Arrow (bottom-right corner)
                              Padding(
                                padding: EdgeInsets.only(right: 10.w),
                                child: Container(
                                  width: 28.r,
                                  height: 28.r,
                                  decoration: BoxDecoration(
                                    color: colors.background,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: colors.border,
                                      width: 1.r,
                                    ),
                                  ),
                                  child: Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    color: colors.textSecondary,
                                    size: 14.r,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
