// features/customer/presentation/bloc/customer_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/entities/customer_entity.dart';
import '../../domain/repositories/customer_repository.dart';
import '../../../auth/domain/repositories/auth_repository.dart';
import '../../../../core/exceptions/app_exception.dart';

// --- Events ---
abstract class CustomerEvent extends Equatable {
  const CustomerEvent();
  @override
  List<Object?> get props => [];
}

class LoadCustomers extends CustomerEvent {
  final String? search;
  final String? parentCustomerId;
  final bool isLoadMore;

  const LoadCustomers({
    this.search,
    this.parentCustomerId,
    this.isLoadMore = false,
  });

  @override
  List<Object?> get props => [search, parentCustomerId, isLoadMore];
}

class CreateCustomer extends CustomerEvent {
  final String fullName;
  final String? firmName;
  final String mobileNo;
  final String email;
  final String password;
  final UserRole role;
  final bool active;

  const CreateCustomer({
    required this.fullName,
    this.firmName,
    required this.mobileNo,
    required this.email,
    required this.password,
    required this.role,
    required this.active,
  });

  @override
  List<Object?> get props =>
      [fullName, firmName, mobileNo, email, password, role, active];
}

class UpdateCustomerDetails extends CustomerEvent {
  final CustomerEntity customer;
  final String? password;

  const UpdateCustomerDetails({required this.customer, this.password});

  @override
  List<Object?> get props => [customer, password];
}

class DeleteCustomer extends CustomerEvent {
  final String customerId;
  final bool removeDevices;

  const DeleteCustomer({required this.customerId, this.removeDevices = false});

  @override
  List<Object?> get props => [customerId, removeDevices];
}

// --- States ---
abstract class CustomerState extends Equatable {
  const CustomerState();
  @override
  List<Object?> get props => [];
}

class CustomerInitial extends CustomerState {}

class CustomerLoading extends CustomerState {}

class CustomerLoadMore extends CustomerState {
  final List<CustomerEntity> customers;

  const CustomerLoadMore(this.customers);

  @override
  List<Object?> get props => [customers];
}

class CustomersLoaded extends CustomerState {
  final List<CustomerEntity> customers;
  final int page;
  final bool hasMore;
  const CustomersLoaded(
    this.customers,
    this.page,
    this.hasMore,
  );
  @override
  List<Object?> get props => [
        customers,
        page,
        hasMore,
      ];
}

class CustomerActionSuccess extends CustomerState {
  final String message;
  const CustomerActionSuccess(this.message);
  @override
  List<Object?> get props => [message];
}

class CustomerError extends CustomerState {
  final String message;
  const CustomerError(this.message);
  @override
  List<Object?> get props => [message];
}

// --- Bloc ---
class CustomerBloc extends Bloc<CustomerEvent, CustomerState> {
  final CustomerRepository _customerRepository;

  CustomerBloc(this._customerRepository) : super(CustomerInitial()) {
    on<LoadCustomers>(_onLoadCustomers);
    on<CreateCustomer>(_onCreateCustomer);
    on<UpdateCustomerDetails>(_onUpdateCustomerDetails);
    on<DeleteCustomer>(_onDeleteCustomer);
  }

  // Future<void> _onLoadCustomers(
  //     LoadCustomers event, Emitter<CustomerState> emit) async {
  //   emit(CustomerLoading());
  //   try {
  //     final list = await _customerRepository.getCustomers(
  //       page: 0,
  //       size: 5,
  //       search: event.search,
  //       parentCustomerId: event.parentCustomerId,
  //     );
  //     emit(CustomersLoaded(list));
  //   } catch (e) {
  //     emit(CustomerError(AppException.from(e).toString()));
  //   }
  // }
  Future<void> _onLoadCustomers(
    LoadCustomers event,
    Emitter  <CustomerState> emit,
  ) async {
    try {
      int page = 0;

      List<CustomerEntity> existingCustomers = [];

      // Pagination case
      if (event.isLoadMore) {
        if (state is CustomersLoaded) {
          final currentState = state as CustomersLoaded;

          if (!currentState.hasMore) {
            return;
          }
          page = currentState.page + 1;
          existingCustomers = currentState.customers;
          emit(
            CustomerLoadMore(
              existingCustomers,
            ),
          );
        } else {
          return;
        }
      }
      // First load
      else {
        emit(
          CustomerLoading(),
        );
      }

      final response = await _customerRepository.getCustomers(
        page: page,
        size: 20,
        search: event.search,
        parentCustomerId: event.parentCustomerId,
      );

      final updatedCustomers = event.isLoadMore
          ? [
              ...existingCustomers,
              ...response,
            ]
          : response;

      emit(
        CustomersLoaded(
          updatedCustomers,
          page,
          response.length == 5,
        ),
      );
    } catch (e) {
      emit(
        CustomerError(
          AppException.from(e).toString(),
        ),
      );
    }
  }

  Future<void> _onCreateCustomer(
      CreateCustomer event, Emitter<CustomerState> emit) async {
    emit(CustomerLoading());
    try {
      await _customerRepository.saveCustomer(
        fullName: event.fullName,
        firmName: event.firmName,
        mobileNo: event.mobileNo,
        email: event.email,
        password: event.password,
        role: event.role,
        active: event.active,
      );
      emit(const CustomerActionSuccess('User created successfully!'));
      // Reload customers list
      final list = await _customerRepository.getCustomers();
      emit(CustomersLoaded(list, 0, false));
    } catch (e) {
      emit(CustomerError(AppException.from(e).toString()));
    }
  }

  Future<void> _onUpdateCustomerDetails(
      UpdateCustomerDetails event, Emitter<CustomerState> emit) async {
    emit(CustomerLoading());
    try {
      await _customerRepository.updateCustomer(event.customer,
          password: event.password);
      emit(const CustomerActionSuccess('User updated successfully!'));
      // Reload customers list
      final list = await _customerRepository.getCustomers();
      emit(CustomersLoaded(list, 0, false));
    } catch (e) {
      emit(CustomerError(AppException.from(e).toString()));
    }
  }

  Future<void> _onDeleteCustomer(
      DeleteCustomer event, Emitter<CustomerState> emit) async {
    emit(CustomerLoading());
    try {
      await _customerRepository.deleteCustomer(
        customerId: event.customerId,
        removeDevices: event.removeDevices,
      );
      emit(const CustomerActionSuccess('User deleted successfully!'));
      // Reload customers list
      final list = await _customerRepository.getCustomers();
      emit(CustomersLoaded(list, 0, false));
    } catch (e) {
      emit(CustomerError(AppException.from(e).toString()));
    }
  }
}
