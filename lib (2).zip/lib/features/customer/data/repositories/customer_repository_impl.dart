// features/customer/data/repositories/customer_repository_impl.dart
import 'dart:convert';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_config.dart';
import '../../../../core/exceptions/app_exception.dart';
import '../../domain/repositories/customer_repository.dart';
import '../../domain/entities/customer_entity.dart';
import '../../domain/entities/allocated_devices_response.dart';
import '../models/customer_model.dart';
import '../../../auth/domain/repositories/auth_repository.dart';
import '../../../admin/data/models/device_model.dart';
import '../../../../core/di/injection.dart';

class CustomerRepositoryImpl implements CustomerRepository {
  final ApiClient _apiClient;

  CustomerRepositoryImpl(this._apiClient);

  @override
  Future<List<CustomerEntity>> getCustomers(
      {int page = 0, int size = 50, String? search, String? parentCustomerId}) async {
    final url = StringBuffer(ApiConfig.customerList);
    url.write('?page=$page&size=$size');
    if (search != null && search.trim().isNotEmpty) {
      url.write('&search_param=${Uri.encodeComponent(search.trim())}');
    }
    String? effectiveParentId = parentCustomerId;
    if (effectiveParentId == null) {
      try {
        final authRepo = getIt<AuthRepository>();
        final currentUser = await authRepo.checkAuthStatus();
        if (currentUser != null && currentUser.role == UserRole.user) {
          effectiveParentId = currentUser.id;
        }
      } catch (e) {
        // Ignore auth check error
      }
    }
    if (effectiveParentId != null && effectiveParentId.isNotEmpty) {
      url.write('&parent_user_id=${Uri.encodeComponent(effectiveParentId)}');
      url.write('&parent_customer_id=${Uri.encodeComponent(effectiveParentId)}');
    }
    try {
      final response = await _apiClient.dio.get(url.toString());
      if (response.statusCode == 200 && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        final list = data['customers'] as List<dynamic>? ?? [];
        return list
            .map((item) => CustomerModel.fromJson(item as Map<String, dynamic>))
            .toList();
      }
      throw AppException('Failed to load customers');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<CustomerEntity> getCustomerDetails(String customerId) async {
    final url = ApiConfig.getCustomerDetails(customerId);
    try {
      final response = await _apiClient.dio.get(url);
      if (response.statusCode == 200 && response.data != null) {
        return CustomerModel.fromJson(response.data as Map<String, dynamic>);
      }
      throw AppException('Failed to get customer details');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<CustomerEntity> saveCustomer({
    required String fullName,
    String? firmName,
    required String mobileNo,
    required String email,
    required String password,
    required UserRole role,
    required bool active,
  }) async {
    int roleId;
    switch (role) {
      case UserRole.admin:
        roleId = 1;
        break;
      case UserRole.user:
        roleId = 2;
        break;
      case UserRole.subAdmin:
        roleId = 3;
        break;
      case UserRole.subUser:
        roleId = 4;
        break;
    }

    String? parentCustomerId;
    if (role == UserRole.subUser) {
      try {
        final authRepo = getIt<AuthRepository>();
        final currentUser = await authRepo.checkAuthStatus();
        if (currentUser != null && currentUser.role == UserRole.user) {
          parentCustomerId = currentUser.id;
        }
      } catch (e) {
        // Ignore auth fetch error in saveCustomer
      }
    }

    final url = ApiConfig.customerSave;
    final body = {
      'full_name': fullName,
      'firm_name': firmName ?? '',
      'mobile_no': mobileNo,
      'email': email,
      'password': password,
      'role': roleId,
      'active': active,
      if (parentCustomerId != null) 'parent_customer_id': parentCustomerId,
    };

    try {
      final response = await _apiClient.dio.post(url, data: body);
      final responseData = response.data;
      if (response.statusCode != null &&
          response.statusCode! >= 200 &&
          response.statusCode! < 300 &&
          responseData != null) {
        Map resData;
        if (responseData is Map) {
          resData = responseData;
        } else if (responseData is String) {
          resData = jsonDecode(responseData) as Map;
        } else {
          throw AppException('Invalid response format');
        }

        final newId = resData['customer_id']?.toString() ?? '';
        if (newId.isNotEmpty) {
          return CustomerModel(
            customerId: newId,
            fullName: fullName,
            firmName: firmName,
            mobileNo: mobileNo,
            email: email,
            role: role,
            active: active,
            isSubUser: role == UserRole.subUser,
            parentCustomerId: parentCustomerId,
          );
        }
        throw AppException(
            resData['message']?.toString() ?? 'Unable to create customer');
      }
      throw AppException('Failed to save customer');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<CustomerEntity> updateCustomer(CustomerEntity customer,
      {String? password}) async {
    final url = ApiConfig.customerUpdate;
    final model = CustomerModel(
      customerId: customer.customerId,
      fullName: customer.fullName,
      firmName: customer.firmName,
      mobileNo: customer.mobileNo,
      email: customer.email,
      role: customer.role,
      active: customer.active,
      isSubUser: customer.isSubUser,
      parentCustomerId: customer.parentCustomerId,
      parentUserName: customer.parentUserName,
    );
    final body = model.toJson();
    if (password != null && password.isNotEmpty) {
      body['password'] = password;
    }
    try {
      final response = await _apiClient.dio.put(url, data: body);
      if (response.statusCode == 200 && response.data != null) {
        return customer;
      }
      throw AppException('Failed to update customer');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<AllocatedDevicesResponse> getAllocatedDevices(
    String customerId, {
    int page = 0,
    int size = 10,
    String? search,
    String? role,
  }) async {
    final url = ApiConfig.getAllocatedDevices(customerId,
        page: page, size: size, search: search, role: role);
    try {
      final response = await _apiClient.dio.get(url);
      if (response.statusCode == 200 && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        final devicesList = data['devices'] as List<dynamic>? ?? [];
        final devices = devicesList
            .map((item) => DeviceModel.fromJson(item as Map<String, dynamic>))
            .toList();
        return AllocatedDevicesResponse(
          devices: devices,
          currentPage: data['current_page'] as int? ?? 0,
          pageSize: data['page_size'] as int? ?? size,
          totalItems: data['total_items'] as int? ?? devices.length,
          totalPages: data['total_pages'] as int? ?? 1,
        );
      }
      throw AppException('Failed to load allocated devices');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> removeDevice(String deviceId) async {
    final url = ApiConfig.removeDevice(deviceId);
    try {
      final response = await _apiClient.dio.delete(url);
      if (response.statusCode == 200 && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        if (data['status'] == false) {
          throw AppException(
              data['message']?.toString() ?? 'Failed to deallocate device');
        }
        return;
      }
      throw AppException('Failed to deallocate device');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> assignDevicesToSubUser({
    required String subUserId,
    required List<String> deviceIds,
    required String remark,
  }) async {
    final url = ApiConfig.assignDevicesToSubUser;
    final body = {
      'sub_user_id': subUserId,
      'device_ids': deviceIds,
      'remark': remark,
    };
    try {
      final response = await _apiClient.dio.post(url, data: body);
      if (response.statusCode != null &&
          response.statusCode! >= 200 &&
          response.statusCode! < 300 &&
          response.data != null) {
        final data = response.data as Map<String, dynamic>;
        if (data['status'] == true) {
          return;
        }
        throw AppException(
            data['message']?.toString() ?? 'Failed to assign devices');
      }
      throw AppException('Failed to assign devices');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> deallocateDeviceFromSubUser({
    required String subUserId,
    required List<String> deviceIds,
    required String remark,
  }) async {
    final url = ApiConfig.deallocateDeviceFromSubUser;
    final body = {
      'sub_user_id': subUserId,
      'device_ids': deviceIds,
      'remark': remark,
    };
    try {
      final response = await _apiClient.dio.put(url, data: body);
      if (response.statusCode != null &&
          response.statusCode! >= 200 &&
          response.statusCode! < 300 &&
          response.data != null) {
        final data = response.data as Map<String, dynamic>;
        if (data['status'] == true) {
          return;
        }
        throw AppException(
            data['message']?.toString() ?? 'Failed to deallocate devices');
      }
      throw AppException('Failed to deallocate devices');
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> deleteCustomer({
    required String customerId,
    bool removeDevices = false,
  }) async {
    final url =
        ApiConfig.deleteCustomer(customerId, removeDevices: removeDevices);
    try {
      final response = await _apiClient.dio.delete(url);
      if (response.statusCode == 200 && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        if (data['status'] == true || data['status'] == null) {
          return;
        }
        throw AppException(
            data['message']?.toString() ?? 'Failed to delete customer');
      }
      throw AppException('Failed to delete customer');
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
