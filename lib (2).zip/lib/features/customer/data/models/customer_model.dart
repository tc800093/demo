import '../../domain/entities/customer_entity.dart';
import '../../../auth/domain/repositories/auth_repository.dart';

class CustomerModel extends CustomerEntity {
  const CustomerModel({
    super.srNo,
    required super.customerId,
    required super.fullName,
    super.firmName,
    required super.mobileNo,
    required super.email,
    required super.role,
    required super.active,
    super.createdAt,
    super.createdBy,
    required super.isSubUser,
    super.parentCustomerId,
    super.parentUserName,
  });

  factory CustomerModel.fromJson(Map<String, dynamic> json) {
    final roleStr = json['role'] as String? ?? 'User';
    UserRole parsedRole;
    switch (roleStr.toLowerCase().trim()) {
      case 'admin':
        parsedRole = UserRole.admin;
        break;
      case 'sub_admin':
      case 'subadmin':
        parsedRole = UserRole.subAdmin;
        break;
      case 'sub_user':
      case 'subuser':
        parsedRole = UserRole.subUser;
        break;
      default:
        parsedRole = UserRole.user;
    }

    return CustomerModel(
      srNo: json['sr_no'] as int?,
      customerId: json['customer_id'] as String? ??
          json['customerId'] as String? ??
          json['id'] as String? ??
          '',
      fullName: json['full_name'] as String? ??
          json['fullName'] as String? ??
          '',
      firmName: json['firm_name'] as String? ?? json['firmName'] as String?,
      mobileNo: json['mobile_no'] as String? ??
          json['mobileNo'] as String? ??
          '',
      email: json['email'] as String? ?? '',
      role: parsedRole,
      active: json['active'] as bool? ?? true,
      createdAt: json['created_at'] as String?,
      createdBy: json['created_by'] as String?,
      isSubUser: json['is_sub_user'] as bool? ??
          json['isSubUser'] as bool? ??
          false,
      parentCustomerId: json['parent_customer_id'] as String? ??
          json['parentCustomerId'] as String? ??
          json['parent_user_id'] as String? ??
          json['parentUserId'] as String?,
      parentUserName: json['parent_user_name'] as String? ??
          json['parentUserName'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    // Roles: Admin -> 1, User -> 2, Sub_Admin -> 3, Sub_User -> 4
    int roleId;
    switch (role) {
      case UserRole.admin:
        roleId = 1;
        break;
      case UserRole.user:
        roleId = 2;
        break;
      case UserRole.subAdmin:
        roleId = 3;
        break;
      case UserRole.subUser:
        roleId = 4;
        break;
    }

    return {
      'sr_no': srNo,
      'customer_id': customerId.isEmpty ? null : customerId,
      'full_name': fullName,
      'firm_name': firmName,
      'mobile_no': mobileNo,
      'email': email,
      'role': roleId,
      'active': active,
      'is_sub_user': isSubUser,
      'parent_customer_id': parentCustomerId,
      'parent_user_name': parentUserName,
    };
  }
}
