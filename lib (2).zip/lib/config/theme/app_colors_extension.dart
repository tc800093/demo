import 'package:flutter/material.dart';

/// A ThemeExtension that provides custom semantic colors for the app.
///
/// Light and dark variants are defined as static constants.
/// Access in widgets via `AppColors.of(context)` or
/// `Theme.of(context).extension<AppColorsExtension>()!`.
class AppColorsExtension extends ThemeExtension<AppColorsExtension> {
  final Color background;
  final Color surface;
  final Color textPrimary;
  final Color textSecondary;
  final Color textMuted;
  final Color border;
  final Color cardShadow;
  final Color cardBorder;

  const AppColorsExtension({
    required this.background,
    required this.surface,
    required this.textPrimary,
    required this.textSecondary,
    required this.textMuted,
    required this.border,
    required this.cardShadow,
    required this.cardBorder,
  });

  /// Light theme palette.
  static const light = AppColorsExtension(
    background: Color(0xFFF6F8FB),
    surface: Color(0xFFFFFFFF),
    textPrimary: Color(0xFF0F172A),
    textSecondary: Color(0xFF64748B),
    textMuted: Color(0xFF94A3B8),
    border: Color(0xFFE2E8F0),
    cardShadow: Color(0x0A64748B), // textSecondary @ 4%
    cardBorder: Color(0xCCFFFFFF), // white @ 80%
  );

  /// Dark theme palette.
  static const dark = AppColorsExtension(
    background: Color(0xFF0F1117),
    surface: Color(0xFF1A1D27),
    textPrimary: Color(0xFFE2E8F0),
    textSecondary: Color(0xFF94A3B8),
    textMuted: Color(0xFF475569),
    border: Color(0xFF2D3348),
    cardShadow: Color(0x33000000), // black @ 20%
    cardBorder: Color(0x0FFFFFFF), // white @ 6%
  );

  @override
  AppColorsExtension copyWith({
    Color? background,
    Color? surface,
    Color? textPrimary,
    Color? textSecondary,
    Color? textMuted,
    Color? border,
    Color? cardShadow,
    Color? cardBorder,
  }) {
    return AppColorsExtension(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textMuted: textMuted ?? this.textMuted,
      border: border ?? this.border,
      cardShadow: cardShadow ?? this.cardShadow,
      cardBorder: cardBorder ?? this.cardBorder,
    );
  }

  @override
  AppColorsExtension lerp(covariant ThemeExtension<AppColorsExtension>? other, double t) {
    if (other is! AppColorsExtension) return this;
    return AppColorsExtension(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textMuted: Color.lerp(textMuted, other.textMuted, t)!,
      border: Color.lerp(border, other.border, t)!,
      cardShadow: Color.lerp(cardShadow, other.cardShadow, t)!,
      cardBorder: Color.lerp(cardBorder, other.cardBorder, t)!,
    );
  }
}
