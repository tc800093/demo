import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'app_colors_extension.dart';

/// AppColors encapsulates the design system colors.
/// Inspired by Material 3, Siemens industrial systems, and IQAir.
///
/// **Brand & AQI colors** are static constants (theme-independent).
/// **Semantic UI colors** (background, surface, text, border) are resolved
/// via the [AppColorsExtension] attached to the current theme.
///
/// Usage:
/// ```dart
/// final colors = AppColors.of(context);
/// Container(color: colors.background);
/// Text('Hello', style: TextStyle(color: colors.textPrimary));
/// ```
class AppColors {
  AppColors._(); // Prevent instantiation

  // ── Brand Colors (theme-independent) ──
  static const Color primary = Color(0xFF1E65CD);
  static const Color primaryLight = Color(0xFFE8F0FE);
  static const Color accent = Color(0xFF0D9488);

  // ── AQI Color System (theme-independent, data-semantic) ──
  static const Color aqiGreen = Color(0xFF00C566);       // 0–50: Good
  static const Color aqiLightGreen = Color(0xFF8BC34A);  // 51–100: Moderate
  static const Color aqiYellow = Color(0xFFFFDF00);      // 101–200: Poor
  static const Color aqiOrange = Color(0xFFFF9800);      // 201–300: Very Poor
  static const Color aqiRed = Color(0xFFFF4A4A);         // 301–400: Severe
  static const Color aqiPurple = Color(0xFFB800FF);      // 401–500: Hazardous/Severe
  static const Color offline = Color(0xFF8E9BAE);        // Offline status

  // ── Device Health & Connectivity Colors (theme-independent) ──
  static const Color online = Color(0xFF00C566);
  static const Color gpsConnected = Color(0xFF0D9488);
  static const Color batteryFull = Color(0xFF00C566);
  static const Color batteryMedium = Color(0xFFFF9800);
  static const Color batteryLow = Color(0xFFFF4A4A);

  // Helper to determine if theme is dark mode at runtime without BuildContext
  static bool get _isDark {
    try {
      final box = Hive.box('settings');
      final stored = box.get('theme_mode', defaultValue: 'system') as String;
      if (stored == 'dark') return true;
      if (stored == 'light') return false;
      return WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
    } catch (_) {
      return false;
    }
  }

  // ── Legacy static accessors (kept for backward-compat during migration) ──
  // These point dynamically to current theme palette values.
  static Color get background => _isDark ? AppColorsExtension.dark.background : AppColorsExtension.light.background;
  static Color get surface => _isDark ? AppColorsExtension.dark.surface : AppColorsExtension.light.surface;
  static Color get textPrimary => _isDark ? AppColorsExtension.dark.textPrimary : AppColorsExtension.light.textPrimary;
  static Color get textSecondary => _isDark ? AppColorsExtension.dark.textSecondary : AppColorsExtension.light.textSecondary;
  static Color get textMuted => _isDark ? AppColorsExtension.dark.textMuted : AppColorsExtension.light.textMuted;
  static Color get border => _isDark ? AppColorsExtension.dark.border : AppColorsExtension.light.border;

  // ── Theme-aware accessor ──
  /// Returns the [AppColorsExtension] from the current theme.
  ///
  /// Usage: `final c = AppColors.of(context); c.background;`
  static AppColorsExtension of(BuildContext context) {
    return Theme.of(context).extension<AppColorsExtension>() ??
        AppColorsExtension.light;
  }

  /// Returns the color corresponding to a given AQI value.
  static Color getAqiColor(int? aqi) {
    if (aqi == null) return offline;
    if (aqi <= 50) return aqiGreen;
    if (aqi <= 100) return aqiLightGreen;
    if (aqi <= 200) return aqiYellow;
    if (aqi <= 300) return aqiOrange;
    if (aqi <= 400) return aqiRed;
    return aqiPurple;
  }

  /// Returns the status label corresponding to a given AQI value.
  static String getAqiStatus(int? aqi) {
    if (aqi == null) return 'Offline';
    if (aqi <= 50) return 'GOOD';
    if (aqi <= 100) return 'MODERATE';
    if (aqi <= 200) return 'POOR';
    if (aqi <= 300) return 'VERY POOR';
    if (aqi <= 400) return 'SEVERE';
    return 'HAZARDOUS';
  }

  /// Returns the status label for visual display corresponding to a given AQI value.
  static String getAqiDescription(int? aqi) {
    if (aqi == null) return 'No device connection';
    if (aqi <= 50) return 'Air quality is satisfactory.';
    if (aqi <= 100) return 'Air quality is acceptable.';
    if (aqi <= 200) return 'Sensitive groups may experience health effects.';
    if (aqi <= 300) return 'Everyone may begin to experience health effects.';
    if (aqi <= 400) return 'Health alert: everyone may experience more serious health effects.';
    return 'Health warning of emergency conditions.';
  }
}
