import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../config/theme/colors.dart';
import 'custom_widgets.dart';

class ErrorDisplayWidget extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final IconData? icon;

  const ErrorDisplayWidget({
    super.key,
    required this.message,
    this.onRetry,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    final lowerMessage = message.toLowerCase();

    // Auto-select icon if not provided
    final IconData displayIcon = icon ??
        (() {
          if (lowerMessage.contains('timeout') ||
              lowerMessage.contains('connection') ||
              lowerMessage.contains('internet') ||
              lowerMessage.contains('network') ||
              lowerMessage.contains('offline')) {
            return Icons.wifi_off_rounded;
          }
          if (lowerMessage.contains('no data') ||
              lowerMessage.contains('empty') ||
              lowerMessage.contains('not found') ||
              lowerMessage.contains('404')) {
            return Icons.insert_drive_file_outlined;
          }
          if (lowerMessage.contains('server') ||
              lowerMessage.contains('internal') ||
              lowerMessage.contains('500') ||
              lowerMessage.contains('502') ||
              lowerMessage.contains('503')) {
            return Icons.dns_rounded;
          }
          return Icons.error_outline_rounded;
        })();

    // Auto-select title based on message content
    final String displayTitle = (() {
      if (lowerMessage.contains('timeout') ||
          lowerMessage.contains('connection') ||
          lowerMessage.contains('internet') ||
          lowerMessage.contains('network') ||
          lowerMessage.contains('offline')) {
        return 'Network Connection Issue';
      }
      if (lowerMessage.contains('no data') ||
          lowerMessage.contains('empty') ||
          lowerMessage.contains('not found') ||
          lowerMessage.contains('404')) {
        return 'No Data Found';
      }
      if (lowerMessage.contains('server') ||
          lowerMessage.contains('internal') ||
          lowerMessage.contains('500')) {
        return 'Server Under Maintenance';
      }
      return 'Oops! Something Went Wrong';
    })();

    return Center(
      child: Container(
        margin: EdgeInsets.all(24.r),
        padding: EdgeInsets.all(24.r),
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(24.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(10), // modern subtle shadow
              blurRadius: 16.r,
              offset: const Offset(0, 8),
            ),
          ],
          border: Border.all(
            color: colors.border.withAlpha(128),
            width: 1.r,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 72.r,
              width: 72.r,
              decoration: BoxDecoration(
                color: AppColors.aqiRed.withAlpha(20),
                shape: BoxShape.circle,
              ),
              child: Icon(
                displayIcon,
                size: 36.r,
                color: AppColors.aqiRed,
              ),
            ),
            SizedBox(height: 20.h),
            Text(
              displayTitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: colors.textPrimary,
                fontFamily: 'Poppins',
              ),
            ),
            SizedBox(height: 10.h),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14.sp,
                color: colors.textSecondary,
                height: 1.4.h,
                fontFamily: 'Poppins',
              ),
            ),
            if (onRetry != null) ...[
              SizedBox(height: 24.h),
              SizedBox(
                width: 140.w,
                child: PrimaryButton(
                  text: 'Retry',
                  icon: Icons.refresh_rounded,
                  onPressed: onRetry,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
