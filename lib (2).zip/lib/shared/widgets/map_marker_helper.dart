import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapMarkerHelper {
  static Future<BitmapDescriptor> createAqiMarker(String aqiText, Color color) async {
    final ui.PictureRecorder pictureRecorder = ui.PictureRecorder();
    final Canvas canvas = Canvas(pictureRecorder);

    // Dimensions for a circular pin
    const double width = 70.0;
    const double height = 75.0;
    const double centerX = width / 2;
    const double centerY = 32.0;
    const double radius = 26.0;

    // Create paths for circle and pointer tail
    final Path pinPath = Path()
      ..addOval(Rect.fromCircle(center: const Offset(centerX, centerY), radius: radius));

    final Path tailPath = Path()
      ..moveTo(centerX - 8.0, centerY + radius - 3.0)
      ..lineTo(centerX + 8.0, centerY + radius - 3.0)
      ..lineTo(centerX, height - 2.0)
      ..close();

    // Union the circle and tail into a single path for a clean outline
    final Path combinedPath = Path.combine(PathOperation.union, pinPath, tailPath);

    // 1. Draw Shadow
    final Paint shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.0);

    canvas.save();
    canvas.translate(0.0, 2.5); // Offset shadow slightly down
    canvas.drawPath(combinedPath, shadowPaint);
    canvas.restore();

    // 2. Draw Bubble Body (Background)
    final Paint bubblePaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    canvas.drawPath(combinedPath, bubblePaint);

    // 3. Draw White Border
    final Paint borderPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    canvas.drawPath(combinedPath, borderPaint);

    // 4. Draw AQI Text
    final TextPainter textPainter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );
    textPainter.text = TextSpan(
      text: aqiText,
      style: const TextStyle(
        fontSize: 16.0,
        fontWeight: FontWeight.w900,
        color: Colors.white,
        fontFamily: 'Inter',
      ),
    );
    textPainter.layout();

    // Paint text centered in the circular bubble
    textPainter.paint(
      canvas,
      Offset(
        centerX - textPainter.width / 2,
        centerY - textPainter.height / 2,
      ),
    );

    // Export image bytes
    final ui.Image image = await pictureRecorder.endRecording().toImage(
          width.toInt(),
          height.toInt(),
        );
    final ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    final Uint8List uint8list = byteData!.buffer.asUint8List();

    return BitmapDescriptor.bytes(uint8list);
  }
}
