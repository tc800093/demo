import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../config/theme/colors.dart';

/// Premium custom Elevated Button with micro-animations.
class PrimaryButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final IconData? icon;

  const PrimaryButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.icon,
  });

  @override
  State<PrimaryButton> createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => widget.onPressed != null ? _controller.forward() : null,
      onTapUp: (_) => widget.onPressed != null ? _controller.reverse() : null,
      onTapCancel: () =>
          widget.onPressed != null ? _controller.reverse() : null,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: SizedBox(
          width: double.infinity,
          height: 45.h,
          child: ElevatedButton(
            onPressed: widget.isLoading ? null : widget.onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              disabledBackgroundColor: AppColors.primary.withValues(alpha: 0.6),
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14.r),
              ),
            ),
            child: widget.isLoading
                ? SizedBox(
                    height: 24.r,
                    width: 24.r,
                    child: const CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (widget.icon != null) ...[
                        Icon(widget.icon, size: 20.r),
                        SizedBox(width: 8.w),
                      ],
                      Text(
                        widget.text,
                        style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

/// Secondary Outlined Button.
class SecondaryButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final IconData? icon;

  const SecondaryButton({
    super.key,
    required this.text,
    this.onPressed,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return SizedBox(
      width: double.infinity,
      height: 54.h,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: colors.border, width: 1.5),
          foregroundColor: colors.textPrimary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14.r),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 20.r, color: colors.textSecondary),
              SizedBox(width: 8.w),
            ],
            Text(
              text,
              style: TextStyle(
                fontSize: 15.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Status Chip displaying AQI classifications or general online states.
class AqiStatusChip extends StatelessWidget {
  final String label;
  final Color color;

  const AqiStatusChip({
    super.key,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: color.withValues(alpha: 0.2), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8.r,
            height: 8.r,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 4.w),
          Text(
            label,
            style: TextStyle(
              fontSize: 10.sp,
              fontWeight: FontWeight.w600,
              color: color == AppColors.aqiYellow
                  ? const Color(0xFFD4AF37)
                  : color,
            ),
          ),
        ],
      ),
    );
  }
}

/// SCADA-inspired Card Container.
class ScadaCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? backgroundColor;

  const ScadaCard({
    super.key,
    required this.child,
    this.padding,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    return Container(
      padding: padding ?? EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: backgroundColor ?? colors.surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: colors.cardBorder),
        boxShadow: [
          BoxShadow(
            color: colors.cardShadow,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}

/// Dynamic Environmental Parameter Grid Card.
class ParamCard extends StatelessWidget {
  final String label;
  final String value;
  final String unit;
  final int?
      scoreValue; // Optional score for calculating parameters color indicator

  const ParamCard({
    super.key,
    required this.label,
    required this.value,
    required this.unit,
    this.scoreValue,
  });

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    // Generate color indicator based on parameter type
    Color indicatorColor = AppColors.online;
    if (scoreValue != null) {
      if (scoreValue! > 150) {
        indicatorColor = AppColors.aqiRed;
      } else if (scoreValue! > 100) {
        indicatorColor = AppColors.aqiOrange;
      } else if (scoreValue! > 50) {
        indicatorColor = AppColors.aqiYellow;
      }
    }

    return ScadaCard(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w600,
                  color: colors.textSecondary,
                ),
              ),
              Container(
                width: 6.r,
                height: 6.r,
                decoration: BoxDecoration(
                  color: indicatorColor,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          SizedBox(height: 6.h),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.bottomLeft,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: colors.textPrimary,
                    height: 1,
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  unit,
                  style: TextStyle(
                    fontSize: 11.sp,
                    fontWeight: FontWeight.w500,
                    color: colors.textMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Offline Banner for visual feedback
class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppColors.offline,
      padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 16.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.wifi_off_rounded, color: Colors.white, size: 16.r),
          SizedBox(width: 8.w),
          Text(
            'Offline Mode — Displaying cached metrics',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

/// A premium animated eye icon for live monitoring screens.
class AnimatedEyeIcon extends StatefulWidget {
  final Color? color;
  final double? size;

  const AnimatedEyeIcon({
    super.key,
    this.color,
    this.size,
  });

  @override
  State<AnimatedEyeIcon> createState() => _AnimatedEyeIconState();
}

class _AnimatedEyeIconState extends State<AnimatedEyeIcon>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.5).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _opacityAnimation = Tween<double>(begin: 0.8, end: 0.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double iconSize = widget.size ?? 20.r;
    final Color iconColor = widget.color ?? AppColors.primary;

    return Stack(
      alignment: Alignment.center,
      children: [
        // Pulsing background ring
        AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Opacity(
              opacity: _opacityAnimation.value,
              child: Transform.scale(
                scale: _scaleAnimation.value,
                child: Container(
                  width: iconSize * 1.6,
                  height: iconSize * 1.6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: iconColor.withValues(alpha: 0.5),
                      width: 2.r,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
        // The Eye Icon
        Icon(
          Icons.visibility_rounded,
          color: iconColor,
          size: iconSize,
        ),
      ],
    );
  }
}

/// A premium animated sprinkler override icon.
class AnimatedSprinklerIcon extends StatefulWidget {
  final bool isRunning;
  final double size;

  const AnimatedSprinklerIcon({
    super.key,
    required this.isRunning,
    this.size = 25.0,
  });

  @override
  State<AnimatedSprinklerIcon> createState() => _AnimatedSprinklerIconState();
}

class _AnimatedSprinklerIconState extends State<AnimatedSprinklerIcon>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    if (widget.isRunning) {
      _controller.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant AnimatedSprinklerIcon oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isRunning != oldWidget.isRunning) {
      if (widget.isRunning) {
        _controller.repeat();
      } else {
        _controller.stop();
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double size = widget.size;
    if (!widget.isRunning) {
      return Icon(
        Icons.invert_colors_off_rounded,
        size: size,
        color: AppColors.aqiRed,
      );
    }

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final t = _controller.value;
        return SizedBox(
          width: size * 1.6,
          height: size * 1.6,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Main pulsating water drop
              Transform.scale(
                scale: 1.0 + 0.1 * math.sin(t * 2 * math.pi),
                child: Icon(
                  Icons.water_drop_rounded,
                  size: size,
                  color: const Color(0xFF0284C7),
                ),
              ),
              // Spray particle 1 (Top-Left)
              Positioned(
                top: (1.0 - t) * (size * 0.3) + (size * 0.1),
                left: (1.0 - t) * (size * 0.3) + (size * 0.1),
                child: Opacity(
                  opacity: 1.0 - t,
                  child: Icon(
                    Icons.circle,
                    size: size * 0.2,
                    color: const Color(0xFF38bdf8),
                  ),
                ),
              ),
              // Spray particle 2 (Top)
              Positioned(
                top: (1.0 - t) * (size * 0.45),
                child: Opacity(
                  opacity: 1.0 - t,
                  child: Icon(
                    Icons.circle,
                    size: size * 0.22,
                    color: const Color(0xFF38bdf8),
                  ),
                ),
              ),
              // Spray particle 3 (Top-Right)
              Positioned(
                top: (1.0 - t) * (size * 0.3) + (size * 0.1),
                right: (1.0 - t) * (size * 0.3) + (size * 0.1),
                child: Opacity(
                  opacity: 1.0 - t,
                  child: Icon(
                    Icons.circle,
                    size: size * 0.2,
                    color: const Color(0xFF38bdf8),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
