import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../config/theme/colors.dart';
import '../../features/contractor/domain/repositories/sites_repository.dart';

/// Digital replica of the Maha AQI physical LED display board.
/// Features a dark industrial frame, high-contrast neon grids, and monospace typography.
class LedDisplayPreview extends StatefulWidget {
  final SiteEntity site;

  const LedDisplayPreview({
    super.key,
    required this.site,
  });

  @override
  State<LedDisplayPreview> createState() => _LedDisplayPreviewState();
}

class _LedDisplayPreviewState extends State<LedDisplayPreview>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.45, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    final aqi = widget.site.aqi ?? 0;
    final aqiColor = AppColors.getAqiColor(aqi);
    final aqiStatus = AppColors.getAqiStatus(aqi);

    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        final pulseVal = _pulseAnimation.value;
        return Container(
          width: double.infinity,
          decoration: BoxDecoration(
            // Premium double frame outer boundary
            gradient: LinearGradient(
              colors: Theme.of(context).brightness == Brightness.light
                  ? [const Color(0xFFF1F5F9), const Color(0xFFE2E8F0), const Color(0xFFCBD5E1)]
                  : [const Color(0xFF1E293B), const Color(0xFF0F172A), const Color(0xFF020617)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16.r),
            border: Border.all(color: colors.border, width: 1.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Padding(
            padding: EdgeInsets.all(6.r), // Inner bezel spacing
            child: Container(
              decoration: BoxDecoration(
                color: colors.background, // Ultra clean adaptive background
                borderRadius: BorderRadius.circular(11.r),
                border: Border.all(color: colors.border, width: 2.r),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(9.r),
                child: Stack(
                  children: [
                    // LED Grid Panel Contents
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Display Header / Metadata panel
                        _buildScreenHeader(pulseVal),

                        // Main LED Grid Area
                        Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 16.w, vertical: 14.h),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Top Primary AQI Panel
                              _buildAqiPanel(
                                  aqi, aqiColor, aqiStatus, pulseVal),

                              SizedBox(height: 14.h),

                              // Monospace parameters grid
                              _buildParametersGrid(pulseVal),
                            ],
                          ),
                        ),
                      ],
                    ),

                    // Dot Matrix Screen Texture Overlay
                    const Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: LedDotMatrixPainter(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildScreenHeader(double pulseVal) {
    final colors = AppColors.of(context);
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 16.w),
      decoration: BoxDecoration(
        color: colors.border, // Clean adaptive header background
        border: Border(
          bottom: BorderSide(color: colors.border, width: 1.5),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                // Pulsing LED Light: Bright red with clear blinking glow
                Container(
                  width: 8.r,
                  height: 8.r,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444)
                        .withValues(alpha: 0.2 + 0.8 * pulseVal),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFEF4444)
                            .withValues(alpha: 0.6 * pulseVal),
                        blurRadius: 6.r,
                        spreadRadius: 1.5.r,
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: Text(
                    'AQI MONITOR',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w900,
                      color: colors.textPrimary, // Adaptive text color
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 8.w),
          // High-contrast, solid green LIVE chip that blinks clearly via opacity
          Opacity(
            opacity: 0.25 + 0.75 * pulseVal,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 4.h),
              decoration: BoxDecoration(
                color: AppColors.online, // Solid green background
                borderRadius: BorderRadius.circular(4.r), // Pill shape
                boxShadow: [
                  BoxShadow(
                    color: AppColors.online.withValues(alpha: 0.4),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                'LIVE',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w900,
                  color: Colors.white, // High contrast white text
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAqiPanel(
      int aqi, Color aqiColor, String status, double pulseVal) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.w),
      decoration: BoxDecoration(
        color: Colors.white, // Clean white card
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'AIR QUALITY INDEX',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w900,
                  color: const Color(0xFF1E293B), // Dark text for readability
                  letterSpacing: 1.0,
                ),
              ),
              SizedBox(height: 6.h),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                decoration: BoxDecoration(
                  color: aqiColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6.r),
                  border: Border.all(
                      color: aqiColor.withValues(alpha: 0.4), width: 1.r),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w900,
                    color: aqiColor,
                  ),
                ),
              ),
            ],
          ),
          Text(
            '$aqi',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 38.sp,
              fontWeight: FontWeight.w900,
              color: aqiColor,
              shadows: [
                Shadow(
                  color: aqiColor.withValues(alpha: 0.25 * pulseVal),
                  blurRadius: 6,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildParametersGrid(double pulseVal) {
    final site = widget.site;
    final List<Widget> cells = [];

    // Only show parameters up to Humidity
    final allowedKeys = ['PM2.5', 'PM10', 'PM1', 'TSP', 'Temp', 'Humidity'];

    for (final key in allowedKeys) {
      if (site.parameters.containsKey(key)) {
        final reading = site.parameters[key]!;
        final value = reading.value?.toString() ?? '-';
        final unit = reading.unit;

        // Clean up key label for display
        String displayKey = key.toUpperCase();
        if (displayKey == 'PM1') {
          displayKey = 'PM1.0';
        }

        // Determine glowColor based on parameter type
        Color glowColor = AppColors.online;
        if (displayKey == 'PM2.5' || displayKey == 'PM10') {
          glowColor = AppColors.getAqiColor(reading.value?.toInt() ?? 0);
        } else if (displayKey == 'TEMP') {
          glowColor = Colors.amber;
        } else if (displayKey == 'HUMIDITY') {
          glowColor = Colors.cyan;
        } else if (displayKey == 'CO' ||
            displayKey == 'CO₂' ||
            displayKey == 'NO₂' ||
            displayKey == 'SO₂' ||
            displayKey == 'O3' ||
            displayKey == 'VOC' ||
            displayKey == 'TSP') {
          glowColor = Colors.orangeAccent;
        }

        cells.add(_buildLedCell(displayKey, value, unit, glowColor, pulseVal));
      }
    }

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10.w,
      mainAxisSpacing: 10.h,
      childAspectRatio: 2.1, // Expanded box size vertically to prevent overflow
      children: cells,
    );
  }

  Widget _buildLedCell(String title, String value, String unit, Color glowColor,
      double pulseVal) {
    // For light mode, make glowColor high contrast by using deeper colors if needed
    Color displayColor = glowColor;
    if (glowColor == Colors.amber) {
      displayColor = const Color(0xFFD97706); // Amber 600
    } else if (glowColor == Colors.orangeAccent) {
      displayColor = const Color(0xFFEA580C); // Orange 600
    } else if (glowColor == Colors.cyan) {
      displayColor = const Color(0xFF0891B2); // Cyan 600
    } else if (glowColor == AppColors.online) {
      displayColor = const Color(0xFF15803D); // Green 700
    }

    final colors = AppColors.of(context);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: colors.surface, // Adaptive card background
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: colors.border, width: 1.2.r),
        boxShadow: [
          BoxShadow(
            color: colors.cardShadow,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 13.sp, // Decreased for responsiveness
                fontWeight: FontWeight.w900,
                color: colors.textSecondary, // Adaptive text color
              ),
            ),
            SizedBox(height: 4.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 24.sp, // High contrast value
                    fontWeight: FontWeight.w900,
                    color: displayColor,
                    shadows: [
                      Shadow(
                        color: displayColor.withValues(alpha: 0.15 * pulseVal),
                        blurRadius: 4.r,
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 8.w),
                Text(
                  unit,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 12.sp, // Decreased for responsiveness
                    fontWeight: FontWeight.w900,
                    color: displayColor.withValues(
                        alpha: 0.8), // Clearly visible unit
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Painter to draw a clean dot matrix grid mesh pattern over the LED display
class LedDotMatrixPainter extends CustomPainter {
  const LedDotMatrixPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
          .withValues(alpha: 0.03) // Soft screen grid texture in light mode
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;

    const double spacing = 3.0;

    // Draw vertical mesh lines
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    // Draw horizontal mesh lines
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
