import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:vasundhara_maha_aqim/app/router/router.dart';
import 'package:vasundhara_maha_aqim/features/contractor/presentation/widgets/sprinkler_info_card_widget.dart';
import '../../config/theme/colors.dart';
import '../../features/contractor/domain/repositories/sites_repository.dart';
import '../../features/contractor/presentation/bloc/sprinkler_bloc.dart';
import 'custom_widgets.dart';

/// SCADA-inspired circular gauge representing AQI level and status.
class AqiGauge extends StatefulWidget {
  final SiteEntity site;
  final String trendText;
  final String updateTimeText;
  final bool showDeviceAndSprinkler;

  const AqiGauge({
    super.key,
    required this.site,
    this.trendText = '+16 since last hour',
    this.updateTimeText = 'Updated 2 min ago',
    this.showDeviceAndSprinkler = false,
  });

  @override
  State<AqiGauge> createState() => _AqiGaugeState();
}

class _AqiGaugeState extends State<AqiGauge> with TickerProviderStateMixin {
  late AnimationController _signalController;
  late Animation<double> _signalAnimation;

  // Dedicated controller for the card border glow — slower, more dramatic.
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // Timer for the "last sync" live seconds counter.
  Timer? _syncTimer;
  int _secondsSinceSync = 0;

  @override
  void initState() {
    super.initState();
    _signalController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _signalAnimation = Tween<double>(begin: 0.45, end: 1.0).animate(
      CurvedAnimation(parent: _signalController, curve: Curves.easeInOut),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _startSyncTimer();
  }

  @override
  void didUpdateWidget(covariant AqiGauge oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Reset the counter when site data updates (new SSE event arrived).
    if (widget.site.lastSyncTime != oldWidget.site.lastSyncTime) {
      _secondsSinceSync = 0;
    }
  }

  void _startSyncTimer() {
    _syncTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && widget.site.isDeviceOnline) {
        setState(() {
          _secondsSinceSync++;
        });
      }
    });
  }

  String _formatDateTime(DateTime dt) {
    final d = dt.day.toString().padLeft(2, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final y = dt.year;
    final h = dt.hour.toString().padLeft(2, '0');
    final min = dt.minute.toString().padLeft(2, '0');
    final s = dt.second.toString().padLeft(2, '0');
    return '$d/$m/$y $h:$min:$s';
  }

  @override
  void dispose() {
    _signalController.dispose();
    _glowController.dispose();
    _syncTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.of(context);
    final aqi = widget.site.aqi ?? 0;

    // Watch SprinklerBloc to update state in real-time
    final sprinklerState = context.watch<SprinklerBloc>().state;
  
    final isSprinklerRunning = (sprinklerState is SprinklerActionSuccess &&
            sprinklerState.site.id == widget.site.id)
        ? sprinklerState.site.isSprinklerRunning
        : widget.site.isSprinklerRunning;
    final isSprinklerLoading = sprinklerState is SprinklerLoading;

    final statusColor = AppColors.getAqiColor(aqi);
    final statusText = AppColors.getAqiStatus(aqi);
    final isLive = widget.site.isDeviceOnline;

    final lastSyncLocal = widget.site.lastSyncTime.toLocal();
    final now = DateTime.now();
    final isSyncToday = lastSyncLocal.year == now.year &&
        lastSyncLocal.month == now.month &&
        lastSyncLocal.day == now.day;

    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return Container(
          padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 10.w),
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: BorderRadius.circular(20.r),
            border: isLive
                ? Border.all(
                    color: statusColor.withValues(
                        alpha: 0.15 + 0.20 * _glowAnimation.value),
                    width: 1.5,
                  )
                : null,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 15,
                offset: const Offset(0, 8),
              ),
              if (isLive)
                BoxShadow(
                  color: statusColor.withValues(
                      alpha: 0.06 + 0.08 * _glowAnimation.value),
                  blurRadius: 16 + 8 * _glowAnimation.value,
                  spreadRadius: 1 + 2 * _glowAnimation.value,
                ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  //here show gps img according to device status red for no signal,green for signal
                  //if device is offline show red color with line in between otherwise green color without line
                  if (isLive)
                    AnimatedBuilder(
                      animation: _signalAnimation,
                      builder: (context, child) {
                        return Opacity(
                          opacity: _signalAnimation.value,
                          child: Icon(
                            Icons.wifi_rounded,
                            size: 22.r,
                            color: AppColors.aqiGreen,
                          ),
                        );
                      },
                    )
                  else
                    Icon(
                      Icons.wifi_off_rounded,
                      size: 22.r,
                      color: Colors.red,
                    ),

                  //here show  GPS icon red for no signal,green for signal
                  //if device is offline show red color with line in between otherwise green color without line
                  if (isLive)
                    AnimatedBuilder(
                      animation: _signalAnimation,
                      builder: (context, child) {
                        return Opacity(
                          opacity: _signalAnimation.value,
                          child: Icon(
                            Icons.gps_fixed_rounded,
                            size: 22.r,
                            color: AppColors.aqiGreen,
                          ),
                        );
                      },
                    )
                  else
                    Icon(
                      Icons.gps_off_rounded,
                      size: 22.r,
                      color: Colors.red,
                    ),
                ],
              ),

              // SizedBox(height: 10.h),
              SizedBox(
                width: double.infinity,
                //    height: 140.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CustomPaint(
                      size: Size(150.w, 150.w),
                      painter: _AqiGaugePainter(
                        aqi: aqi,
                        textPrimaryColor: colors.textPrimary,
                        borderColor: colors.border,
                      ),
                    ),
                    //here show thw Good Moderate poor status text
                    Positioned(
                      top: 30.h,
                      child: Column(
                        children: [
                          //AQI icon and text
                          Row(
                            children: [
                              Text(
                                'A',
                                style: TextStyle(
                                  fontSize: 22.sp,
                                  fontWeight: FontWeight.w900,
                                  color: colors.textPrimary,
                                ),
                              ),
                              // here show thw Q img in red and green color according to device status
                              //if device is offline show red color with line in between otherwise green color without line
                              // AnimatedBuilder(
                              //   animation: _signalAnimation,
                              //   builder: (context, child) {
                              //     return Opacity(
                              //       opacity:
                              //           isLive ? _signalAnimation.value : 0.5,
                              //       child: Image.asset(
                              //         'assets/icons/Q_without_bg.png',
                              //         width: 55.r,
                              //         height: 30.r,
                              //         fit: BoxFit.contain,
                              //       ),
                              //     );
                              //   },
                              // ),
                              ColorFiltered(
                                colorFilter: ColorFilter.mode(
                                  isLive
                                      ? statusColor
                                      : Colors
                                          .red, // when device is live, use statusColor, else use red
                                  BlendMode
                                      .srcATop, // this mode tints the image to the new color
                                ),
                                child: Image.asset(
                                  'assets/icons/Q_without_bg.png',
                                  //  width: 55.r,
                                  height: 30.r,
                                  fit: BoxFit.contain,
                                  color: isLive ? statusColor : Colors.red,
                                ),
                              ),
                              Text(
                                'I',
                                style: TextStyle(
                                  fontSize: 22.sp,
                                  fontWeight: FontWeight.w900,
                                  color: colors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 35.h),
                          Text(
                            statusText,
                            style: TextStyle(
                              fontSize: 13.sp,
                              fontWeight: FontWeight.bold,
                              color: statusColor,
                            ),
                          ),
                          SizedBox(height: 2.h),
                          // Spacer to prevent overlap with the center needle pivot
                          // AQI value with subtle glow when live
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.w, vertical: 1.5.h),
                            decoration: isLive
                                ? BoxDecoration(
                                    borderRadius: BorderRadius.circular(10.r),
                                    boxShadow: [
                                      BoxShadow(
                                        color: statusColor.withValues(
                                            alpha: 0.08 +
                                                0.10 * _glowAnimation.value),
                                        blurRadius:
                                            8 + 4 * _glowAnimation.value,
                                        spreadRadius: 1.2,
                                      ),
                                    ],
                                  )
                                : null,
                            child: Text(
                              '$aqi',
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                                color: colors.textPrimary,
                                height: 1.1,
                              ),
                            ),
                          ),
                          // SizedBox(height: 4.h),
                          // Row(
                          //   mainAxisSize: MainAxisSize.min,
                          //   children: [
                          //     Icon(
                          //       widget.trendText.startsWith('-')
                          //           ? Icons.arrow_downward_rounded
                          //           : Icons.arrow_upward_rounded,
                          //       size: 11.r,
                          //       color: widget.trendText.startsWith('-')
                          //           ? AppColors.online
                          //           : AppColors.aqiRed,
                          //     ),
                          //     SizedBox(width: 2.w),
                          //     Text(
                          //       widget.trendText,
                          //       style: TextStyle(
                          //         fontSize: 10.sp,
                          //         fontWeight: FontWeight.w600,
                          //         color: AppColors.textSecondary,
                          //       ),
                          //     ),
                          //   ],
                          // ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              //SizedBox(height: 8.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          GestureDetector(
                            onTap: isSprinklerLoading
                                ? null
                                : () {
                                    // context.push(AppRoutes.contractorSprinklerPage);
                                    context.read<SprinklerBloc>().add(
                                          SprinklerToggleRequested(
                                            siteId: widget.site.id,
                                            isRunning: !isSprinklerRunning,
                                          ),
                                        );
                                  },
                            behavior: HitTestBehavior.opaque,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 4.w, vertical: 4.h),
                              child: isSprinklerLoading
                                  ? SizedBox(
                                      width: 22.r,
                                      height: 22.r,
                                      child: const CircularProgressIndicator(
                                        strokeWidth: 1.5,
                                        color: AppColors.primary,
                                      ),
                                    )
                                  : AnimatedSprinklerIcon(
                                      isRunning: isSprinklerRunning,
                                      size: 25.r,
                                    ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              context.push(
                                AppRoutes.contractorSprinklerPage,
                                extra: widget.site.id,
                              );
                              // _showInfoDialog(context);
                            },
                            borderRadius: BorderRadius.circular(20),
                            child: Icon(
                              Icons.info_outline,
                              size: 18,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  if (isLive)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Pulsing sync icon
                        AnimatedBuilder(
                          animation: _signalAnimation,
                          builder: (context, child) {
                            return Icon(
                              Icons.sync_rounded,
                              size: 14.r,
                              color: AppColors.online
                                  .withValues(alpha: _signalAnimation.value),
                            );
                          },
                        ),
                        SizedBox(width: 6.w),
                        Text(
                          isSyncToday
                              ? (_secondsSinceSync < 2
                                  ? 'Syncing now...'
                                  : 'Last sync: ${_secondsSinceSync}s ago')
                              : 'Last sync: ${_formatDateTime(lastSyncLocal)}',
                          style: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: isSyncToday && _secondsSinceSync < 2
                                ? FontWeight.w600
                                : FontWeight.normal,
                            color: isSyncToday && _secondsSinceSync < 2
                                ? AppColors.online
                                : colors.textSecondary,
                          ),
                        ),
                      ],
                    )
                  else
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.cloud_off_rounded,
                          size: 14.r,
                          color: AppColors.offline,
                        ),
                        SizedBox(width: 6.w),
                        Text(
                          'Last sync: ${_formatDateTime(lastSyncLocal)}',
                          style: TextStyle(
                            fontSize: 12.sp,
                            color: colors.textMuted,
                          ),
                        ),
                      ],
                    ),
                ],
              ),
              //    SizedBox(height: 12.h),
              Divider(
                height: 10,
                thickness: 1,
                color: colors.border,
              ),
              SizedBox(height: 4.h),
              _buildParametersGrid(context),
              SprinklerInfoCardWidget(
                  site: widget.site, isSprinklerRunning: isSprinklerRunning)
            ],
          ),
        );
      },
    );
  }

  Widget _buildParametersGrid(BuildContext context) {
    final site = widget.site;
    final List<Widget> cells = [];
    //final allowedKeys = ['PM2.5', 'PM10', 'PM1', 'TSP', 'Temp', 'Humidity'];
    final allowedKeys = ['PM2.5', 'PM10', 'Temp', 'Humidity'];
    for (final key in allowedKeys) {
      if (site.parameters.containsKey(key)) {
        final reading = site.parameters[key]!;
        final value = reading.value?.toString() ?? '-';
        final unit = reading.unit;

        String displayKey = key.toUpperCase();
        if (displayKey == 'PM1') {
          displayKey = 'PM1.0';
        }

        Color glowColor = AppColors.online;
        if (displayKey == 'PM2.5' || displayKey == 'PM10') {
          glowColor = AppColors.getAqiColor(reading.value?.toInt() ?? 0);
        } else if (displayKey == 'TEMP') {
          glowColor = Colors.amber;
        } else if (displayKey == 'HUMIDITY') {
          glowColor = Colors.cyan;
        } else if (displayKey == 'CO' ||
            displayKey == 'CO₂' ||
            displayKey == 'NO₂' ||
            displayKey == 'SO₂' ||
            displayKey == 'O3' ||
            displayKey == 'VOC' ||
            displayKey == 'TSP') {
          glowColor = Colors.orangeAccent;
        }

        cells.add(_buildParameterCell(displayKey, value, unit, glowColor));
      }
    }

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10.w,
      mainAxisSpacing: 10.h,
      childAspectRatio: 2.3, // Proportions for a nice layout
      children: cells,
    );
  }

  Widget _buildParameterCell(
      String title, String value, String unit, Color glowColor) {
    Color displayColor = glowColor;
    if (glowColor == Colors.amber) {
      displayColor = const Color(0xFFD97706); // Amber 600
    } else if (glowColor == Colors.orangeAccent) {
      displayColor = const Color(0xFFEA580C); // Orange 600
    } else if (glowColor == Colors.cyan) {
      displayColor = const Color(0xFF0891B2); // Cyan 600
    } else if (glowColor == AppColors.online) {
      displayColor = const Color(0xFF15803D); // Green 700
    }

    final colors = AppColors.of(context);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: colors.background, // Faint background inside card for depth
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: colors.border, width: 1.r),
      ),
      child: Stack(
        children: [
          // Subtle Grid Background inside each box
          const Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: _CellGridPainter(),
              ),
            ),
          ),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 11.sp,
                    fontWeight: FontWeight.bold,
                    color: colors.textSecondary,
                  ),
                ),
                SizedBox(height: 4.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(
                      value,
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 22.sp,
                        fontWeight: FontWeight.bold,
                        color: displayColor,
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      unit,
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                        color: displayColor.withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CellGridPainter extends CustomPainter {
  const _CellGridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color =
          Colors.black.withValues(alpha: 0.015) // Extremely soft grid texture
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 4.0;

    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _AqiGaugePainter extends CustomPainter {
  final int aqi;
  final Color textPrimaryColor;
  final Color borderColor;

  _AqiGaugePainter({
    required this.aqi,
    required this.textPrimaryColor,
    required this.borderColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final double centerX = size.width / 2;
    final double centerY = size.height / 2 + 5;
    final double radius = size.width / 2 - 10;

    final Offset center = Offset(centerX, centerY);

    // Drawing Parameters
    const double startAngle = 135 * pi / 180;
    const double sweepAngle = 270 * pi / 180;
    final double strokeWidth = size.width * 0.09;

    // Draw background track
    final Paint trackPaint = Paint()
      ..color = borderColor.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepAngle,
      false,
      trackPaint,
    );

    // Colored Arc Segments: Good, Moderate, Poor, Very Poor, Severe, Hazardous
    final List<Map<String, dynamic>> segments = [
      {'val': 50, 'color': AppColors.aqiGreen},
      {'val': 100, 'color': AppColors.aqiLightGreen},
      {'val': 200, 'color': AppColors.aqiYellow},
      {'val': 300, 'color': AppColors.aqiOrange},
      {'val': 400, 'color': AppColors.aqiRed},
      {'val': 500, 'color': AppColors.aqiPurple},
    ];

    double currentStart = startAngle;
    int prevVal = 0;

    for (var seg in segments) {
      final int val = seg['val'];
      final Color color = seg['color'];

      final double segSweep = (val - prevVal) / 500.0 * sweepAngle;

      final Paint segPaint = Paint()
        ..color = color.withValues(alpha: 0.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.square;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        currentStart,
        segSweep,
        false,
        segPaint,
      );

      currentStart += segSweep;
      prevVal = val;
    }

    // Draw pointer
    final double percent = min(aqi / 500.0, 1.0);
    final double pointerAngle = startAngle + (percent * sweepAngle);

    final double pointerX = centerX + radius * cos(pointerAngle);
    final double pointerY = centerY + radius * sin(pointerAngle);

    // 1. Draw pointer needle (from center pivot to track)
    final double tipLength = radius - size.width * 0.06;
    final double baseWidth = size.width * 0.02; // half width of needle base
    final double tipWidth = size.width * 0.005; // half width of needle tip

    final double tipX = centerX + tipLength * cos(pointerAngle);
    final double tipY = centerY + tipLength * sin(pointerAngle);

    final double baseLeftX = centerX + baseWidth * cos(pointerAngle - pi / 2);
    final double baseLeftY = centerY + baseWidth * sin(pointerAngle - pi / 2);

    final double baseRightX = centerX + baseWidth * cos(pointerAngle + pi / 2);
    final double baseRightY = centerY + baseWidth * sin(pointerAngle + pi / 2);

    final double tipLeftX = tipX + tipWidth * cos(pointerAngle - pi / 2);
    final double tipLeftY = tipY + tipWidth * sin(pointerAngle - pi / 2);

    final double tipRightX = tipX + tipWidth * cos(pointerAngle + pi / 2);
    final double tipRightY = tipY + tipWidth * sin(pointerAngle + pi / 2);

    final Path needlePath = Path()
      ..moveTo(baseLeftX, baseLeftY)
      ..lineTo(tipLeftX, tipLeftY)
      ..lineTo(tipRightX, tipRightY)
      ..lineTo(baseRightX, baseRightY)
      ..close();

    final Paint needlePaint = Paint()
      ..color = textPrimaryColor
      ..style = PaintingStyle.fill;

    canvas.drawPath(needlePath, needlePaint);

    // 2. Draw pointer outer circle (dot on color arc)
    final Paint pointerPaint = Paint()
      ..color = textPrimaryColor
      ..style = PaintingStyle.fill;

    final double outerCircleRadius = size.width * 0.04;

    canvas.drawCircle(
        Offset(pointerX, pointerY), outerCircleRadius, pointerPaint);

    final Paint pointerBorder = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    canvas.drawCircle(
        Offset(pointerX, pointerY), outerCircleRadius, pointerBorder);

    // 3. Draw central pivot cap (hub)
    final Paint pivotPaint = Paint()
      ..color = textPrimaryColor
      ..style = PaintingStyle.fill;

    final double pivotRadius = size.width * 0.047;
    canvas.drawCircle(center, pivotRadius, pivotPaint);

    final Paint innerCap = Paint()
      ..color = Colors.white.withValues(alpha: 0.35)
      ..style = PaintingStyle.fill;

    final double innerCapRadius = size.width * 0.018;
    canvas.drawCircle(center, innerCapRadius, innerCap);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

//http://192.168.1.18:9090/aqi-consumer/api/v1/device/customer/allocated_devices/3cb14796-d065-42dd-8031-a2931c4cdb44?page=0&size=100&role=Sub_User
