import 'dart:math' as math;
import 'package:flutter/material.dart';

/// A premium visual effect overlay representing active water sprinklers.
/// Includes water mist/spray particles and vertical running droplets.
class SprinklerEffect extends StatefulWidget {
  final bool isRunning;
  const SprinklerEffect({super.key, required this.isRunning});

  @override
  State<SprinklerEffect> createState() => _SprinklerEffectState();
}

class _SprinklerEffectState extends State<SprinklerEffect>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final List<_WaterParticle> _particles = [];
  final List<_ScreenDroplet> _droplets = [];
  final math.Random _random = math.Random();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..addListener(_updateEffect);

    if (widget.isRunning) {
      _controller.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant SprinklerEffect oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isRunning != oldWidget.isRunning) {
      if (widget.isRunning) {
        _controller.repeat();
      } else {
        _controller.stop();
        _particles.clear();
        _droplets.clear();
        setState(() {});
      }
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_updateEffect);
    _controller.dispose();
    super.dispose();
  }

  void _updateEffect() {
    if (!mounted || !widget.isRunning) return;

    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;
    final double heightLimit = height > 0 ? height * 0.5 : 300.0;

    // setState(() {
    // 1. Update existing mist particles
    for (int i = _particles.length - 1; i >= 0; i--) {
      final p = _particles[i];
      p.update();
      if (p.opacity <= 0 || p.y > height) {
        _particles.removeAt(i);
      }
    }

    // 2. Spawn new mist particles from multiple side points (half of screen and above)
    if (_particles.length < 200) {
      // Spawn 2 particles from left side per tick to increase count
      for (int k = 0; k < 2; k++) {
        final double spawnY = _random.nextDouble() * heightLimit;
        _particles.add(_WaterParticle(
          x: 0,
          y: spawnY,
          vx: 5.0 +
              _random.nextDouble() *
                  8.0, // Increased speed from 3.0-8.0 to 5.0-13.0
          vy: -2.5 + _random.nextDouble() * 4.0,
          size: 16.0 + _random.nextDouble() * 24.0,
          opacity: 0.10 + _random.nextDouble() * 0.15,
          decay: 0.004 +
              _random.nextDouble() *
                  0.006, // Decay slightly faster for higher velocity
        ));
      }

      // Spawn 2 particles from right side per tick to increase count
      for (int k = 0; k < 2; k++) {
        final double spawnY = _random.nextDouble() * heightLimit;
        _particles.add(_WaterParticle(
          x: width,
          y: spawnY,
          vx: -(5.0 +
              _random.nextDouble() *
                  8.0), // Increased speed from 3.0-8.0 to 5.0-13.0
          vy: -2.5 + _random.nextDouble() * 4.0,
          size: 16.0 + _random.nextDouble() * 24.0,
          opacity: 0.10 + _random.nextDouble() * 0.15,
          decay: 0.004 + _random.nextDouble() * 0.006,
        ));
      }
    }

    // 3. Update existing screen droplets
    for (int i = _droplets.length - 1; i >= 0; i--) {
      final d = _droplets[i];
      d.update();
      if (d.y > height) {
        _droplets.removeAt(i);
      }
    }

    // 4. Spawn new screen droplets (larger size, longer tails, and higher count)
    if (_droplets.length < 80 && _random.nextDouble() < 0.45) {
      _droplets.add(_ScreenDroplet(
        x: _random.nextDouble() * width,
        y: _random.nextDouble() * heightLimit,
        speed: 4.5 +
            _random.nextDouble() *
                6.0, // Increased initial speed from 2.0-5.0 to 4.5-10.5
        size: 4.5 + _random.nextDouble() * 4.5,
        length: 22.0 + _random.nextDouble() * 28.0,
      ));
    }
    // });
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isRunning) return const SizedBox.shrink();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return IgnorePointer(
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Soft pulsing radial background vignette
          _buildVignetteGlow(isDark),

          // 2. Custom Painter for water mist and run down droplets
          CustomPaint(
            painter: _SprinklerPainter(
              particles: _particles,
              droplets: _droplets,
              animationValue: _controller.value,
              isDark: isDark,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVignetteGlow(bool isDark) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final pulse = 0.04 * math.sin(_controller.value * 2 * math.pi);
        return Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: const Color(0xFF0284C7)
                  .withValues(alpha: (isDark ? 0.12 : 0.06) + pulse * 0.5),
              width: 2.5,
            ),
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.4,
              colors: [
                const Color(0xFF0284C7).withValues(alpha: 0.0),
                const Color(0xFF0284C7).withValues(alpha: isDark ? 0.04 : 0.02),
                const Color(0xFF0284C7)
                    .withValues(alpha: (isDark ? 0.16 : 0.08) + pulse),
              ],
              stops: const [0.0, 0.6, 1.0],
            ),
          ),
        );
      },
    );
  }
}

class _WaterParticle {
  double x;
  double y;
  double vx;
  double vy;
  double size;
  double opacity;
  double decay;

  _WaterParticle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.size,
    required this.opacity,
    required this.decay,
  });

  void update() {
    x += vx;
    y += vy;
    vy += 0.16; // Increased gravity acceleration from 0.08 to 0.16
    vx *= 0.96; // Slightly more air friction for high velocity spray simulation
    opacity -= decay;
    if (opacity < 0) opacity = 0;
  }
}

class _ScreenDroplet {
  double x;
  double y;
  double speed;
  double size;
  double length;

  _ScreenDroplet({
    required this.x,
    required this.y,
    required this.speed,
    required this.size,
    required this.length,
  });

  void update() {
    y += speed;
    speed +=
        0.09; // Increased gravity acceleration down window pane from 0.03 to 0.09
  }
}

class _SprinklerPainter extends CustomPainter {
  final List<_WaterParticle> particles;
  final List<_ScreenDroplet> droplets;
  final double animationValue;
  final bool isDark;

  _SprinklerPainter({
    required this.particles,
    required this.droplets,
    required this.animationValue,
    required this.isDark,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    // Draw mist/spray particles with blur effect for soft, realistic vapor
    for (final p in particles) {
      final double blurRadius = p.size * 0.7;
      paint.maskFilter = MaskFilter.blur(
          BlurStyle.normal, blurRadius > 0.1 ? blurRadius : 1.0);

      // Outer soft mist: use a beautiful translucent sky blue visible on both dark and light backgrounds
      paint.color = const Color(0xFF38bdf8)
          .withValues(alpha: p.opacity * (isDark ? 0.38 : 0.16));
      canvas.drawCircle(Offset(p.x, p.y), p.size, paint);
    }

    // Reset maskFilter for droplets to maintain crisp refraction details
    paint.maskFilter = null;

    // Draw running screen droplets with glass refraction and specular highlight
    final linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (final d in droplets) {
      // Trail (wet track left behind): translucent sky blue line to be visible on white and black
      linePaint.color =
          const Color(0xFF0ea5e9).withValues(alpha: isDark ? 0.24 : 0.12);
      linePaint.strokeWidth = d.size * 0.55;
      canvas.drawLine(
        Offset(d.x, d.y - d.length * 0.6),
        Offset(d.x, d.y + d.length * 0.4),
        linePaint,
      );

      // 1. Droplet drop shadow: cast a soft dark shadow to make it pop on white backgrounds
      final double shadowOffset = d.size * 0.15;
      paint.color =
          const Color(0xFF0F172A).withValues(alpha: isDark ? 0.05 : 0.14);
      canvas.drawCircle(
          Offset(d.x + shadowOffset, d.y + d.length * 0.4 + shadowOffset),
          d.size,
          paint);

      // 2. Droplet body: translucent sky blue
      paint.color =
          const Color(0xFF38bdf8).withValues(alpha: isDark ? 0.32 : 0.16);
      canvas.drawCircle(Offset(d.x, d.y + d.length * 0.4), d.size, paint);

      // 3. Droplet reflection outline: semi-transparent blue/grey
      linePaint.color =
          const Color(0xFF0ea5e9).withValues(alpha: isDark ? 0.55 : 0.32);
      linePaint.strokeWidth = 0.7;
      canvas.drawCircle(Offset(d.x, d.y + d.length * 0.4), d.size, linePaint);

      // 4. Specular highlight (light reflection on the droplet's top-left): bright white
      paint.color = Colors.white.withValues(alpha: isDark ? 0.95 : 0.80);
      canvas.drawCircle(
        Offset(d.x - d.size * 0.35, d.y + d.length * 0.4 - d.size * 0.35),
        d.size * 0.22,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _SprinklerPainter oldDelegate) => true;
}
