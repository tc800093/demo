import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';

/// A Cubit that manages the application's ThemeMode.
///
/// Persists the selected theme mode to Hive (`settings` box, key `theme_mode`)
/// and restores it on startup.
class ThemeCubit extends Cubit<ThemeMode> {
  static const String _boxName = 'settings';
  static const String _key = 'theme_mode';

  ThemeCubit() : super(_loadInitial());

  /// Reads the stored theme mode from Hive synchronously.
  static ThemeMode _loadInitial() {
    try {
      final box = Hive.box(_boxName);
      final stored = box.get(_key, defaultValue: 'system') as String;
      return _fromString(stored);
    } catch (_) {
      return ThemeMode.system;
    }
  }

  /// Change the theme mode and persist it.
  void setThemeMode(ThemeMode mode) {
    emit(mode);
    _persist(mode);
  }

  /// Convenience setters.
  void setLight() => setThemeMode(ThemeMode.light);
  void setDark() => setThemeMode(ThemeMode.dark);
  void setSystem() => setThemeMode(ThemeMode.system);

  /// Persist to Hive.
  Future<void> _persist(ThemeMode mode) async {
    try {
      final box = Hive.box(_boxName);
      await box.put(_key, _toString(mode));
    } catch (_) {
      // Silent fail — non-critical
    }
  }

  static String _toString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  static ThemeMode _fromString(String value) {
    switch (value) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }
}
