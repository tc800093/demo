import 'package:vasundhara_maha_aqim/core/network/websocket_service.dart';
import 'package:vasundhara_maha_aqim/features/contractor/data/repositories/notification_repository_impl.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/analytics_repository.dart';
import 'package:vasundhara_maha_aqim/features/contractor/domain/repositories/notification_respository.dart';
import 'package:get_it/get_it.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

// Import Features Blocs
import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/contractor/presentation/bloc/sites_bloc.dart';
import '../../features/contractor/presentation/bloc/sprinkler_bloc.dart';
import '../../features/admin/presentation/bloc/admin_bloc.dart';
import '../../features/contractor/presentation/bloc/analytics_bloc/analytics_bloc.dart';
import '../../features/contractor/presentation/bloc/notification_history/notification_history_bloc.dart';

// Import Repositories
import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/auth/data/repositories/auth_repository_impl.dart';
import '../../features/contractor/domain/repositories/sites_repository.dart';
import '../../features/contractor/data/repositories/sites_repository_impl.dart';
import '../../features/contractor/data/repositories/analytics_repository_impl.dart';
import '../../features/admin/domain/repositories/admin_repository.dart';
import '../../features/admin/data/repositories/admin_repository_impl.dart';
import '../../features/customer/domain/repositories/customer_repository.dart';
import '../../features/customer/data/repositories/customer_repository_impl.dart';
import '../../features/customer/presentation/bloc/customer_bloc.dart';

// Import Core
import '../network/api_client.dart';
import '../network/api_config.dart';
import '../network/sse_service.dart';
import '../services/notifications/notification_service.dart';
import '../theme/theme_cubit.dart';

final GetIt getIt = GetIt.instance;

/// Sets up the dependency injection container.
Future<void> configureDependencies() async {
  // Core Services
  getIt.registerLazySingleton<Dio>(() => Dio());
  getIt.registerLazySingleton<Connectivity>(() => Connectivity());

  // API Client
  getIt.registerLazySingleton<ApiClient>(() => ApiClient(getIt<Dio>()));

  // SSE Service — independent, singleton lifecycle.
  // Registered separately so it can be reused or replaced without
  // touching the repository layer.
  getIt.registerLazySingleton<SseService>(() {
    final service = SseService(
      url: ApiConfig.aqiStreamAll,
      eventFilter: 'aqi-update',
      reconnectDelay: const Duration(seconds: 5),
    );
    // service.connect();
    return service;
  });

  getIt.registerLazySingleton<WebsocketService>(() {
    final service = WebsocketServiceImpl(dioClient: getIt());
    service.connectWebSocket();
    return service;
  });

  // Notification Service
  getIt.registerLazySingleton<NotificationService>(() => NotificationService());

  // Theme Management (singleton — survives navigation)
  getIt.registerLazySingleton<ThemeCubit>(() => ThemeCubit());

  // Repositories
  getIt.registerLazySingleton<AuthRepository>(
      () => AuthRepositoryImpl(getIt<ApiClient>()));
  getIt.registerLazySingleton<SitesRepository>(
    () => SitesRepositoryImpl(
        getIt<ApiClient>(), getIt<SseService>(), getIt<WebsocketService>()),
  );

  getIt.registerLazySingleton<NotificationRespository>(
    () => NotificationRepositoryImpl(
      getIt<ApiClient>(),
    ),
  );
  getIt.registerLazySingleton<AnalyticsRepository>(
    () => AnalyticsRepositoryImpl(
      getIt<ApiClient>(),
    ),
  );
  getIt.registerLazySingleton<AdminRepository>(
    () => AdminRepositoryImpl(getIt<ApiClient>()),
  );
  getIt.registerLazySingleton<CustomerRepository>(
    () => CustomerRepositoryImpl(getIt<ApiClient>()),
  );

  // Blocs / State Management
  // Registered as factory so we get fresh instances when navigating
  getIt.registerFactory<AuthBloc>(() => AuthBloc(getIt<AuthRepository>()));
  getIt
      .registerFactory<AnalyticsBloc>(() => AnalyticsBloc(repository: getIt()));
  getIt.registerFactory<SitesBloc>(() => SitesBloc(getIt<SitesRepository>()));
  getIt.registerFactory<SprinklerBloc>(() => SprinklerBloc());
  getIt.registerFactory<NotificationHistoryBloc>(() => NotificationHistoryBloc(
      notificationRespository: getIt<NotificationRespository>()));
  getIt.registerFactory<AdminBloc>(
      () => AdminBloc(getIt<SitesRepository>(), getIt<AdminRepository>()));
  getIt.registerFactory<CustomerBloc>(
      () => CustomerBloc(getIt<CustomerRepository>()));
}
