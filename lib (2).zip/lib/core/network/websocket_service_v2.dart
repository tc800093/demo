import 'dart:async';
import 'dart:developer';

import 'package:hive/hive.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class WebSocketServiceV2 {
  WebSocketServiceV2._();

  static final WebSocketServiceV2 instance = WebSocketServiceV2._();

  static const String _url = 'ws://192.168.1.5/aqi-consumer/ws';

  WebSocketChannel? _channel;
  StreamSubscription? _subscription;

  bool _connected = false;

  bool get isConnected => _connected;

  final StreamController<String> _controller =
      StreamController<String>.broadcast();

  Stream<String> get events => _controller.stream;

  Future<String?> _getAuthToken() async {
    try {
      String? token;

      if (Hive.isBoxOpen('settings')) {
        final box = Hive.box('settings');

        token = box.get('auth_token') as String?;
      } else {
        final box = await Hive.openBox('settings');

        token = box.get('auth_token') as String?;
      }

      return token;
    } catch (e) {
      log("Token read error : $e");

      return null;
    }
  }

  Future<void> connect() async {
    log("Connecting via web socket channel ");
    final token = await _getAuthToken();
    if (_connected) return;

    try {
      _channel = WebSocketChannel.connect(Uri.parse('$_url?token=$token'),
          protocols: {});

      _connected = true;

      log("✅ WebSocket Connected");

      _subscription = _channel!.stream.listen(
        (message) {
          log("WS => $message");

          _controller.add(message.toString());
        },
        onDone: () {
          _connected = false;
          _reconnect();
        },
        onError: (e) {
          log("WebSocket channel method issue "+e.toString());

          _connected = false;

          _reconnect();
        },
      );
    } catch (e) {
      log(e.toString());

      _reconnect();
    }
  }

  void send(String message) {
    _channel?.sink.add(message);
  }

  void disconnect() {
    _connected = false;

    _subscription?.cancel();

    _channel?.sink.close();
  }

  void _reconnect() {
    Future.delayed(const Duration(seconds: 5), () {
      connect();
    });
  }

  void dispose() {
    disconnect();

    _controller.close();
  }
}
