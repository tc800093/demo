// core/network/api_config.dart
/// Configuration for API base URLs and endpoints.
///
/// All backend URLs and endpoint paths are centralised here for easy
/// maintenance. Changing a base URL or path only requires editing this file.
class ApiConfig {
  ApiConfig._(); // Prevent instantiation.

  // ────────────────── Base URLs ────────────────────────────────

  /// Default backend base URL for auth and general servic
  // static const String defaultBaseUrl =
  //     'http://192.168.1.18:9090'; // local developme
  // static const String defaultBaseUrl = 'http://192.168.1.5';
  // static const String defaultBaseUrl = 'http://192.168.1.42:8083';
  static const String defaultBaseUrl = 'http://103.175.176.26';

  /// Base URL for the AQI telemetry consumer services.
  static const String aqiConsumerBaseUrl =
      '$defaultBaseUrl/aqi-consumer/api/v1';

  /// Base URL for authentication.
  static String get authBaseUrl {
    final baseUrl = defaultBaseUrl.endsWith('/')
        ? defaultBaseUrl.substring(0, defaultBaseUrl.length - 1)
        : defaultBaseUrl;
    return '$baseUrl/aqi-consumer/auth';
  }

  /// Endpoint for requesting login OTP.
  static String get authLogin => '$authBaseUrl/login';

  /// Endpoint for verifying OTP validation.
  static String get authValidate => '$authBaseUrl/validate';

  /// AQI live real time data using websocket
  static String getLiveDashboardAPIForWebSocket =
      '$defaultBaseUrl/aqi-consumer/ws';
  // 'ws://103.175.176.26/aqi-consumer/ws';
  // 'ws://192.168.1.18:9090/aqi-consumer/ws';

  static String subscriptionAQILive = '/user/aqi/data';

  //******************************************************************************* */

  /// Base URL for the secondary telemetry server (e.g. telemetry stream & history)
  static const String secondaryBaseUrl =
      'http://103.175.176.26/aqi-consumer/api/v1';

  // ─── SSE (Server-Sent Events) ─────────────────────────────────────────────

  /// SSE live stream endpoint — pushes `aqi-update` events for **all** devices.
  static const String aqiStreamAll = '$secondaryBaseUrl/aqi/stream/all';

  // ─── REST Endpoints ───────────────────────────────────────────────────────

  /// Fetch the latest telemetry snapshot for a specific device.
  ///
  /// Example: `http://103.175.176.26/aqi-consumer/api/v1/aqi/latest?deviceId=866738089033714`
  static String aqiLatest(String imeiNo) {
    return '$secondaryBaseUrl/aqi/latest?deviceId=$imeiNo';
  }

  /// Get list of all devices with pagination and optional search filter.
  static String getDeviceList(int page, int size, {String? search}) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    final queryParams = StringBuffer('page=$page&size=$size');
    if (search != null && search.trim().isNotEmpty) {
      queryParams.write('&search_param=${Uri.encodeComponent(search.trim())}');
    }
    return '$cleanBase/device/get_device_list?$queryParams';
  }

  /// Create a new device.
  static String get createDevice => createDeviceUrl();
  static String createDeviceUrl({bool isDeviceReactivate = false}) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/device/create?is_device_reactivate=$isDeviceReactivate';
  }

  /// Update an existing device.
  static String get updateDevice {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/device/update';
  }

  /// Fetch details for a specific device by ID.
  static String getDeviceDetail(String id) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/device/get_device_detail/$id';
  }

  /// Register the fcm token for firebase push notification
  static String registerFCMToke() {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/device_token/register';
  }

  /// Fetch allocated devices for a specific customer (paginated).
  static String getAllocatedDevices(
    String customerId, {
    int page = 0,
    int size = 10,
    String? search,
    String? role,
  }) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    final queryParams = StringBuffer('page=$page&size=$size');
    if (search != null && search.trim().isNotEmpty) {
      queryParams.write('&search_param=${Uri.encodeComponent(search.trim())}');
    }
    if (role != null) {
      queryParams.write('&role=$role');
    } else {
      queryParams.write('&role=null');
    }
    return '$cleanBase/device/customer/allocated_devices/$customerId?$queryParams';
  }

  /// Deallocate/remove a device from a customer.
  static String removeDevice(String deviceId) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/device/remove_device/$deviceId';
  }

  /// Fetch full history for a specific device (all records, paginated).
  ///
  /// Example: `.../aqi/history?deviceId=865510083200693&page=0&size=2000`
  static String aqiHistory(String imeiNo, {int page = 0, int size = 2000}) {
    return '$secondaryBaseUrl/aqi/history?deviceId=$imeiNo&page=$page&size=$size';
  }

  /// Fetch AQI Analytics by passing device id and date
  static String fetchintervialAnalyticsBydate(
    String deviceID,
    String date,
    String inteval,
  ) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/aqi_analysis/intervals/$deviceID?date=$date&interval=$inteval'; //23-07-2026
  }

  /// Fetch AQI Analytics by passing device id and date
  static String fetchAnalyticsDayWiseByFromDateAndToDate(
    String deviceID,
    String fromDate,
    String toDate,
  ) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/aqi_analysis/day_wise/$deviceID?from_date=$fromDate&to_date=$toDate'; //23-07-2026
  }

  /// Fetch telemetry records for a device within a date range.
  ///
  /// [from] and [to] should be ISO‑8601 timestamps, e.g. `2026-06-01T00:00:00`.
  ///
  /// Example: `.../aqi/history/range?deviceId=865510083200693&from=2026-06-01T00:00:00&to=2026-07-02T00:00:00&page=0&size=2000`
  static String aqiHistoryRange(
    String imeiNo,
    String from,
    String to, {
    int page = 0,
    int size = 2000,
  }) {
    return '$secondaryBaseUrl/aqi/history/range?deviceId=$imeiNo&from=$from&to=$to&page=$page&size=$size';
  }

  /// Fetch telemetry range for all devices.
  static String aqiRange(
    String from,
    String to, {
    int page = 0,
    int size = 100,
  }) {
    return '$secondaryBaseUrl/aqi/range?from=$from&to=$to&page=$page&size=$size';
  }

  /// Fetch Calibration info by device id
  static String getClilbaratoinInfoByDeviceID(
    String deviceID, {
    int page = 0,
    int size = 100,
  }) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/calibration/get_calibration_info/$deviceID?page=$page&size=$size';
  }

  /// Fetch Calibration sechudel by device id
  static String getClilbaratoinScheduleByDeviceID(
    String deviceID, {
    int page = 0,
    int size = 100,
  }) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/calibration/get_calibration_schedule/$deviceID?page=$page&size=$size';
  }

  ///  Save Calibaration info
  static String saveClilbaratoinInfo() {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/calibration/calibration_info/save';
  }

  /// Update calibration info
  static String updateClilbaratoinInfo() {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/calibration/calibration_info/update';
  }

  /// update calibration schedule
  static String updateClilbaratoinSchedule() {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/calibration/calibration_schedule/update';
  }

  // ─── Customer Endpoints ───────────────────────────────────────────

  /// Base URL for customer management endpoints.
  static String get customerBaseUrl {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/customer';
  }

  /// Endpoint to list customers (GET)
  static String get customerList => customerBaseUrl;

  /// Endpoint to save customer (POST)
  static String get customerSave => '$customerBaseUrl/save';

  /// Endpoint to update customer (PUT)
  static String get customerUpdate => '$customerBaseUrl/update';

  /// Endpoint to get customer roles (GET)
  static String get customerRoles => '$customerBaseUrl/roles';

  /// Endpoint to get customer details by id (GET)
  static String getCustomerDetails(String id) =>
      '$customerBaseUrl/get_customer_details?customer_id=$id';

  /// Endpoint to assign devices to sub users (POST)
  static String get assignDevicesToSubUser =>
      '$customerBaseUrl/assign_devices/sub_users';

  /// Endpoint to deallocate/deassign devices from sub users (PUT)
  static String get deallocateDeviceFromSubUser =>
      '$customerBaseUrl/deassign_devices/sub_users';

  /// Endpoint to delete/remove a customer (DELETE)
  /// Optionally pass is_device_removed=true to delete with all allocated devices
  static String deleteCustomer(
    String customerId, {
    bool removeDevices = false,
  }) {
    final baseUrl = '$customerBaseUrl/remove/$customerId';
    if (removeDevices) {
      return '$baseUrl?is_device_removed=true';
    }
    return baseUrl;
  }

  /// Fetch All Notificaiton history
  static String notificationAllHistory({
    String page = '0',
    String size = '100',
  }) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/notification/all_history?page=$page&size=$size'; //2026-07-01 00:00:00&end=2026-07-31 23:59:59
  }

  /// Fetch Notificaiton history with range passing start date and end date
  static String notificationHistoryWithRange({
    String page = '0',
    String size = '10',
    required String startDate,
    required String endDate,
  }) {
    final cleanBase = aqiConsumerBaseUrl
        .replaceAll('//', '/')
        .replaceFirst('http:/', 'http://');
    return '$cleanBase/notification/history?page=$page&size=$size&start=$startDate&end=$endDate'; //2026-07-01 00:00:00&end=2026-07-31 23:59:59
  }

  /// Generate a Google Maps directions URL for a destination.
  static String googleMapsDirections(String destination) {
    return 'https://www.google.com/maps/dir/?api=1&destination=$destination';
  }
}
