import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import 'package:hive/hive.dart';

/// Centralized API client using Dio.
/// Sets up headers, timeouts, logging, and token refresh interceptors.
class ApiClient {
  final Dio _dio;

  ApiClient(this._dio) {
    _dio.options.baseUrl = const String.fromEnvironment(
      'API_BASE_URL',
      defaultValue: 'https://api.mahaaqi.industrial-monitor.com/v1',
    );
    _dio.options.connectTimeout = const Duration(seconds: 15);
    _dio.options.receiveTimeout = const Duration(seconds: 15);

    // Inject interceptors
    _dio.interceptors.add(QueuedInterceptorsWrapper(
      onRequest: _onRequest,
      onResponse: _onResponse,
      onError: _onError,
    ));

    if (kDebugMode) {
      _dio.interceptors.add(LogInterceptor(
        requestHeader: true,
        requestBody: true,
        responseHeader: false,
        responseBody: true,
        error: true,
      ));
    }
  }

  Dio get dio => _dio;

  /// Injects authentication token into outgoing requests
  void _onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    String? token;
    try {
      if (Hive.isBoxOpen('settings')) {
        final box = Hive.box('settings');
        token = box.get('auth_token') as String?;
      } else {
        final box = await Hive.openBox('settings');
        token = box.get('auth_token') as String?;
      }
    } catch (e) {
      debugPrint('Error retrieving auth token from Hive: $e');
    }

    if (token != null && token.isNotEmpty) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    options.headers['Accept'] = 'application/json';
    options.headers['Content-Type'] = 'application/json';
    options.headers['X-API-KEY'] =
        'g4rG6DMrR68CvvIKWOWdkzhsHy5QEvCDhfKoivqrYxE=';

    return handler.next(options);
  }

  /// Handles responses globally
  void _onResponse(Response response, ResponseInterceptorHandler handler) {
    return handler.next(response);
  }

  /// Global error interceptor with retry mechanism and refresh token support
  void _onError(DioException err, ErrorInterceptorHandler handler) async {
    // Refresh token logic
    if (err.response?.statusCode == 401) {}

    // Map status code to friendly user-facing messages
    final message = _mapDioErrorToMessage(err);
    final errorWithMsg = DioException(
      requestOptions: err.requestOptions,
      response: err.response,
      type: err.type,
      error: message,
    );

    return handler.next(errorWithMsg);
  }

  /// Maps technical errors to user friendly messages
  String _mapDioErrorToMessage(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Connection timeout. Please check your internet connection and try again.';
      case DioExceptionType.badResponse:
        final status = error.response?.statusCode;
        final responseData = error.response?.data;

        if (responseData != null) {
          if (responseData is Map) {
            if (responseData.containsKey('errors') &&
                responseData['errors'] is Map) {
              final errorsMap = responseData['errors'] as Map;
              if (errorsMap.isNotEmpty) {
                final errorMessages =
                    errorsMap.values.map((v) => v.toString()).join('\n');
                if (errorMessages.isNotEmpty) {
                  return errorMessages;
                }
              }
            }
            if (responseData.containsKey('message') &&
                responseData['message'] != null) {
              return responseData['message'].toString();
            }
            if (responseData.containsKey('error') &&
                responseData['error'] != null) {
              return responseData['error'].toString();
            }
          } else if (responseData is String) {
            try {
              final decoded = jsonDecode(responseData);
              if (decoded is Map) {
                if (decoded.containsKey('errors') && decoded['errors'] is Map) {
                  final errorsMap = decoded['errors'] as Map;
                  if (errorsMap.isNotEmpty) {
                    final errorMessages =
                        errorsMap.values.map((v) => v.toString()).join('\n');
                    if (errorMessages.isNotEmpty) {
                      return errorMessages;
                    }
                  }
                }
                if (decoded.containsKey('message') &&
                    decoded['message'] != null) {
                  return decoded['message'].toString();
                }
                if (decoded.containsKey('error') && decoded['error'] != null) {
                  return decoded['error'].toString();
                }
              }
            } catch (_) {}

            // If it is just a plain text string error, return it
            if (responseData.trim().isNotEmpty && responseData.length < 100) {
              return responseData.trim();
            }
          }
        }

        if (status == 400) {
          return 'Invalid request. Please verify your input.';
        }
        if (status == 401) {
          
          return 'Session expired. Please log in again.';
        }
        if (status == 403) {

          return 'Access denied. You do not have permissions for this action.';
        }
        if (status == 404) {
          return 'Requested resource not found.';
        }
        if (status == 409) {
          return 'Conflict occurred. Please check duplicate fields.';
        }
        if (status == 500) {
          return 'Server error. Please try again later.';
        }
        return 'Received invalid response ($status) from server.';
      case DioExceptionType.cancel:
        return 'Request cancelled.';
      case DioExceptionType.connectionError:
        return 'No internet connection. Operating in offline mode.';
      default:
        return 'An unexpected network error occurred.';
    }
  }
}
