import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';

/// A standalone, reusable Server-Sent Events (SSE) client.
///
/// Manages a single long-lived HTTP connection to an SSE endpoint.
/// Automatically reconnects on failure with configurable delay.
/// Publishes parsed events through a broadcast [Stream].
///
/// Usage:
/// ```dart
/// final sse = SseService(url: 'http://example.com/events');
/// sse.events.listen((event) => print(event.data));
/// sse.connect();
/// // When done:
/// sse.dispose();
/// ```
///

class SseService {
  /// The SSE endpoint URL to connect to.
  final String url;

  /// Delay between automatic reconnection attempts.
  final Duration reconnectDelay;

  /// Optional event filter. Only events matching this name are emitted.
  /// If null, all events (including unnamed ones) are emitted.
  final String? eventFilter;

  final StreamController<SseEvent> _eventController =
      StreamController<SseEvent>.broadcast();

  HttpClient? _httpClient;
  bool _isConnecting = false;
  bool _isDisposed = false;
  bool _shouldBypassDelay = false;

  /// Connection state notifier for UI feedback.
  final ValueNotifier<SseConnectionState> connectionState =
      ValueNotifier<SseConnectionState>(SseConnectionState.disconnected);

  SseService({
    required this.url,
    this.reconnectDelay = const Duration(seconds: 11),
    this.eventFilter,
  });

  /// Stream of parsed SSE events.
  Stream<SseEvent> get events => _eventController.stream;

  /// Whether this service has been disposed.
  bool get isDisposed => _isDisposed;

  /// Start the SSE connection loop. Safe to call multiple times.
  void connect() {
    if (_isConnecting || _isDisposed) return;
    _isConnecting = true;
    _connectionLoop();
  }

  /// Disconnect and release all resources.
  void dispose() {
    _isDisposed = true;
    _httpClient?.close(force: true);
    _httpClient = null;
    _eventController.close();
    connectionState.value = SseConnectionState.disconnected;
    connectionState.dispose();
  }

  /// Closes the current connection and triggers an immediate reconnection attempt.
  void forceReconnect() {
    debugPrint('[SSE] Forcing immediate SSE reconnection');
    _shouldBypassDelay = true;
    _httpClient?.close(force: true);
    _httpClient = null;
  }

  /// Internal reconnection loop.
  Future<void> _connectionLoop() async {
    while (!_isDisposed) {
      try {
        connectionState.value = SseConnectionState.connecting;
        debugPrint('[SSE] Connecting to $url');

        _httpClient = HttpClient();
        final request = await _httpClient!.getUrl(Uri.parse(url));
        request.headers.add('Accept', 'text/event-stream');
        request.headers.add('Cache-Control', 'no-cache');

        // Add Bearer token & API key to secure SSE connections
        try {
          String? token;
          if (Hive.isBoxOpen('settings')) {
            final box = Hive.box('settings');
            token = box.get('auth_token') as String?;
          } else {
            final box = await Hive.openBox('settings');
            token = box.get('auth_token') as String?;
          }
          if (token != null && token.isNotEmpty) {
            request.headers.add('Authorization', 'Bearer $token');
          }
        } catch (e) {
          debugPrint('[SSE] Error retrieving authorization token: $e');
        }
        request.headers
            .add('X-API-KEY', 'g4rG6DMrR68CvvIKWOWdkzhsHy5QEvCDhfKoivqrYxE=');

        final response = await request.close();
        if (response.statusCode != 200) {
          throw HttpException(
            'SSE stream returned status ${response.statusCode}',
          );
        }

        connectionState.value = SseConnectionState.connected;
        debugPrint('[SSE] Connected successfully');
        debugPrint('[SSE] Response Headers:');
        response.headers.forEach((name, values) {
          debugPrint('  $name: $values');
        });

        String currentEvent = '';
        final lineStream =
            response.transform(utf8.decoder).transform(const LineSplitter());

        await for (final line in lineStream) {
          if (_isDisposed) break;

          final trimmed = line.trim();

          // SSE comment/heartbeat lines start with ':'
          if (trimmed.startsWith(':')) continue;

          if (trimmed.startsWith('event:')) {
            currentEvent = trimmed.substring(6).trim();
          } else if (trimmed.startsWith('data:')) {
            final dataStr = trimmed.substring(5).trim();
            if (dataStr.isEmpty) continue;

            // Apply event filter if configured.
            final shouldEmit = eventFilter == null ||
                currentEvent == eventFilter ||
                currentEvent.isEmpty;

            if (shouldEmit) {
              try {
                final json = jsonDecode(dataStr);
                _eventController.add(SseEvent(
                  event: currentEvent,
                  data: json,
                  rawData: dataStr,
                ));
              } catch (e) {
                debugPrint('[SSE] JSON parse error: $e');
              }
            }
          } else if (trimmed.isEmpty) {
            // Blank line resets current event (per SSE spec).
            currentEvent = '';
          }
        }
      } catch (e) {
        if (!_isDisposed) {
          debugPrint('[SSE] Connection error: $e');
          connectionState.value = SseConnectionState.error;
        }
      } finally {
        _httpClient?.close();
        _httpClient = null;
      }

      if (_isDisposed) break;

      // Wait before reconnecting unless bypassed.
      if (_shouldBypassDelay) {
        _shouldBypassDelay = false;
        debugPrint('[SSE] Bypassing reconnection delay.');
      } else {
        connectionState.value = SseConnectionState.reconnecting;
        debugPrint(
            '[SSE] Reconnecting in ${reconnectDelay.inSeconds} seconds...');
        await Future.delayed(reconnectDelay);
      }
    }
  }
}

/// Represents a single parsed SSE event.
class SseEvent {
  /// The event name (from the `event:` field). Empty string if unnamed.
  final String event;

  /// Parsed JSON data payload.
  final dynamic data;

  /// The raw data string before JSON parsing.
  final String rawData;

  const SseEvent({
    required this.event,
    required this.data,
    required this.rawData,
  });

  @override
  String toString() => 'SseEvent(event: $event, data: $data)';
}

/// Connection state for the SSE service.
enum SseConnectionState {
  disconnected,
  connecting,
  connected,
  reconnecting,
  error,
}
