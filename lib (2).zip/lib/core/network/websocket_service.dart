import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:stomp_dart_client/stomp_dart_client.dart';
import 'package:vasundhara_maha_aqim/core/network/api_client.dart';
import 'package:vasundhara_maha_aqim/core/network/api_config.dart';

abstract class WebsocketService {
  Future<void> connectWebSocket();

  Stream<WebSocketEvent> get dataStream;

  Future<void> disconnectWebSocket();
}

class WebsocketServiceImpl implements WebsocketService {
  StompClient? _stompClient;

  final StreamController<WebSocketEvent> _controller =
      StreamController<WebSocketEvent>.broadcast();

  final ApiClient dioClient;

  bool _isConnecting = false;

  WebsocketServiceImpl({
    required this.dioClient,
  });

  @override
  Stream<WebSocketEvent> get dataStream => _controller.stream;

  @override
  Future<void> connectWebSocket() async {
    // Already connected
    if (_stompClient?.connected == true) {
      debugPrint("Websocket already connected");
      return;
    }

    // Prevent multiple activate calls
    if (_isConnecting) {
      debugPrint("Websocket connection already in progress");
      return;
    }

    _isConnecting = true;

    final token = await _getAuthToken();

    if (token == null || token.isEmpty) {
      _isConnecting = false;

      debugPrint("Websocket connection cancelled. Token missing");

      return;
    }

    _stompClient = StompClient(
      config: StompConfig.sockJS(
          url: ApiConfig.getLiveDashboardAPIForWebSocket,
          // url: url,
          // url: 'http://103.175.176.26/ws',
          // url: 'http://192.168.1.42:8083/ws',
          // url: 'http://192.168.1.18/aqi-consumer/ws',
          onDebugMessage: (msg) {
            // log("debuggin for websocket $msg}");
          },
          stompConnectHeaders: {
            "Authorization": "Bearer $token",
            "X-API-KEY": "g4rG6DMrR68CvvIKWOWdkzhsHy5QEvCDhfKoivqrYxE=",
          },
          webSocketConnectHeaders: {
            "Authorization": "Bearer $token",
            "X-API-KEY": "g4rG6DMrR68CvvIKWOWdkzhsHy5QEvCDhfKoivqrYxE=",
          },

          // Disable internal reconnect
          // because token/session can change
          reconnectDelay: Duration.zero,
          heartbeatIncoming: const Duration(seconds: 10),
          heartbeatOutgoing: const Duration(seconds: 10),
          onConnect: (frame) {
            _isConnecting = false;
            debugPrint("STOMP CONNECTED");
            _subscribe();
          },
          onDisconnect: (frame) {
            _isConnecting = false;

            debugPrint("STOMP DISCONNECTED");
          },
          onWebSocketError: (error) {
            _isConnecting = false;

            debugPrint("WEBSOCKET ERROR : $error");
          },
          onStompError: (frame) {
            _isConnecting = false;

            debugPrint("STOMP ERROR : ${frame.body}");
          },
          onUnhandledMessage: (p0) {
            debugPrint("unhandle message $p0");
          },
          onWebSocketDone: () {
            debugPrint("on connectoin done");
          }),
    );

    _stompClient!.activate();
  }

  void _subscribe() {
    final client = _stompClient;

    if (client == null || !client.connected) {
      debugPrint("Cannot subscribe. STOMP not connected");

      return;
    }

    client.subscribe(
      destination: ApiConfig.subscriptionAQILive,
      callback: (message) {
        if (message.body == null) {
          return;
        }

        try {
          final data = jsonDecode(message.body!);

          if (data is Map<String, dynamic>) {
            debugPrint("ADDING STREAM DATA MAP");
            // final jsonResponse = jsonDecode(data.toString());
            _controller
                .add(WebSocketEvent(data: data, rawData: data.toString()));
          } else if (data is List) {
            debugPrint("ADDING STREAM DATA LIST ${data.length}");

            for (final item in data) {
              if (item is Map<String, dynamic>) {
                // final itemJsonResponse = jsonDecode(item.toString());
                _controller
                    .add(WebSocketEvent(data: item, rawData: item.toString()));
              }
            }
          } else {
            debugPrint("if else connnection ");
          }
        } catch (e) {
          debugPrint("Websocket JSON parse error : $e");
        }
      },
    );
  }

  @override
  Future<void> disconnectWebSocket() async {
    final client = _stompClient;

    if (client == null) {
      log("No websocket client found");

      return;
    }

    try {
      if (client.connected) {
        client.deactivate();

        log("STOMP disconnected successfully");
      }
    } catch (e) {
      log("STOMP disconnect error : $e");
    } finally {
      _stompClient = null;

      _isConnecting = false;
    }
  }

  Future<String?> _getAuthToken() async {
    try {
      String? token;

      if (Hive.isBoxOpen('settings')) {
        final box = Hive.box('settings');

        token = box.get('auth_token') as String?;
      } else {
        final box = await Hive.openBox('settings');

        token = box.get('auth_token') as String?;
      }

      return token;
    } catch (e) {
      log("Token read error : $e");

      return null;
    }
  }

  // Call only when application is destroyed.
  // Do not call on logout.
  Future<void> dispose() async {
    await disconnectWebSocket();

    await _controller.close();
  }
}

class WebSocketEvent {
  /// Parsed JSON data payload.
  final Map<String, dynamic> data;

  /// The raw data string before JSON parsing.
  final String rawData;

  const WebSocketEvent({
    required this.data,
    required this.rawData,
  });

  @override
  String toString() => 'WebSocketEvent(data: $data)';
}
