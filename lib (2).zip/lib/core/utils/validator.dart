class Validator {
  ///IMEI number validation
  static String? validateImei(String? value, {String? msg}) {
    if (value == null || value.isEmpty) {
      return msg ?? 'Enter IMEI number';
    }

    if (!RegExp(r'^\d{15}$').hasMatch(value)) {
      return 'IMEI must contain exactly 15 digits';
    }

    return null;
  }

  /// Email Validation
  /// Check  email is valid
  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Email is required';
    }

    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

    if (!emailRegex.hasMatch(value.trim())) {
      return 'Enter valid email';
    }

    return null;
  }

  /// Phone Validation
  /// Check if phone field is empty
  /// check if entered phone number is 10 digit or not
  static String? phone(String? value, String? msg) {
    if (value == null || value.trim().isEmpty) {
      return msg ?? 'Phone number is required';
    }

    final phoneRegex = RegExp(r'^[0-9]{10}$');

    if (!phoneRegex.hasMatch(value.trim())) {
      return 'Enter valid 10 digit number';
    }

    return null;
  }

  // static String? simNumber(String? value, String? msg) {
  //   if (value == null || value.trim().isEmpty) {
  //     return msg ?? 'Phone number is required';
  //   }

  //   final phoneRegex = RegExp(r'^[0-9]{16}$');

  //   if (!phoneRegex.hasMatch(value.trim())) {
  //     return 'Enter valid 10 to 16 digit number';
  //   }

  //   return null;
  // }

  static String? simNumber(String? value, String? msg) {
    if (value == null || value.trim().isEmpty) {
      return msg ?? 'SIM number is required';
    }

    final simNumber = value.trim();

    if (simNumber.length < 11) {
      return 'SIM number must be at least 11 digits';
    }

    if (simNumber.length > 16) {
      return 'SIM number must not exceed 16 digits';
    }

    return null;
  }

  /// Firmware Validator
  static String? validateFirmwareVersion(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Firmware version is required";
    }

    final firmwareRegex = RegExp(r'^v\d+\.\d+\.\d+$');

    if (!firmwareRegex.hasMatch(value.trim())) {
      return "Invalid firmware version format.e.g v1.0.0";
    }

    return null;
  }
}
