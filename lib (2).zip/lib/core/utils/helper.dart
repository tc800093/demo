import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vasundhara_maha_aqim/config/theme/colors.dart' show AppColors;

String getTimeAgo(String dateTime) {
  try {
    final DateTime notificationTime = DateTime.parse(dateTime);
    final DateTime now = DateTime.now();

    final Duration difference = now.difference(notificationTime);

    if (difference.inSeconds < 60) {
      return "${difference.inSeconds} sec ago";
    }

    if (difference.inMinutes < 60) {
      return "${difference.inMinutes} min ago";
    }

    if (difference.inHours < 24) {
      return "${difference.inHours} hour ago";
    }

    final today = DateTime(now.year, now.month, now.day);
    final notificationDate = DateTime(
      notificationTime.year,
      notificationTime.month,
      notificationTime.day,
    );

    final dayDifference = today.difference(notificationDate).inDays;

    if (dayDifference == 0) {
      return "Today";
    }

    if (dayDifference == 1) {
      return "Yesterday";
    }

    return "$dayDifference days ago";
  } catch (e) {
    return "";
  }
}

Widget sprinklerDetailItem({
  required IconData icon,
  required String title,
  required String value,
}) {
  return Column(
    children: [
      Icon(
        icon,
        size: 18.r,
        color: AppColors.primary,
      ),
      SizedBox(height: 4.h),
      Text(
        title,
        style: TextStyle(
          fontSize: 11.sp,
          color: Colors.grey,
        ),
      ),
      SizedBox(height: 2.h),
      Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 12.sp,
          fontWeight: FontWeight.bold,
        ),
      )
    ],
  );
}
