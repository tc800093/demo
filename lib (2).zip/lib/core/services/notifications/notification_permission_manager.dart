import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart' as ph;

enum PermissionState {
  granted,
  denied,
  permanentlyDenied
}

class NotificationPermissionManager {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  /// Checks the current notification permission state.
  Future<PermissionState> getPermissionStatus() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      final status = await ph.Permission.notification.status;
      if (status.isGranted) {
        return PermissionState.granted;
      } else if (status.isPermanentlyDenied) {
        return PermissionState.permanentlyDenied;
      } else {
        return PermissionState.denied;
      }
    } else {
      final settings = await _messaging.getNotificationSettings();
      if (settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional) {
        return PermissionState.granted;
      } else if (settings.authorizationStatus == AuthorizationStatus.denied) {
        return PermissionState.permanentlyDenied;
      } else {
        return PermissionState.denied;
      }
    }
  }

  /// Requests notification permission from the user.
  /// On Android 13+ this triggers the runtime permission.
  Future<PermissionState> requestPermissions() async {
    NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    if (defaultTargetPlatform == TargetPlatform.android) {
      ph.PermissionStatus status = await ph.Permission.notification.request();
      if (status.isGranted) {
        return PermissionState.granted;
      } else if (status.isPermanentlyDenied) {
        debugPrint("Notification permission permanently denied on Android.");
        return PermissionState.permanentlyDenied;
      } else {
        return PermissionState.denied;
      }
    } else {
      if (settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional) {
        return PermissionState.granted;
      } else {
        return PermissionState.permanentlyDenied;
      }
    }
  }

  /// Opens the app settings page for the user to manually enable permissions.
  Future<bool> redirectToAppSettings() async {
    debugPrint("Opening App Settings...");
    return await ph.openAppSettings();
  }
}
