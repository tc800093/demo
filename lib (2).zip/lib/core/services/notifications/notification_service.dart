import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'notification_payload_parser.dart';
import 'notification_permission_manager.dart';
import 'token_manager.dart';
import 'local_notification_service.dart';
import 'firebase_messaging_service.dart';
import 'notification_handler.dart';
import 'notification_navigation_handler.dart';

class NotificationService {
  final NotificationPermissionManager permissionManager = NotificationPermissionManager();
  final TokenManager tokenManager = TokenManager();
  late final NotificationNavigationHandler navigationHandler;
  late final NotificationHandler notificationHandler;
  late final LocalNotificationService localNotificationService;
  late final FirebaseMessagingService firebaseMessagingService;

  bool _isInitialized = false;

  NotificationService() {
    navigationHandler = NotificationNavigationHandler();
    notificationHandler = NotificationHandler(navigationHandler);
    localNotificationService = LocalNotificationService(
      onNotificationTapped: (payload) => notificationHandler.handleNotificationTap(payload),
    );
    firebaseMessagingService = FirebaseMessagingService(
      onMessageReceived: _handleForegroundMessage,
      onNotificationOpenedApp: (message) {
        final payload = NotificationPayloadParser.parseRemoteMessage(message);
        notificationHandler.handleNotificationTap(payload);
      },
    );
  }

  /// Initializes all notification services (FCM, Local Notifications, Token, Permissions).
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      debugPrint("Initializing NotificationService...");

      // 1. Initialize Local Notifications
      await localNotificationService.initialize();

      // 2. Initialize Firebase Messaging streams
      await firebaseMessagingService.initialize();

      // 3. Initialize Token Manager
      await tokenManager.initialize();

      // 4. Check/Request Permissions
      await permissionManager.requestPermissions();

      // 5. Handle terminated launch notification
      final initialMessage = await firebaseMessagingService.getInitialMessage();
      if (initialMessage != null) {
        final payload = NotificationPayloadParser.parseRemoteMessage(initialMessage);
        await notificationHandler.handleNotificationTap(payload, isAppLaunch: true);
      }

      // 6. Process stashed payloads after router initialization settles
      Timer(const Duration(seconds: 2), () {
        notificationHandler.processStashedPayload();
      });

      _isInitialized = true;
      debugPrint("NotificationService initialization completed.");
    } catch (e) {
      debugPrint("Error initializing NotificationService: $e");
    }
  }

  /// Subscribes to a notification topic.
  Future<void> subscribeToTopic(String topic) async {
    await firebaseMessagingService.subscribeToTopic(topic);
  }

  /// Unsubscribes from a notification topic.
  Future<void> unsubscribeFromTopic(String topic) async {
    await firebaseMessagingService.unsubscribeFromTopic(topic);
  }

  /// Handles FCM messages received while the app is in the foreground.
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    try {
      final payload = NotificationPayloadParser.parseRemoteMessage(message);
      debugPrint("Handling foreground notification: ${payload.title}");

      if (message.notification != null) {
        await localNotificationService.showNotification(
          id: message.hashCode,
          title: message.notification!.title ?? 'New Alert',
          body: message.notification!.body ?? '',
          payload: payload,
        );
      } else {
        debugPrint("Silent data notification received in foreground. Data: ${message.data}");
      }
    } catch (e) {
      debugPrint("Error handling foreground message: $e");
    }
  }

  /// Cleans up resources.
  void dispose() {
    tokenManager.dispose();
  }
}
