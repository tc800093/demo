import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';
import 'notification_payload_parser.dart';

class LocalNotificationService {
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  // Callback when a notification is clicked/tapped
  final void Function(NotificationPayload payload)? onNotificationTapped;

  LocalNotificationService({this.onNotificationTapped});

  /// Initializes the local notification plugin.
  Future<void> initialize() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/launcher_icon');

    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings(
          requestAlertPermission: false,
          requestBadgePermission: false,
          requestSoundPermission: false,
        );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
    );

    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'aqi_alerts_channel',
      'High Importance AQI Alerts',
      description:
          'This channel is used for high priority AQI monitoring alerts.',
      importance: Importance.high,
      playSound: true,
      enableVibration: true,
      showBadge: true,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.createNotificationChannel(channel);

    debugPrint("LocalNotificationService initialized successfully.");
  }

  /// Triggers when the user taps a local notification.
  void _onDidReceiveNotificationResponse(NotificationResponse response) {
    if (response.payload != null && onNotificationTapped != null) {
      try {
        final Map<String, dynamic> data = json.decode(response.payload!);
        final payload = NotificationPayloadParser.parseMap(data);
        onNotificationTapped!(payload);
      } catch (e) {
        debugPrint("Error parsing local notification tap payload: $e");
      }
    }
  }

  /// Displays a local notification when the app is in the foreground.
  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    required NotificationPayload payload,
  }) async {
    try {
      final String payloadStr = json.encode(payload.toMap());

      const AndroidNotificationDetails androidDetails =
          AndroidNotificationDetails(
            'aqi_alerts_channel',
            'High Importance AQI Alerts',
            channelDescription:
                'This channel is used for high priority AQI monitoring alerts.',
            importance: Importance.max,
            priority: Priority.high,
            ticker: 'ticker',
            playSound: true,
            enableVibration: true,
          );

      const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      const NotificationDetails details = NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      );

      await _localNotifications.show(
        id,
        title,
        body,
        details,
        payload: payloadStr,
      );
      debugPrint(
        "Local notification showed successfully: ID=$id, Title='$title'",
      );
    } catch (e) {
      debugPrint("Error displaying local notification: $e");
    }
  }
}
