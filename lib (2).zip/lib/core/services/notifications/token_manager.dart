import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

class TokenManager {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final _tokenController = StreamController<String>.broadcast();
  StreamSubscription<String>? _tokenRefreshSubscription;

  /// Stream of token updates
  Stream<String> get onTokenChanged => _tokenController.stream;

  /// Initializes the token manager and starts listening to token refreshes.
  Future<void> initialize() async {
    // Listen to token refresh events
    _tokenRefreshSubscription = _messaging.onTokenRefresh.listen((String newToken) async {
      debugPrint("FCM Token refreshed: $newToken");
      await saveToken(newToken);
      _tokenController.add(newToken);
    });

    // Fetch the token initially
    await getAndSaveToken();
  }

  /// Fetches the current FCM token, saves it locally, and prints it to the console.
  Future<String?> getAndSaveToken() async {
    try {
      String? token = await _messaging.getToken();
      if (token != null) {
        debugPrint("FCM Registration Token: $token");
        await saveToken(token);
        _tokenController.add(token);
      }
      return token;
    } catch (e) {
      debugPrint("Error fetching FCM token: $e");
      return null;
    }
  }

  /// Saves the FCM token locally in Hive database.
  Future<void> saveToken(String token) async {
    try {
      final box = Hive.box('settings');
      await box.put('fcm_token', token);
      debugPrint("FCM token saved locally in Hive settings box.");
    } catch (e) {
      debugPrint("Error saving FCM token locally: $e");
    }
  }

  /// Retrieves the locally stored FCM token.
  String? getSavedToken() {
    try {
      final box = Hive.box('settings');
      return box.get('fcm_token') as String?;
    } catch (e) {
      debugPrint("Error reading FCM token from Hive: $e");
      return null;
    }
  }

  /// Deletes the FCM token from the device and local storage (used during logout).
  Future<void> deleteToken() async {
    try {
      await _messaging.deleteToken();
      debugPrint("FCM token deleted from Firebase Messaging SDK.");

      final box = Hive.box('settings');
      await box.delete('fcm_token');
      debugPrint("FCM token deleted from local storage.");
    } catch (e) {
      debugPrint("Error deleting FCM token: $e");
    }
  }

  /// Disposes resources.
  void dispose() {
    _tokenRefreshSubscription?.cancel();
    _tokenController.close();
  }
}
