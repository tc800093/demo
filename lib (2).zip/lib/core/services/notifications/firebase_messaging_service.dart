import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';

/// Top-level background message handler for Firebase Messaging.
/// Must be a top-level function annotated with @pragma('vm:entry-point')
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint("Background message handler triggered: ${message.messageId}");
  debugPrint("Data: ${message.data}");
  if (message.notification != null) {
    debugPrint("Notification Title: ${message.notification?.title}");
    debugPrint("Notification Body: ${message.notification?.body}");
  }
}

class FirebaseMessagingService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  
  // Callback when a new message is received in the foreground
  final void Function(RemoteMessage message)? onMessageReceived;

  // Callback when a notification is clicked while the app is in the background
  final void Function(RemoteMessage message)? onNotificationOpenedApp;

  FirebaseMessagingService({
    this.onMessageReceived,
    this.onNotificationOpenedApp,
  });

  /// Initializes the messaging service stream listeners.
  Future<void> initialize() async {
    // 1. Listen to foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint("FCM Foreground message received: ${message.messageId}");
      if (onMessageReceived != null) {
        onMessageReceived!(message);
      }
    });

    // 2. Listen to notification click events when the app is in background (but not terminated)
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint("FCM Background notification click received: ${message.messageId}");
      if (onNotificationOpenedApp != null) {
        onNotificationOpenedApp!(message);
      }
    });

    // 3. Register background message handler
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    debugPrint("FirebaseMessagingService initialized successfully.");
  }

  /// Check if the app was launched from a terminated state via a notification click.
  Future<RemoteMessage?> getInitialMessage() async {
    try {
      RemoteMessage? initialMessage = await _messaging.getInitialMessage();
      if (initialMessage != null) {
        debugPrint("FCM Terminated notification click detected: ${initialMessage.messageId}");
      }
      return initialMessage;
    } catch (e) {
      debugPrint("Error checking initial message: $e");
      return null;
    }
  }

  /// Subscribes the device to a messaging topic.
  Future<void> subscribeToTopic(String topic) async {
    try {
      await _messaging.subscribeToTopic(topic);
      debugPrint("Successfully subscribed to topic: $topic");
    } catch (e) {
      debugPrint("Error subscribing to topic $topic: $e");
    }
  }

  /// Unsubscribes the device from a messaging topic.
  Future<void> unsubscribeFromTopic(String topic) async {
    try {
      await _messaging.unsubscribeFromTopic(topic);
      debugPrint("Successfully unsubscribed from topic: $topic");
    } catch (e) {
      debugPrint("Error unsubscribing from topic $topic: $e");
    }
  }
}
