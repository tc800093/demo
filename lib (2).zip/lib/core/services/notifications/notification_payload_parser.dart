import 'package:firebase_messaging/firebase_messaging.dart';

enum NotificationType {
  alert,
  aqi,
  siteDetails,
  calibration,
  reports,
  unknown
}

class NotificationPayload {
  final String? title;
  final String? body;
  final NotificationType type;
  final String? targetId; // e.g. siteId
  final String? deepLink;
  final Map<String, dynamic> rawData;

  NotificationPayload({
    this.title,
    this.body,
    required this.type,
    this.targetId,
    this.deepLink,
    required this.rawData,
  });

  factory NotificationPayload.fromMap(Map<String, dynamic> data, {String? title, String? body}) {
    final typeStr = data['type'] as String?;
    final targetId = data['targetId'] as String? ?? data['siteId'] as String?;
    final deepLink = data['deepLink'] as String? ?? data['click_action'] as String?;

    NotificationType type = NotificationType.unknown;
    if (typeStr != null) {
      switch (typeStr.toLowerCase()) {
        case 'alert':
          type = NotificationType.alert;
          break;
        case 'aqi':
          type = NotificationType.aqi;
          break;
        case 'site_details':
        case 'sitedetails':
        case 'site':
          type = NotificationType.siteDetails;
          break;
        case 'calibration':
          type = NotificationType.calibration;
          break;
        case 'reports':
        case 'report':
          type = NotificationType.reports;
          break;
      }
    } else if (deepLink != null) {
      if (deepLink.contains('/alerts')) {
        type = NotificationType.alert;
      } else if (deepLink.contains('/sites/')) {
        type = NotificationType.siteDetails;
      } else if (deepLink.contains('/reports')) {
        type = NotificationType.reports;
      }
    }

    return NotificationPayload(
      title: title ?? data['title'] as String?,
      body: body ?? data['body'] as String?,
      type: type,
      targetId: targetId,
      deepLink: deepLink,
      rawData: data,
    );
  }

  factory NotificationPayload.fromRemoteMessage(RemoteMessage message) {
    return NotificationPayload.fromMap(
      message.data,
      title: message.notification?.title,
      body: message.notification?.body,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'body': body,
      'type': type.name,
      'targetId': targetId,
      'deepLink': deepLink,
      ...rawData,
    };
  }
}

class NotificationPayloadParser {
  static NotificationPayload parseRemoteMessage(RemoteMessage message) {
    return NotificationPayload.fromRemoteMessage(message);
  }

  static NotificationPayload parseMap(Map<String, dynamic> data, {String? title, String? body}) {
    return NotificationPayload.fromMap(data, title: title, body: body);
  }
}
