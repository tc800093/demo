import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'notification_payload_parser.dart';
import 'notification_navigation_handler.dart';

class NotificationHandler {
  final NotificationNavigationHandler _navigationHandler;
  
  NotificationHandler(this._navigationHandler);

  /// Stashes a notification payload to Hive for later handling (when offline or launching).
  Future<void> stashOfflinePayload(NotificationPayload payload) async {
    try {
      final box = Hive.box('settings');
      await box.put('pending_notification_payload', payload.toMap());
      debugPrint("Offline notification payload stashed successfully.");
    } catch (e) {
      debugPrint("Error stashing offline notification payload: $e");
    }
  }

  /// Checks if there is a stashed notification payload, processes it, and clears it.
  Future<void> processStashedPayload() async {
    try {
      final box = Hive.box('settings');
      final dynamic rawPayload = box.get('pending_notification_payload');
      if (rawPayload != null) {
        debugPrint("Stashed offline notification payload found. Processing...");
        final Map<String, dynamic> data = Map<String, dynamic>.from(rawPayload as Map);
        final payload = NotificationPayloadParser.parseMap(data);
        
        // Remove it first to prevent double execution
        await box.delete('pending_notification_payload');

        // Trigger navigation
        await _navigationHandler.handleNavigation(payload);
      }
    } catch (e) {
      debugPrint("Error processing stashed offline notification payload: $e");
    }
  }

  /// Handles incoming notification tap events.
  Future<void> handleNotificationTap(NotificationPayload payload, {bool isAppLaunch = false}) async {
    debugPrint("Notification tapped. IsAppLaunch: $isAppLaunch");
    if (isAppLaunch) {
      await stashOfflinePayload(payload);
    } else {
      await _navigationHandler.handleNavigation(payload);
    }
  }
}
