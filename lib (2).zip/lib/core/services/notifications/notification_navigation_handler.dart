// core/services/notifications/notification_navigation_handler.dart
import 'package:flutter/foundation.dart';
import '../../../app/router/router.dart';
import '../../di/injection.dart';
import '../../../features/auth/domain/repositories/auth_repository.dart';
import 'notification_payload_parser.dart';

class NotificationNavigationHandler {
  final AuthRepository _authRepository = getIt<AuthRepository>();

  /// Handles navigation based on the parsed notification payload.
  Future<void> handleNavigation(NotificationPayload payload) async {
    try {
      debugPrint("Handling notification navigation for type: ${payload.type}");

      final user = await _authRepository.checkAuthStatus();
      if (user == null) {
        debugPrint("User is not authenticated. Redirecting to login.");
        appRouter.go(AppRoutes.login);
        return;
      }

      if (payload.deepLink != null && payload.deepLink!.isNotEmpty) {
        final path = payload.deepLink!;
        debugPrint("Navigating via deepLink: $path");
        appRouter.push(path);
        return;
      }

      final isAdmin = user.role == UserRole.admin;

      switch (payload.type) {
        case NotificationType.alert:
          final route =
              isAdmin ? AppRoutes.adminAlerts : AppRoutes.contractorAlerts;
          debugPrint("Navigating to alerts: $route");
          appRouter.push(route);
          break;

        case NotificationType.siteDetails:
          final route =
              isAdmin ? AppRoutes.adminDevices : AppRoutes.contractorDashboard;
          debugPrint("Navigating to device view: $route");
          appRouter.go(route);
          break;

        case NotificationType.aqi:
          final route = isAdmin
              ? AppRoutes.adminDashboard
              : AppRoutes.contractorDashboard;
          debugPrint("Navigating to dashboard: $route");
          appRouter.go(route);
          break;

        case NotificationType.calibration:
          final route = isAdmin
              ? AppRoutes.adminDashboard
              : AppRoutes.contractorDashboard;
          debugPrint("Navigating to calibration (dashboard fallback): $route");
          appRouter.go(route);
          break;

        case NotificationType.reports:
          final route =
              isAdmin ? AppRoutes.adminDashboard : AppRoutes.contractorReports;
          debugPrint("Navigating to reports: $route");
          appRouter.push(route);
          break;

        case NotificationType.unknown:
          debugPrint("Unknown notification type. No navigation action taken.");
          break;
      }
    } catch (e) {
      debugPrint("Error handling notification navigation: $e");
    }
  }
}
