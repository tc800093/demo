import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:geocoding/geocoding.dart';

class AddressSuggestion {
  final String displayName;
  final double latitude;
  final double longitude;
  final String city;
  final String district;
  final String state;

  const AddressSuggestion({
    required this.displayName,
    required this.latitude,
    required this.longitude,
    required this.city,
    required this.district,
    required this.state,
  });

  factory AddressSuggestion.fromJson(Map<String, dynamic> json) {
    final addr = json['address'] as Map<String, dynamic>? ?? {};
    final city = addr['city'] ??
        addr['town'] ??
        addr['village'] ??
        addr['municipality'] ??
        addr['suburb'] ??
        '';
    final district = addr['district'] ?? addr['county'] ?? '';
    final state = addr['state'] ?? '';

    return AddressSuggestion(
      displayName: json['display_name']?.toString() ?? '',
      latitude: double.tryParse(json['lat']?.toString() ?? '0') ?? 0.0,
      longitude: double.tryParse(json['lon']?.toString() ?? '0') ?? 0.0,
      city: city.toString(),
      district: district.toString(),
      state: state.toString(),
    );
  }
}

class GeocodingService {
  static final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 5),
      receiveTimeout: const Duration(seconds: 5),
      headers: {
        'User-Agent': 'vasundhara_aqim_admin_app',
      },
    ),
  );

  static Future<List<AddressSuggestion>> searchAddress(String query) async {
    if (query.trim().isEmpty) return const [];
    try {
      final response = await _dio.get(
        'https://nominatim.openstreetmap.org/search',
        queryParameters: {
          'format': 'json',
          'q': query,
          'addressdetails': 1,
          'limit': 5,
        },
      );
      if (response.statusCode == 200 && response.data != null) {
        final list = response.data as List<dynamic>;
        return list
            .map((item) =>
                AddressSuggestion.fromJson(item as Map<String, dynamic>))
            .toList();
      }
    } catch (e) {
      debugPrint('Geocoding search error: $e');
    }
    return const [];
  }

  static Future<AddressSuggestion?> getCoordinatesFromAddress(
      String address) async {
    try {
      final locations = await locationFromAddress(address);

      if (locations.isEmpty) {
        throw Exception('Location not found');
      }

      final placeName = await placemarkFromCoordinates(
          locations.first.latitude, locations.first.longitude);
      if (placeName.isEmpty) {
        throw Exception("Address details not found");
      }
      final place = placeName.first;

      return AddressSuggestion(
          displayName: place.name.toString(),
          latitude: locations.first.latitude,
          longitude: locations.first.longitude,
          city: place.locality ?? '',
          district: place.subAdministrativeArea ?? '',
          state: place.administrativeArea ?? '');
    } catch (e) {
      throw Exception('Failed to get coordinates: $e');
    }
  }
}
