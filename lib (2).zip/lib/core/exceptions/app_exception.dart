import 'package:dio/dio.dart';

class AppException implements Exception {
  final String message;
  final dynamic originalError;

  AppException(this.message, [this.originalError]);

  factory AppException.from(dynamic error, [String? prefix]) {
    if (error is AppException) {
      if (prefix != null && !error.message.startsWith(prefix)) {
        return AppException('$prefix: ${error.message}', error.originalError);
      }
      return error;
    }
    
    String message = 'An unexpected error occurred.';
    if (error is DioException) {
      // Extract the friendly message mapped in the interceptor (ApiClient)
      final errObj = error.error;
      if (errObj != null && errObj.toString().isNotEmpty) {
        message = errObj.toString();
      } else {
        final responseData = error.response?.data;
        if (responseData is Map && responseData['errors'] is Map) {
          final errorsMap = responseData['errors'] as Map;
          if (errorsMap.isNotEmpty) {
            message = errorsMap.values.map((v) => v.toString()).join('\n');
          } else {
            message = responseData['message']?.toString() ?? 'Validation failed';
          }
        } else if (responseData is Map && responseData['message'] != null) {
          message = responseData['message'].toString();
        } else if (responseData is Map && responseData['error'] != null) {
          message = responseData['error'].toString();
        } else {
          message = error.message ?? 'An unexpected network error occurred.';
        }
      }
    } else if (error is Exception) {
      final str = error.toString();
      message = str.startsWith('Exception: ') ? str.substring(11) : str;
    } else if (error != null) {
      message = error.toString();
    }
    
    if (prefix != null) {
      message = '$prefix: $message';
    }
    return AppException(message, error);
  }

  @override
  String toString() => message;
}

class DeviceDuplicateException implements Exception {
  final String message;
  final bool isCurrentlyActive;
  final dynamic existingDevice;

  DeviceDuplicateException({
    required this.message,
    required this.isCurrentlyActive,
    required this.existingDevice,
  });

  @override
  String toString() => message;
}
