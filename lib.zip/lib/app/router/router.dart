// app/router/router.dart
import 'package:vasundhara_maha_aqim/features/contractor/presentation/pages/sprinkler_usage_page.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/di/injection.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';

// Import Pages
import '../../features/auth/presentation/pages/splash_page.dart';
import '../../features/auth/presentation/pages/onboarding_page.dart';
import '../../features/auth/presentation/pages/role_selection_page.dart';
import '../../features/auth/presentation/pages/login_page.dart';

// Contractor Pages
import '../../features/contractor/presentation/pages/contractor_shell.dart';
import '../../features/contractor/presentation/pages/contractor_dashboard.dart';
import '../../features/contractor/presentation/pages/alerts_page.dart';
import '../../features/contractor/presentation/pages/reports_page.dart';
import '../../features/contractor/presentation/pages/profile_page.dart';
import '../../features/contractor/presentation/pages/sites_list_page.dart';
import '../../features/contractor/presentation/pages/sites_map_page.dart';
import '../../features/contractor/presentation/pages/site_details_page.dart';
import '../../features/contractor/presentation/pages/assign_devices_page.dart';

// Admin Pages
import '../../features/admin/presentation/pages/admin_shell.dart';
import '../../features/admin/presentation/pages/admin_dashboard.dart';
import '../../features/admin/presentation/pages/contractor_details_page.dart';
import '../../features/admin/presentation/pages/compliance_page.dart';
import '../../features/admin/presentation/pages/devices_list_page.dart';
import '../../features/admin/presentation/pages/admin_sites_map_page.dart';
import '../../features/admin/presentation/pages/add_site_wizard.dart';
import '../../features/customer/presentation/pages/customer_list_page.dart';
import '../../features/customer/presentation/pages/create_customer_page.dart';
import '../../features/customer/presentation/pages/customer_details_page.dart';
import '../../features/customer/presentation/bloc/customer_bloc.dart';
import '../../features/customer/domain/entities/customer_entity.dart';

/// Define navigation paths
class AppRoutes {
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String roleSelection = '/role-selection';
  static const String login = '/login';

  // Contractor
  static const String contractorDashboard = '/contractor/dashboard';
  static const String contractorSites = '/contractor/sites';
  static const String contractorMap = '/contractor/map';
  static const String contractorSprinklerPage = '/contractor/sprinklerPage';
  static const String contractorSiteDetails = '/contractor/sites/:id';
  static const String contractorAddSite = '/contractor/sites/add';
  static const String contractorAlerts = '/contractor/alerts';
  static const String contractorReports = '/contractor/reports';
  static const String contractorProfile = '/contractor/profile';
  static const String contractorSubCustomers = '/contractor/sub-customers';
  static const String contractorCreateSubCustomer =
      '/contractor/sub-customers/create';
  static const String contractorCustomerDetails =
      '/contractor/sub-customers/details';
  static const String contractorAssignDevices =
      '/contractor/sub-customers/assign-devices';

  // Admin
  static const String adminDashboard = '/admin/dashboard';
  static const String adminContractors = '/admin/contractors';
  static const String adminCreateCustomer = '/admin/contractors/create';
  static const String adminCustomerDetails = '/admin/contractors/details';
  static const String adminContractorDetails = '/admin/contractors/:id';
  static const String adminSitesMap = '/admin/sites';
  static const String adminSiteDetails = '/admin/sites/:id';
  static const String adminAddSite = '/admin/sites/add';
  static const String adminCompliance = '/admin/compliance';
  static const String adminProfile = '/admin/profile';
  static const String adminAlerts = '/admin/alerts';
  static const String adminDevices = '/admin/devices';
}

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> _shellNavigatorKey =
    GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> _adminShellNavigatorKey =
    GlobalKey<NavigatorState>();

/// Router configuration for routing and guarding
final GoRouter appRouter = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: AppRoutes.splash,
  redirect: (BuildContext context, GoRouterState state) async {
    // Return immediately on splash page to avoid black screens during initial auth check
    if (state.matchedLocation == AppRoutes.splash) {
      return null;
    }

    final authRepository = getIt<AuthRepository>();
    final user = await authRepository.checkAuthStatus();

    final isLoggingIn = state.matchedLocation == AppRoutes.login ||
        state.matchedLocation == AppRoutes.onboarding ||
        state.matchedLocation == AppRoutes.roleSelection ||
        state.matchedLocation == AppRoutes.splash;

    if (user == null) {
      // Not logged in: allow onboarding / login routes, redirect others to login
      if (!isLoggingIn) {
        return AppRoutes.login;
      }
      return null;
    }

    // User is logged in:
    if (isLoggingIn && state.matchedLocation != AppRoutes.splash) {
      // Redirect from login pages to home based on role
      return (user.role == UserRole.admin || user.role == UserRole.subAdmin)
          ? AppRoutes.adminDashboard
          : AppRoutes.contractorDashboard;
    }

    // Role Guard redirects
    if (state.matchedLocation.startsWith('/admin') &&
        user.role != UserRole.admin &&
        user.role != UserRole.subAdmin) {
      return AppRoutes.contractorDashboard;
    }
    if (state.matchedLocation.startsWith('/contractor') &&
        user.role != UserRole.user &&
        user.role != UserRole.subUser) {
      return AppRoutes.adminDashboard;
    }

    return null;
  },
  routes: [
    // Auth Routes
    GoRoute(
      path: AppRoutes.splash,
      builder: (context, state) => const SplashPage(),
    ),
    GoRoute(
      path: AppRoutes.onboarding,
      builder: (context, state) => const OnboardingPage(),
    ),
    GoRoute(
      path: AppRoutes.roleSelection,
      builder: (context, state) => const RoleSelectionPage(),
    ),
    GoRoute(
      path: AppRoutes.login,
      builder: (context, state) => const LoginPage(),
    ),

    // Contractor Nested Routes (Bottom Navigation Shell)
    ShellRoute(
      navigatorKey: _shellNavigatorKey,
      builder: (context, state, child) {
        return ContractorShell(child: child);
      },
      routes: [
        GoRoute(
          path: AppRoutes.contractorDashboard,
          builder: (context, state) => const ContractorDashboard(),
        ),
        GoRoute(
          path: AppRoutes.contractorSites,
          builder: (context, state) => const SitesListPage(),
        ),
        GoRoute(
          path: AppRoutes.contractorSprinklerPage,
          builder: (context, state) => const SprinklerUsagePage(),
        ),
        GoRoute(
          path: AppRoutes.contractorMap,
          builder: (context, state) {
            final siteId = state.uri.queryParameters['siteId'];
            return SitesMapPage(selectedSiteId: siteId);
          },
        ),
        GoRoute(
          path: AppRoutes.contractorReports,
          builder: (context, state) => const ReportsPage(),
        ),
        GoRoute(
          path: AppRoutes.contractorProfile,
          builder: (context, state) => const ProfilePage(),
        ),
        GoRoute(
          path: AppRoutes.contractorSubCustomers,
          builder: (context, state) => BlocProvider<CustomerBloc>(
            create: (context) =>
                getIt<CustomerBloc>()..add(const LoadCustomers()),
            child: const CustomerListPage(),
          ),
        ),
      ],
    ),

    // Site-related routes now redirect to existing contractor screens
    GoRoute(
      path: AppRoutes.contractorAddSite,
      parentNavigatorKey: _rootNavigatorKey,
      redirect: (context, state) => AppRoutes.contractorDashboard,
    ),

    // Alerts Page (outside shell so back button shows and redirects cleanly back to dashboard)
    GoRoute(
      path: AppRoutes.contractorAlerts,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const AlertsPage(),
    ),

    GoRoute(
      path: AppRoutes.contractorSiteDetails,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final siteId = state.pathParameters['id'] ?? '';
        return SiteDetailsPage(siteId: siteId);
      },
    ),

    // Admin Nested Routes (Bottom Navigation Shell)
    ShellRoute(
      navigatorKey: _adminShellNavigatorKey,
      builder: (context, state, child) {
        return AdminShell(child: child);
      },
      routes: [
        GoRoute(
          path: AppRoutes.adminDashboard,
          builder: (context, state) => const AdminDashboard(),
        ),
        GoRoute(
          path: AppRoutes.adminContractors,
          builder: (context, state) => BlocProvider<CustomerBloc>(
            create: (context) =>
                getIt<CustomerBloc>()..add(const LoadCustomers()),
            child: const CustomerListPage(),
          ),
        ),
        GoRoute(
          path: AppRoutes.adminSitesMap,
          builder: (context, state) => const AdminSitesMapPage(),
        ),
        GoRoute(
          path: AppRoutes.adminCompliance,
          builder: (context, state) => const CompliancePage(),
        ),
        GoRoute(
          path: AppRoutes.adminProfile,
          builder: (context, state) =>
              const ProfilePage(), // Uses shared ProfilePage
        ),
        GoRoute(
          path: AppRoutes.adminDevices,
          builder: (context, state) {
            final filter = state.uri.queryParameters['filter'];
            final search = state.uri.queryParameters['search'];
            return DevicesListPage(
                initialFilter: filter, initialSearch: search);
          },
        ),
      ],
    ),

    // Admin Detail pages (outside shell)
    GoRoute(
      path: AppRoutes.adminCreateCustomer,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final customer = state.extra as CustomerEntity?;
        return BlocProvider<CustomerBloc>(
          create: (context) => getIt<CustomerBloc>(),
          child: CreateCustomerPage(customerToEdit: customer),
        );
      },
    ),
    GoRoute(
      path: AppRoutes.contractorCreateSubCustomer,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final customer = state.extra as CustomerEntity?;
        return BlocProvider<CustomerBloc>(
          create: (context) => getIt<CustomerBloc>(),
          child: CreateCustomerPage(customerToEdit: customer),
        );
      },
    ),
    GoRoute(
      path: AppRoutes.adminCustomerDetails,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final customer = state.extra as CustomerEntity;
        return BlocProvider<CustomerBloc>(
          create: (context) => getIt<CustomerBloc>(),
          child: CustomerDetailsPage(customer: customer),
        );
      },
    ),
    GoRoute(
      path: AppRoutes.contractorCustomerDetails,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final customer = state.extra as CustomerEntity;
        return BlocProvider<CustomerBloc>(
          create: (context) => getIt<CustomerBloc>(),
          child: CustomerDetailsPage(customer: customer),
        );
      },
    ),
    GoRoute(
      path: AppRoutes.contractorAssignDevices,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final subcontractor = state.extra as CustomerEntity;
        return AssignDevicesPage(subcontractor: subcontractor);
      },
    ),
    GoRoute(
      path: AppRoutes.adminAddSite,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const AddSiteWizard(),
    ),
    GoRoute(
      path: AppRoutes.adminContractorDetails,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final contractorId = state.pathParameters['id'] ?? '';
        return ContractorDetailsPage(contractorId: contractorId);
      },
    ),
    GoRoute(
      path: AppRoutes.adminSiteDetails,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) {
        final siteId = state.pathParameters['id'] ?? '';
        return SiteDetailsPage(siteId: siteId);
      },
    ),
    GoRoute(
      path: AppRoutes.adminAlerts,
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const AlertsPage(),
    ),
  ],
);
